import { pgTable, text, serial, timestamp, numeric, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const giftCardsTable = pgTable("gift_cards", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  amountUsd: numeric("amount_usd", { precision: 10, scale: 4 }).notNull(),
  purchasedBy: integer("purchased_by").notNull(),
  redeemedBy: integer("redeemed_by"),
  redeemedAt: timestamp("redeemed_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  status: text("status").notNull().default("active"), // active | redeemed | expired
  messageAr: text("message_ar"),
  recipientNote: text("recipient_note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  codeIdx: index("gc_code_idx").on(t.code),
  buyerIdx: index("gc_buyer_idx").on(t.purchasedBy),
}));

export const insertGiftCardSchema = createInsertSchema(giftCardsTable).omit({ id: true, createdAt: true, redeemedBy: true, redeemedAt: true });
export type InsertGiftCard = z.infer<typeof insertGiftCardSchema>;
export type GiftCard = typeof giftCardsTable.$inferSelect;
