import { pgTable, text, serial, timestamp, numeric, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ordersTable = pgTable("orders", {
  id: text("id").primaryKey(),
  orderNumber: serial("order_number").notNull(),
  userId: integer("user_id").notNull(),
  productId: text("product_id").notNull(),
  productName: text("product_name").notNull(),
  qty: integer("qty").notNull().default(1),
  playerId: text("player_id"),
  fieldValues: jsonb("field_values").$type<Record<string, string>>().default({}),
  totalPrice: numeric("total_price", { precision: 18, scale: 6 }).notNull().default("0"),
  originalPrice: numeric("original_price", { precision: 18, scale: 6 }),
  paidAmount: numeric("paid_amount", { precision: 18, scale: 6 }),
  paidCurrency: text("paid_currency"),
  promoCodeId: integer("promo_code_id"),
  promoDiscount: numeric("promo_discount", { precision: 10, scale: 4 }),
  currency: text("currency").notNull().default("USD"),
  status: text("status").notNull().default("pending"),
  providerOrderId: text("provider_order_id"),
  giftToEmail: text("gift_to_email"),
  deliveredCode: text("delivered_code"),
  retryCount: integer("retry_count").notNull().default(0),
  nextRetryAt: timestamp("next_retry_at", { withTimezone: true }),
  lastDispatchError: text("last_dispatch_error"),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  bundleId: integer("bundle_id"),
  bundlePurchaseId: text("bundle_purchase_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({ createdAt: true, updatedAt: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
