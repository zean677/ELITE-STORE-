import { pgTable, text, serial, timestamp, numeric, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("user"),
  publicCode: text("public_code").unique(),
  balance: numeric("balance", { precision: 18, scale: 6 }).notNull().default("0"),
  vipLevel: integer("vip_level").notNull().default(0),
  vipLocked: boolean("vip_locked").notNull().default(false),
  totalSpentUsd: numeric("total_spent_usd", { precision: 18, scale: 6 }).notNull().default("0"),
  isSuspended: boolean("is_suspended").notNull().default(false),
  totpSecret: text("totp_secret"),
  totpEnabled: boolean("totp_enabled").notNull().default(false),
  loyaltyPoints: integer("loyalty_points").notNull().default(0),
  lowBalanceThreshold: numeric("low_balance_threshold", { precision: 10, scale: 2 }).default("5"),
  signupIp: text("signup_ip"),
  notes: text("notes"),
  permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
