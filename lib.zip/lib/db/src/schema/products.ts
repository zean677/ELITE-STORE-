import { pgTable, text, serial, timestamp, numeric, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const productsTable = pgTable("products", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar"),
  description: text("description"),
  image: text("image"),
  imageOverride: text("image_override"),
  priceUsd: numeric("price_usd", { precision: 18, scale: 6 }).notNull().default("0"),
  unitPriceUsd: numeric("unit_price_usd", { precision: 18, scale: 8 }).default("0"),
  category: text("category").notNull().default("general"),
  provider: text("provider").notNull().default("manual"),
  providerProductId: text("provider_product_id").notNull().default("manual"),
  requiredFields: text("required_fields").array().notNull().default([]),
  customFields: jsonb("custom_fields").$type<Array<{
    key: string;
    type: 'text' | 'number' | 'email' | 'phone' | 'notes' | 'dropdown';
    labelAr: string;
    labelEn?: string;
    placeholder?: string;
    required: boolean;
    options?: string[];
  }>>().default([]),
  status: text("status").notNull().default("active"),
  profitMargin: numeric("profit_margin", { precision: 5, scale: 2 }).notNull().default("10"),
  productType: text("product_type").default("package"),
  qtyMin: numeric("qty_min", { precision: 18, scale: 2 }),
  qtyMax: numeric("qty_max", { precision: 18, scale: 2 }),
  sortOrder: integer("sort_order").notNull().default(0),
  isManual: boolean("is_manual").notNull().default(false),
  subGroup: text("sub_group"),
  stockQty: integer("stock_qty"),
  lowStockThreshold: integer("low_stock_threshold").default(5),
  isFeatured: boolean("is_featured").notNull().default(false),
  autoApprove: boolean("auto_approve").notNull().default(false),
  salePriceUsd: numeric("sale_price_usd", { precision: 18, scale: 6 }),
  saleEndsAt: timestamp("sale_ends_at", { withTimezone: true }),
  // ── Sync-safety: list of field names the admin manually edited.
  //    These fields will NOT be overwritten by the auto-sync.
  manualOverrides: text("manual_overrides").array().notNull().default([]),
  // ── Original provider category info kept for transparency/mapping.
  providerCategoryId: text("provider_category_id"),
  providerCategoryName: text("provider_category_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertProductSchema = createInsertSchema(productsTable).omit({ createdAt: true, updatedAt: true });
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;
