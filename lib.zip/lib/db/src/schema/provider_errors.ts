import { pgTable, text, serial, timestamp, integer, index } from "drizzle-orm/pg-core";

export const providerErrorsTable = pgTable("provider_errors", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull(),
  operation: text("operation").notNull(),
  status: integer("status"),
  message: text("message").notNull(),
  context: text("context"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  providerIdx: index("provider_errors_provider_idx").on(t.provider),
  createdIdx: index("provider_errors_created_idx").on(t.createdAt),
}));

export type ProviderError = typeof providerErrorsTable.$inferSelect;
