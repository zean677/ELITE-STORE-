import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const loginAttemptsTable = pgTable("login_attempts", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  ip: text("ip").notNull(),
  userAgent: text("user_agent"),
  success: boolean("success").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const knownDevicesTable = pgTable("known_devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  ip: text("ip").notNull(),
  userAgent: text("user_agent"),
  firstSeen: timestamp("first_seen", { withTimezone: true }).notNull().defaultNow(),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
});

export type LoginAttempt = typeof loginAttemptsTable.$inferSelect;
export type KnownDevice = typeof knownDevicesTable.$inferSelect;
