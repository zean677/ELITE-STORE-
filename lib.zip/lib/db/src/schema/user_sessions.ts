import { pgTable, text, timestamp, integer, boolean, index } from "drizzle-orm/pg-core";

export const userSessionsTable = pgTable("user_sessions", {
  id: text("id").primaryKey(), // jti (uuid)
  userId: integer("user_id").notNull(),
  ip: text("ip"),
  userAgent: text("user_agent"),
  location: text("location"),
  revoked: boolean("revoked").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
}, (t) => ({
  userIdx: index("user_sessions_user_idx").on(t.userId),
}));

export type UserSession = typeof userSessionsTable.$inferSelect;
