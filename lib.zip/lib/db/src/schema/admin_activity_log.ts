import { pgTable, serial, text, integer, timestamp, jsonb } from "drizzle-orm/pg-core";

export const adminActivityLogTable = pgTable("admin_activity_log", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").notNull(),
  adminUsername: text("admin_username").notNull(),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id"),
  details: jsonb("details"),
  ip: text("ip"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AdminActivityLog = typeof adminActivityLogTable.$inferSelect;
