import { pgTable, serial, integer, text, numeric, boolean, timestamp } from "drizzle-orm/pg-core";

export const priceAlertsTable = pgTable("price_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  productId: text("product_id").notNull(),
  productName: text("product_name").notNull(),
  targetPriceUsd: numeric("target_price_usd", { precision: 18, scale: 6 }).notNull(),
  priceWhenCreated: numeric("price_when_created", { precision: 18, scale: 6 }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  lastNotifiedAt: timestamp("last_notified_at", { withTimezone: true }),
  triggeredAt: timestamp("triggered_at", { withTimezone: true }),
  triggeredPriceUsd: numeric("triggered_price_usd", { precision: 18, scale: 6 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type PriceAlert = typeof priceAlertsTable.$inferSelect;
