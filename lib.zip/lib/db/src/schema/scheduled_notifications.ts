import { pgTable, serial, text, timestamp, integer, index } from "drizzle-orm/pg-core";

export const scheduledNotificationsTable = pgTable("scheduled_notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("announcement"),
  targetUserId: integer("target_user_id"), // null = broadcast to all users
  sendAt: timestamp("send_at", { withTimezone: true }).notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled | processing | sent | failed | cancelled
  sentAt: timestamp("sent_at", { withTimezone: true }),
  processingAt: timestamp("processing_at", { withTimezone: true }),
  errorMessage: text("error_message"),
  cancelled: text("cancelled").notNull().default("no"), // no | yes
  createdById: integer("created_by_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pendingIdx: index("sn_pending_idx").on(t.sendAt, t.sentAt),
}));

export type ScheduledNotification = typeof scheduledNotificationsTable.$inferSelect;
