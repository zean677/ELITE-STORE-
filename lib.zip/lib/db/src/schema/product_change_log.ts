import { pgTable, serial, text, timestamp, integer, index } from "drizzle-orm/pg-core";

export const productChangeLogTable = pgTable("product_change_log", {
  id: serial("id").primaryKey(),
  productId: text("product_id").notNull(),
  productName: text("product_name").notNull().default(""),
  adminId: integer("admin_id").notNull(),
  adminUsername: text("admin_username").notNull().default(""),
  field: text("field").notNull(),
  oldValue: text("old_value"),
  newValue: text("new_value"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  productIdx: index("pcl_product_idx").on(t.productId, t.createdAt),
}));

export type ProductChangeLog = typeof productChangeLogTable.$inferSelect;
