import { pgTable, text, serial, timestamp, numeric, integer, index } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { createInsertSchema } from "drizzle-zod";

export const groupBuysTable = pgTable("group_buys", {
  id: serial("id").primaryKey(),
  productId: text("product_id").notNull(),
  productName: text("product_name").notNull(),
  productImageUrl: text("product_image_url"),
  targetQty: integer("target_qty").notNull(),
  currentQty: integer("current_qty").notNull().default(0),
  discountPct: numeric("discount_pct", { precision: 5, scale: 2 }).notNull(),
  originalPriceUsd: numeric("original_price_usd", { precision: 10, scale: 4 }).notNull(),
  groupPriceUsd: numeric("group_price_usd", { precision: 10, scale: 4 }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  status: text("status").notNull().default("open"), // open | completed | expired | cancelled
  promoCode: text("promo_code"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  statusIdx: index("gb_status_idx").on(t.status, t.endsAt),
}));

export const groupBuyParticipantsTable = pgTable("group_buy_participants", {
  id: serial("id").primaryKey(),
  groupBuyId: integer("group_buy_id").notNull(),
  userId: integer("user_id").notNull(),
  username: text("username").notNull().default(""),
  joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  uniqueJoin: index("gb_participant_unique_idx").on(t.groupBuyId, t.userId),
}));

export const insertGroupBuySchema = createInsertSchema(groupBuysTable).omit({ id: true, createdAt: true, currentQty: true });
export type InsertGroupBuy = z.infer<typeof insertGroupBuySchema>;
export type GroupBuy = typeof groupBuysTable.$inferSelect;
export type GroupBuyParticipant = typeof groupBuyParticipantsTable.$inferSelect;
