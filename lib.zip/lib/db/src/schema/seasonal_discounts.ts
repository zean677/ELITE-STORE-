import { pgTable, text, serial, timestamp, numeric, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const seasonalDiscountsTable = pgTable("seasonal_discounts", {
  id: serial("id").primaryKey(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  emoji: text("emoji").default("🎉"),
  bannerColor: text("banner_color").default("#f59e0b"),
  discountPercent: numeric("discount_percent", { precision: 5, scale: 2 }).notNull().default("10"),
  category: text("category"),
  productId: text("product_id"),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  autoBanner: boolean("auto_banner").notNull().default(true),
  appliedCount: integer("applied_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSeasonalDiscountSchema = createInsertSchema(seasonalDiscountsTable).omit({ id: true, createdAt: true, appliedCount: true });
export type InsertSeasonalDiscount = z.infer<typeof insertSeasonalDiscountSchema>;
export type SeasonalDiscount = typeof seasonalDiscountsTable.$inferSelect;
