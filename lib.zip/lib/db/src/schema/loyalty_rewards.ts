import { pgTable, text, serial, timestamp, integer, boolean, numeric } from "drizzle-orm/pg-core";

export const loyaltyRewardsTable = pgTable("loyalty_rewards", {
  id: serial("id").primaryKey(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull().default(""),
  pointsCost: integer("points_cost").notNull(),
  type: text("type").notNull(),
  value: numeric("value", { precision: 18, scale: 6 }),
  emoji: text("emoji").notNull().default("🎁"),
  imageUrl: text("image_url"),
  accentColor: text("accent_color").notNull().default("#fbbf24"),
  stock: integer("stock"),
  redeemedCount: integer("redeemed_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const loyaltyRewardRedemptionsTable = pgTable("loyalty_reward_redemptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  rewardId: integer("reward_id").notNull(),
  rewardName: text("reward_name").notNull(),
  pointsCost: integer("points_cost").notNull(),
  rewardType: text("reward_type").notNull(),
  rewardValue: numeric("reward_value", { precision: 18, scale: 6 }),
  status: text("status").notNull().default("delivered"),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type LoyaltyReward = typeof loyaltyRewardsTable.$inferSelect;
export type LoyaltyRewardRedemption = typeof loyaltyRewardRedemptionsTable.$inferSelect;
