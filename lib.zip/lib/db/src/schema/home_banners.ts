import { pgTable, serial, text, boolean, integer, timestamp } from "drizzle-orm/pg-core";

export const homeBannersTable = pgTable("home_banners", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default(""),
  subtitle: text("subtitle").notNull().default(""),
  badgeText: text("badge_text").notNull().default(""),
  badge2Text: text("badge2_text").notNull().default(""),
  ctaText: text("cta_text").notNull().default(""),
  ctaHref: text("cta_href").notNull().default("/games?category=mobile_games"),
  ctaSecondaryText: text("cta_secondary_text").notNull().default(""),
  ctaSecondaryHref: text("cta_secondary_href").notNull().default(""),
  bgGradient: text("bg_gradient").notNull().default("linear-gradient(135deg, #0d0025 0%, #1e0060 40%, #0a0a2e 100%)"),
  accentColor: text("accent_color").notNull().default("#6C5CE7"),
  glow1: text("glow1").notNull().default("#6C5CE7"),
  glow2: text("glow2").notNull().default("#a29bfe"),
  emoji: text("emoji").notNull().default("🎮"),
  icon: text("icon").notNull().default("🕹️"),
  iconEnabled: boolean("icon_enabled").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type HomeBanner = typeof homeBannersTable.$inferSelect;
export type InsertHomeBanner = typeof homeBannersTable.$inferInsert;
