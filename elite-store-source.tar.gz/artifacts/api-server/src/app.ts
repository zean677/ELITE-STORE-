import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

const requestBuckets = new Map<string, { count: number; resetAt: number }>();

app.use((req, res, next) => {
  const now = Date.now();
  const key = `${req.ip}:${req.path}`;
  const current = requestBuckets.get(key);
  const bucket = current && current.resetAt > now ? current : { count: 0, resetAt: now + 60_000 };
  bucket.count += 1;
  requestBuckets.set(key, bucket);

  if (bucket.count > 180) {
    res.status(429).json({ error: "Too many requests", message: "Please slow down and try again shortly" });
    return;
  }

  next();
});

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

app.use("/api", router);

export default app;
