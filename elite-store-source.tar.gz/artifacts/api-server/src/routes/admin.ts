import { Router, type IRouter } from "express";
import { db, usersTable, ordersTable, paymentsTable, productsTable, walletTransactionsTable, notificationsTable, settingsTable } from "@workspace/db";
import { eq, desc, and, count, sum, gte, sql, ilike } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";
import { VerifyPaymentBody, GetAdminOrdersQueryParams, GetAdminPaymentsQueryParams, GetAdminUsersQueryParams, UpdateUserBalanceBody, SuspendUserBody } from "@workspace/api-zod";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../lib/logger";

async function getSettingValue(key: string, defaultVal: string): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  return row?.value ?? defaultVal;
}

const router: IRouter = Router();

router.get("/admin/dashboard", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const [totalRevenueResult] = await db
    .select({ total: sum(ordersTable.totalPrice) })
    .from(ordersTable)
    .where(eq(ordersTable.status, "completed"));

  const [totalOrdersResult] = await db.select({ count: count() }).from(ordersTable);
  const [totalUsersResult] = await db.select({ count: count() }).from(usersTable).where(eq(usersTable.role, "user"));
  const [totalProductsResult] = await db.select({ count: count() }).from(productsTable).where(eq(productsTable.status, "active"));
  const [pendingPaymentsResult] = await db.select({ count: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending"));
  const [completedOrdersResult] = await db.select({ count: count() }).from(ordersTable).where(eq(ordersTable.status, "completed"));
  const [failedOrdersResult] = await db.select({ count: count() }).from(ordersTable).where(eq(ordersTable.status, "failed"));

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const [revenueTodayResult] = await db
    .select({ total: sum(ordersTable.totalPrice) })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, todayStart)));

  const [ordersTodayResult] = await db
    .select({ count: count() })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, todayStart));

  const topProductsRaw = await db
    .select({
      productId: ordersTable.productId,
      productName: ordersTable.productName,
      orderCount: count(),
      revenue: sum(ordersTable.totalPrice),
    })
    .from(ordersTable)
    .groupBy(ordersTable.productId, ordersTable.productName)
    .orderBy(desc(count()))
    .limit(5);

  const recentOrders = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt))
    .limit(10);

  res.json({
    totalRevenue: parseFloat(totalRevenueResult?.total ?? "0"),
    totalOrders: totalOrdersResult?.count ?? 0,
    totalUsers: totalUsersResult?.count ?? 0,
    totalProducts: totalProductsResult?.count ?? 0,
    pendingPayments: pendingPaymentsResult?.count ?? 0,
    completedOrders: completedOrdersResult?.count ?? 0,
    failedOrders: failedOrdersResult?.count ?? 0,
    revenueToday: parseFloat(revenueTodayResult?.total ?? "0"),
    ordersToday: ordersTodayResult?.count ?? 0,
    topProducts: topProductsRaw.map(p => ({
      productId: p.productId,
      productName: p.productName,
      orderCount: p.orderCount,
      revenue: parseFloat(p.revenue ?? "0"),
    })),
    recentOrders: recentOrders.map(o => ({ ...o, totalPrice: parseFloat(o.totalPrice ?? "0") })),
  });
});

router.get("/admin/orders", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetAdminOrdersQueryParams.safeParse(req.query);
  const page = qp.success ? (qp.data.page ?? 1) : 1;
  const limit = qp.success ? (qp.data.limit ?? 20) : 20;
  const status = qp.success ? qp.data.status : undefined;
  const offset = (page - 1) * limit;

  const conditions = status ? [eq(ordersTable.status, status)] : [];
  const whereClause = conditions.length > 0 ? conditions[0] : undefined;

  const totalQ = whereClause
    ? db.select({ count: count() }).from(ordersTable).where(whereClause)
    : db.select({ count: count() }).from(ordersTable);

  const ordersQ = whereClause
    ? db.select().from(ordersTable).where(whereClause).orderBy(desc(ordersTable.createdAt)).limit(limit).offset(offset)
    : db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(limit).offset(offset);

  const [[totalResult], orders] = await Promise.all([totalQ, ordersQ]);

  res.json({
    orders: orders.map(o => ({ ...o, totalPrice: parseFloat(o.totalPrice ?? "0") })),
    total: totalResult?.count ?? 0,
    page,
    limit,
  });
});

router.post("/admin/orders/:id/retry", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;

  const [order] = await db
    .update(ordersTable)
    .set({ status: "processing", updatedAt: new Date() })
    .where(and(eq(ordersTable.id, rawId), eq(ordersTable.status, "failed")))
    .returning();

  if (!order) {
    res.status(404).json({ error: "Order not found or not in failed state" });
    return;
  }

  logger.info({ orderId: rawId }, "Order retry requested by admin");
  res.json({ ...order, totalPrice: parseFloat(order.totalPrice ?? "0") });
});

router.get("/admin/payments", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetAdminPaymentsQueryParams.safeParse(req.query);
  const status = qp.success ? qp.data.status : undefined;

  const rows = await db
    .select({
      id: paymentsTable.id,
      userId: paymentsTable.userId,
      amount: paymentsTable.amount,
      currency: paymentsTable.currency,
      method: paymentsTable.method,
      status: paymentsTable.status,
      screenshotUrl: paymentsTable.screenshotUrl,
      transactionRef: paymentsTable.transactionRef,
      adminNote: paymentsTable.adminNote,
      createdAt: paymentsTable.createdAt,
      userEmail: usersTable.email,
      username: usersTable.username,
    })
    .from(paymentsTable)
    .leftJoin(usersTable, eq(paymentsTable.userId, usersTable.id))
    .where(status ? eq(paymentsTable.status, status) : undefined)
    .orderBy(desc(paymentsTable.createdAt));

  res.json(rows.map(p => ({ ...p, amount: parseFloat(p.amount ?? "0") })));
});

router.post("/admin/payments/:id/verify", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const parsed = VerifyPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { action, adminNote } = parsed.data;
  const newStatus = action === "approve" ? "approved" : "rejected";

  const [existingPayment] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, id));
  if (!existingPayment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }

  if (existingPayment.status !== "pending") {
    res.status(409).json({ error: "Payment already processed", message: "This payment request was already verified" });
    return;
  }

  const [payment] = await db
    .update(paymentsTable)
    .set({ status: newStatus, adminNote: adminNote ?? null })
    .where(and(eq(paymentsTable.id, id), eq(paymentsTable.status, "pending")))
    .returning();

  if (!payment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }

  if (action === "approve") {
    const amountRaw = parseFloat(payment.amount ?? "0");
    // Read dynamic rates from settings
    const sypRateRow = await db.select().from(settingsTable).where(eq(settingsTable.key, "syp_rate"));
    const eurRateRow = await db.select().from(settingsTable).where(eq(settingsTable.key, "eur_rate"));
    const sypRate = parseFloat(sypRateRow[0]?.value ?? "13000");
    const eurRate = parseFloat(eurRateRow[0]?.value ?? "0.92");
    const convertedToUsd = payment.currency === "SYP" ? amountRaw / sypRate : payment.currency === "EUR" ? amountRaw / eurRate : amountRaw;

    await db
      .update(usersTable)
      .set({ balance: sql`${usersTable.balance} + ${convertedToUsd.toString()}` })
      .where(eq(usersTable.id, payment.userId));

    await db.insert(walletTransactionsTable).values({
      userId: payment.userId,
      type: "deposit",
      amount: convertedToUsd.toString(),
      currency: "USD",
      description: `إيداع عبر ${payment.method} (${payment.currency} ${payment.amount})`,
    });

    await db.insert(notificationsTable).values({
      userId: payment.userId,
      type: "payment_approved",
      title: "✅ تمت الموافقة على الدفعة",
      message: `تمت الموافقة على إيداعك بقيمة ${payment.currency} ${parseFloat(payment.amount ?? "0").toLocaleString()} وإضافته لمحفظتك. (≈ $${convertedToUsd.toFixed(2)})`,
      isRead: false,
    });
  }

  logger.info({ paymentId: id, action, adminId: req.user!.id }, "Payment verified by admin");
  res.json({ ...payment, amount: parseFloat(payment.amount ?? "0") });
});

router.get("/admin/users", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetAdminUsersQueryParams.safeParse(req.query);
  const page = qp.success ? (qp.data.page ?? 1) : 1;
  const limit = qp.success ? (qp.data.limit ?? 20) : 20;
  const search = qp.success ? qp.data.search : undefined;
  const offset = (page - 1) * limit;

  const conditions = search ? [ilike(usersTable.email, `%${search}%`)] : [];
  const whereClause = conditions.length > 0 ? conditions[0] : undefined;

  const totalQ = whereClause
    ? db.select({ count: count() }).from(usersTable).where(whereClause)
    : db.select({ count: count() }).from(usersTable);

  const usersQ = whereClause
    ? db.select().from(usersTable).where(whereClause).orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset)
    : db.select().from(usersTable).orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset);

  const [[totalResult], users] = await Promise.all([totalQ, usersQ]);

  res.json({
    users: users.map(u => ({
      id: u.id,
      username: u.username,
      email: u.email,
      role: u.role,
      balance: parseFloat(u.balance ?? "0"),
      isSuspended: u.isSuspended,
      createdAt: u.createdAt,
    })),
    total: totalResult?.count ?? 0,
    page,
    limit,
  });
});

router.patch("/admin/users/:id/balance", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const userId = parseInt(rawId, 10);

  const parsed = UpdateUserBalanceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { amount, operation, reason } = parsed.data;

  let newBalanceSql;
  if (operation === "add") {
    newBalanceSql = sql`${usersTable.balance} + ${amount.toString()}`;
  } else if (operation === "subtract") {
    newBalanceSql = sql`${usersTable.balance} - ${amount.toString()}`;
  } else {
    newBalanceSql = sql`${amount.toString()}`;
  }

  const [user] = await db
    .update(usersTable)
    .set({ balance: newBalanceSql })
    .where(eq(usersTable.id, userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  await db.insert(walletTransactionsTable).values({
    userId,
    type: operation === "subtract" ? "purchase" : "deposit",
    amount: (operation === "subtract" ? -amount : amount).toString(),
    currency: "USD",
    description: reason ?? `Admin balance adjustment (${operation})`,
  });

  await db.insert(notificationsTable).values({
    userId,
    type: "balance_updated",
    title: "Balance Updated",
    message: `Your balance has been updated by an administrator.`,
    isRead: false,
  });

  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    balance: parseFloat(user.balance ?? "0"),
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });
});

router.patch("/admin/users/:id/suspend", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const userId = parseInt(rawId, 10);

  const parsed = SuspendUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set({ isSuspended: parsed.data.suspended })
    .where(eq(usersTable.id, userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    balance: parseFloat(user.balance ?? "0"),
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });
});

router.post("/admin/sync/ahminix", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const apiKey = (await getSettingValue("ahminix_api_key", "")) || process.env.AHMINIX_API_KEY || "";

  if (!apiKey) {
    res.status(500).json({ error: "AHMINIX_API_KEY not configured. Add it in Admin Settings → API Providers." });
    return;
  }

  const baseUrl = await getSettingValue("ahminix_base_url", "https://store.ahminix.com/client/api/");
  const savedMargin = await getSettingValue("default_profit_margin", "10");
  const profitMarginPct = req.body?.profit_margin !== undefined ? parseFloat(req.body.profit_margin) : parseFloat(savedMargin);
  const profitMultiplier = 1 + profitMarginPct / 100;

  let synced = 0, failed = 0;

  try {
    const response = await fetch(`${baseUrl.replace(/\/$/, "")}/products`, {
      method: "GET",
      headers: { "api-key": apiKey.trim(), "Accept": "application/json" },
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      const body = await response.text().catch(() => "");
      res.status(502).json({ error: `AHMINIX API returned ${response.status}`, detail: body });
      return;
    }

    const products: any[] = await response.json();

    for (const p of products) {
      try {
        const productId = `ahminix_${p.id}`;
        const price = typeof p.price === "number" ? p.price : parseFloat(String(p.price ?? 0));
        const finalPrice = parseFloat((price * profitMultiplier).toFixed(6));

        await db.insert(productsTable).values({
          id: productId,
          name: p.name ?? `Product ${p.id}`,
          nameAr: p.name ?? null,
          description: p.description ?? null,
          category: "general",
          provider: "ahminix",
          providerProductId: String(p.id),
          priceUsd: String(finalPrice),
          unitPriceUsd: String(price),
          requiredFields: p.params ?? [],
          status: p.available !== false ? "active" : "inactive",
          profitMargin: String(profitMarginPct),
          productType: p.product_type ?? "package",
          qtyMin: null,
          qtyMax: null,
        }).onConflictDoUpdate({
          target: productsTable.id,
          set: { name: p.name, priceUsd: String(finalPrice), unitPriceUsd: String(price), status: p.available !== false ? "active" : "inactive", requiredFields: p.params ?? [], profitMargin: String(profitMarginPct) },
        });
        synced++;
      } catch (err) {
        logger.error({ err, productId: p.id }, "Failed to upsert AHMINIX product");
        failed++;
      }
    }
  } catch (err) {
    logger.error({ err }, "Failed to fetch from AHMINIX");
    res.status(502).json({ error: "Failed to connect to AHMINIX API" });
    return;
  }

  res.json({ synced, failed, message: `Synced ${synced} products from AHMINIX` });
});

router.post("/admin/products", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const SHAMS_TOKEN = (await getSettingValue("shams4store_api_token", "")) || process.env.SHAMS4STORE_API_TOKEN;

  if (!SHAMS_TOKEN) {
    res.status(500).json({ error: "SHAMS4STORE_API_TOKEN is not configured" });
    return;
  }

  // Get profit margin from settings (or use override from request body)
  const savedMargin = await getSettingValue("default_profit_margin", "10");
  const profitMarginPct = req.body?.profit_margin !== undefined
    ? parseFloat(req.body.profit_margin)
    : parseFloat(savedMargin);
  const profitMultiplier = 1 + profitMarginPct / 100;

  let synced = 0;
  let failed = 0;
  let skipped = 0;

  function mapCategory(catName: string): string {
    const n = catName.toLowerCase().trim();

    // ── Gift Cards ──────────────────────────────────────────────────────────
    const giftCardKeywords = [
      "steam", "xbox", "playstation", "nintendo", "google play", "itunes",
      "amazon card", "gamestop", "blizzard card", "فيزا", "visa",
    ];
    if (giftCardKeywords.some(k => n.includes(k))) return "gift_cards";

    // ── PC Games ─────────────────────────────────────────────────────────────
    const pcGameKeywords = [
      "league of legends", "valorant", "overwatch",
    ];
    if (pcGameKeywords.some(k => n.includes(k))) return "pc_games";

    // ── Services ─────────────────────────────────────────────────────────────
    // Applications category
    if (n === "التطبيقات" || n === "applications") return "services";

    // VPN
    if (n.includes("vpn")) return "services";

    // Streaming & media
    const streamingKeywords = [
      "netflix", "spotify", "youtube premium", "apple tv", "apple music",
      "wetv", "crunchyroll", "shahid", "amazon prime", "osn", "ip tv", "iptv",
      "deezer", "filmix", "zain 4k", "look 4k", "blue 4k", "shamna tv",
      "picsart", "capcut", "canva", "invideo", "flaticon",
    ];
    if (streamingKeywords.some(k => n.includes(k))) return "services";

    // Social / live streaming apps
    const socialKeywords = [
      "telegram", "snapchat", "imo ", "momo ", "gomeet", "غوميت",
      "ميو لايف", "meyo", "livu", "ليف يو", "mixu", "ميكس يو",
      "hicat", "هاي كات", "yalla live", "يلا لايف", "weplay", "وي بلاي",
      "كملنا", "كوينز", "zepeto", "chatgpt", "gemini", "الذكاء الاصطناعي",
    ];
    if (socialKeywords.some(k => n.includes(k))) return "services";

    // Reactions / boosts / phone numbers
    if (n.startsWith("رشق") || n.includes("ارقام")) return "services";

    // Telecom / operator services
    const telecomKeywords = [
      "ليرات", "فئات جاهزة", "الرصيد والاتصالات", "خدمات سيريتل",
      "خدمات mtn", "خدمات شام", "خدمات عامة", "alfa", "باقات",
      "أيام صلاحية", "مزود", "خدمات mtن",
    ];
    if (telecomKeywords.some(k => n.includes(k))) return "services";

    // VIP / membership / subscriptions (non-game)
    if (n.includes("مستويات vip") || n.includes("vip") && !n.includes("mobile") && !n.includes("legend")) return "services";

    // iCloud / crypto / AI
    if (n.includes("ايكلود") || n.includes("icloud")) return "services";
    if (n.includes("العملات الرقمية")) return "services";

    // ── Mobile Games ─────────────────────────────────────────────────────────
    const mobileGameKeywords = [
      "pubg", "ببجي", "free fire", "فري فاير", "شدات", "ألماس",
      "mobile legend", "mobile legends", "magic chess",
      "clash", "roblox", "minecraft", "genshin", "honkai", "zenless",
      "wuthering", "star rail", "blood strike", "arena breakout",
      "wild rift", "age of empire", "ragnarok", "arknights",
      "war robot", "lords mobile", "last war", "whiteout", "state of survival",
      "stumble guys", "marvel", "dragon", "arena of valor",
      "ludo", "puzzle", "idle", "مغلفات", "جواكر",
      "solo leveling", "etheria", "frag pro", "devil may cry",
      "tarisland", "haikyu", "cats:", "pixel gun", "eggy party",
      "star resonance", "harry potter", "overmortal", "once human",
      "age of magic", "moonlight blade", "modern warship", "mwt",
      "black clover", "blockman", "modern strike", "acecraft",
      "crossfire", "crystal of atlan", "heartopia", "silver and blood",
      "rainbow six", "dragon nest", "super sus", "life after",
      "sword of justice", "oxide:", "farlight", "afk journey",
      "crossout", "honor of kings", "revenge of sultan", "eve echoes",
      "knives out", "heaven burns", "echocalypse", "duet night",
      "deadly dudes", "winjoy", "guns of glory", "hero clash",
      "snowbreak", "maplestory", "watcher of realm", "onmyoji",
      "destiny rising", "mecha break", "8ball", "8 ball",
      "stormshot", "piggy go", "identity v", "city of crime",
      "tiles survive", "sea of conquest", "asphalt", "نداء الحرب",
      "rise of the king", "king of avalon", "war robot", "brawl",
      "brawel", "football rising", "fortnite", "the walking dead",
      "merge kingdom", "mobile royale", "dragonheir", "pure sniper",
      "undawn", "garena", "legend of the phoenix", "bleach:",
      "legend of neverland", "legend of neverland", "project entropy",
      "age of empires mobile", "ببجي روبوت", "عضويات ببجي",
      "عضويات فري فاير", "فري فاير اكواد", "ألماس",
      "yalla ludo", "يلا لودو",
    ];
    if (mobileGameKeywords.some(k => n.includes(k))) return "mobile_games";

    // Fallback: if the name looks like a game title (Latin/English characters with
    // common game patterns), treat as mobile_games
    if (/^[a-z0-9\s:\-\.!'&]+$/i.test(catName.trim())) return "mobile_games";

    return "services";
  }

  try {
    const cleanToken = SHAMS_TOKEN.trim();
    const response = await fetch(`https://api.shams4store.com/client/api/products`, {
      method: "GET",
      headers: {
        "api-token": cleanToken,
        "Accept": "application/json",
      },
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      const body = await response.text().catch(() => "");
      logger.error({ status: response.status, body }, "shams4store API error");
      res.status(502).json({ error: `shams4store API returned ${response.status}`, detail: body });
      return;
    }

    const products: Array<{
      id: number;
      name: string;
      description?: string;
      price: number;
      params: string[];
      category_name: string;
      available: boolean;
      product_type: string;
      parent_id: number;
      qty_values?: { min?: number; max?: number } | null;
    }> = await response.json();

    for (const p of products) {
      try {
        const productId = `shams_${p.id}`;
        const category = mapCategory(p.category_name);
        const unitPrice = typeof p.price === "number" ? p.price : parseFloat(String(p.price));
        const qtyMin = p.qty_values?.min ?? null;
        const qtyMax = p.qty_values?.max ?? null;

        // Base price before profit
        const basePrice =
          p.product_type === "amount" && qtyMin && qtyMin > 0
            ? unitPrice * qtyMin
            : unitPrice;

        // Apply profit margin
        const effectivePrice = parseFloat((basePrice * profitMultiplier).toFixed(6));

        await db
          .insert(productsTable)
          .values({
            id: productId,
            name: p.name,
            nameAr: p.name,
            description: p.description ?? null,
            category,
            provider: "shams4store",
            providerProductId: String(p.id),
            priceUsd: String(effectivePrice),
            unitPriceUsd: String(unitPrice),
            requiredFields: p.params ?? [],
            status: p.available ? "active" : "inactive",
            profitMargin: String(profitMarginPct),
            productType: p.product_type ?? "package",
            qtyMin: qtyMin !== null ? String(qtyMin) : null,
            qtyMax: qtyMax !== null ? String(qtyMax) : null,
          })
          .onConflictDoUpdate({
            target: productsTable.id,
            set: {
              name: p.name,
              category,
              priceUsd: String(effectivePrice),
              unitPriceUsd: String(unitPrice),
              status: p.available ? "active" : "inactive",
              requiredFields: p.params ?? [],
              productType: p.product_type ?? "package",
              profitMargin: String(profitMarginPct),
              qtyMin: qtyMin !== null ? String(qtyMin) : null,
              qtyMax: qtyMax !== null ? String(qtyMax) : null,
            },
          });
        synced++;
      } catch (err) {
        logger.error({ err, productId: p.id }, "Failed to upsert product");
        failed++;
      }
    }
  } catch (err) {
    logger.error({ err }, "Failed to fetch from shams4store");
    res.status(502).json({ error: "Failed to connect to shams4store API" });
    return;
  }

  logger.info({ synced, failed, skipped }, "Products sync from shams4store completed");
  res.json({ synced, failed, skipped, message: `Synced ${synced} products from shams4store` });
});

router.get("/admin/revenue-chart", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const period = (req.query.period as string) ?? "30d";
  const days = period === "7d" ? 7 : period === "90d" ? 90 : 30;

  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const result = await db
    .select({
      date: sql<string>`DATE(${ordersTable.createdAt})`.as("date"),
      revenue: sum(ordersTable.totalPrice),
      orders: count(),
    })
    .from(ordersTable)
    .where(and(gte(ordersTable.createdAt, startDate), eq(ordersTable.status, "completed")))
    .groupBy(sql`DATE(${ordersTable.createdAt})`)
    .orderBy(sql`DATE(${ordersTable.createdAt})`);

  res.json(result.map(r => ({
    date: r.date,
    revenue: parseFloat(r.revenue ?? "0"),
    orders: r.orders,
  })));
});

router.post("/admin/products/create", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { name, nameAr, description, image, priceUsd, category, provider, providerProductId, requiredFields, status, profitMargin } = req.body;

  if (!name || priceUsd === undefined || !category || !provider) {
    res.status(400).json({ error: "name, priceUsd, category, and provider are required" });
    return;
  }

  const id = uuidv4();
  const [product] = await db
    .insert(productsTable)
    .values({
      id,
      name,
      nameAr: nameAr ?? null,
      description: description ?? null,
      image: image ?? null,
      priceUsd: String(priceUsd),
      category: category ?? "general",
      provider: provider ?? "manual",
      providerProductId: providerProductId ?? id,
      requiredFields: requiredFields ?? [],
      status: status ?? "active",
      profitMargin: String(profitMargin ?? 10),
    })
    .returning();

  res.status(201).json({
    ...product,
    priceUsd: parseFloat(product.priceUsd ?? "0"),
    profitMargin: parseFloat(product.profitMargin ?? "10"),
    requiredFields: product.requiredFields ?? [],
  });
});

router.put("/admin/products/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = req.params.id;
  const { name, nameAr, description, image, priceUsd, category, status, profitMargin } = req.body;

  const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const updateData: Record<string, unknown> = {};
  if (name !== undefined) updateData.name = name;
  if (nameAr !== undefined) updateData.nameAr = nameAr;
  if (description !== undefined) updateData.description = description;
  if (image !== undefined) updateData.image = image;
  if (priceUsd !== undefined) updateData.priceUsd = String(priceUsd);
  if (category !== undefined) updateData.category = category;
  if (status !== undefined) updateData.status = status;
  if (profitMargin !== undefined) updateData.profitMargin = String(profitMargin);

  const [updated] = await db
    .update(productsTable)
    .set(updateData)
    .where(eq(productsTable.id, productId))
    .returning();

  res.json({
    ...updated,
    priceUsd: parseFloat(updated.priceUsd ?? "0"),
    profitMargin: parseFloat(updated.profitMargin ?? "10"),
    requiredFields: updated.requiredFields ?? [],
  });
});

router.delete("/admin/products/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = req.params.id;

  const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  await db.delete(productsTable).where(eq(productsTable.id, productId));
  res.json({ success: true });
});

export default router;
