import { Router, type IRouter } from "express";
import { db, usersTable, loyaltyTransactionsTable, walletTransactionsTable, loyaltyRewardsTable, loyaltyRewardRedemptionsTable, notificationsTable } from "@workspace/db";
import { eq, desc, sql, and } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { POINTS_PER_USD, POINTS_PER_USD_REDEEM } from "../lib/vip";
import { logger } from "../lib/logger";
import { notifyLoyaltyRedeem } from "../lib/telegram";

const router: IRouter = Router();

router.get("/loyalty", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const history = await db
    .select()
    .from(loyaltyTransactionsTable)
    .where(eq(loyaltyTransactionsTable.userId, userId))
    .orderBy(desc(loyaltyTransactionsTable.createdAt))
    .limit(50);

  const points = user.loyaltyPoints ?? 0;
  res.json({
    points,
    redeemableUsd: +(points / POINTS_PER_USD_REDEEM).toFixed(2),
    pointsPerUsdEarned: POINTS_PER_USD,
    pointsPerUsdRedeemed: POINTS_PER_USD_REDEEM,
    minRedeem: POINTS_PER_USD_REDEEM,
    history: history.map(h => ({
      ...h,
      redeemedUsd: h.redeemedUsd ? parseFloat(h.redeemedUsd) : null,
    })),
  });
});

router.post("/loyalty/redeem", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const pointsToRedeem = Math.floor(Number(req.body?.points ?? 0));

  if (!Number.isFinite(pointsToRedeem) || pointsToRedeem < POINTS_PER_USD_REDEEM) {
    res.status(400).json({ error: "Invalid points", message: `الحد الأدنى ${POINTS_PER_USD_REDEEM} نقطة` });
    return;
  }
  if (pointsToRedeem % POINTS_PER_USD_REDEEM !== 0) {
    res.status(400).json({ error: "Invalid amount", message: `يجب أن تكون النقاط بمضاعفات ${POINTS_PER_USD_REDEEM}` });
    return;
  }

  const usdValue = pointsToRedeem / POINTS_PER_USD_REDEEM;

  // Atomic deduct: only succeed if enough points available
  const [updated] = await db
    .update(usersTable)
    .set({
      loyaltyPoints: sql`${usersTable.loyaltyPoints} - ${pointsToRedeem}`,
      balance: sql`${usersTable.balance} + ${usdValue.toFixed(6)}`,
    })
    .where(sql`${usersTable.id} = ${userId} AND ${usersTable.loyaltyPoints} >= ${pointsToRedeem}`)
    .returning();

  if (!updated) {
    res.status(409).json({ error: "Insufficient points", message: "نقاطك غير كافية" });
    return;
  }

  await db.insert(loyaltyTransactionsTable).values({
    userId,
    type: "redeem",
    points: -pointsToRedeem,
    balanceAfter: updated.loyaltyPoints,
    description: `استبدال ${pointsToRedeem} نقطة بـ $${usdValue.toFixed(2)} رصيد`,
    redeemedUsd: usdValue.toFixed(6),
  }).catch(() => {});

  await db.insert(walletTransactionsTable).values({
    userId,
    type: "loyalty_redeem",
    amount: usdValue.toFixed(6),
    currency: "USD",
    description: `إضافة رصيد من استبدال ${pointsToRedeem} نقطة ولاء`,
  }).catch(() => {});

  logger.info({ userId, pointsRedeemed: pointsToRedeem, usdAdded: usdValue }, "Loyalty points redeemed");

  notifyLoyaltyRedeem({
    username: updated.username,
    points: pointsToRedeem,
    usdAdded: usdValue,
  }).catch(() => {});

  res.json({
    success: true,
    pointsRedeemed: pointsToRedeem,
    usdAdded: usdValue,
    remainingPoints: updated.loyaltyPoints,
    newBalance: parseFloat(updated.balance),
  });
});

// Admin: overall loyalty stats + top earners
router.get("/admin/loyalty/stats", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const [agg] = await db.execute<{ total_outstanding: string; total_users: string; avg_points: string }>(sql`
    SELECT
      COALESCE(SUM(loyalty_points), 0)::text AS total_outstanding,
      COUNT(*) FILTER (WHERE loyalty_points > 0)::text AS total_users,
      COALESCE(ROUND(AVG(loyalty_points) FILTER (WHERE loyalty_points > 0))::int, 0)::text AS avg_points
    FROM users
  `).then((r: any) => r.rows ?? r);

  const [earned] = await db.execute<{ total_earned: string; total_redeemed: string; total_redeemed_usd: string }>(sql`
    SELECT
      COALESCE(SUM(points) FILTER (WHERE points > 0), 0)::text AS total_earned,
      COALESCE(ABS(SUM(points) FILTER (WHERE points < 0 AND type = 'redeem')), 0)::text AS total_redeemed,
      COALESCE(SUM(redeemed_usd::numeric) FILTER (WHERE type = 'redeem'), 0)::text AS total_redeemed_usd
    FROM loyalty_transactions
  `).then((r: any) => r.rows ?? r);

  const topEarners = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      email: usersTable.email,
      publicCode: usersTable.publicCode,
      loyaltyPoints: usersTable.loyaltyPoints,
      vipLevel: usersTable.vipLevel,
    })
    .from(usersTable)
    .where(sql`${usersTable.loyaltyPoints} > 0`)
    .orderBy(desc(usersTable.loyaltyPoints))
    .limit(10);

  const recent = await db
    .select({
      id: loyaltyTransactionsTable.id,
      userId: loyaltyTransactionsTable.userId,
      type: loyaltyTransactionsTable.type,
      points: loyaltyTransactionsTable.points,
      balanceAfter: loyaltyTransactionsTable.balanceAfter,
      description: loyaltyTransactionsTable.description,
      redeemedUsd: loyaltyTransactionsTable.redeemedUsd,
      createdAt: loyaltyTransactionsTable.createdAt,
      username: usersTable.username,
      publicCode: usersTable.publicCode,
    })
    .from(loyaltyTransactionsTable)
    .leftJoin(usersTable, eq(usersTable.id, loyaltyTransactionsTable.userId))
    .orderBy(desc(loyaltyTransactionsTable.createdAt))
    .limit(30);

  res.json({
    config: {
      pointsPerUsdEarned: POINTS_PER_USD,
      pointsPerUsdRedeemed: POINTS_PER_USD_REDEEM,
      minRedeem: POINTS_PER_USD_REDEEM,
    },
    stats: {
      totalOutstanding: parseInt(agg?.total_outstanding ?? "0", 10),
      activeUsers: parseInt(agg?.total_users ?? "0", 10),
      avgPoints: parseInt(agg?.avg_points ?? "0", 10),
      totalEarned: parseInt(earned?.total_earned ?? "0", 10),
      totalRedeemed: parseInt(earned?.total_redeemed ?? "0", 10),
      totalRedeemedUsd: parseFloat(earned?.total_redeemed_usd ?? "0"),
      liabilityUsd: +(parseInt(agg?.total_outstanding ?? "0", 10) / POINTS_PER_USD_REDEEM).toFixed(2),
    },
    topEarners,
    recent: recent.map(r => ({
      ...r,
      redeemedUsd: r.redeemedUsd ? parseFloat(r.redeemedUsd) : null,
    })),
  });
});

// Admin: manually adjust user loyalty points (+ or -)
router.post("/admin/users/:id/loyalty", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const targetUserId = Number(req.params.id);
  const delta = Math.floor(Number(req.body?.delta ?? 0));
  const reason = String(req.body?.reason ?? "تعديل أدمن").slice(0, 200);

  if (!Number.isFinite(delta) || delta === 0) {
    res.status(400).json({ error: "Invalid delta" });
    return;
  }

  const [target] = await db.select().from(usersTable).where(eq(usersTable.id, targetUserId));
  if (!target) { res.status(404).json({ error: "User not found" }); return; }

  const newTotal = Math.max(0, (target.loyaltyPoints ?? 0) + delta);
  const actualDelta = newTotal - (target.loyaltyPoints ?? 0);

  await db.update(usersTable).set({ loyaltyPoints: newTotal }).where(eq(usersTable.id, targetUserId));

  await db.insert(loyaltyTransactionsTable).values({
    userId: targetUserId,
    type: actualDelta >= 0 ? "admin_grant" : "admin_deduct",
    points: actualDelta,
    balanceAfter: newTotal,
    description: `${actualDelta >= 0 ? "منحة" : "خصم"} من الأدمن (${req.user!.username}): ${reason}`,
  }).catch(() => {});

  logger.info({ adminId: req.user!.id, targetUserId, delta: actualDelta, newTotal }, "Admin adjusted loyalty points");

  res.json({ success: true, newTotal, delta: actualDelta });
});

// Admin: bulk grant points to all users / by VIP level
router.post("/admin/loyalty/bulk-grant", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const points = Math.floor(Number(req.body?.points ?? 0));
  const targetVip = req.body?.vipLevel != null ? Number(req.body.vipLevel) : null;
  const reason = String(req.body?.reason ?? "منحة عامة من الإدارة").slice(0, 200);

  if (!Number.isFinite(points) || points <= 0) {
    res.status(400).json({ error: "Invalid points amount" });
    return;
  }

  const targets = await db
    .select({ id: usersTable.id, current: usersTable.loyaltyPoints })
    .from(usersTable)
    .where(targetVip != null ? eq(usersTable.vipLevel, targetVip) : sql`1=1`);

  if (targets.length === 0) {
    res.status(404).json({ error: "No users matched" });
    return;
  }

  for (const u of targets) {
    const newTotal = (u.current ?? 0) + points;
    await db.update(usersTable).set({ loyaltyPoints: newTotal }).where(eq(usersTable.id, u.id));
    await db.insert(loyaltyTransactionsTable).values({
      userId: u.id,
      type: "admin_grant",
      points,
      balanceAfter: newTotal,
      description: `منحة جماعية (${req.user!.username}): ${reason}`,
    }).catch(() => {});
    await db.insert(notificationsTable).values({
      userId: u.id,
      type: "loyalty_granted",
      title: "🎁 منحة نقاط ولاء",
      message: `حصلت على ${points} نقطة ولاء! السبب: ${reason}`,
      isRead: false,
    }).catch(() => {});
  }

  logger.info({ adminId: req.user!.id, count: targets.length, points, targetVip }, "Bulk loyalty grant");
  res.json({ success: true, granted: targets.length, points });
});

// Admin: update loyalty config (rate values stored in settings table)
router.patch("/admin/loyalty/config", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const earned = Number(req.body?.pointsPerUsdEarned);
  const redeemed = Number(req.body?.pointsPerUsdRedeemed);
  const updates: { key: string; value: string }[] = [];
  if (Number.isFinite(earned) && earned > 0) updates.push({ key: "loyalty_points_per_usd_earned", value: String(earned) });
  if (Number.isFinite(redeemed) && redeemed >= 1) updates.push({ key: "loyalty_points_per_usd_redeemed", value: String(redeemed) });
  if (updates.length === 0) { res.status(400).json({ error: "No valid config updates" }); return; }

  const { settingsTable } = await import("@workspace/db");
  for (const u of updates) {
    await db.insert(settingsTable).values({ key: u.key, value: u.value })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value: u.value } });
  }
  res.json({ success: true, updated: updates.length });
});

// ─── Loyalty Rewards Catalog ─────────────────────────────────────

// Public: VIP leaderboard (top VIP users — masked usernames, only if enabled)
router.get("/vip-leaderboard", async (_req, res): Promise<void> => {
  const { settingsTable } = await import("@workspace/db");
  const { eq: eqS } = await import("drizzle-orm");
  const [row] = await db.select().from(settingsTable).where(eqS(settingsTable.key, 'vip_leaderboard_enabled'));
  const enabled = (row?.value ?? 'false') === 'true';
  if (!enabled) {
    res.json({ enabled: false, leaders: [] });
    return;
  }
  const leaders = await db
    .select({
      username: usersTable.username,
      vipLevel: usersTable.vipLevel,
      totalSpentUsd: usersTable.totalSpentUsd,
    })
    .from(usersTable)
    .where(sql`${usersTable.vipLevel} > 0`)
    .orderBy(desc(usersTable.totalSpentUsd))
    .limit(10);

  res.json({
    enabled: true,
    leaders: leaders.map((u, i) => ({
      rank: i + 1,
      username: u.username.length > 2 ? u.username.slice(0, 2) + '***' : u.username[0] + '***',
      vipLevel: u.vipLevel ?? 0,
      totalSpentUsd: Math.round(parseFloat(u.totalSpentUsd?.toString() ?? '0')),
    })),
  });
});

// Public: list active rewards (for users)
router.get("/loyalty/rewards", async (_req, res): Promise<void> => {
  const rewards = await db.select().from(loyaltyRewardsTable)
    .where(eq(loyaltyRewardsTable.isActive, true))
    .orderBy(loyaltyRewardsTable.sortOrder, loyaltyRewardsTable.pointsCost);
  res.json(rewards.map(r => ({ ...r, value: r.value ? parseFloat(r.value) : null })));
});

// User: redeem a reward
router.post("/loyalty/rewards/:id/redeem", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const rewardId = Number(req.params.id);
  if (!Number.isInteger(rewardId) || rewardId <= 0) {
    res.status(400).json({ error: "Invalid reward id" });
    return;
  }

  const result = await db.transaction(async (tx) => {
    // Lock the reward row so concurrent requests cannot oversell limited stock.
    const [reward] = await tx.select().from(loyaltyRewardsTable)
      .where(eq(loyaltyRewardsTable.id, rewardId))
      .for("update");
    if (!reward || !reward.isActive) return { kind: "not-found" as const };
    if (!Number.isInteger(reward.pointsCost) || reward.pointsCost <= 0) {
      return { kind: "invalid-reward" as const };
    }
    if (reward.stock != null && reward.stock <= 0) return { kind: "out-of-stock" as const };
    const balanceRewardUsd = reward.type === "balance" ? Number(reward.value) : null;
    if (reward.type === "balance" && (!Number.isFinite(balanceRewardUsd) || balanceRewardUsd! <= 0)) {
      return { kind: "invalid-reward" as const };
    }

    const [updated] = await tx.update(usersTable)
      .set({ loyaltyPoints: sql`${usersTable.loyaltyPoints} - ${reward.pointsCost}` })
      .where(sql`${usersTable.id} = ${userId} AND ${usersTable.loyaltyPoints} >= ${reward.pointsCost}`)
      .returning();
    if (!updated) return { kind: "insufficient" as const };

    let deliveryMessage = "تم استلام طلبك وسيتم التواصل معك قريباً";
    let status = "pending";
    if (reward.type === "balance") {
      const usd = balanceRewardUsd!;
      await tx.update(usersTable)
        .set({ balance: sql`${usersTable.balance} + ${usd.toFixed(6)}` })
        .where(eq(usersTable.id, userId));
      await tx.insert(walletTransactionsTable).values({
        userId, type: "loyalty_reward", amount: usd.toFixed(6), currency: "USD",
        description: `مكافأة ولاء: ${reward.nameAr}`,
      });
      deliveryMessage = `تم إضافة $${usd.toFixed(2)} إلى رصيدك`;
      status = "delivered";
    }

    await tx.update(loyaltyRewardsTable).set({
      ...(reward.stock != null ? { stock: sql`${loyaltyRewardsTable.stock} - 1` } : {}),
      redeemedCount: sql`${loyaltyRewardsTable.redeemedCount} + 1`,
    }).where(eq(loyaltyRewardsTable.id, rewardId));

    await tx.insert(loyaltyRewardRedemptionsTable).values({
      userId, rewardId, rewardName: reward.nameAr, pointsCost: reward.pointsCost,
      rewardType: reward.type, rewardValue: reward.value, status,
    });
    await tx.insert(loyaltyTransactionsTable).values({
      userId, type: "reward_redeem", points: -reward.pointsCost,
      balanceAfter: updated.loyaltyPoints, description: `استبدال مكافأة: ${reward.nameAr}`,
    });
    return {
      kind: "success" as const,
      rewardName: reward.nameAr,
      remainingPoints: updated.loyaltyPoints,
      status,
      deliveryMessage,
    };
  });

  if (result.kind === "not-found") { res.status(404).json({ error: "Reward not found" }); return; }
  if (result.kind === "out-of-stock") { res.status(409).json({ error: "Out of stock", message: "نفدت الكمية" }); return; }
  if (result.kind === "insufficient") { res.status(409).json({ error: "Insufficient points", message: "نقاطك غير كافية" }); return; }
  if (result.kind === "invalid-reward") {
    res.status(409).json({ error: "Reward configuration is invalid" });
    return;
  }

  await db.insert(notificationsTable).values({
    userId, type: "loyalty_reward_redeemed",
    title: `🎁 ${result.rewardName}`, message: result.deliveryMessage, isRead: false,
  }).catch(() => {});

  res.json({
    success: true,
    message: result.deliveryMessage,
    status: result.status,
    remainingPoints: result.remainingPoints,
  });
});

// Admin: list ALL rewards (incl inactive)
router.get("/admin/loyalty/rewards", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rewards = await db.select().from(loyaltyRewardsTable).orderBy(loyaltyRewardsTable.sortOrder, desc(loyaltyRewardsTable.id));
  res.json(rewards.map(r => ({ ...r, value: r.value ? parseFloat(r.value) : null })));
});

// Admin: create reward
router.post("/admin/loyalty/rewards", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const body = req.body ?? {};
  const nameAr = String(body.nameAr ?? "").trim();
  const pointsCost = Math.floor(Number(body.pointsCost));
  const type = String(body.type ?? "custom");
  if (!nameAr || !Number.isFinite(pointsCost) || pointsCost <= 0) {
    res.status(400).json({ error: "Invalid input" }); return;
  }
  const [created] = await db.insert(loyaltyRewardsTable).values({
    nameAr,
    description: String(body.description ?? "").slice(0, 500),
    pointsCost,
    type,
    value: body.value != null ? String(body.value) : null,
    emoji: String(body.emoji ?? "🎁").slice(0, 8),
    imageUrl: body.imageUrl ?? null,
    accentColor: String(body.accentColor ?? "#fbbf24"),
    stock: body.stock != null ? Math.floor(Number(body.stock)) : null,
    isActive: body.isActive !== false,
    sortOrder: Math.floor(Number(body.sortOrder ?? 0)),
  }).returning();
  res.json(created);
});

// Admin: update reward
router.patch("/admin/loyalty/rewards/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = Number(req.params.id);
  const body = req.body ?? {};
  const updates: any = {};
  if (body.nameAr !== undefined) updates.nameAr = String(body.nameAr);
  if (body.description !== undefined) updates.description = String(body.description).slice(0, 500);
  if (body.pointsCost !== undefined) updates.pointsCost = Math.floor(Number(body.pointsCost));
  if (body.type !== undefined) updates.type = String(body.type);
  if (body.value !== undefined) updates.value = body.value != null ? String(body.value) : null;
  if (body.emoji !== undefined) updates.emoji = String(body.emoji).slice(0, 8);
  if (body.imageUrl !== undefined) updates.imageUrl = body.imageUrl;
  if (body.accentColor !== undefined) updates.accentColor = String(body.accentColor);
  if (body.stock !== undefined) updates.stock = body.stock != null ? Math.floor(Number(body.stock)) : null;
  if (body.isActive !== undefined) updates.isActive = !!body.isActive;
  if (body.sortOrder !== undefined) updates.sortOrder = Math.floor(Number(body.sortOrder));
  const [updated] = await db.update(loyaltyRewardsTable).set(updates).where(eq(loyaltyRewardsTable.id, id)).returning();
  if (!updated) { res.status(404).json({ error: "Not found" }); return; }
  res.json(updated);
});

// Admin: delete reward
router.delete("/admin/loyalty/rewards/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = Number(req.params.id);
  await db.delete(loyaltyRewardsTable).where(eq(loyaltyRewardsTable.id, id));
  res.json({ success: true });
});

// Admin: list redemptions (history of who claimed what)
router.get("/admin/loyalty/redemptions", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rows = await db
    .select({
      id: loyaltyRewardRedemptionsTable.id,
      userId: loyaltyRewardRedemptionsTable.userId,
      rewardName: loyaltyRewardRedemptionsTable.rewardName,
      pointsCost: loyaltyRewardRedemptionsTable.pointsCost,
      rewardType: loyaltyRewardRedemptionsTable.rewardType,
      rewardValue: loyaltyRewardRedemptionsTable.rewardValue,
      status: loyaltyRewardRedemptionsTable.status,
      adminNote: loyaltyRewardRedemptionsTable.adminNote,
      createdAt: loyaltyRewardRedemptionsTable.createdAt,
      username: usersTable.username,
      publicCode: usersTable.publicCode,
    })
    .from(loyaltyRewardRedemptionsTable)
    .leftJoin(usersTable, eq(usersTable.id, loyaltyRewardRedemptionsTable.userId))
    .orderBy(desc(loyaltyRewardRedemptionsTable.createdAt))
    .limit(100);
  res.json(rows.map(r => ({ ...r, rewardValue: r.rewardValue ? parseFloat(r.rewardValue) : null })));
});

// ─── Default rewards seed (logical, based on prices) ─────────────────────────
// Earn rate: 1 point per $1 spent. Redeem rate: 100 points = $1 base.
// Tiered rewards — fair pricing (~2-3% effective return) with cheap 50-pt entry rewards.
const DEFAULT_REWARDS = [
  // ── 50-point entry tier (light & fun perks for everyone) ──
  {
    nameAr: "🎁 رصيد $0.50 فوري",
    description: "50 نقطة = نصف دولار رصيد فوراً في محفظتك",
    pointsCost: 50, type: "balance", value: "0.5",
    emoji: "🪙", accentColor: "#10b981", sortOrder: 0, stock: null, isActive: true,
  },
  {
    nameAr: "كوبون خصم 3% (لمرة واحدة)",
    description: "كود خصم 3% على أي منتج — سقف $1",
    pointsCost: 50, type: "discount_coupon", value: "3",
    emoji: "🏷️", accentColor: "#f59e0b", sortOrder: 1, stock: null, isActive: true,
  },
  {
    nameAr: "🎯 شحن أولوية للطلب التالي",
    description: "طلبك التالي يُعالَج بأولوية قصوى — تسليم أسرع",
    pointsCost: 50, type: "perk", value: "1",
    emoji: "⚡", accentColor: "#06b6d4", sortOrder: 2, stock: null, isActive: true,
  },
  // ── Wallet credit tier (better effective return) ──
  {
    nameAr: "رصيد $1.5 للمحفظة",
    description: "100 نقطة = $1.5 رصيد فوري (مكافأة 50%)",
    pointsCost: 100, type: "balance", value: "1.5",
    emoji: "💵", accentColor: "#10b981", sortOrder: 10, stock: null, isActive: true,
  },
  {
    nameAr: "رصيد $4 للمحفظة (+ مكافأة)",
    description: "250 نقطة = $4 (وفّرت 50%)",
    pointsCost: 250, type: "balance", value: "4",
    emoji: "💰", accentColor: "#22c55e", sortOrder: 11, stock: null, isActive: true,
  },
  {
    nameAr: "رصيد $9 للمحفظة (+ مكافأة كبيرة)",
    description: "500 نقطة = $9 (مكافأة 80%)",
    pointsCost: 500, type: "balance", value: "9",
    emoji: "💎", accentColor: "#06b6d4", sortOrder: 12, stock: null, isActive: true,
  },
  {
    nameAr: "رصيد $20 للمحفظة (Best Deal)",
    description: "1000 نقطة = $20 (مكافأة 100%)",
    pointsCost: 1000, type: "balance", value: "20",
    emoji: "💸", accentColor: "#a855f7", sortOrder: 13, stock: null, isActive: true,
  },
  {
    nameAr: "رصيد $55 للمحفظة (لكبار الزبائن)",
    description: "2500 نقطة = $55 (مكافأة 120% — للزبائن المميزين)",
    pointsCost: 2500, type: "balance", value: "55",
    emoji: "👑", accentColor: "#fbbf24", sortOrder: 14, stock: null, isActive: true,
  },
  // ── Discount coupons ──
  {
    nameAr: "كوبون خصم 5% على الطلب القادم",
    description: "نرسلك كود خصم 5% خاص فيك على أي منتج",
    pointsCost: 80, type: "discount_coupon", value: "5",
    emoji: "🏷️", accentColor: "#f97316", sortOrder: 20, stock: null, isActive: true,
  },
  {
    nameAr: "كوبون خصم 10% على الطلب القادم",
    description: "كود خصم 10% — سقف الخصم $5",
    pointsCost: 200, type: "discount_coupon", value: "10",
    emoji: "🎟️", accentColor: "#ef4444", sortOrder: 21, stock: null, isActive: true,
  },
  {
    nameAr: "كوبون خصم 15% (مميز)",
    description: "خصم 15% على أي منتج — سقف $8",
    pointsCost: 400, type: "discount_coupon", value: "15",
    emoji: "🎫", accentColor: "#dc2626", sortOrder: 22, stock: null, isActive: true,
  },
  {
    nameAr: "كوبون خصم 20% (لمرة واحدة)",
    description: "خصم كبير 20% على أي منتج — سقف $10",
    pointsCost: 600, type: "discount_coupon", value: "20",
    emoji: "🎟️", accentColor: "#dc2626", sortOrder: 23, stock: null, isActive: true,
  },
  // ── Cheap free products (great value at low points) ──
  {
    nameAr: "60 شدة PUBG مجاناً",
    description: "60 شدة PUBG ($0.99) — تسليم بعد التواصل معك",
    pointsCost: 50, type: "free_product", value: "0.99",
    emoji: "🎮", accentColor: "#7c3aed", sortOrder: 30, stock: 100, isActive: true,
  },
  {
    nameAr: "100 ألماسة Free Fire مجاناً",
    description: "100 ألماسة ($0.99) — تسليم بعد التواصل معك",
    pointsCost: 50, type: "free_product", value: "0.99",
    emoji: "💎", accentColor: "#06b6d4", sortOrder: 31, stock: 100, isActive: true,
  },
  {
    nameAr: "310 ألماسة Free Fire",
    description: "310 ألماسة ($2.99) — تسليم خلال ساعات بعد التواصل",
    pointsCost: 150, type: "free_product", value: "2.99",
    emoji: "💠", accentColor: "#0ea5e9", sortOrder: 32, stock: 50, isActive: true,
  },
  {
    nameAr: "660 شدة PUBG (أفضل صفقة)",
    description: "660 شدة PUBG ($6.99) — صفقة مميزة بـ 300 نقطة فقط",
    pointsCost: 300, type: "free_product", value: "6.99",
    emoji: "🔫", accentColor: "#f97316", sortOrder: 33, stock: 50, isActive: true,
  },
  // ── VIP perks (more accessible) ──
  {
    nameAr: "ترقية VIP1 لمدة شهر",
    description: "احصل على خصومات VIP1 (1%) لمدة 30 يوم",
    pointsCost: 600, type: "vip_boost", value: "1",
    emoji: "⭐", accentColor: "#fbbf24", sortOrder: 40, stock: null, isActive: true,
  },
  {
    nameAr: "ترقية VIP2 لمدة شهر",
    description: "احصل على خصومات VIP2 (2%) لمدة 30 يوم",
    pointsCost: 1500, type: "vip_boost", value: "2",
    emoji: "🌟", accentColor: "#f59e0b", sortOrder: 41, stock: null, isActive: true,
  },
  // ── Premium subscriptions (high-value) ──
  {
    nameAr: "اشتراك Spotify شهر مجاني",
    description: "اشتراك Spotify Premium لمدة شهر (~$5)",
    pointsCost: 400, type: "free_product", value: "5",
    emoji: "🎵", accentColor: "#22c55e", sortOrder: 50, stock: 30, isActive: true,
  },
  {
    nameAr: "اشتراك YouTube Premium شهر",
    description: "اشتراك YouTube Premium لمدة شهر كامل (~$12) — بدون إعلانات",
    pointsCost: 700, type: "free_product", value: "12",
    emoji: "▶️", accentColor: "#ef4444", sortOrder: 51, stock: 25, isActive: true,
  },
  {
    nameAr: "بطاقة Google Play بـ $10",
    description: "بطاقة Google Play بقيمة $10 — تسليم خلال 24 ساعة",
    pointsCost: 700, type: "free_product", value: "10",
    emoji: "🎁", accentColor: "#10b981", sortOrder: 52, stock: 20, isActive: true,
  },
  {
    nameAr: "اشتراك Netflix شهر",
    description: "اشتراك Netflix لمدة شهر كامل (~$16) — جودة HD",
    pointsCost: 900, type: "free_product", value: "16",
    emoji: "🎬", accentColor: "#dc2626", sortOrder: 53, stock: 20, isActive: true,
  },
  {
    nameAr: "اشتراك ChatGPT Plus شهر",
    description: "اشتراك ChatGPT Plus لمدة شهر (~$20) — GPT-4 + DALL-E",
    pointsCost: 1100, type: "free_product", value: "20",
    emoji: "🤖", accentColor: "#10b981", sortOrder: 54, stock: 15, isActive: true,
  },
  {
    nameAr: "بطاقة Steam بـ $20",
    description: "بطاقة Steam بقيمة $20 — تسليم خلال 24 ساعة",
    pointsCost: 1300, type: "free_product", value: "20",
    emoji: "♨️", accentColor: "#1e40af", sortOrder: 55, stock: 15, isActive: true,
  },
  // ── Mystery boxes (fun, surprise reward) ──
  {
    nameAr: "🎁 الصندوق الغامض",
    description: "اربح مكافأة مفاجئة بقيمة $3 إلى $15 — UC، ألماسات، أو رصيد!",
    pointsCost: 350, type: "free_product", value: "10",
    emoji: "🎁", accentColor: "#a855f7", sortOrder: 60, stock: 50, isActive: true,
  },
  {
    nameAr: "🎰 الصندوق الذهبي (Mega)",
    description: "صندوق كبير بقيمة $20 إلى $50 — جوائز قيّمة جداً!",
    pointsCost: 1200, type: "free_product", value: "30",
    emoji: "🏆", accentColor: "#fbbf24", sortOrder: 61, stock: 15, isActive: true,
  },
];

router.post("/admin/loyalty/rewards/seed-defaults", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(loyaltyRewardsTable);
  if (Number(count) > 0) {
    res.json({ success: false, skipped: true, message: `Already has ${count} rewards — won't overwrite.`, existing: Number(count) });
    return;
  }
  const inserted = await db.insert(loyaltyRewardsTable).values(DEFAULT_REWARDS).returning();
  res.json({ success: true, inserted: inserted.length });
});

export { DEFAULT_REWARDS };

// Admin: mark redemption as delivered
router.patch("/admin/loyalty/redemptions/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = Number(req.params.id);
  const status = String(req.body?.status ?? "delivered");
  const adminNote = req.body?.adminNote ? String(req.body.adminNote).slice(0, 300) : null;
  const [updated] = await db.update(loyaltyRewardRedemptionsTable)
    .set({ status, adminNote })
    .where(eq(loyaltyRewardRedemptionsTable.id, id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Not found" }); return; }

  if (status === "delivered") {
    await db.insert(notificationsTable).values({
      userId: updated.userId,
      type: "loyalty_reward_delivered",
      title: `✅ ${updated.rewardName}`,
      message: `تم تسليم مكافأتك بنجاح${adminNote ? `: ${adminNote}` : ""}`,
      isRead: false,
    }).catch(() => {});
  }
  res.json(updated);
});

export default router;
