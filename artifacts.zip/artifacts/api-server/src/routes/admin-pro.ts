import { Router, type IRouter } from "express";
import {
  db, ordersTable, productsTable, usersTable, settingsTable,
  loginAttemptsTable, userSessionsTable, adminActivityLogTable,
} from "@workspace/db";
import { sql, eq, and, gte, lte, desc, count, ne } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";

const router: IRouter = Router();

// ─── Financial Summary ────────────────────────────────────────────────────────
router.get("/admin/financial/summary", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const now = Date.now();
  const since30 = new Date(now - 30 * 24 * 3600_000);
  const sincePrev30 = new Date(now - 60 * 24 * 3600_000);

  // SYP rate
  const [sypRow] = await db.select().from(settingsTable).where(eq(settingsTable.key, "syp_rate"));
  const sypRate = parseFloat(sypRow?.value ?? "13000");

  // Revenue + cost for net profit
  const [rev] = await db.select({
    revenue: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}::numeric), 0)::text`,
    cost: sql<string>`COALESCE(SUM(
      CASE
        WHEN ${productsTable.unitPriceUsd}::numeric > 0
        THEN ${ordersTable.qty}::numeric * ${productsTable.unitPriceUsd}::numeric
        ELSE ${ordersTable.totalPrice}::numeric / (1 + COALESCE(${productsTable.profitMargin}::numeric, 10) / 100)
      END
    ), 0)::text`,
    orderCount: sql<number>`count(${ordersTable.id})::int`,
  })
  .from(ordersTable)
  .leftJoin(productsTable, eq(ordersTable.productId, productsTable.id))
  .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since30)));

  const revenue = parseFloat(rev?.revenue ?? "0");
  const cost = parseFloat(rev?.cost ?? "0");
  const netProfit = revenue - cost;
  const orderCount = rev?.orderCount ?? 0;

  // Prev 30d revenue for comparison
  const [prevRev] = await db.select({
    revenue: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}::numeric), 0)::text`,
  })
  .from(ordersTable)
  .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, sincePrev30), lte(ordersTable.createdAt, since30)));
  const prevRevenue = parseFloat(prevRev?.revenue ?? "0");
  const revenueGrowth = prevRevenue > 0 ? ((revenue - prevRevenue) / prevRevenue) * 100 : 0;

  // Peak hours
  const peakHoursRaw = await db.select({
    hour: sql<number>`EXTRACT(HOUR FROM ${ordersTable.createdAt})::int`,
    cnt: sql<number>`count(*)::int`,
  })
  .from(ordersTable)
  .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since30)))
  .groupBy(sql`EXTRACT(HOUR FROM ${ordersTable.createdAt})`)
  .orderBy(desc(sql`count(*)`))
  .limit(24);

  // Conversion rate: users who placed at least 1 completed order / total users
  const [totalUsers] = await db.select({ c: sql<number>`count(*)::int` }).from(usersTable).where(eq(usersTable.role, "user"));
  const [activeUsers] = await db.select({ c: sql<number>`count(distinct ${ordersTable.userId})::int` })
    .from(ordersTable).where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since30)));
  const conversionRate = (totalUsers?.c ?? 0) > 0
    ? Math.round((activeUsers?.c ?? 0) / (totalUsers?.c ?? 1) * 100)
    : 0;

  // Daily net profit chart (last 30 days)
  const daily = await db.select({
    date: sql<string>`DATE(${ordersTable.createdAt} AT TIME ZONE 'Asia/Damascus')::text`,
    revenue: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}::numeric), 0)::text`,
    cost: sql<string>`COALESCE(SUM(
      CASE
        WHEN ${productsTable.unitPriceUsd}::numeric > 0
        THEN ${ordersTable.qty}::numeric * ${productsTable.unitPriceUsd}::numeric
        ELSE ${ordersTable.totalPrice}::numeric / (1 + COALESCE(${productsTable.profitMargin}::numeric, 10) / 100)
      END
    ), 0)::text`,
    orders: sql<number>`count(${ordersTable.id})::int`,
  })
  .from(ordersTable)
  .leftJoin(productsTable, eq(ordersTable.productId, productsTable.id))
  .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since30)))
  .groupBy(sql`DATE(${ordersTable.createdAt} AT TIME ZONE 'Asia/Damascus')`)
  .orderBy(sql`DATE(${ordersTable.createdAt} AT TIME ZONE 'Asia/Damascus')`);

  const avgOrderValue = orderCount > 0 ? revenue / orderCount : 0;

  // Deposits (SYP/USD deposits from wallet transactions if available, else estimate)
  res.json({
    revenue30d: revenue,
    revenueSyp30d: Math.round(revenue * sypRate),
    cost30d: cost,
    netProfit30d: netProfit,
    netProfitSyp30d: Math.round(netProfit * sypRate),
    orderCount30d: orderCount,
    avgOrderValue,
    revenueGrowthPct: parseFloat(revenueGrowth.toFixed(1)),
    conversionRate,
    totalUsers: totalUsers?.c ?? 0,
    activeUsers30d: activeUsers?.c ?? 0,
    sypRate,
    peakHours: peakHoursRaw,
    daily: daily.map(d => ({
      date: d.date,
      revenue: parseFloat(d.revenue),
      cost: parseFloat(d.cost),
      netProfit: parseFloat(d.revenue) - parseFloat(d.cost),
      revenueSyp: Math.round(parseFloat(d.revenue) * sypRate),
      orders: d.orders,
    })),
  });
});

// ─── Product Analytics ────────────────────────────────────────────────────────
router.get("/admin/products/:id/analytics", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = String(req.params.id);
  const now = Date.now();
  const since30 = new Date(now - 30 * 24 * 3600_000);
  const since7 = new Date(now - 7 * 24 * 3600_000);
  const prevWeekStart = new Date(now - 14 * 24 * 3600_000);

  const [summary] = await db.select({
    orders: sql<number>`count(${ordersTable.id})::int`,
    revenue: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}::numeric), 0)::text`,
    avgExecMin: sql<string>`COALESCE(AVG(
      EXTRACT(EPOCH FROM (${ordersTable.completedAt} - ${ordersTable.createdAt})) / 60
    ) FILTER (WHERE ${ordersTable.completedAt} IS NOT NULL), 0)::text`,
  })
  .from(ordersTable)
  .where(and(eq(ordersTable.productId, productId), gte(ordersTable.createdAt, since30)));

  const [thisWeek] = await db.select({ c: sql<number>`count(*)::int` })
    .from(ordersTable)
    .where(and(eq(ordersTable.productId, productId), gte(ordersTable.createdAt, since7)));

  const [prevWeek] = await db.select({ c: sql<number>`count(*)::int` })
    .from(ordersTable)
    .where(and(eq(ordersTable.productId, productId), gte(ordersTable.createdAt, prevWeekStart), lte(ordersTable.createdAt, since7)));

  const weekOverWeek = (prevWeek?.c ?? 0) > 0
    ? (((thisWeek?.c ?? 0) - (prevWeek?.c ?? 0)) / (prevWeek?.c ?? 1)) * 100
    : (thisWeek?.c ?? 0) > 0 ? 100 : 0;

  const byDay = await db.select({
    date: sql<string>`DATE(${ordersTable.createdAt} AT TIME ZONE 'Asia/Damascus')::text`,
    orders: sql<number>`count(*)::int`,
    revenue: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}::numeric), 0)::text`,
  })
  .from(ordersTable)
  .where(and(eq(ordersTable.productId, productId), gte(ordersTable.createdAt, since30)))
  .groupBy(sql`DATE(${ordersTable.createdAt} AT TIME ZONE 'Asia/Damascus')`)
  .orderBy(sql`DATE(${ordersTable.createdAt} AT TIME ZONE 'Asia/Damascus')`);

  res.json({
    orders30d: summary?.orders ?? 0,
    revenue30d: parseFloat(summary?.revenue ?? "0"),
    avgExecMinutes: parseFloat(parseFloat(summary?.avgExecMin ?? "0").toFixed(1)),
    thisWeekOrders: thisWeek?.c ?? 0,
    prevWeekOrders: prevWeek?.c ?? 0,
    weekOverWeekPct: parseFloat(weekOverWeek.toFixed(1)),
    byDay: byDay.map(d => ({ date: d.date, orders: d.orders, revenue: parseFloat(d.revenue) })),
  });
});

// ─── Security Overview ────────────────────────────────────────────────────────
router.get("/admin/security/overview", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const since24h = new Date(Date.now() - 24 * 3600_000);
  const since7d = new Date(Date.now() - 7 * 24 * 3600_000);

  const [failedLogins24h] = await db.select({ c: sql<number>`count(*)::int` })
    .from(loginAttemptsTable)
    .where(and(eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since24h)));

  const [failedLogins7d] = await db.select({ c: sql<number>`count(*)::int` })
    .from(loginAttemptsTable)
    .where(and(eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since7d)));

  const [activeSessions] = await db.select({ c: sql<number>`count(*)::int` }).from(userSessionsTable);

  const recentFailed = await db.select({
    ip: loginAttemptsTable.ip,
    username: loginAttemptsTable.username,
    createdAt: loginAttemptsTable.createdAt,
  })
  .from(loginAttemptsTable)
  .where(and(eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since24h)))
  .orderBy(desc(loginAttemptsTable.createdAt))
  .limit(20);

  const recentAdminActivity = await db.select({
    adminUsername: adminActivityLogTable.adminUsername,
    action: adminActivityLogTable.action,
    entity: adminActivityLogTable.entity,
    ip: adminActivityLogTable.ip,
    createdAt: adminActivityLogTable.createdAt,
  })
  .from(adminActivityLogTable)
  .orderBy(desc(adminActivityLogTable.createdAt))
  .limit(10);

  // Suspicious IPs: more than 5 failed attempts in 24h
  const suspiciousIps = await db.select({
    ip: loginAttemptsTable.ip,
    cnt: sql<number>`count(*)::int`,
  })
  .from(loginAttemptsTable)
  .where(and(eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since24h)))
  .groupBy(loginAttemptsTable.ip)
  .having(sql`count(*) >= 5`)
  .orderBy(desc(sql`count(*)`));

  res.json({
    failedLogins24h: failedLogins24h?.c ?? 0,
    failedLogins7d: failedLogins7d?.c ?? 0,
    activeSessions: activeSessions?.c ?? 0,
    recentFailed,
    recentAdminActivity,
    suspiciousIps,
  });
});

// ─── Logout all user sessions (admin action) ─────────────────────────────────
router.delete("/admin/sessions/all", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { userId } = req.body as { userId?: number };
  if (userId) {
    await db.delete(userSessionsTable).where(eq(userSessionsTable.userId, userId));
    res.json({ ok: true, detail: `Sessions cleared for user ${userId}` });
  } else {
    await db.delete(userSessionsTable).where(ne(userSessionsTable.userId, req.user!.id));
    res.json({ ok: true, detail: "All sessions cleared (except yours)" });
  }
});

// ─── Automation Config ────────────────────────────────────────────────────────
const AUTOMATION_KEYS = [
  "auto_retry_failed_orders",
  "auto_stop_loss_products",
  "auto_hide_unavailable_products",
  "price_sync_interval_minutes",
  "low_balance_threshold_syp",
  "sync_on_startup",
] as const;

const AUTOMATION_DEFAULTS: Record<string, string> = {
  auto_retry_failed_orders: "true",
  auto_stop_loss_products: "true",
  auto_hide_unavailable_products: "false",
  price_sync_interval_minutes: "60",
  low_balance_threshold_syp: "50000",
  sync_on_startup: "true",
};

router.get("/admin/automation/config", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rows = await db.select().from(settingsTable)
    .where(sql`${settingsTable.key} = ANY(ARRAY[${sql.join(AUTOMATION_KEYS.map(k => sql`${k}`), sql`, `)}])`);

  const config: Record<string, string> = { ...AUTOMATION_DEFAULTS };
  for (const row of rows) config[row.key] = row.value;
  res.json(config);
});

router.post("/admin/automation/config", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const body = req.body as Record<string, unknown>;
  const updates: { key: string; value: string }[] = [];
  for (const key of AUTOMATION_KEYS) {
    if (key in body && body[key] !== undefined) {
      updates.push({ key, value: String(body[key]) });
    }
  }
  if (updates.length === 0) { res.json({ ok: true }); return; }
  for (const { key, value } of updates) {
    await db.insert(settingsTable).values({ key, value })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
  }
  res.json({ ok: true, updated: updates.length });
});

// ─── Store Appearance Config ──────────────────────────────────────────────────
const STORE_APPEARANCE_KEYS = [
  "store_primary_color", "store_accent_color", "store_bg_color",
  "store_card_radius", "store_font", "store_logo_text",
] as const;

const STORE_APPEARANCE_DEFAULTS: Record<string, string> = {
  store_primary_color: "#6C5CE7",
  store_accent_color: "#FD79A8",
  store_bg_color: "#0f0e17",
  store_card_radius: "16",
  store_font: "inherit",
  store_logo_text: "Elite Store",
};

router.get("/admin/store-appearance", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rows = await db.select().from(settingsTable)
    .where(sql`${settingsTable.key} = ANY(ARRAY[${sql.join(STORE_APPEARANCE_KEYS.map(k => sql`${k}`), sql`, `)}])`);
  const config: Record<string, string> = { ...STORE_APPEARANCE_DEFAULTS };
  for (const row of rows) config[row.key] = row.value;
  res.json(config);
});

router.post("/admin/store-appearance", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const body = req.body as Record<string, unknown>;
  const updates: { key: string; value: string }[] = [];
  for (const key of STORE_APPEARANCE_KEYS) {
    if (key in body && body[key] !== undefined) {
      updates.push({ key, value: String(body[key]) });
    }
  }
  for (const { key, value } of updates) {
    await db.insert(settingsTable).values({ key, value })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
  }
  res.json({ ok: true, updated: updates.length });
});

// ─── Home Sections Config ─────────────────────────────────────────────────────
const DEFAULT_HOME_SECTIONS = [
  { id: "hero",             label: "السلايدر الرئيسي 🎠", type: "slider",      enabled: true  },
  { id: "ad_banner",        label: "بانر الإعلانات 📢",   type: "announcement", enabled: false },
  { id: "featured_bundles", label: "الباقات والعروض 🎁",  type: "bundles",      enabled: true  },
  { id: "quick_discount",   label: "الخصم السريع ⚡",     type: "flash_sale",   enabled: true  },
  { id: "categories",       label: "تصفح الأقسام 🗂️",    type: "categories",   enabled: true  },
];

router.get("/admin/home-sections", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, "home_sections_config"));
  if (!row?.value) { res.json({ sections: DEFAULT_HOME_SECTIONS }); return; }
  try { res.json({ sections: JSON.parse(row.value) }); }
  catch { res.json({ sections: DEFAULT_HOME_SECTIONS }); }
});

router.post("/admin/home-sections", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { sections } = req.body as { sections: unknown };
  if (!Array.isArray(sections)) { res.status(400).json({ error: "sections must be an array" }); return; }

  const value = JSON.stringify(sections);
  await db.insert(settingsTable).values({ key: "home_sections_config", value })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });

  const adBanner = (sections as any[]).find((s: any) => s.id === "ad_banner");
  if (adBanner !== undefined) {
    const announcementActive = adBanner.enabled ? "true" : "false";
    await db.insert(settingsTable).values({ key: "announcement_active", value: announcementActive })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value: announcementActive, updatedAt: new Date() } });
  }

  res.json({ ok: true });
});

// Public: used by the storefront to know which sections to show
router.get("/home-sections", async (_req: AuthRequest, res): Promise<void> => {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, "home_sections_config"));
  if (!row?.value) { res.json({ sections: DEFAULT_HOME_SECTIONS }); return; }
  try { res.json({ sections: JSON.parse(row.value) }); }
  catch { res.json({ sections: DEFAULT_HOME_SECTIONS }); }
});

// ─── Lightweight user balance endpoint ────────────────────────────────────────
router.get("/me/balance", async (req: AuthRequest, res): Promise<void> => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");
  if (!token) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { verifyToken } = await import("../lib/auth");
  const payload = verifyToken(token);
  if (!payload) { res.status(401).json({ error: "Invalid token" }); return; }
  const [user] = await db.select({ balance: usersTable.balance }).from(usersTable).where(eq(usersTable.id, payload.userId));
  if (!user) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ balance: user.balance });
});

export default router;
