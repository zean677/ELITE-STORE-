import { Router, type IRouter } from "express";
import { db, supportTicketsTable, supportMessagesTable, usersTable } from "@workspace/db";
import { eq, desc, and, count } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { z } from "zod/v4";

const router: IRouter = Router();

// ─── User: Create ticket ───────────────────────────────────────────────────────
router.post("/support/tickets", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const schema = z.object({
    subject: z.string().min(3).max(200),
    body: z.string().min(5).max(2000),
    orderId: z.string().optional(),
    priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }

  const { subject, body, orderId, priority } = parsed.data;
  const userId = req.user!.id;

  const [ticket] = await db.insert(supportTicketsTable).values({
    userId,
    subject,
    orderId: orderId ?? null,
    priority: priority ?? "medium",
    status: "open",
  }).returning();

  await db.insert(supportMessagesTable).values({
    ticketId: ticket.id,
    userId,
    body,
    isAdmin: "false",
  });

  res.json({ ticket });
});

// ─── User: List own tickets ────────────────────────────────────────────────────
router.get("/support/tickets", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const tickets = await db
    .select()
    .from(supportTicketsTable)
    .where(eq(supportTicketsTable.userId, userId))
    .orderBy(desc(supportTicketsTable.updatedAt))
    .limit(50);
  res.json({ tickets });
});

// ─── User: Get ticket + messages ──────────────────────────────────────────────
router.get("/support/tickets/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const ticketId = parseInt(String(req.params.id));
  const userId = req.user!.id;
  const isAdmin = req.user!.role === "admin";

  const [ticket] = await db.select().from(supportTicketsTable).where(eq(supportTicketsTable.id, ticketId));
  if (!ticket) { res.status(404).json({ error: "التذكرة غير موجودة" }); return; }
  if (!isAdmin && ticket.userId !== userId) { res.status(403).json({ error: "غير مصرح" }); return; }

  const messages = await db
    .select()
    .from(supportMessagesTable)
    .where(eq(supportMessagesTable.ticketId, ticketId))
    .orderBy(supportMessagesTable.createdAt);

  res.json({ ticket, messages });
});

// ─── User: Send message to ticket ─────────────────────────────────────────────
router.post("/support/tickets/:id/messages", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const ticketId = parseInt(String(req.params.id));
  const userId = req.user!.id;
  const isAdmin = req.user!.role === "admin";

  const schema = z.object({ body: z.string().min(1).max(2000) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "الرسالة فارغة" }); return; }

  const [ticket] = await db.select().from(supportTicketsTable).where(eq(supportTicketsTable.id, ticketId));
  if (!ticket) { res.status(404).json({ error: "التذكرة غير موجودة" }); return; }
  if (!isAdmin && ticket.userId !== userId) { res.status(403).json({ error: "غير مصرح" }); return; }
  if (ticket.status === "closed" && !isAdmin) { res.status(400).json({ error: "التذكرة مغلقة" }); return; }

  const [msg] = await db.insert(supportMessagesTable).values({
    ticketId,
    userId: isAdmin ? req.user!.id : userId,
    body: parsed.data.body,
    isAdmin: isAdmin ? "true" : "false",
  }).returning();

  // Mark ticket as in_progress when admin replies
  if (isAdmin && ticket.status === "open") {
    await db.update(supportTicketsTable)
      .set({ status: "in_progress", updatedAt: new Date() })
      .where(eq(supportTicketsTable.id, ticketId));
  } else if (!isAdmin && ticket.status !== "open") {
    // User replied — re-open if in_progress
    await db.update(supportTicketsTable)
      .set({ status: "open", updatedAt: new Date() })
      .where(eq(supportTicketsTable.id, ticketId));
  } else {
    await db.update(supportTicketsTable)
      .set({ updatedAt: new Date() })
      .where(eq(supportTicketsTable.id, ticketId));
  }

  res.json({ message: msg });
});

// ─── Admin: List all tickets ───────────────────────────────────────────────────
router.get("/admin/support/tickets", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const where = status && status !== "all" ? eq(supportTicketsTable.status, status) : undefined;

  const tickets = await db
    .select({
      id: supportTicketsTable.id,
      subject: supportTicketsTable.subject,
      status: supportTicketsTable.status,
      priority: supportTicketsTable.priority,
      orderId: supportTicketsTable.orderId,
      userId: supportTicketsTable.userId,
      createdAt: supportTicketsTable.createdAt,
      updatedAt: supportTicketsTable.updatedAt,
      closedAt: supportTicketsTable.closedAt,
      userName: usersTable.username,
      userEmail: usersTable.email,
    })
    .from(supportTicketsTable)
    .leftJoin(usersTable, eq(usersTable.id, supportTicketsTable.userId))
    .where(where)
    .orderBy(desc(supportTicketsTable.updatedAt))
    .limit(200);

  // Get message counts
  const counts = await db
    .select({ ticketId: supportMessagesTable.ticketId, total: count() })
    .from(supportMessagesTable)
    .groupBy(supportMessagesTable.ticketId);
  const countMap: Record<number, number> = {};
  for (const c of counts) countMap[c.ticketId] = c.total;

  const result = tickets.map(t => ({ ...t, messageCount: countMap[t.id] ?? 0 }));
  res.json({ tickets: result });
});

// ─── Admin: Update ticket status ──────────────────────────────────────────────
router.patch("/admin/support/tickets/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const ticketId = parseInt(String(req.params.id));
  const schema = z.object({
    status: z.enum(["open", "in_progress", "closed"]).optional(),
    priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }

  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (parsed.data.status) {
    updates.status = parsed.data.status;
    if (parsed.data.status === "closed") updates.closedAt = new Date();
  }
  if (parsed.data.priority) updates.priority = parsed.data.priority;

  const [ticket] = await db.update(supportTicketsTable).set(updates).where(eq(supportTicketsTable.id, ticketId)).returning();
  res.json({ ticket });
});

// ─── Admin: Stats summary ──────────────────────────────────────────────────────
router.get("/admin/support/stats", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const all = await db.select({ status: supportTicketsTable.status, c: count() })
    .from(supportTicketsTable)
    .groupBy(supportTicketsTable.status);
  const stats: Record<string, number> = {};
  for (const r of all) stats[r.status] = r.c;
  res.json({ stats });
});

export default router;
