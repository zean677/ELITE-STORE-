import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../lib/auth";
import { generateSecret, generateURI, generateSync, verifySync } from "otplib";
import QRCode from "qrcode";
import { z } from "zod";

const router: IRouter = Router();

const VerifyBody = z.object({ token: z.string().length(6) });
const DisableBody = z.object({ token: z.string().length(6) });

router.get("/auth/2fa/setup", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  if (user.totpEnabled) {
    res.json({ enabled: true });
    return;
  }

  const secret = generateSecret();
  const otpauth = generateURI({ strategy: "totp", issuer: "Elite Store", label: user.email, secret });
  const qrCodeDataUrl = await QRCode.toDataURL(otpauth);

  await db.update(usersTable).set({ totpSecret: secret }).where(eq(usersTable.id, userId));

  res.json({ enabled: false, secret, qrCode: qrCodeDataUrl, otpauth });
});

router.post("/auth/2fa/verify", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const parsed = VerifyBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid token" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user || !user.totpSecret) {
    res.status(400).json({ error: "2FA not set up yet" });
    return;
  }

  const isValid = verifySync({ strategy: "totp", token: parsed.data.token, secret: user.totpSecret });
  if (!isValid) {
    res.status(400).json({ error: "Invalid verification code" });
    return;
  }

  await db.update(usersTable).set({ totpEnabled: true }).where(eq(usersTable.id, userId));
  res.json({ success: true, message: "2FA enabled successfully" });
});

router.post("/auth/2fa/disable", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const parsed = DisableBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid token" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user || !user.totpSecret || !user.totpEnabled) {
    res.status(400).json({ error: "2FA is not enabled" });
    return;
  }

  const isValid = verifySync({ strategy: "totp", token: parsed.data.token, secret: user.totpSecret });
  if (!isValid) {
    res.status(400).json({ error: "Invalid verification code" });
    return;
  }

  await db.update(usersTable).set({ totpEnabled: false, totpSecret: null }).where(eq(usersTable.id, userId));
  res.json({ success: true, message: "2FA disabled" });
});

router.get("/auth/2fa/status", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ enabled: !!user.totpEnabled });
});

export default router;
