import { Router, type IRouter } from "express";
import { db, bundlesTable, bundleItemsTable, productsTable, ordersTable, usersTable, walletTransactionsTable, notificationsTable } from "@workspace/db";
import { eq, desc, and, asc, inArray, sql } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../lib/logger";
import { notifyNewOrder } from "../lib/telegram";
import { emitNewOrder } from "../lib/ws";
import { sendPushToUser } from "../lib/push";

const router: IRouter = Router();

async function loadBundleWithItems(id: number) {
  const [bundle] = await db.select().from(bundlesTable).where(eq(bundlesTable.id, id));
  if (!bundle) return null;
  const items = await db.select().from(bundleItemsTable).where(eq(bundleItemsTable.bundleId, id)).orderBy(asc(bundleItemsTable.sortOrder));
  const productIds = items.map(i => i.productId);
  const products = productIds.length > 0
    ? await db.select().from(productsTable).where(inArray(productsTable.id, productIds))
    : [];
  const productMap = new Map(products.map(p => [p.id, p]));
  const enrichedItems = items.map(i => {
    const p = productMap.get(i.productId);
    return {
      ...i,
      product: p ? {
        id: p.id,
        name: p.name,
        imageUrl: p.image,
        priceUsd: parseFloat(p.priceUsd ?? "0"),
        status: p.status,
        requiredFields: p.requiredFields ?? [],
      } : null,
    };
  });
  const originalTotal = enrichedItems.reduce((s, i) => s + (i.product ? i.product.priceUsd * i.qty : 0), 0);
  const bundlePrice = parseFloat(bundle.bundlePriceUsd ?? "0");
  const savings = Math.max(0, originalTotal - bundlePrice);
  return {
    ...bundle,
    bundlePriceUsd: bundlePrice,
    items: enrichedItems,
    originalTotalUsd: originalTotal,
    savingsUsd: savings,
    savingsPercent: originalTotal > 0 ? Math.round((savings / originalTotal) * 100) : 0,
  };
}

// ─── PUBLIC ───────────────────────────────────────────────────
router.get("/bundles", async (_req, res): Promise<void> => {
  const now = new Date();
  const rows = await db.select().from(bundlesTable).where(eq(bundlesTable.status, "active")).orderBy(desc(bundlesTable.isFeatured), asc(bundlesTable.sortOrder), desc(bundlesTable.createdAt));
  const valid = rows.filter(b => (!b.startsAt || b.startsAt <= now) && (!b.endsAt || b.endsAt >= now));
  const out = await Promise.all(valid.map(b => loadBundleWithItems(b.id)));
  res.json({ bundles: out.filter(Boolean) });
});

router.get("/bundles/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id as string, 10);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const b = await loadBundleWithItems(id);
  if (!b || b.status !== "active") { res.status(404).json({ error: "Bundle not found" }); return; }
  res.json(b);
});

// ─── PURCHASE ─────────────────────────────────────────────────
router.post("/bundles/:id/order", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(req.params.id as string, 10);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const b = await loadBundleWithItems(id);
  if (!b || b.status !== "active") { res.status(404).json({ error: "Bundle not found" }); return; }
  const now = new Date();
  if ((b.startsAt && b.startsAt > now) || (b.endsAt && b.endsAt < now)) {
    res.status(400).json({ error: "Bundle not currently available" }); return;
  }
  const playerIds: Record<string, string> = (req.body?.playerIds && typeof req.body.playerIds === "object") ? req.body.playerIds : {};
  const fieldValuesMap: Record<string, Record<string, string>> = (req.body?.fieldValues && typeof req.body.fieldValues === "object") ? req.body.fieldValues : {};

  // Validate all items
  for (const it of b.items) {
    if (!it.product || it.product.status !== "active") {
      res.status(400).json({ error: "Bundle contains an unavailable product", productId: it.productId }); return;
    }
    const required = it.product.requiredFields ?? [];
    if ((required.includes("playerId") || required.includes("email")) && !playerIds[it.productId]?.trim()) {
      res.status(400).json({ error: "Missing player id", productId: it.productId, message: `يرجى إدخال المعرف لـ ${it.product.name}` });
      return;
    }
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  const balance = parseFloat(user.balance ?? "0");
  const total = b.bundlePriceUsd;
  if (balance < total) { res.status(400).json({ error: "Insufficient balance", message: "رصيدك لا يكفي لشراء الحزمة" }); return; }

  // Atomically deduct
  const deducted = await db
    .update(usersTable)
    .set({ balance: sql`${usersTable.balance} - ${total.toString()}` })
    .where(and(eq(usersTable.id, req.user!.id), sql`${usersTable.balance} >= ${total.toString()}`))
    .returning();
  if (deducted.length === 0) { res.status(409).json({ error: "Balance changed", message: "تغير رصيدك، يرجى إعادة المحاولة" }); return; }

  await db.insert(walletTransactionsTable).values({
    userId: req.user!.id,
    type: "purchase",
    amount: (-total).toString(),
    currency: "USD",
    description: `🎁 حزمة: ${b.nameAr || b.name}`,
  });

  const purchaseId = uuidv4();
  const originalTotal = b.originalTotalUsd || total;
  const createdOrders: any[] = [];

  for (const it of b.items) {
    if (!it.product) continue;
    const itemOriginal = it.product.priceUsd * it.qty;
    const share = originalTotal > 0 ? (itemOriginal / originalTotal) * total : total / b.items.length;
    const orderId = uuidv4();
    const [o] = await db.insert(ordersTable).values({
      id: orderId,
      userId: req.user!.id,
      productId: it.productId,
      productName: `${it.product.name} (ضمن حزمة: ${b.nameAr || b.name})`,
      qty: it.qty,
      playerId: playerIds[it.productId] ?? null,
      fieldValues: fieldValuesMap[it.productId] ?? {},
      totalPrice: share.toString(),
      originalPrice: itemOriginal.toString(),
      paidAmount: share.toString(),
      paidCurrency: "USD",
      currency: "USD",
      status: "processing",
      bundleId: b.id,
      bundlePurchaseId: purchaseId,
    }).returning();
    createdOrders.push(o);

    notifyNewOrder({ username: user.username, productName: o.productName, price: share, orderId, currency: "USD" }).catch(() => {});
    emitNewOrder({ id: orderId, orderNumber: (o as any).orderNumber, productName: o.productName, username: user.username, totalPrice: share, status: "processing" });

    // Auto-approve per-product if enabled
    const [productRow] = await db.select().from(productsTable).where(eq(productsTable.id, it.productId));
    if ((productRow as any)?.autoApprove === true) {
      try {
        const { approveOrderById } = await import("../lib/order-actions");
        await approveOrderById(orderId, { username: "auto-approve(bundle)" });
      } catch (e) {
        logger.error({ err: e, orderId }, "Bundle auto-approve failed; remains processing");
      }
    }
  }

  await db.insert(notificationsTable).values({
    userId: req.user!.id,
    type: "order_completed",
    title: "🎁 تم استلام طلب الحزمة",
    message: `تم استلام طلبك لحزمة "${b.nameAr || b.name}" (${createdOrders.length} منتج). جاري المعالجة.`,
    isRead: false,
  });
  sendPushToUser(req.user!.id, { title: "🎁 تم استلام طلب الحزمة", body: `${b.nameAr || b.name} — ${createdOrders.length} منتج`, url: "/orders" }).catch(() => {});

  logger.info({ bundleId: b.id, purchaseId, userId: req.user!.id, count: createdOrders.length }, "Bundle order placed");
  res.status(201).json({ purchaseId, bundleId: b.id, totalPaid: total, orders: createdOrders });
});

// ─── ADMIN CRUD ───────────────────────────────────────────────
router.get("/admin/bundles", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select().from(bundlesTable).orderBy(desc(bundlesTable.createdAt));
  const out = await Promise.all(rows.map(r => loadBundleWithItems(r.id)));
  res.json({ bundles: out.filter(Boolean) });
});

router.get("/admin/bundles/:id", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id as string, 10);
  const b = await loadBundleWithItems(id);
  if (!b) { res.status(404).json({ error: "Not found" }); return; }
  res.json(b);
});

router.post("/admin/bundles", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const { name, nameAr, description, imageUrl, bundlePriceUsd, status, badge, sortOrder, isFeatured, startsAt, endsAt, items } = req.body ?? {};
  if (!name || typeof bundlePriceUsd !== "number") { res.status(400).json({ error: "name and bundlePriceUsd required" }); return; }
  const [created] = await db.insert(bundlesTable).values({
    name, nameAr: nameAr ?? null, description: description ?? null, imageUrl: imageUrl ?? null,
    bundlePriceUsd: String(bundlePriceUsd),
    status: status ?? "active",
    badge: badge ?? null,
    sortOrder: typeof sortOrder === "number" ? sortOrder : 0,
    isFeatured: Boolean(isFeatured),
    startsAt: startsAt ? new Date(startsAt) : null,
    endsAt: endsAt ? new Date(endsAt) : null,
  }).returning();
  if (Array.isArray(items)) {
    for (const [idx, it] of items.entries()) {
      if (!it?.productId) continue;
      await db.insert(bundleItemsTable).values({
        bundleId: created.id,
        productId: String(it.productId),
        qty: Math.max(1, parseInt(String(it.qty ?? 1), 10) || 1),
        sortOrder: typeof it.sortOrder === "number" ? it.sortOrder : idx,
      });
    }
  }
  const out = await loadBundleWithItems(created.id);
  res.status(201).json(out);
});

router.put("/admin/bundles/:id", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id as string, 10);
  const { name, nameAr, description, imageUrl, bundlePriceUsd, status, badge, sortOrder, isFeatured, startsAt, endsAt, items } = req.body ?? {};
  const patch: any = {};
  if (name !== undefined) patch.name = name;
  if (nameAr !== undefined) patch.nameAr = nameAr;
  if (description !== undefined) patch.description = description;
  if (imageUrl !== undefined) patch.imageUrl = imageUrl;
  if (typeof bundlePriceUsd === "number") patch.bundlePriceUsd = String(bundlePriceUsd);
  if (status !== undefined) patch.status = status;
  if (badge !== undefined) patch.badge = badge;
  if (typeof sortOrder === "number") patch.sortOrder = sortOrder;
  if (isFeatured !== undefined) patch.isFeatured = Boolean(isFeatured);
  if (startsAt !== undefined) patch.startsAt = startsAt ? new Date(startsAt) : null;
  if (endsAt !== undefined) patch.endsAt = endsAt ? new Date(endsAt) : null;
  if (Object.keys(patch).length > 0) {
    await db.update(bundlesTable).set(patch).where(eq(bundlesTable.id, id));
  }
  if (Array.isArray(items)) {
    await db.delete(bundleItemsTable).where(eq(bundleItemsTable.bundleId, id));
    for (const [idx, it] of items.entries()) {
      if (!it?.productId) continue;
      await db.insert(bundleItemsTable).values({
        bundleId: id,
        productId: String(it.productId),
        qty: Math.max(1, parseInt(String(it.qty ?? 1), 10) || 1),
        sortOrder: typeof it.sortOrder === "number" ? it.sortOrder : idx,
      });
    }
  }
  const out = await loadBundleWithItems(id);
  res.json(out);
});

router.delete("/admin/bundles/:id", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id as string, 10);
  await db.delete(bundleItemsTable).where(eq(bundleItemsTable.bundleId, id));
  await db.delete(bundlesTable).where(eq(bundlesTable.id, id));
  res.json({ ok: true });
});

export default router;
