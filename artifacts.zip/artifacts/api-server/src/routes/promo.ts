import { Router, type IRouter } from "express";
import { db, promoCodesTable, promoCodeUsagesTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { z } from "zod";

const router: IRouter = Router();

const CreatePromoBody = z.object({
  code: z.string().min(3).max(30).toUpperCase(),
  discountType: z.enum(["percent", "fixed"]),
  discountValue: z.number().positive(),
  maxUses: z.number().int().positive().optional(),
  minOrderUsd: z.number().min(0).optional(),
  maxDiscountUsd: z.number().positive().optional(),
  expiresAt: z.string().optional(),
});

const ValidatePromoBody = z.object({
  code: z.string(),
  orderAmountUsd: z.number().positive(),
});

router.post("/promo/validate", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = ValidatePromoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const { code, orderAmountUsd } = parsed.data;
  const userId = req.user!.id;

  const [promo] = await db
    .select()
    .from(promoCodesTable)
    .where(and(eq(promoCodesTable.code, code.toUpperCase()), eq(promoCodesTable.isActive, true)));

  if (!promo) {
    res.status(404).json({ error: "Invalid or expired promo code" });
    return;
  }

  if (promo.expiresAt && new Date(promo.expiresAt) < new Date()) {
    res.status(400).json({ error: "Promo code has expired" });
    return;
  }

  if (promo.maxUses !== null && promo.usedCount >= promo.maxUses) {
    res.status(400).json({ error: "Promo code usage limit reached" });
    return;
  }

  const minOrder = parseFloat(promo.minOrderUsd ?? "0");
  if (orderAmountUsd < minOrder) {
    res.status(400).json({ error: `Minimum order amount is $${minOrder.toFixed(2)}` });
    return;
  }

  const [alreadyUsed] = await db
    .select()
    .from(promoCodeUsagesTable)
    .where(and(eq(promoCodeUsagesTable.promoCodeId, promo.id), eq(promoCodeUsagesTable.userId, userId)));

  if (alreadyUsed) {
    res.status(400).json({ error: "You have already used this promo code" });
    return;
  }

  const discountValue = parseFloat(promo.discountValue ?? "0");
  let discountUsd = 0;
  if (promo.discountType === "percent") {
    discountUsd = (orderAmountUsd * discountValue) / 100;
    if (promo.maxDiscountUsd) {
      discountUsd = Math.min(discountUsd, parseFloat(promo.maxDiscountUsd));
    }
  } else {
    discountUsd = discountValue;
  }
  discountUsd = Math.min(discountUsd, orderAmountUsd);

  res.json({
    valid: true,
    promoId: promo.id,
    discountType: promo.discountType,
    discountValue,
    discountUsd: Math.round(discountUsd * 10000) / 10000,
    finalAmountUsd: Math.round((orderAmountUsd - discountUsd) * 10000) / 10000,
  });
});

router.get("/admin/promo-codes", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const codes = await db.select().from(promoCodesTable).orderBy(sql`${promoCodesTable.createdAt} DESC`);
  res.json(codes.map(c => ({
    ...c,
    discountValue: parseFloat(c.discountValue ?? "0"),
    minOrderUsd: parseFloat(c.minOrderUsd ?? "0"),
    maxDiscountUsd: c.maxDiscountUsd ? parseFloat(c.maxDiscountUsd) : null,
  })));
});

router.post("/admin/promo-codes", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreatePromoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", details: parsed.error.message });
    return;
  }

  const { code, discountType, discountValue, maxUses, minOrderUsd, maxDiscountUsd, expiresAt } = parsed.data;

  const [existing] = await db.select().from(promoCodesTable).where(eq(promoCodesTable.code, code));
  if (existing) {
    res.status(400).json({ error: "Promo code already exists" });
    return;
  }

  const [created] = await db
    .insert(promoCodesTable)
    .values({
      code,
      discountType,
      discountValue: String(discountValue),
      maxUses: maxUses ?? null,
      minOrderUsd: minOrderUsd !== undefined ? String(minOrderUsd) : "0",
      maxDiscountUsd: maxDiscountUsd !== undefined ? String(maxDiscountUsd) : null,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      isActive: true,
    })
    .returning();

  res.json({ success: true, promoCode: created });
});

router.patch("/admin/promo-codes/:id/toggle", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(req.params.id as string);
  const [promo] = await db.select().from(promoCodesTable).where(eq(promoCodesTable.id, id));
  if (!promo) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  const [updated] = await db
    .update(promoCodesTable)
    .set({ isActive: !promo.isActive })
    .where(eq(promoCodesTable.id, id))
    .returning();
  res.json({ success: true, isActive: updated.isActive });
});

router.delete("/admin/promo-codes/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(req.params.id as string);
  await db.delete(promoCodeUsagesTable).where(eq(promoCodeUsagesTable.promoCodeId, id));
  await db.delete(promoCodesTable).where(eq(promoCodesTable.id, id));
  res.json({ success: true });
});

export default router;
