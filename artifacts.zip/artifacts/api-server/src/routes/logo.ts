import { Router, type IRouter } from "express";

const router: IRouter = Router();

const LOGO_CACHE = new Map<string, { buf: Buffer; ct: string; ts: number }>();
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 h

router.get("/logo", async (req, res) => {
  const domain = String(req.query.domain || "").toLowerCase().trim();

  if (!domain || !/^[a-z0-9][a-z0-9.-]{0,200}\.[a-z]{2,}$/.test(domain)) {
    res.status(400).json({ error: "Invalid domain" });
    return;
  }

  // Serve from in-memory cache
  const cached = LOGO_CACHE.get(domain);
  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    res.set("Content-Type", cached.ct);
    res.set("Cache-Control", "public, max-age=86400");
    res.set("X-Cache", "HIT");
    res.send(cached.buf);
    return;
  }

  const sources = [
    `https://logo.clearbit.com/${domain}?size=256`,
    `https://icon.horse/icon/${domain}`,
    `https://www.google.com/s2/favicons?domain=${domain}&sz=128`,
  ];

  for (const url of sources) {
    try {
      const resp = await fetch(url, {
        signal: AbortSignal.timeout(6000),
        headers: {
          "User-Agent": "EliteStore/1.0 (+https://elite-store.com)",
          Accept: "image/*,*/*",
        },
      });

      if (!resp.ok) continue;

      const ct = resp.headers.get("content-type") || "image/png";
      if (!ct.startsWith("image/")) continue;

      const buf = Buffer.from(await resp.arrayBuffer());
      if (buf.length < 100) continue;

      LOGO_CACHE.set(domain, { buf, ct, ts: Date.now() });

      res.set("Content-Type", ct);
      res.set("Cache-Control", "public, max-age=86400");
      res.set("X-Cache", "MISS");
      res.send(buf);
      return;
    } catch {
      continue;
    }
  }

  res.status(404).end();
});

export default router;
