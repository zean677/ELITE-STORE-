import { Router, type IRouter } from "express";
import { db, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";

const router: IRouter = Router();

const DEFAULT_SETTINGS: Record<string, string> = {
  syp_rate: "13000",
  eur_rate: "0.92",
  default_profit_margin: "10",
  announcement: "",
  announcement_active: "false",
  announcement_type: "info",
  maintenance_mode: "false",

  // ─── Single-provider configuration (admin-editable) ────────────────────────
  provider_name: "megagame",
  provider_display_name: "Fast API (Mega Game)",
  provider_base_url: "https://mega-game.net/api",
  provider_api_token: "x76mc7wrsjr1755ov33st659hh",
  provider_enabled: "true",
  provider_endpoint_games: "/fastapi/products",
  provider_endpoint_products: "/fastapi/products",
  provider_endpoint_profile: "/fastapi/balance",
  provider_endpoint_newOrder: "/fastapi/requestorder",
  provider_endpoint_check: "/fastapi/checkorders",
  // SYP (Syrian pound) — alert when remote balance falls below this value.
  provider_balance_threshold_syp: "100000",

  vip_level_1_threshold: "100",
  vip_level_1_discount: "1",
  vip_level_2_threshold: "300",
  vip_level_2_discount: "2",
  vip_level_3_threshold: "700",
  vip_level_3_discount: "4",
  vip_level_4_threshold: "1500",
  vip_level_4_discount: "7",

  // ─── Telegram bot operational controls ─────────────────────────────────────
  orders_paused: "false",
  telegram_silent_start: "",
  telegram_silent_end: "",

  // ─── VIP Display & Leaderboard ─────────────────────────────────────────────
  vip_leaderboard_enabled: "false",

  // ─── Order automation & safety guards ──────────────────────────────────────
  // Auto-cancel & refund orders that have been "processing" longer than this.
  order_timeout_minutes: "30",
  // Block dispatch when sell price < provider cost (auto-deactivates product).
  enforce_profit_margin: "true",
  // Status poller interval — informational; the poller itself reads code default 30s
  order_status_check_interval_seconds: "30",
};

// Keys that the admin Settings PUT endpoint will accept and persist.
const ALLOWED_KEYS = new Set<string>([
  "syp_rate", "eur_rate", "default_profit_margin",
  "announcement", "announcement_active", "announcement_type", "maintenance_mode",
  "provider_name", "provider_display_name", "provider_base_url", "provider_api_token",
  "provider_enabled",
  "provider_endpoint_games", "provider_endpoint_products", "provider_endpoint_profile",
  "provider_endpoint_newOrder", "provider_endpoint_check",
  "provider_balance_threshold_syp",
  "vip_level_1_threshold", "vip_level_1_discount",
  "vip_level_2_threshold", "vip_level_2_discount",
  "vip_level_3_threshold", "vip_level_3_discount",
  "vip_level_4_threshold", "vip_level_4_discount",
  "vip_leaderboard_enabled",
  "orders_paused", "telegram_silent_start", "telegram_silent_end",
  "order_timeout_minutes", "enforce_profit_margin", "order_status_check_interval_seconds",
  "product_card_style", "category_card_style", "image_cache_version",
  "auto_retry_failed_orders", "auto_stop_loss_products", "auto_hide_unavailable_products",
  "price_sync_interval_minutes", "low_balance_threshold_syp", "sync_on_startup",
  "store_primary_color", "store_accent_color", "store_bg_color",
  "store_card_radius", "store_font", "store_logo_text",
]);

async function getSetting(key: string): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  // Use || so an empty string in DB falls back to the code default.
  return row?.value || DEFAULT_SETTINGS[key] || "";
}

router.get("/settings", async (req, res): Promise<void> => {
  const rows = await db.select().from(settingsTable);
  const map: Record<string, string> = { ...DEFAULT_SETTINGS };
  for (const row of rows) {
    // Only override the default when the stored value is non-empty.
    // An empty string in the DB is treated the same as "not set".
    if (row.value) map[row.key] = row.value;
  }
  res.json(map);
});

router.put("/admin/settings", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const updates: { key: string; value: string }[] = [];
  for (const [key, value] of Object.entries(body)) {
    if (!ALLOWED_KEYS.has(key)) continue;
    if (value === undefined || value === null) continue;
    updates.push({ key, value: String(value) });
  }

  for (const { key, value } of updates) {
    await db
      .insert(settingsTable)
      .values({ key, value })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
  }

  const rows = await db.select().from(settingsTable);
  const map: Record<string, string> = { ...DEFAULT_SETTINGS };
  for (const row of rows) map[row.key] = row.value;
  res.json(map);
});

export { getSetting };
export default router;
