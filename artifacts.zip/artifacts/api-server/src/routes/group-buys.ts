import { Router, type IRouter } from "express";
import { db, groupBuysTable, groupBuyParticipantsTable } from "@workspace/db";
import { promoCodesTable } from "@workspace/db";
import { eq, desc, and, sql, count } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { z } from "zod/v4";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ─── Public: list active group buys ──────────────────────────────────────────
router.get("/group-buys", async (req, res): Promise<void> => {
  const now = new Date();
  const buys = await db.select().from(groupBuysTable)
    .where(and(eq(groupBuysTable.status, "open"), sql`${groupBuysTable.endsAt} > ${now}`))
    .orderBy(desc(groupBuysTable.createdAt))
    .limit(20);

  // Attach participant counts
  const counts = await db.select({ groupBuyId: groupBuyParticipantsTable.groupBuyId, total: count() })
    .from(groupBuyParticipantsTable)
    .groupBy(groupBuyParticipantsTable.groupBuyId);
  const countMap: Record<number, number> = {};
  for (const c of counts) countMap[c.groupBuyId] = c.total;

  res.json({ groupBuys: buys.map(b => ({ ...b, participantCount: countMap[b.id] ?? 0 })) });
});

// ─── Public: get single group buy ────────────────────────────────────────────
router.get("/group-buys/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  const [buy] = await db.select().from(groupBuysTable).where(eq(groupBuysTable.id, id));
  if (!buy) { res.status(404).json({ error: "غير موجود" }); return; }

  const participants = await db.select({
    username: groupBuyParticipantsTable.username,
    joinedAt: groupBuyParticipantsTable.joinedAt,
  }).from(groupBuyParticipantsTable)
    .where(eq(groupBuyParticipantsTable.groupBuyId, id))
    .orderBy(groupBuyParticipantsTable.joinedAt)
    .limit(50);

  res.json({ groupBuy: buy, participants });
});

// ─── Join a group buy ─────────────────────────────────────────────────────────
router.post("/group-buys/:id/join", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  const userId = req.user!.id;
  const username = req.user!.username;

  const [buy] = await db.select().from(groupBuysTable).where(eq(groupBuysTable.id, id));
  if (!buy) { res.status(404).json({ error: "غير موجود" }); return; }
  if (buy.status !== "open") { res.status(400).json({ error: "هذا العرض لم يعد متاحاً" }); return; }
  if (new Date() > buy.endsAt) { res.status(400).json({ error: "انتهت مدة هذا العرض" }); return; }

  // Check if already joined
  const existing = await db.select().from(groupBuyParticipantsTable)
    .where(and(eq(groupBuyParticipantsTable.groupBuyId, id), eq(groupBuyParticipantsTable.userId, userId)));
  if (existing.length > 0) { res.status(400).json({ error: "انضممت لهذا العرض مسبقاً" }); return; }

  await db.insert(groupBuyParticipantsTable).values({ groupBuyId: id, userId, username });

  // Update participant count
  const newQty = buy.currentQty + 1;
  await db.update(groupBuysTable).set({ currentQty: newQty }).where(eq(groupBuysTable.id, id));

  // Auto-complete if target reached
  if (newQty >= buy.targetQty) {
    // Generate promo code
    const code = `GB${id}-${Date.now().toString(36).toUpperCase()}`;
    await db.insert(promoCodesTable).values({
      code,
      discountType: "percentage",
      discountValue: buy.discountPct,
      usageLimit: buy.targetQty + 10,
      usageCount: 0,
      productId: buy.productId === "all" ? null : buy.productId,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      isActive: true,
    } as any).catch(() => {});

    await db.update(groupBuysTable).set({ status: "completed", promoCode: code }).where(eq(groupBuysTable.id, id));
    logger.info({ groupBuyId: id, code }, "Group buy completed — promo code generated");
    res.json({ joined: true, completed: true, promoCode: code });
    return;
  }

  res.json({ joined: true, completed: false, currentQty: newQty, targetQty: buy.targetQty });
});

// ─── Check if user joined ─────────────────────────────────────────────────────
router.get("/group-buys/:id/my-status", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  const userId = req.user!.id;
  const existing = await db.select().from(groupBuyParticipantsTable)
    .where(and(eq(groupBuyParticipantsTable.groupBuyId, id), eq(groupBuyParticipantsTable.userId, userId)));
  res.json({ joined: existing.length > 0 });
});

// ─── Admin: create group buy ──────────────────────────────────────────────────
router.post("/admin/group-buys", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const schema = z.object({
    productId: z.string(),
    productName: z.string().min(2),
    productImageUrl: z.string().optional(),
    targetQty: z.number().int().min(2).max(10000),
    discountPct: z.number().min(1).max(80),
    originalPriceUsd: z.number().min(0),
    groupPriceUsd: z.number().min(0),
    endsAt: z.string(), // ISO date string
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "بيانات غير صحيحة", details: parsed.error }); return; }

  const [buy] = await db.insert(groupBuysTable).values({
    ...parsed.data,
    originalPriceUsd: String(parsed.data.originalPriceUsd),
    groupPriceUsd: String(parsed.data.groupPriceUsd),
    discountPct: String(parsed.data.discountPct),
    endsAt: new Date(parsed.data.endsAt),
  }).returning();

  res.json({ groupBuy: buy });
});

// ─── Admin: list all group buys ───────────────────────────────────────────────
router.get("/admin/group-buys", requireAdmin, async (_req, res): Promise<void> => {
  const buys = await db.select().from(groupBuysTable).orderBy(desc(groupBuysTable.createdAt)).limit(100);
  res.json({ groupBuys: buys });
});

// ─── Admin: cancel group buy ──────────────────────────────────────────────────
router.patch("/admin/group-buys/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  const schema = z.object({ status: z.enum(["cancelled", "completed", "open"]) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }
  const [buy] = await db.update(groupBuysTable).set({ status: parsed.data.status }).where(eq(groupBuysTable.id, id)).returning();
  res.json({ groupBuy: buy });
});

export default router;
