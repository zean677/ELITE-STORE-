import { Router, type IRouter } from "express";
import { handleTelegramUpdate, configureTelegramWebhook, deleteTelegramWebhook, getTelegramWebhookInfo, sendTestMessage } from "../lib/telegram";
import { getBotHealth, getQueueStats } from "../lib/telegram-queue";
import { requireAdmin } from "../lib/auth";

const router: IRouter = Router();

// Public webhook endpoint for Telegram to POST updates to
router.post("/telegram/webhook", async (req, res): Promise<void> => {
  await handleTelegramUpdate(req.body);
  res.json({ ok: true });
});

// Status — no auth needed for health checks
router.get("/telegram/status", (_req, res): void => {
  const replitDomains = process.env.REPLIT_DOMAINS?.trim() ?? "";
  const siteUrl = process.env.SITE_URL?.trim() ?? "";
  const webhookBase = process.env.TELEGRAM_WEBHOOK_URL?.trim()
    || (siteUrl ? `${siteUrl.replace(/\/$/, "")}` : "")
    || (replitDomains ? `https://${replitDomains.split(",")[0].trim()}` : "");

  res.json({
    ok: true,
    botTokenSet: !!(process.env.TELEGRAM_BOT_TOKEN?.trim()),
    adminChatIdSet: !!(process.env.TELEGRAM_ADMIN_CHAT_ID?.trim()),
    webhookUrl: webhookBase ? `${webhookBase}/api/telegram/webhook` : null,
    siteUrl: siteUrl || null,
    replitDomains: replitDomains || null,
  });
});

// Admin: get webhook info from Telegram
router.get("/admin/telegram/webhook-info", requireAdmin, async (_req, res): Promise<void> => {
  try {
    const info = await getTelegramWebhookInfo();
    res.json({ ok: true, info });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message });
  }
});

// Admin: re-register webhook
router.post("/admin/telegram/set-webhook", requireAdmin, async (_req, res): Promise<void> => {
  try {
    await configureTelegramWebhook();
    const info = await getTelegramWebhookInfo();
    res.json({ ok: true, info });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message });
  }
});

// Admin: delete webhook (switch to polling mode)
router.delete("/admin/telegram/webhook", requireAdmin, async (_req, res): Promise<void> => {
  try {
    const result = await deleteTelegramWebhook();
    res.json({ ok: true, result });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message });
  }
});

// Admin: bot health + queue stats (used by /admin/telegram dashboard)
router.get("/admin/telegram/health", requireAdmin, (_req, res): void => {
  res.json({
    ok: true,
    bot: getBotHealth(),
    queue: getQueueStats(),
    config: {
      botTokenSet: !!(process.env.TELEGRAM_BOT_TOKEN?.trim()),
      adminChatIdSet: !!(process.env.TELEGRAM_ADMIN_CHAT_ID?.trim() || "2113043286"),
      ownerHandle: "@zean_10M",
      ownerId: "2113043286",
    },
  });
});

// Admin: send test message
router.post("/admin/telegram/test", requireAdmin, async (_req, res): Promise<void> => {
  try {
    const sent = await sendTestMessage();
    res.json({ ok: sent, message: sent ? "Test message sent to Telegram." : "Failed to send — check BOT_TOKEN and ADMIN_CHAT_ID." });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message });
  }
});

export default router;
