import { Router, type IRouter } from "express";
import { db, ordersTable, productsTable, usersTable, walletTransactionsTable, notificationsTable, settingsTable } from "@workspace/db";
import { eq, desc, and, count, sql } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../lib/auth";
import { CreateOrderBody, GetOrdersQueryParams, GetOrderParams } from "@workspace/api-zod";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../lib/logger";
import { notifyNewOrder, notifyOrderSuccess, notifyOrderFailed, notifyHighValueOrder } from "../lib/telegram";
import { applyCompletedOrderSpend, getUserVipProfile } from "../lib/vip";
import { emitNewOrder, emitOrderUpdate } from "../lib/ws";
import { dispatchOrder, type ProviderName } from "../lib/providers";

const router: IRouter = Router();

async function getSettingVal(key: string, def: string): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  return row?.value ?? def;
}

async function getCurrencyRates(): Promise<Record<string, number>> {
  const sypRate = parseFloat(await getSettingVal("syp_rate", "13000"));
  const eurRate = parseFloat(await getSettingVal("eur_rate", "0.92"));
  return { USD: 1, SYP: Number.isFinite(sypRate) ? sypRate : 13000, EUR: Number.isFinite(eurRate) ? eurRate : 0.92 };
}

async function dispatchToProvider(order: any, product: any): Promise<{ success: boolean; providerOrderId?: string; error?: string }> {
  const provider = (product?.provider ?? "manual") as ProviderName | "manual";
  if (provider === "manual") {
    // Manual products — admin processes manually
    return { success: true, providerOrderId: order.id };
  }
  return dispatchOrder(provider, { providerProductId: product.providerProductId ?? null }, {
    id: order.id,
    qty: order.qty,
    playerId: order.playerId ?? "",
    fieldValues: order.fieldValues ?? null,
  });
}

router.get("/orders", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetOrdersQueryParams.safeParse(req.query);
  const page = qp.success ? (qp.data.page ?? 1) : 1;
  const limit = qp.success ? (qp.data.limit ?? 20) : 20;
  const status = qp.success ? qp.data.status : undefined;
  const offset = (page - 1) * limit;

  const conditions = [eq(ordersTable.userId, req.user!.id)];
  if (status) {
    conditions.push(eq(ordersTable.status, status));
  }
  const whereClause = conditions.length === 1 ? conditions[0] : and(...conditions);

  const [totalResult] = await db.select({ count: count() }).from(ordersTable).where(whereClause);
  const orders = await db
    .select()
    .from(ordersTable)
    .where(whereClause)
    .orderBy(desc(ordersTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json({
    orders: orders.map(o => ({ ...o, totalPrice: parseFloat(o.totalPrice ?? "0") })),
    total: totalResult?.count ?? 0,
    page,
    limit,
  });
});

router.post("/orders", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  // Maintenance mode block
  const maintenanceEnabled = (await getSettingVal("maintenance.enabled", "false")) === "true";
  if (maintenanceEnabled && req.user?.role !== "admin") {
    const msg = await getSettingVal("maintenance.message", "المتجر تحت الصيانة مؤقتاً، يرجى المحاولة لاحقاً.");
    res.status(503).json({ error: "Maintenance mode", message: msg });
    return;
  }

  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { productId, qty, playerId, currency = "USD" } = parsed.data;

  // Accept dynamic field values (not part of generated zod schema)
  const rawFieldValues = (req.body as any)?.formValues ?? (req.body as any)?.fieldValues;
  const fieldValues: Record<string, string> = {};
  if (rawFieldValues && typeof rawFieldValues === "object") {
    for (const [k, v] of Object.entries(rawFieldValues)) {
      if (typeof v === "string" && v.trim()) {
        fieldValues[String(k).slice(0, 64)] = String(v).slice(0, 500);
      }
    }
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!product || product.status !== "active") {
    res.status(404).json({ error: "Product not found or inactive" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  // Global "orders paused" admin switch (toggleable from Telegram /pause /resume)
  const paused = await getSettingVal("orders_paused", "false");
  if (paused === "true") {
    res.status(503).json({ error: "Orders paused", message: "استقبال الطلبات متوقّف مؤقتاً من قبل الإدارة. حاول لاحقاً." });
    return;
  }

  const requiredFields = product.requiredFields ?? [];
  if ((requiredFields.includes("playerId") || requiredFields.includes("email")) && !playerId?.trim()) {
    res.status(400).json({ error: "Missing required field", message: "Player ID or account identifier is required for this product" });
    return;
  }

  const minQty = product.qtyMin ? parseFloat(product.qtyMin) : 1;
  const maxQty = product.qtyMax ? parseFloat(product.qtyMax) : undefined;
  if (qty < minQty || (maxQty !== undefined && qty > maxQty)) {
    res.status(400).json({ error: "Invalid quantity", message: `Quantity must be between ${minQty}${maxQty ? ` and ${maxQty}` : ""}` });
    return;
  }

  const rates = await getCurrencyRates();
  const rate = rates[currency] ?? 1;
  const priceUsd = parseFloat(product.priceUsd ?? "0");
  const subtotalUsd = priceUsd * qty;
  const vip = await getUserVipProfile(user);
  const vipDiscountPercent = vip.discountPercent;
  const discountUsd = subtotalUsd * (vipDiscountPercent / 100);
  const deductUsd = Math.max(0, subtotalUsd - discountUsd);
  // Canonical wallet amount (always USD).
  const totalPrice = deductUsd;
  // The exact figure shown to the customer at checkout, frozen at purchase
  // time. We use this rate snapshot so future rate changes never alter the
  // displayed paid amount.
  const paidAmount = deductUsd * rate;
  const paidCurrency = currency;
  const userBalanceUsd = parseFloat(user.balance ?? "0");

  if (userBalanceUsd < deductUsd) {
    res.status(400).json({ error: "Insufficient balance", message: "Your wallet balance is insufficient for this order" });
    return;
  }

  const orderId = uuidv4();
  const deducted = await db
    .update(usersTable)
    .set({ balance: sql`${usersTable.balance} - ${deductUsd.toString()}` })
    .where(and(eq(usersTable.id, req.user!.id), sql`${usersTable.balance} >= ${deductUsd.toString()}`))
    .returning();

  if (deducted.length === 0) {
    res.status(409).json({ error: "Balance locked", message: "Your balance changed before the order could be created. Please retry." });
    return;
  }

  await db.insert(walletTransactionsTable).values({
    userId: req.user!.id,
    type: "purchase",
    amount: (-deductUsd).toString(),
    currency: "USD",
    description: vipDiscountPercent > 0 ? `Order: ${product.name} x${qty} (VIP ${vip.level} -${vipDiscountPercent}%)` : `Order: ${product.name} x${qty}`,
  });

  const [order] = await db
    .insert(ordersTable)
    .values({
      id: orderId,
      userId: req.user!.id,
      productId,
      productName: product.name,
      qty,
      playerId: playerId ?? null,
      fieldValues,
      totalPrice: totalPrice.toString(),
      originalPrice: subtotalUsd.toString(),
      paidAmount: paidAmount.toString(),
      paidCurrency,
      currency: "USD",
      status: "processing",
      providerOrderId: null,
    })
    .returning();

  await db.insert(notificationsTable).values({
    userId: req.user!.id,
    type: "order_completed",
    title: "تم استلام طلبك",
    message: `تم استلام طلبك لـ ${product.name} (x${qty}) وهو قيد المراجعة من قبل الإدارة. سيتم تنفيذه قريباً.`,
    isRead: false,
  });

  logger.info({ orderId, userId: req.user!.id, productId }, "Order created (awaiting admin approval)");

  // Telegram: notify new order to admin
  notifyNewOrder({
    username: user.username,
    productName: product.name,
    price: deductUsd,
    orderId,
    currency: "USD",
  }).catch(() => {});

  // High-value alert (>$50): adds approve/reject buttons to the message
  if (deductUsd > 50) {
    notifyHighValueOrder({
      username: user.username,
      productName: product.name,
      price: deductUsd,
      orderId,
      currency: "USD",
    }).catch(() => {});
  }

  // WebSocket: broadcast new order to all admin connections
  emitNewOrder({
    id: orderId,
    orderNumber: (order as any).orderNumber,
    productName: product.name,
    username: user.username,
    totalPrice: deductUsd,
    status: "processing",
  });

  // ── Auto-approve: if product has autoApprove=true, dispatch immediately ──
  if ((product as any).autoApprove === true) {
    try {
      const { approveOrderById } = await import("../lib/order-actions");
      await approveOrderById(orderId, { username: "auto-approve" });
    } catch (e) {
      logger.error({ err: e, orderId }, "Auto-approve dispatch failed; order remains processing for manual review");
    }
    const [refreshed] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
    res.status(201).json({ ...(refreshed ?? order), totalPrice: parseFloat((refreshed ?? order).totalPrice ?? "0"), vipDiscountPercent, discountUsd, autoApproved: true });
    return;
  }

  // NOTE: Orders are NOT auto-dispatched (unless autoApprove=true above).
  // Admin must approve manually via POST /admin/orders/:id/approve to
  // dispatch (API products) or mark complete (manual products).

  res.status(201).json({ ...order, totalPrice: parseFloat(order.totalPrice ?? "0"), vipDiscountPercent, discountUsd });
});

export { dispatchToProvider };

router.get("/orders/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(and(eq(ordersTable.id, rawId), eq(ordersTable.userId, req.user!.id)));

  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json({ ...order, totalPrice: parseFloat(order.totalPrice ?? "0") });
});

export default router;
