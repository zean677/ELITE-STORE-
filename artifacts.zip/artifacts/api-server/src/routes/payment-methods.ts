import { Router, type IRouter } from "express";
import { db, paymentMethodsTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";

const router: IRouter = Router();

const DEFAULT_METHODS = [
  {
    slug: "syriatel_cash",
    nameAr: "سيريتل كاش",
    nameEn: "Syriatel Cash",
    emoji: "📱",
    color: "#ef4444",
    currency: "SYP",
    sortOrder: 0,
    isActive: true,
    details: JSON.stringify([
      { label: "رقم المحفظة", value: "1122755750" },
      { label: "العملة", value: "ليرة سورية فقط" },
    ]),
  },
  {
    slug: "sham_cash_syp",
    nameAr: "شام كاش — ليرة سورية",
    nameEn: "Sham Cash SYP",
    emoji: "💜",
    color: "#8b5cf6",
    currency: "SYP",
    sortOrder: 1,
    isActive: true,
    details: JSON.stringify([
      { label: "اسم المحفظة", value: "zean677" },
      { label: "معرّف المحفظة", value: "5649dd63431812890980008b5b1c3d53" },
      { label: "العملة", value: "ليرة سورية" },
    ]),
  },
  {
    slug: "sham_cash_dollar",
    nameAr: "شام كاش — دولار",
    nameEn: "Sham Cash USD",
    emoji: "💲",
    color: "#3b82f6",
    currency: "USD",
    sortOrder: 2,
    isActive: true,
    details: JSON.stringify([
      { label: "اسم المحفظة", value: "zean677" },
      { label: "معرّف المحفظة", value: "5649dd63431812890980008b5b1c3d53" },
      { label: "العملة", value: "دولار أمريكي" },
    ]),
  },
  {
    slug: "usdt_bep20",
    nameAr: "USDT — BEP20",
    nameEn: "USDT BEP-20",
    emoji: "💚",
    color: "#22c55e",
    currency: "USD",
    sortOrder: 3,
    isActive: true,
    details: JSON.stringify([
      { label: "الشبكة", value: "BEP-20 (BSC)" },
      { label: "عنوان المحفظة", value: "0xf7b0923201d4dcf6a984d5bf400d8185d889d753" },
    ]),
  },
  {
    slug: "usdt_trc20",
    nameAr: "USDT — TRC20",
    nameEn: "USDT TRC-20",
    emoji: "🔵",
    color: "#06b6d4",
    currency: "USD",
    sortOrder: 4,
    isActive: true,
    details: JSON.stringify([
      { label: "الشبكة", value: "TRC-20 (TRON)" },
      { label: "عنوان المحفظة", value: "TBEqyveczZvGGksbP7dBErW83YCqFS67dC" },
    ]),
  },
];

// Seed default methods if table is empty
export async function seedPaymentMethods() {
  const existing = await db.select().from(paymentMethodsTable).limit(1);
  if (existing.length === 0) {
    await db.insert(paymentMethodsTable).values(DEFAULT_METHODS);
  }
}

// ─── Public: list active payment methods ────────────────────────────────────
router.get("/payment-methods", async (_req, res): Promise<void> => {
  const methods = await db
    .select()
    .from(paymentMethodsTable)
    .where(eq(paymentMethodsTable.isActive, true))
    .orderBy(asc(paymentMethodsTable.sortOrder));

  res.json(methods.map(m => ({
    ...m,
    details: (() => { try { return JSON.parse(m.details); } catch { return []; } })(),
  })));
});

// ─── Admin: list all payment methods ────────────────────────────────────────
router.get("/admin/payment-methods", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const methods = await db
    .select()
    .from(paymentMethodsTable)
    .orderBy(asc(paymentMethodsTable.sortOrder));

  res.json(methods.map(m => ({
    ...m,
    details: (() => { try { return JSON.parse(m.details); } catch { return []; } })(),
  })));
});

// ─── Admin: create payment method ────────────────────────────────────────────
router.post("/admin/payment-methods", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { slug, nameAr, nameEn, emoji, color, currency, details, imageUrl, sortOrder, isActive } = req.body as any;

  if (!slug || !nameAr || !nameEn) {
    res.status(400).json({ error: "slug, nameAr, nameEn are required" });
    return;
  }

  const [created] = await db.insert(paymentMethodsTable).values({
    slug,
    nameAr,
    nameEn,
    emoji: emoji || "💳",
    color: color || "#6366f1",
    currency: currency || "SYP",
    details: Array.isArray(details) ? JSON.stringify(details) : (details || "[]"),
    imageUrl: imageUrl || null,
    sortOrder: sortOrder ?? 0,
    isActive: isActive !== false,
  }).returning();

  res.json({ ...created, details: (() => { try { return JSON.parse(created.details); } catch { return []; } })() });
});

// ─── Admin: update payment method ────────────────────────────────────────────
router.put("/admin/payment-methods/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(req.params.id as string);
  const { slug, nameAr, nameEn, emoji, color, currency, details, imageUrl, sortOrder, isActive } = req.body as any;

  const updates: Record<string, any> = {};
  if (slug !== undefined) updates.slug = slug;
  if (nameAr !== undefined) updates.nameAr = nameAr;
  if (nameEn !== undefined) updates.nameEn = nameEn;
  if (emoji !== undefined) updates.emoji = emoji;
  if (color !== undefined) updates.color = color;
  if (currency !== undefined) updates.currency = currency;
  if (details !== undefined) updates.details = Array.isArray(details) ? JSON.stringify(details) : details;
  if (imageUrl !== undefined) updates.imageUrl = imageUrl;
  if (sortOrder !== undefined) updates.sortOrder = sortOrder;
  if (isActive !== undefined) updates.isActive = isActive;

  const [updated] = await db
    .update(paymentMethodsTable)
    .set(updates)
    .where(eq(paymentMethodsTable.id, id))
    .returning();

  if (!updated) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...updated, details: (() => { try { return JSON.parse(updated.details); } catch { return []; } })() });
});

// ─── Admin: delete payment method ────────────────────────────────────────────
router.delete("/admin/payment-methods/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(req.params.id as string);
  await db.delete(paymentMethodsTable).where(eq(paymentMethodsTable.id, id));
  res.json({ success: true });
});

// ─── Admin: reorder payment methods ─────────────────────────────────────────
router.post("/admin/payment-methods/reorder", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { order } = req.body as { order: number[] };
  if (!Array.isArray(order)) { res.status(400).json({ error: "order must be an array of ids" }); return; }

  await Promise.all(order.map((id, index) =>
    db.update(paymentMethodsTable)
      .set({ sortOrder: index })
      .where(eq(paymentMethodsTable.id, id))
  ));

  res.json({ success: true });
});

export default router;
