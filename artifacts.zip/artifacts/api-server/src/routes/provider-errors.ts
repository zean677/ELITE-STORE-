import { Router } from "express";
import { db, providerErrorsTable } from "@workspace/db";
import { desc, eq, and, gte, sql } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";

const router = Router();

router.get("/admin/provider-errors", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const provider = typeof req.query.provider === "string" ? req.query.provider : null;
  const limit = Math.min(Number(req.query.limit) || 100, 500);

  const conds = [];
  if (provider) {
    conds.push(eq(providerErrorsTable.provider, provider));
  }

  const rows = await db
    .select()
    .from(providerErrorsTable)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(providerErrorsTable.createdAt))
    .limit(limit);

  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const stats = await db
    .select({ provider: providerErrorsTable.provider, count: sql<number>`count(*)::int` })
    .from(providerErrorsTable)
    .where(gte(providerErrorsTable.createdAt, since))
    .groupBy(providerErrorsTable.provider);

  res.json({ errors: rows, stats });
});

router.delete("/admin/provider-errors", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  await db.delete(providerErrorsTable);
  res.json({ ok: true });
});

export default router;
