import { Router, type IRouter } from "express";
import { db, giftCardsTable, usersTable, walletTransactionsTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { z } from "zod/v4";
import { logger } from "../lib/logger";

const router: IRouter = Router();

function generateCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 16; i++) {
    if (i > 0 && i % 4 === 0) code += "-";
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

// ─── Buy a gift card ──────────────────────────────────────────────────────────
router.post("/gift-cards", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const schema = z.object({
    amountUsd: z.number().min(1).max(500),
    messageAr: z.string().max(200).optional(),
    recipientNote: z.string().max(100).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }

  const userId = req.user!.id;
  const { amountUsd, messageAr, recipientNote } = parsed.data;

  // Deduct from wallet
  const [walletRow] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!walletRow) { res.status(404).json({ error: "المستخدم غير موجود" }); return; }

  // Generate unique code
  let code = generateCode();
  let attempts = 0;
  while (attempts < 5) {
    const existing = await db.select({ id: giftCardsTable.id }).from(giftCardsTable).where(eq(giftCardsTable.code, code));
    if (existing.length === 0) break;
    code = generateCode();
    attempts++;
  }

  // Set expiry 1 year from now
  const expiresAt = new Date();
  expiresAt.setFullYear(expiresAt.getFullYear() + 1);

  const [card] = await db.insert(giftCardsTable).values({
    code,
    amountUsd: String(amountUsd),
    purchasedBy: userId,
    expiresAt,
    status: "active",
    messageAr: messageAr ?? null,
    recipientNote: recipientNote ?? null,
  }).returning();

  // Log wallet deduction
  await db.insert(walletTransactionsTable).values({
    userId,
    type: "gift_card_purchase",
    amountUsd: String(-amountUsd),
    description: `شراء بطاقة هدية #${card.id}`,
    status: "completed",
  } as any).catch(() => {});

  logger.info({ userId, cardId: card.id, amountUsd }, "Gift card purchased");
  res.json({ card });
});

// ─── List my gift cards ───────────────────────────────────────────────────────
router.get("/gift-cards", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const cards = await db.select().from(giftCardsTable)
    .where(eq(giftCardsTable.purchasedBy, userId))
    .orderBy(desc(giftCardsTable.createdAt))
    .limit(50);
  res.json({ cards });
});

// ─── Preview a gift card by code (public) ────────────────────────────────────
router.get("/gift-cards/preview/:code", async (req, res): Promise<void> => {
  const code = String(req.params.code).toUpperCase().replace(/[^A-Z0-9-]/g, "");
  const [card] = await db.select({
    id: giftCardsTable.id,
    code: giftCardsTable.code,
    amountUsd: giftCardsTable.amountUsd,
    status: giftCardsTable.status,
    messageAr: giftCardsTable.messageAr,
    recipientNote: giftCardsTable.recipientNote,
    expiresAt: giftCardsTable.expiresAt,
    createdAt: giftCardsTable.createdAt,
  }).from(giftCardsTable).where(eq(giftCardsTable.code, code));

  if (!card) { res.status(404).json({ error: "البطاقة غير موجودة" }); return; }
  res.json({ card });
});

// ─── Redeem a gift card ───────────────────────────────────────────────────────
router.post("/gift-cards/redeem", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const schema = z.object({ code: z.string().min(4) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "كود غير صحيح" }); return; }

  const userId = req.user!.id;
  const code = parsed.data.code.toUpperCase().trim().replace(/\s/g, "");

  const [card] = await db.select().from(giftCardsTable).where(eq(giftCardsTable.code, code));
  if (!card) { res.status(404).json({ error: "البطاقة غير موجودة أو الكود غلط" }); return; }
  if (card.status !== "active") { res.status(400).json({ error: card.status === "redeemed" ? "هذه البطاقة تم استخدامها مسبقاً" : "البطاقة منتهية الصلاحية" }); return; }
  if (card.expiresAt && new Date() > card.expiresAt) {
    await db.update(giftCardsTable).set({ status: "expired" }).where(eq(giftCardsTable.id, card.id));
    res.status(400).json({ error: "البطاقة منتهية الصلاحية" }); return;
  }
  if (card.purchasedBy === userId) { res.status(400).json({ error: "لا يمكنك استخدام بطاقتك الخاصة" }); return; }

  // Mark as redeemed
  await db.update(giftCardsTable).set({
    status: "redeemed",
    redeemedBy: userId,
    redeemedAt: new Date(),
  }).where(and(eq(giftCardsTable.id, card.id), eq(giftCardsTable.status, "active")));

  // Credit wallet
  await db.insert(walletTransactionsTable).values({
    userId,
    type: "gift_card_redeem",
    amountUsd: card.amountUsd,
    description: `استلام بطاقة هدية`,
    status: "completed",
  } as any).catch(() => {});

  logger.info({ userId, cardId: card.id, amountUsd: card.amountUsd }, "Gift card redeemed");
  res.json({ success: true, amountUsd: parseFloat(card.amountUsd) });
});

// ─── Admin: list all gift cards ───────────────────────────────────────────────
router.get("/admin/gift-cards", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const cards = await db.select().from(giftCardsTable).orderBy(desc(giftCardsTable.createdAt)).limit(200);
  res.json({ cards });
});

export default router;
