import { Router, type IRouter } from "express";
import { db, productsTable, usersTable, ordersTable } from "@workspace/db";
import { sql, eq, and, gte } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";
import os from "os";
import { fetchAllBalances } from "../lib/providers";
import { runBackup } from "../lib/backup-scheduler";
import { readdir, stat, unlink } from "fs/promises";
import { createReadStream } from "fs";
import path from "path";

const router: IRouter = Router();
const BACKUP_DIR = process.env.BACKUP_DIR || path.resolve(process.cwd(), "backups");

// Admin: trigger manual database backup (synchronous — returns when done)
router.post("/admin/backup/now", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const result = await runBackup();
  if (!result.ok) { res.status(500).json({ ok: false, error: result.error }); return; }
  res.json({ ok: true, file: result.file ? path.basename(result.file) : null, size: result.size });
});

// Admin: list all backups
router.get("/admin/backup/list", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  try {
    const files = await readdir(BACKUP_DIR).catch(() => [] as string[]);
    const out: Array<{ name: string; size: number; createdAt: string }> = [];
    for (const f of files) {
      if (!f.endsWith(".sql.gz")) continue;
      const st = await stat(path.join(BACKUP_DIR, f)).catch(() => null);
      if (st) out.push({ name: f, size: st.size, createdAt: st.mtime.toISOString() });
    }
    out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.json({ backups: out });
  } catch (err: any) {
    res.status(500).json({ error: String(err?.message || err) });
  }
});

// Admin: download a backup file
router.get("/admin/backup/download/:name", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const name = req.params.name as string;
  if (!/^[a-zA-Z0-9._-]+\.sql\.gz$/.test(name)) { res.status(400).json({ error: "Invalid filename" }); return; }
  const full = path.join(BACKUP_DIR, name);
  const st = await stat(full).catch(() => null);
  if (!st) { res.status(404).json({ error: "Not found" }); return; }
  res.setHeader("Content-Type", "application/gzip");
  res.setHeader("Content-Disposition", `attachment; filename="${name}"`);
  res.setHeader("Content-Length", String(st.size));
  createReadStream(full).pipe(res);
});

// Admin: delete a backup file
router.delete("/admin/backup/:name", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const name = req.params.name as string;
  if (!/^[a-zA-Z0-9._-]+\.sql\.gz$/.test(name)) { res.status(400).json({ error: "Invalid filename" }); return; }
  try {
    await unlink(path.join(BACKUP_DIR, name));
    res.json({ ok: true });
  } catch {
    res.status(404).json({ ok: false, error: "Backup not found or could not be removed" });
  }
});

// ─── Public stats (real numbers for hero/stats bar) ────────────────────────
let _statsCache: { data: any; ts: number } | null = null;
const STATS_TTL_MS = 60_000;

router.get("/stats/public", async (_req, res): Promise<void> => {
  try {
    if (_statsCache && Date.now() - _statsCache.ts < STATS_TTL_MS) {
      res.json(_statsCache.data);
      return;
    }
    const [productsRow] = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(productsTable)
      .where(eq(productsTable.status, "active"));
    const [usersRow] = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(usersTable);
    const [ordersRow] = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(eq(ordersTable.status, "completed"));
    const since = new Date(Date.now() - 24 * 3600_000);
    const [todayOrdersRow] = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since)));

    const data = {
      products: productsRow?.c ?? 0,
      customers: usersRow?.c ?? 0,
      ordersCompleted: ordersRow?.c ?? 0,
      ordersToday: todayOrdersRow?.c ?? 0,
      timestamp: new Date().toISOString(),
    };
    _statsCache = { data, ts: Date.now() };
    res.json(data);
  } catch (e: any) {
    res.status(503).json({ error: "Public statistics are temporarily unavailable" });
  }
});

router.get("/admin/system", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {

  const start = Date.now();

  // DB check
  let dbStatus = "ok";
  let dbLatencyMs = 0;
  try {
    const t0 = Date.now();
    await db.execute(sql`SELECT 1`);
    dbLatencyMs = Date.now() - t0;
  } catch {
    dbStatus = "error";
  }

  // Telegram check
  const botToken = process.env.TELEGRAM_BOT_TOKEN ?? "";
  let telegramStatus = "not_configured";
  if (botToken) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${botToken}/getMe`, { signal: AbortSignal.timeout(5000) });
      telegramStatus = r.ok ? "ok" : "error";
    } catch {
      telegramStatus = "error";
    }
  }

  // Provider live balance (single-provider system: Mega Game)
  const balances = await fetchAllBalances().catch(() => []);
  const primary = balances[0];

  // Order metrics (last 24h, last 7d)
  let orders24h = 0, orders7d = 0, ordersPending = 0, ordersFailed24h = 0, revenue24h = 0;
  try {
    const since24 = new Date(Date.now() - 24 * 3600_000);
    const since7d = new Date(Date.now() - 7 * 24 * 3600_000);
    const [r1] = await db.select({ c: sql<number>`count(*)::int` }).from(ordersTable).where(gte(ordersTable.createdAt, since24));
    const [r2] = await db.select({ c: sql<number>`count(*)::int` }).from(ordersTable).where(gte(ordersTable.createdAt, since7d));
    const [r3] = await db.select({ c: sql<number>`count(*)::int` }).from(ordersTable).where(eq(ordersTable.status, "pending"));
    const [r4] = await db.select({ c: sql<number>`count(*)::int` }).from(ordersTable)
      .where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, since24)));
    const [r5] = await db.select({ s: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}), 0)::text` })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since24)));
    orders24h = r1?.c ?? 0; orders7d = r2?.c ?? 0; ordersPending = r3?.c ?? 0; ordersFailed24h = r4?.c ?? 0;
    revenue24h = parseFloat(r5?.s ?? "0");
  } catch {}

  // Uptime / memory
  const uptimeSecs = Math.floor(process.uptime());
  const memUsed = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
  const memTotal = Math.round(os.totalmem() / 1024 / 1024);
  const loadAvg = os.loadavg();

  res.json({
    status: dbStatus === "ok" ? "healthy" : "degraded",
    timestamp: new Date().toISOString(),
    uptime: { seconds: uptimeSecs, human: `${Math.floor(uptimeSecs / 3600)}h ${Math.floor((uptimeSecs % 3600) / 60)}m` },
    database: { status: dbStatus, latencyMs: dbLatencyMs },
    telegram: { status: telegramStatus, configured: !!botToken, adminChatConfigured: !!process.env.TELEGRAM_ADMIN_CHAT_ID },
    providers: primary
      ? {
          [primary.provider]: {
            configured: primary.configured,
            displayName: primary.displayName ?? primary.provider,
            balance: primary.balanceUsd ?? null,
            balanceSyp: primary.balanceSyp ?? null,
            currency: primary.currency ?? "SYP",
            sypRate: primary.sypRate ?? null,
            email: primary.email ?? null,
            enabled: primary.enabled ?? null,
            error: primary.error ?? null,
          },
        }
      : {},
    env: {
      jwtSecret: !!process.env.SESSION_SECRET,
      siteUrl: process.env.SITE_URL ?? "(not set)",
      nodeEnv: process.env.NODE_ENV ?? "development",
    },
    orders: { last24h: orders24h, last7d: orders7d, pending: ordersPending, failed24h: ordersFailed24h, revenue24h },
    memory: { usedMb: memUsed, totalMb: memTotal },
    load: { "1m": loadAvg[0].toFixed(2), "5m": loadAvg[1].toFixed(2), "15m": loadAvg[2].toFixed(2) },
    responseMs: Date.now() - start,
  });
});

export default router;
