import { Router, type IRouter } from "express";
import { db, pushSubscriptionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { initPush, getPublicKey, sendPushToUser, sendPushToAll } from "../lib/push";

const router: IRouter = Router();

router.get("/push/public-key", async (_req, res): Promise<void> => {
  await initPush();
  res.json({ key: getPublicKey() });
});

router.post("/push/subscribe", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const { endpoint, keys } = req.body as { endpoint?: string; keys?: { p256dh?: string; auth?: string } };
  if (!endpoint || !keys?.p256dh || !keys?.auth) {
    res.status(400).json({ error: "subscription invalid" }); return;
  }
  const userAgent = (req.headers["user-agent"] as string) || null;
  await db.insert(pushSubscriptionsTable).values({
    userId: req.user!.id,
    endpoint,
    p256dh: keys.p256dh,
    auth: keys.auth,
    userAgent,
  }).onConflictDoUpdate({
    target: pushSubscriptionsTable.endpoint,
    set: { userId: req.user!.id, p256dh: keys.p256dh, auth: keys.auth, lastUsedAt: new Date() },
  });
  res.json({ ok: true });
});

router.post("/push/unsubscribe", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const { endpoint } = req.body as { endpoint?: string };
  if (!endpoint) { res.status(400).json({ error: "endpoint required" }); return; }
  await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.endpoint, endpoint));
  res.json({ ok: true });
});

router.post("/push/test", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const r = await sendPushToUser(req.user!.id, {
    title: "🔔 Elite Store",
    body: "إشعارات المتصفح شغّالة 100% الحمدلله!",
    url: "/",
    tag: "test",
  });
  res.json(r);
});

router.post("/admin/push/broadcast", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { title, body, url } = req.body as { title?: string; body?: string; url?: string };
  if (!title || !body) { res.status(400).json({ error: "title and body required" }); return; }
  const r = await sendPushToAll({ title, body, url, tag: "broadcast" });
  res.json(r);
});

export default router;
