import { Router, type IRouter, type Request, type Response } from "express";
import { db, productsTable, categoriesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

const STATIC_PAGES: { path: string; priority: string; changefreq: string }[] = [
  { path: "/",          priority: "1.0", changefreq: "daily" },
  { path: "/products",  priority: "0.9", changefreq: "daily" },
  { path: "/games",     priority: "0.9", changefreq: "daily" },
  { path: "/loyalty",   priority: "0.6", changefreq: "weekly" },
  { path: "/support",   priority: "0.5", changefreq: "monthly" },
  { path: "/faq",       priority: "0.5", changefreq: "monthly" },
  { path: "/terms",     priority: "0.3", changefreq: "yearly" },
  { path: "/privacy",   priority: "0.3", changefreq: "yearly" },
  { path: "/login",     priority: "0.4", changefreq: "yearly" },
  { path: "/register",  priority: "0.4", changefreq: "yearly" },
];

function escapeXml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

router.get("/sitemap.xml", async (req: Request, res: Response): Promise<void> => {
  const proto = (req.headers["x-forwarded-proto"] as string) || req.protocol;
  const host = req.headers["x-forwarded-host"] || req.headers.host;
  const base = process.env.PUBLIC_URL || `${proto}://${host}`;

  const today = new Date().toISOString().split("T")[0];

  // Fetch active products + active categories
  const [products, categories] = await Promise.all([
    db.select({ id: productsTable.id, updatedAt: productsTable.updatedAt })
      .from(productsTable)
      .where(eq(productsTable.status, "active"))
      .limit(50000),
    db.select({ id: categoriesTable.id })
      .from(categoriesTable)
      .where(eq(categoriesTable.isActive, true)),
  ]);

  const urls: string[] = [];

  // Static pages
  for (const p of STATIC_PAGES) {
    urls.push(`<url><loc>${base}${p.path}</loc><lastmod>${today}</lastmod><changefreq>${p.changefreq}</changefreq><priority>${p.priority}</priority></url>`);
  }

  // Categories
  for (const c of categories) {
    urls.push(`<url><loc>${base}/games?category=${encodeURIComponent(c.id)}</loc><lastmod>${today}</lastmod><changefreq>daily</changefreq><priority>0.7</priority></url>`);
  }

  // Products
  for (const p of products) {
    const lastmod = p.updatedAt ? new Date(p.updatedAt).toISOString().split("T")[0] : today;
    urls.push(`<url><loc>${base}/product/${escapeXml(p.id)}</loc><lastmod>${lastmod}</lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>`);
  }

  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`;

  res.setHeader("Content-Type", "application/xml; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=3600"); // cache 1 hour
  res.send(xml);
});

router.get("/robots.txt", (req: Request, res: Response): void => {
  const proto = (req.headers["x-forwarded-proto"] as string) || req.protocol;
  const host = req.headers["x-forwarded-host"] || req.headers.host;
  const base = process.env.PUBLIC_URL || `${proto}://${host}`;

  const txt = `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api\nDisallow: /dashboard\nDisallow: /checkout\n\nSitemap: ${base}/sitemap.xml\n`;
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.send(txt);
});

export default router;
