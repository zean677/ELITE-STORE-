import { Router, type IRouter } from "express";
import { db, ordersTable, usersTable, productsTable, walletTransactionsTable } from "@workspace/db";
import { sql, eq, and, gte, desc, count } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";

const router: IRouter = Router();

router.get("/admin/analytics", requireAuth, requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const range = String(req.query.range ?? "30");
  const days = Math.max(1, Math.min(365, parseInt(range, 10) || 30));
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  // ── Daily sales (orders + revenue per day) ─────────────────────────────────
  const dailyRows = await db.execute(sql`
    SELECT
      to_char(created_at AT TIME ZONE 'Asia/Damascus', 'YYYY-MM-DD') AS day,
      COUNT(*)::int AS orders,
      COUNT(*) FILTER (WHERE status = 'completed')::int AS completed,
      COUNT(*) FILTER (WHERE status = 'failed')::int AS failed,
      COALESCE(SUM(CAST(total_price AS NUMERIC)) FILTER (WHERE status = 'completed'), 0)::float AS revenue
    FROM orders
    WHERE created_at >= ${since}
    GROUP BY day
    ORDER BY day ASC
  `);

  // ── Totals & summary ───────────────────────────────────────────────────────
  const summaryRes = await db.execute(sql`
    SELECT
      COUNT(*)::int AS total_orders,
      COUNT(*) FILTER (WHERE status = 'completed')::int AS completed_orders,
      COUNT(*) FILTER (WHERE status = 'failed')::int AS failed_orders,
      COUNT(*) FILTER (WHERE status = 'pending')::int AS pending_orders,
      COALESCE(SUM(CAST(total_price AS NUMERIC)) FILTER (WHERE status = 'completed'), 0)::float AS total_revenue,
      COALESCE(AVG(CAST(total_price AS NUMERIC)) FILTER (WHERE status = 'completed'), 0)::float AS avg_order_value
    FROM orders
    WHERE created_at >= ${since}
  `) as any;
  const summary = summaryRes.rows?.[0] ?? {};

  // ── Top products by revenue ────────────────────────────────────────────────
  const topProducts = await db.execute(sql`
    SELECT
      product_id,
      product_name,
      COUNT(*)::int AS orders,
      COALESCE(SUM(qty), 0)::int AS units,
      COALESCE(SUM(CAST(total_price AS NUMERIC)), 0)::float AS revenue
    FROM orders
    WHERE status = 'completed' AND created_at >= ${since}
    GROUP BY product_id, product_name
    ORDER BY revenue DESC
    LIMIT 10
  `);

  // ── Top customers by spend ─────────────────────────────────────────────────
  const topCustomers = await db.execute(sql`
    SELECT
      o.user_id,
      u.username,
      u.public_code,
      u.vip_level,
      COUNT(*)::int AS orders,
      COALESCE(SUM(CAST(o.total_price AS NUMERIC)), 0)::float AS spent
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    WHERE o.status = 'completed' AND o.created_at >= ${since}
    GROUP BY o.user_id, u.username, u.public_code, u.vip_level
    ORDER BY spent DESC
    LIMIT 10
  `);

  // ── New users per day ──────────────────────────────────────────────────────
  const dailyUsers = await db.execute(sql`
    SELECT
      to_char(created_at AT TIME ZONE 'Asia/Damascus', 'YYYY-MM-DD') AS day,
      COUNT(*)::int AS users
    FROM users
    WHERE created_at >= ${since}
    GROUP BY day
    ORDER BY day ASC
  `);

  // ── Category breakdown ─────────────────────────────────────────────────────
  const categoryBreakdown = await db.execute(sql`
    SELECT
      COALESCE(p.category, 'other') AS category,
      COUNT(o.id)::int AS orders,
      COALESCE(SUM(CAST(o.total_price AS NUMERIC)), 0)::float AS revenue
    FROM orders o
    LEFT JOIN products p ON p.id = o.product_id
    WHERE o.status = 'completed' AND o.created_at >= ${since}
    GROUP BY category
    ORDER BY revenue DESC
  `);

  // ── Deposits in range ──────────────────────────────────────────────────────
  const depositRes = await db.execute(sql`
    SELECT
      COUNT(*) FILTER (WHERE type = 'deposit')::int AS deposits,
      COALESCE(SUM(CAST(amount AS NUMERIC)) FILTER (WHERE type = 'deposit'), 0)::float AS deposit_total
    FROM wallet_transactions
    WHERE created_at >= ${since}
  `) as any;
  const depositSummary = depositRes.rows?.[0] ?? {};

  // ── Live counters (all-time) ───────────────────────────────────────────────
  const [{ usersCount }] = await db.select({ usersCount: count() }).from(usersTable);
  const [{ productsCount }] = await db.select({ productsCount: count() }).from(productsTable);

  // ── Forecast: linear projection based on last 7-day avg ────────────────────
  const last7Rev = (dailyRows.rows as any[])
    .slice(-7)
    .reduce((s: number, r: any) => s + (r.revenue ?? 0), 0);
  const dailyAvg = last7Rev / Math.min(7, (dailyRows.rows as any[]).slice(-7).length || 1);
  const forecast30 = dailyAvg * 30;

  res.json({
    range: days,
    summary: {
      totalOrders: summary?.total_orders ?? 0,
      completedOrders: summary?.completed_orders ?? 0,
      failedOrders: summary?.failed_orders ?? 0,
      pendingOrders: summary?.pending_orders ?? 0,
      totalRevenue: summary?.total_revenue ?? 0,
      avgOrderValue: summary?.avg_order_value ?? 0,
      depositsCount: depositSummary?.deposits ?? 0,
      depositsTotal: depositSummary?.deposit_total ?? 0,
      usersCount,
      productsCount,
      forecast30,
      dailyAvg,
    },
    daily: dailyRows.rows,
    dailyUsers: dailyUsers.rows,
    topProducts: topProducts.rows,
    topCustomers: topCustomers.rows,
    categoryBreakdown: categoryBreakdown.rows,
  });
});

// ─── User personal stats ──────────────────────────────────────────────────────
router.get("/user/stats", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "Not found" }); return; }

  // Orders summary
  const ordersSummary = await db.execute(sql`
    SELECT
      COUNT(*) AS total_orders,
      COUNT(*) FILTER (WHERE status = 'delivered') AS completed_orders,
      COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_usd ELSE 0 END), 0) AS total_spent_usd,
      COALESCE(SUM(CASE WHEN status = 'delivered' AND promo_code IS NOT NULL THEN original_price_usd - total_usd ELSE 0 END), 0) AS total_saved_usd
    FROM orders WHERE user_id = ${userId}
  `);

  // Favorite product category (most ordered)
  const favCatRows = await db.execute(sql`
    SELECT p.category, COUNT(*) AS cnt
    FROM orders o
    JOIN products p ON p.id = o.product_id
    WHERE o.user_id = ${userId} AND o.status = 'delivered'
    GROUP BY p.category ORDER BY cnt DESC LIMIT 1
  `);

  // Loyalty points
  const loyaltyRows = await db.execute(sql`
    SELECT COALESCE(SUM(points), 0) AS total_points FROM loyalty_transactions WHERE user_id = ${userId} AND points > 0
  `);

  const summary: any = (ordersSummary.rows as any[])[0] ?? {};
  const favCat: any = (favCatRows.rows as any[])[0];
  const loyaltyPts: any = (loyaltyRows.rows as any[])[0];

  res.json({
    memberSince: user.createdAt,
    totalOrders: Number(summary.total_orders ?? 0),
    completedOrders: Number(summary.completed_orders ?? 0),
    totalSpentUsd: parseFloat(summary.total_spent_usd ?? "0"),
    totalSavedUsd: parseFloat(summary.total_saved_usd ?? "0"),
    favoriteCategory: favCat?.category ?? null,
    loyaltyPoints: Number(loyaltyPts?.total_points ?? 0),
    vipLevel: (user as any).vipLevel ?? 0,
    vipSpent: parseFloat((user as any).vipSpentUsd ?? "0"),
    username: user.username,
  });
});

// ─── Admin: Revenue Intelligence (compare periods + forecast) ─────────────────
router.get("/admin/analytics/intelligence", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const now = new Date();
  const d7ago = new Date(now.getTime() - 7 * 86400000);
  const d14ago = new Date(now.getTime() - 14 * 86400000);

  // This week vs last week
  const thisWeekResult = await db.execute(sql`
    SELECT
      COUNT(*) FILTER (WHERE status='delivered') AS orders,
      COALESCE(SUM(total_usd) FILTER (WHERE status='delivered'), 0) AS revenue,
      COUNT(*) FILTER (WHERE status='failed') AS failed
    FROM orders WHERE created_at >= ${d7ago}
  `);
  const lastWeekResult = await db.execute(sql`
    SELECT
      COUNT(*) FILTER (WHERE status='delivered') AS orders,
      COALESCE(SUM(total_usd) FILTER (WHERE status='delivered'), 0) AS revenue,
      COUNT(*) FILTER (WHERE status='failed') AS failed
    FROM orders WHERE created_at >= ${d14ago} AND created_at < ${d7ago}
  `);

  // Daily revenue last 14 days for sparkline
  const dailyRows = await db.execute(sql`
    SELECT DATE(created_at AT TIME ZONE 'Asia/Damascus') AS day,
           COALESCE(SUM(total_usd) FILTER (WHERE status='delivered'), 0) AS revenue,
           COUNT(*) FILTER (WHERE status='delivered') AS orders
    FROM orders WHERE created_at >= ${d14ago}
    GROUP BY day ORDER BY day
  `);

  // Best performing products this week
  const topProducts = await db.execute(sql`
    SELECT p.name_ar AS name, p.id, COUNT(*) AS orders, COALESCE(SUM(o.total_usd),0) AS revenue
    FROM orders o JOIN products p ON p.id = o.product_id
    WHERE o.created_at >= ${d7ago} AND o.status = 'delivered'
    GROUP BY p.id, p.name_ar ORDER BY revenue DESC LIMIT 5
  `);

  // New users this week vs last
  const newUsersThisResult = await db.execute(sql`SELECT COUNT(*) AS cnt FROM users WHERE created_at >= ${d7ago}`);
  const newUsersLastResult = await db.execute(sql`SELECT COUNT(*) AS cnt FROM users WHERE created_at >= ${d14ago} AND created_at < ${d7ago}`);

  // Hour-of-day heatmap (last 30 days)
  const hourHeatmap = await db.execute(sql`
    SELECT EXTRACT(HOUR FROM created_at AT TIME ZONE 'Asia/Damascus')::int AS hour, COUNT(*) AS orders
    FROM orders WHERE created_at >= NOW() - INTERVAL '30 days' AND status='delivered'
    GROUP BY hour ORDER BY hour
  `);

  const tw: any = (thisWeekResult.rows as any[])[0] ?? {};
  const lw: any = (lastWeekResult.rows as any[])[0] ?? {};
  const nwt: any = (newUsersThisResult.rows as any[])[0] ?? {};
  const nwl: any = (newUsersLastResult.rows as any[])[0] ?? {};

  const twRevenue = parseFloat(tw.revenue ?? "0");
  const lwRevenue = parseFloat(lw.revenue ?? "0");
  const twOrders = Number(tw.orders ?? 0);
  const lwOrders = Number(lw.orders ?? 0);

  const pct = (curr: number, prev: number) =>
    prev === 0 ? (curr > 0 ? 100 : 0) : Math.round(((curr - prev) / prev) * 100);

  // Simple 7-day forecast based on daily average of last 14 days
  const totalRevenue14 = (dailyRows.rows as any[]).reduce((s, r) => s + parseFloat(r.revenue ?? "0"), 0);
  const dailyAvg = totalRevenue14 / 14;
  const forecast7 = dailyAvg * 7;

  res.json({
    thisWeek: { revenue: twRevenue, orders: twOrders, failed: Number(tw.failed ?? 0), newUsers: Number(nwt.cnt ?? 0) },
    lastWeek: { revenue: lwRevenue, orders: lwOrders, failed: Number(lw.failed ?? 0), newUsers: Number(nwl.cnt ?? 0) },
    change: {
      revenuePct: pct(twRevenue, lwRevenue),
      ordersPct: pct(twOrders, lwOrders),
      newUsersPct: pct(Number(nwt.cnt ?? 0), Number(nwl.cnt ?? 0)),
    },
    forecast7,
    daily: dailyRows.rows,
    topProducts: topProducts.rows,
    hourHeatmap: hourHeatmap.rows,
  });
});

export default router;
