import { Router, type IRouter } from "express";
import { db, priceAlertsTable, productsTable, notificationsTable } from "@workspace/db";
import { eq, and, desc, sql, lte, isNotNull } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../lib/auth";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ─── List my alerts ──────────────────────────────────────────────────────────
router.get("/price-alerts", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const rows = await db
    .select({
      id: priceAlertsTable.id,
      productId: priceAlertsTable.productId,
      productName: priceAlertsTable.productName,
      targetPriceUsd: priceAlertsTable.targetPriceUsd,
      priceWhenCreated: priceAlertsTable.priceWhenCreated,
      isActive: priceAlertsTable.isActive,
      triggeredAt: priceAlertsTable.triggeredAt,
      triggeredPriceUsd: priceAlertsTable.triggeredPriceUsd,
      createdAt: priceAlertsTable.createdAt,
      currentPriceUsd: productsTable.priceUsd,
      productImage: productsTable.image,
    })
    .from(priceAlertsTable)
    .leftJoin(productsTable, eq(priceAlertsTable.productId, productsTable.id))
    .where(eq(priceAlertsTable.userId, userId))
    .orderBy(desc(priceAlertsTable.createdAt));
  res.json(rows);
});

// ─── Create alert ────────────────────────────────────────────────────────────
router.post("/price-alerts", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const productId = String(req.body?.productId ?? "").trim();
  const targetPrice = parseFloat(req.body?.targetPriceUsd ?? "0");

  if (!productId || !Number.isFinite(targetPrice) || targetPrice <= 0) {
    res.status(400).json({ message: "بيانات غير صحيحة" });
    return;
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!product) {
    res.status(404).json({ message: "المنتج غير موجود" });
    return;
  }

  const currentPrice = parseFloat(product.priceUsd ?? "0");
  if (targetPrice >= currentPrice) {
    res.status(400).json({ message: `يجب أن يكون السعر المستهدف أقل من السعر الحالي ($${currentPrice.toFixed(2)})` });
    return;
  }

  // Cap: max 25 active alerts per user
  const [{ cnt }] = await db
    .select({ cnt: sql<number>`count(*)::int` })
    .from(priceAlertsTable)
    .where(and(eq(priceAlertsTable.userId, userId), eq(priceAlertsTable.isActive, true)));
  if (cnt >= 25) {
    res.status(400).json({ message: "وصلت للحد الأقصى (25 تنبيه نشط). احذف القديم أولاً." });
    return;
  }

  // Avoid duplicates
  const [existing] = await db
    .select()
    .from(priceAlertsTable)
    .where(and(
      eq(priceAlertsTable.userId, userId),
      eq(priceAlertsTable.productId, productId),
      eq(priceAlertsTable.isActive, true),
    ));
  if (existing) {
    res.status(400).json({ message: "لديك تنبيه نشط لهذا المنتج بالفعل" });
    return;
  }

  const [created] = await db.insert(priceAlertsTable).values({
    userId,
    productId,
    productName: product.name,
    targetPriceUsd: String(targetPrice),
    priceWhenCreated: String(currentPrice),
  }).returning();

  res.json(created);
});

// ─── Delete alert ────────────────────────────────────────────────────────────
router.delete("/price-alerts/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const id = parseInt(String(req.params.id), 10);
  if (!Number.isFinite(id)) { res.status(400).json({ message: "معرّف غير صالح" }); return; }
  await db.delete(priceAlertsTable).where(and(eq(priceAlertsTable.id, id), eq(priceAlertsTable.userId, userId)));
  res.json({ ok: true });
});

// ─── Background checker ──────────────────────────────────────────────────────
export async function checkAndNotifyPriceAlerts(): Promise<{ triggered: number }> {
  try {
    // Find active alerts where current price <= target
    const matches = await db
      .select({
        alertId: priceAlertsTable.id,
        userId: priceAlertsTable.userId,
        productId: priceAlertsTable.productId,
        productName: priceAlertsTable.productName,
        targetPriceUsd: priceAlertsTable.targetPriceUsd,
        priceWhenCreated: priceAlertsTable.priceWhenCreated,
        currentPriceUsd: productsTable.priceUsd,
      })
      .from(priceAlertsTable)
      .innerJoin(productsTable, eq(priceAlertsTable.productId, productsTable.id))
      .where(and(
        eq(priceAlertsTable.isActive, true),
        sql`CAST(${productsTable.priceUsd} AS NUMERIC) <= CAST(${priceAlertsTable.targetPriceUsd} AS NUMERIC)`,
      ));

    if (matches.length === 0) return { triggered: 0 };

    let triggered = 0;
    for (const m of matches) {
      const cur = parseFloat(m.currentPriceUsd ?? "0");
      const target = parseFloat(m.targetPriceUsd);
      const original = parseFloat(m.priceWhenCreated);
      const savings = original - cur;
      const savingsPct = original > 0 ? Math.round((savings / original) * 100) : 0;

      // Send in-app notification
      await db.insert(notificationsTable).values({
        userId: m.userId,
        type: "price_alert",
        title: "🔔 تنبيه سعر! انخفض السعر",
        message: `وصل سعر "${m.productName}" إلى $${cur.toFixed(2)} (هدفك كان $${target.toFixed(2)}). وفّر $${savings.toFixed(2)}${savingsPct ? ` (${savingsPct}%)` : ""} الآن!`,
      }).catch(() => {});

      // Mark as triggered + deactivate (one-shot)
      await db.update(priceAlertsTable)
        .set({
          isActive: false,
          triggeredAt: new Date(),
          triggeredPriceUsd: String(cur),
          lastNotifiedAt: new Date(),
        })
        .where(eq(priceAlertsTable.id, m.alertId));

      triggered++;
    }

    logger.info({ triggered }, "Price alerts: triggered");
    return { triggered };
  } catch (err) {
    logger.warn({ err }, "checkAndNotifyPriceAlerts failed");
    return { triggered: 0 };
  }
}

export default router;
