import { Router, type IRouter } from "express";
import { db, productReviewsTable, productsTable, ordersTable, usersTable } from "@workspace/db";
import { eq, and, sql, desc } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../lib/auth";
import { z } from "zod";

const router: IRouter = Router();

const CreateReviewBody = z.object({
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(500).optional(),
});

router.get("/reviews/:productId", async (req, res): Promise<void> => {
  const productId = String(req.params.productId);

  const reviews = await db
    .select({
      id: productReviewsTable.id,
      rating: productReviewsTable.rating,
      comment: productReviewsTable.comment,
      createdAt: productReviewsTable.createdAt,
      username: usersTable.username,
    })
    .from(productReviewsTable)
    .leftJoin(usersTable, eq(productReviewsTable.userId, usersTable.id))
    .where(eq(productReviewsTable.productId, productId))
    .orderBy(desc(productReviewsTable.createdAt))
    .limit(50);

  const avgResult = await db
    .select({
      avgRating: sql<number>`AVG(${productReviewsTable.rating})`,
      count: sql<number>`COUNT(*)`,
    })
    .from(productReviewsTable)
    .where(eq(productReviewsTable.productId, productId));

  res.json({
    reviews,
    avgRating: avgResult[0]?.avgRating ? parseFloat(String(avgResult[0].avgRating)).toFixed(1) : null,
    totalReviews: parseInt(String(avgResult[0]?.count ?? 0)),
  });
});

router.post("/reviews/:productId", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const productId = String(req.params.productId);

  const parsed = CreateReviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid review data" });
    return;
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const [existingReview] = await db
    .select()
    .from(productReviewsTable)
    .where(and(eq(productReviewsTable.productId, productId), eq(productReviewsTable.userId, userId)));

  if (existingReview) {
    const [updated] = await db
      .update(productReviewsTable)
      .set({ rating: parsed.data.rating, comment: parsed.data.comment ?? null })
      .where(eq(productReviewsTable.id, existingReview.id))
      .returning();
    res.json({ success: true, review: updated });
    return;
  }

  const [review] = await db
    .insert(productReviewsTable)
    .values({ productId, userId, rating: parsed.data.rating, comment: parsed.data.comment ?? null })
    .returning();

  res.json({ success: true, review });
});

export default router;
