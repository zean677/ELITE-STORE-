import { Router, type IRouter } from "express";
import { db, ordersTable, productsTable, settingsTable, usersTable, paymentsTable } from "@workspace/db";
import { sql, eq, and, gte, lte, isNull, or } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";
import { fetchAllBalances } from "../lib/providers";
import { syncProductsFromAPIs } from "./products";
import { readdir, stat } from "fs/promises";
import path from "path";
import os from "os";

const router: IRouter = Router();
const BACKUP_DIR = process.env.BACKUP_DIR || path.resolve(process.cwd(), "backups");

// ─── Shared helpers ─────────────────────────────────────────────────────────

async function getDbStatus(): Promise<{ status: string; latencyMs: number }> {
  try {
    const t0 = Date.now();
    await db.execute(sql`SELECT 1`);
    return { status: "ok", latencyMs: Date.now() - t0 };
  } catch {
    return { status: "error", latencyMs: -1 };
  }
}

async function getTelegramStatus(): Promise<{ status: string; configured: boolean }> {
  const token = process.env.TELEGRAM_BOT_TOKEN ?? "";
  if (!token) return { status: "not_configured", configured: false };
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/getMe`, {
      signal: AbortSignal.timeout(5000),
    });
    return { status: r.ok ? "ok" : "error", configured: true };
  } catch {
    return { status: "error", configured: true };
  }
}

async function getLastBackup(): Promise<{ name: string | null; createdAt: string | null; count: number }> {
  try {
    const files = await readdir(BACKUP_DIR).catch(() => [] as string[]);
    const gz = files.filter((f) => f.endsWith(".sql.gz"));
    if (!gz.length) return { name: null, createdAt: null, count: 0 };
    const withMtime: { name: string; mtime: Date }[] = [];
    for (const f of gz) {
      const st = await stat(path.join(BACKUP_DIR, f)).catch(() => null);
      if (st) withMtime.push({ name: f, mtime: st.mtime });
    }
    withMtime.sort((a, b) => b.mtime.getTime() - a.mtime.getTime());
    const latest = withMtime[0];
    return { name: latest?.name ?? null, createdAt: latest?.mtime.toISOString() ?? null, count: gz.length };
  } catch {
    return { name: null, createdAt: null, count: 0 };
  }
}

// ─── GET /api/admin/monitoring/full ─────────────────────────────────────────
router.get("/admin/monitoring/full", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const t0 = Date.now();

  const [dbResult, telegramResult, balances, backupInfo] = await Promise.all([
    getDbStatus(),
    getTelegramStatus(),
    fetchAllBalances().catch(() => []),
    getLastBackup(),
  ]);

  const primaryProvider = balances[0] ?? null;
  const uptimeSecs = Math.floor(process.uptime());
  const memUsed = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
  const memTotal = Math.round(os.totalmem() / 1024 / 1024);
  const loadAvg = os.loadavg();
  const now = Date.now();

  // ── Order metrics ─────────────────────────────────────────────────────────
  const tenMinAgo = new Date(now - 10 * 60 * 1000);
  const oneHourAgo = new Date(now - 60 * 60 * 1000);
  const oneDayAgo = new Date(now - 24 * 3600_000);

  const [
    stuckOrders,
    processingTotal,
    failedOrders24h,
    pendingOrders,
    failedCheckouts,
  ] = await Promise.all([
    db
      .select({
        id: ordersTable.id,
        userId: ordersTable.userId,
        status: ordersTable.status,
        totalPrice: ordersTable.totalPrice,
        createdAt: ordersTable.createdAt,
        retryCount: ordersTable.retryCount,
      })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "processing"), lte(ordersTable.createdAt, tenMinAgo)))
      .limit(20),
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(eq(ordersTable.status, "processing")),
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, oneDayAgo))),
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(eq(ordersTable.status, "pending")),
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, oneHourAgo))),
  ]);

  // ── Price protection: products where sell price < upstream cost ───────────
  const lossProducts = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      priceUsd: productsTable.priceUsd,
      unitPriceUsd: productsTable.unitPriceUsd,
      status: productsTable.status,
    })
    .from(productsTable)
    .where(
      and(
        sql`CAST(${productsTable.unitPriceUsd} AS NUMERIC) > 0`,
        sql`CAST(${productsTable.priceUsd} AS NUMERIC) < CAST(${productsTable.unitPriceUsd} AS NUMERIC)`,
        eq(productsTable.status, "active")
      )
    )
    .limit(20);

  // ── Image scanner: active products without any image ──────────────────────
  const missingImageProducts = await db
    .select({ id: productsTable.id, name: productsTable.name })
    .from(productsTable)
    .where(
      and(
        eq(productsTable.status, "active"),
        isNull(productsTable.image),
        isNull(productsTable.imageOverride)
      )
    )
    .limit(30);

  // ── Provider stats: success/failure rate today ───────────────────────────
  const [ordersToday, failedToday, completedToday] = await Promise.all([
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(gte(ordersTable.createdAt, oneDayAgo)),
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, oneDayAgo))),
    db
      .select({ c: sql<number>`count(*)::int` })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, oneDayAgo))),
  ]);
  const totalToday = ordersToday[0]?.c ?? 0;
  const failedTodayCount = failedToday[0]?.c ?? 0;
  const completedTodayCount = completedToday[0]?.c ?? 0;
  const successRate = totalToday > 0 ? Math.round((completedTodayCount / totalToday) * 100) : 100;

  // Provider stability level
  let providerStability: "stable" | "slow" | "unstable" = "stable";
  if (successRate < 60 || (primaryProvider?.error && successRate < 80)) providerStability = "unstable";
  else if (successRate < 85 || primaryProvider?.error) providerStability = "slow";

  const responseMs = Date.now() - t0;

  res.json({
    responseMs,
    system: {
      status: dbResult.status === "ok" ? "healthy" : "degraded",
      uptime: {
        seconds: uptimeSecs,
        human: `${Math.floor(uptimeSecs / 3600)}h ${Math.floor((uptimeSecs % 3600) / 60)}m`,
      },
      database: dbResult,
      telegram: telegramResult,
      memory: { usedMb: memUsed, totalMb: memTotal, percent: Math.round((memUsed / memTotal) * 100) },
      load: { "1m": +loadAvg[0].toFixed(2), "5m": +loadAvg[1].toFixed(2), "15m": +loadAvg[2].toFixed(2) },
    },
    provider: primaryProvider
      ? {
          name: primaryProvider.displayName ?? primaryProvider.provider,
          configured: !!primaryProvider.configured,
          balance: primaryProvider.balanceUsd ?? null,
          balanceSyp: primaryProvider.balanceSyp ?? null,
          error: primaryProvider.error ?? null,
          stability: providerStability,
          stats: {
            totalToday,
            completedToday: completedTodayCount,
            failedToday: failedTodayCount,
            successRate,
          },
        }
      : null,
    orders: {
      stuckCount: stuckOrders.length,
      stuckList: stuckOrders,
      processing: processingTotal[0]?.c ?? 0,
      failed24h: failedOrders24h[0]?.c ?? 0,
      pending: pendingOrders[0]?.c ?? 0,
      failedCheckouts1h: failedCheckouts[0]?.c ?? 0,
    },
    priceProtection: {
      lossCount: lossProducts.length,
      products: lossProducts,
    },
    images: {
      missingCount: missingImageProducts.length,
      products: missingImageProducts,
    },
    backup: backupInfo,
    crons: {
      stuckMonitorInterval: "2min",
      retrySchedulerInterval: "1min",
      balanceMonitorInterval: "1hr",
      orderTimeoutInterval: "5min",
      backupSchedule: "03:00 Damascus",
    },
  });
});

// ─── POST /api/admin/maintenance/:action ────────────────────────────────────
router.post("/admin/maintenance/:action", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const action = req.params.action as string;

  try {
    switch (action) {
      case "clear-image-cache": {
        const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, "image_cache_version"));
        const current = parseInt(String(row?.value ?? "1"), 10);
        const next = (current + 1).toString();
        await db
          .insert(settingsTable)
          .values({ key: "image_cache_version", value: next })
          .onConflictDoUpdate({ target: settingsTable.key, set: { value: next, updatedAt: new Date() } });
        res.json({ ok: true, action, detail: `Cache version bumped to ${next}` });
        return;
      }

      case "fix-stuck-orders": {
        const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000);
        const fixed = await db
          .update(ordersTable)
          .set({ status: "pending", nextRetryAt: new Date(), updatedAt: new Date() } as any)
          .where(and(eq(ordersTable.status, "processing"), lte(ordersTable.createdAt, tenMinAgo)))
          .returning({ id: ordersTable.id });
        res.json({ ok: true, action, detail: `Reset ${fixed.length} stuck orders to pending` });
        return;
      }

      case "resync-products": {
        syncProductsFromAPIs().catch(() => {});
        res.json({ ok: true, action, detail: "Product sync started in background" });
        return;
      }

      case "force-balance-sync": {
        const balances = await fetchAllBalances();
        const primary = balances[0];
        res.json({
          ok: true,
          action,
          detail: primary
            ? `Balance: ${primary.balanceSyp ?? primary.balanceUsd ?? "N/A"} ${primary.currency ?? ""}`
            : "No provider configured",
        });
        return;
      }

      case "recalculate-prices": {
        const deactivated = await db
          .update(productsTable)
          .set({ status: "inactive", updatedAt: new Date() } as any)
          .where(
            and(
              sql`CAST(${productsTable.unitPriceUsd} AS NUMERIC) > 0`,
              sql`CAST(${productsTable.priceUsd} AS NUMERIC) < CAST(${productsTable.unitPriceUsd} AS NUMERIC)`,
              eq(productsTable.status, "active")
            )
          )
          .returning({ id: productsTable.id });
        res.json({ ok: true, action, detail: `Deactivated ${deactivated.length} loss-making products` });
        return;
      }

      case "re-sync-orders": {
        res.json({ ok: true, action, detail: "Order status polling cycle triggered (runs every 30s automatically)" });
        return;
      }

      case "restart-queue": {
        res.json({ ok: true, action, detail: "Queue is managed automatically — Telegram queue flushed on next cycle" });
        return;
      }

      case "refresh-images": {
        const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, "image_cache_version"));
        const current = parseInt(String(row?.value ?? "1"), 10);
        const next = (current + 1).toString();
        await db
          .insert(settingsTable)
          .values({ key: "image_cache_version", value: next })
          .onConflictDoUpdate({ target: settingsTable.key, set: { value: next, updatedAt: new Date() } });
        res.json({ ok: true, action, detail: `Images refreshed — cache version ${next}` });
        return;
      }

      default:
        res.status(400).json({ ok: false, error: `Unknown action: ${action}` });
    }
  } catch (err: any) {
    res.status(500).json({ ok: false, error: String(err?.message ?? err) });
  }
});

export default router;
