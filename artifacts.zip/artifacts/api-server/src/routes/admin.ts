import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import path from "path";
import fs from "fs";
import { db, usersTable, ordersTable, paymentsTable, productsTable, walletTransactionsTable, notificationsTable, settingsTable, adminActivityLogTable, categoriesTable, paymentMethodsTable, productChangeLogTable } from "@workspace/db";
import { eq, desc, and, count, sum, gte, sql, ilike, or, inArray, isNotNull } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";
import { VerifyPaymentBody, GetAdminOrdersQueryParams, GetAdminPaymentsQueryParams, GetAdminUsersQueryParams, UpdateUserBalanceBody, SuspendUserBody } from "@workspace/api-zod";
import { v4 as uuidv4 } from "uuid";
import { z } from "zod";
import { logger } from "../lib/logger";
import { notifyDepositApproved, notifyOrderSuccess, notifyOrderFailed, notifyVipChange, notifyBalanceChange, configureTelegramWebhook, deleteTelegramWebhook, getTelegramWebhookInfo, sendTestMessage, sendDailyReport, sendWeeklyReport } from "../lib/telegram";
import { syncProductsFromAPIs } from "./products";
import { dispatchToProvider } from "./orders";
import { applyCompletedOrderSpend } from "../lib/vip";
import { emitOrderUpdate } from "../lib/ws";
import { approveOrderById, rejectOrderById } from "../lib/order-actions";
import { type ProviderName } from "../lib/providers";
import { loginAttemptsTable } from "@workspace/db";

// ─── Admin Activity Log helper ─────────────────────────────────────────────────
export async function logAdminAction(params: {
  adminId: number;
  adminUsername: string;
  action: string;
  entity: string;
  entityId?: string;
  details?: Record<string, unknown>;
  ip?: string;
}): Promise<void> {
  try {
    await db.insert(adminActivityLogTable).values({
      adminId: params.adminId,
      adminUsername: params.adminUsername,
      action: params.action,
      entity: params.entity,
      entityId: params.entityId ?? null,
      details: params.details ?? null,
      ip: params.ip ?? null,
    });
  } catch { /* ignore */ }
}

async function getSettingValue(key: string, defaultVal: string): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  return row?.value ?? defaultVal;
}

const router: IRouter = Router();

router.get("/admin/dashboard", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const [totalRevenueResult] = await db
    .select({ total: sum(ordersTable.totalPrice) })
    .from(ordersTable)
    .where(eq(ordersTable.status, "completed"));

  const [totalOrdersResult] = await db.select({ count: count() }).from(ordersTable);
  const [totalUsersResult] = await db.select({ count: count() }).from(usersTable).where(eq(usersTable.role, "user"));
  const [totalProductsResult] = await db.select({ count: count() }).from(productsTable).where(eq(productsTable.status, "active"));
  const [pendingPaymentsResult] = await db.select({ count: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending"));
  const [completedOrdersResult] = await db.select({ count: count() }).from(ordersTable).where(eq(ordersTable.status, "completed"));
  const [failedOrdersResult] = await db.select({ count: count() }).from(ordersTable).where(eq(ordersTable.status, "failed"));

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const [revenueTodayResult] = await db
    .select({ total: sum(ordersTable.totalPrice) })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, todayStart)));

  const [ordersTodayResult] = await db
    .select({ count: count() })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, todayStart));

  const topProductsRaw = await db
    .select({
      productId: ordersTable.productId,
      productName: ordersTable.productName,
      orderCount: count(),
      revenue: sum(ordersTable.totalPrice),
    })
    .from(ordersTable)
    .groupBy(ordersTable.productId, ordersTable.productName)
    .orderBy(desc(count()))
    .limit(5);

  const recentOrders = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt))
    .limit(10);

  res.json({
    totalRevenue: parseFloat(totalRevenueResult?.total ?? "0"),
    totalOrders: totalOrdersResult?.count ?? 0,
    totalUsers: totalUsersResult?.count ?? 0,
    totalProducts: totalProductsResult?.count ?? 0,
    pendingPayments: pendingPaymentsResult?.count ?? 0,
    completedOrders: completedOrdersResult?.count ?? 0,
    failedOrders: failedOrdersResult?.count ?? 0,
    revenueToday: parseFloat(revenueTodayResult?.total ?? "0"),
    ordersToday: ordersTodayResult?.count ?? 0,
    topProducts: topProductsRaw.map(p => ({
      productId: p.productId,
      productName: p.productName,
      orderCount: p.orderCount,
      revenue: parseFloat(p.revenue ?? "0"),
    })),
    recentOrders: recentOrders.map(o => ({ ...o, totalPrice: parseFloat(o.totalPrice ?? "0") })),
  });
});

router.get("/admin/orders", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetAdminOrdersQueryParams.safeParse(req.query);
  const page = qp.success ? (qp.data.page ?? 1) : 1;
  const limit = qp.success ? (qp.data.limit ?? 20) : 20;
  const status = qp.success ? qp.data.status : undefined;
  const offset = (page - 1) * limit;

  const conditions = status ? [eq(ordersTable.status, status)] : [];
  const whereClause = conditions.length > 0 ? conditions[0] : undefined;

  const totalQ = whereClause
    ? db.select({ count: count() }).from(ordersTable).where(whereClause)
    : db.select({ count: count() }).from(ordersTable);

  const ordersQ = whereClause
    ? db.select().from(ordersTable).where(whereClause).orderBy(desc(ordersTable.createdAt)).limit(limit).offset(offset)
    : db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(limit).offset(offset);

  const [[totalResult], orders] = await Promise.all([totalQ, ordersQ]);

  res.json({
    orders: orders.map(o => ({ ...o, totalPrice: parseFloat(o.totalPrice ?? "0") })),
    total: totalResult?.count ?? 0,
    page,
    limit,
  });
});

router.post("/admin/orders/:id/retry", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;

  const [existing] = await db.select().from(ordersTable).where(eq(ordersTable.id, rawId));
  if (!existing) { res.status(404).json({ error: "Order not found" }); return; }
  if (existing.status !== "failed" && existing.status !== "pending") {
    res.status(409).json({ error: "Order cannot be retried", message: `Order status is ${existing.status}` });
    return;
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, existing.productId));
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, existing.userId));
  const provider = product?.provider ?? "manual";

  // Re-dispatch to upstream provider (skipped for manual products)
  let dispatchResult: { success: boolean; providerOrderId?: string; error?: string } = { success: true };
  if (product && provider !== "manual") {
    dispatchResult = await dispatchToProvider(existing, product);
  }

  if (dispatchResult.success) {
    const [updated] = await db.update(ordersTable)
      .set({
        status: "processing",
        providerOrderId: dispatchResult.providerOrderId ?? existing.providerOrderId,
        updatedAt: new Date(),
      })
      .where(eq(ordersTable.id, rawId))
      .returning();

    if (user) {
      await db.insert(notificationsTable).values({
        userId: existing.userId,
        type: "order_retry",
        title: "🔄 تمت إعادة محاولة طلبك",
        message: `أعاد الإدمن محاولة تنفيذ طلبك لـ ${existing.productName} — قيد التنفيذ الآن.`,
        isRead: false,
      });
    }

    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "retry", entity: "order", entityId: rawId }).catch(() => {});
    logger.info({ orderId: rawId, providerOrderId: dispatchResult.providerOrderId }, "Order retry dispatched to provider");
    res.json({ ...updated, totalPrice: parseFloat(updated.totalPrice ?? "0"), retryDispatched: true });
    return;
  }

  // Provider rejected again
  logger.warn({ orderId: rawId, error: dispatchResult.error }, "Order retry failed at provider");
  res.status(502).json({
    error: "Provider rejected retry",
    message: dispatchResult.error || "Provider did not accept the retry. Try again later or contact provider.",
  });
});

// ─── Admin: APPROVE order (manual or API) ──────────────────────────────────────
router.post("/admin/orders/:id/approve", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const deliveryMessage = typeof req.body?.deliveryMessage === "string" ? req.body.deliveryMessage : undefined;
  const result = await approveOrderById(rawId, { id: req.user!.id, username: req.user!.username }, { deliveryMessage });
  if (!result.ok) {
    res.status(result.reason === "Order not found" ? 404 : 409).json({ error: result.reason });
    return;
  }
  const [updated] = await db.select().from(ordersTable).where(eq(ordersTable.id, rawId));
  res.status(result.status === "completed" ? 200 : 502).json({ ...updated, totalPrice: parseFloat(updated?.totalPrice ?? "0") });
});

// ─── Admin: REJECT order (manual decline + refund) ────────────────────────────
router.post("/admin/orders/:id/reject", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const reason = (req.body?.reason as string | undefined)?.trim() || undefined;
  const result = await rejectOrderById(rawId, reason, { id: req.user!.id, username: req.user!.username });
  if (!result.ok) {
    res.status(result.reason === "Order not found" ? 404 : 409).json({ error: result.reason });
    return;
  }
  const [updated] = await db.select().from(ordersTable).where(eq(ordersTable.id, rawId));
  res.json({ ...updated, totalPrice: parseFloat(updated?.totalPrice ?? "0") });
});

router.get("/admin/payments", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetAdminPaymentsQueryParams.safeParse(req.query);
  const status = qp.success ? qp.data.status : undefined;

  const rows = await db
    .select({
      id: paymentsTable.id,
      userId: paymentsTable.userId,
      amount: paymentsTable.amount,
      currency: paymentsTable.currency,
      method: paymentsTable.method,
      status: paymentsTable.status,
      screenshotUrl: paymentsTable.screenshotUrl,
      transactionRef: paymentsTable.transactionRef,
      adminNote: paymentsTable.adminNote,
      createdAt: paymentsTable.createdAt,
      userEmail: usersTable.email,
      username: usersTable.username,
    })
    .from(paymentsTable)
    .leftJoin(usersTable, eq(paymentsTable.userId, usersTable.id))
    .where(status ? eq(paymentsTable.status, status) : undefined)
    .orderBy(desc(paymentsTable.createdAt));

  res.json(rows.map(p => ({ ...p, amount: parseFloat(p.amount ?? "0") })));
});

router.post("/admin/payments/:id/verify", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const parsed = VerifyPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { action, adminNote } = parsed.data;
  const newStatus = action === "approve" ? "approved" : "rejected";

  const [existingPayment] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, id));
  if (!existingPayment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }

  if (existingPayment.status !== "pending") {
    res.status(409).json({ error: "Payment already processed", message: "This payment request was already verified" });
    return;
  }

  const [payment] = await db
    .update(paymentsTable)
    .set({ status: newStatus, adminNote: adminNote ?? null })
    .where(and(eq(paymentsTable.id, id), eq(paymentsTable.status, "pending")))
    .returning();

  if (!payment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }

  if (action === "approve") {
    const amountRaw = parseFloat(payment.amount ?? "0");
    // Read dynamic rates from settings
    const sypRateRow = await db.select().from(settingsTable).where(eq(settingsTable.key, "syp_rate"));
    const eurRateRow = await db.select().from(settingsTable).where(eq(settingsTable.key, "eur_rate"));
    const sypRate = parseFloat(sypRateRow[0]?.value ?? "13000");
    const eurRate = parseFloat(eurRateRow[0]?.value ?? "0.92");
    const convertedToUsd = payment.currency === "SYP" ? amountRaw / sypRate : payment.currency === "EUR" ? amountRaw / eurRate : amountRaw;

    await db
      .update(usersTable)
      .set({ balance: sql`${usersTable.balance} + ${convertedToUsd.toString()}` })
      .where(eq(usersTable.id, payment.userId));

    await db.insert(walletTransactionsTable).values({
      userId: payment.userId,
      type: "deposit",
      amount: convertedToUsd.toString(),
      currency: "USD",
      description: `إيداع عبر ${payment.method} (${payment.currency} ${payment.amount})`,
    });

    await db.insert(notificationsTable).values({
      userId: payment.userId,
      type: "payment_approved",
      title: "✅ تمت الموافقة على الدفعة",
      message: `تمت الموافقة على إيداعك بقيمة ${payment.currency} ${parseFloat(payment.amount ?? "0").toLocaleString()} وإضافته لمحفظتك. (≈ $${convertedToUsd.toFixed(2)})`,
      isRead: false,
    });

    const [userRow] = await db.select({ username: usersTable.username }).from(usersTable).where(eq(usersTable.id, payment.userId));
    notifyDepositApproved({
      username: userRow?.username ?? String(payment.userId),
      amountUsd: convertedToUsd,
    }).catch(() => {});

    // Push live update to admin dashboard + user wallet via WebSocket
    try {
      const { emitPaymentApproved } = await import("../lib/ws");
      emitPaymentApproved({
        id: payment.id,
        username: userRow?.username ?? String(payment.userId),
        amount: convertedToUsd,
        currency: payment.currency,
      });
    } catch { /* ignore */ }
  } else {
    // Notify the user their deposit was rejected
    await db.insert(notificationsTable).values({
      userId: payment.userId,
      type: "payment_rejected",
      title: "🚫 تم رفض طلب الإيداع",
      message: adminNote
        ? `تم رفض طلب إيداعك. السبب: ${adminNote}`
        : `تم رفض طلب إيداعك. الرجاء التواصل مع الدعم.`,
      isRead: false,
    });
    try {
      const { emitPaymentApproved } = await import("../lib/ws");
      emitPaymentApproved({
        id: payment.id,
        username: String(payment.userId),
        amount: 0,
        currency: payment.currency,
      });
    } catch { /* ignore */ }
  }

  logger.info({ paymentId: id, action, adminId: req.user!.id }, "Payment verified by admin");
  res.json({ ...payment, amount: parseFloat(payment.amount ?? "0") });
});

router.get("/admin/users", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const qp = GetAdminUsersQueryParams.safeParse(req.query);
  const page = qp.success ? (qp.data.page ?? 1) : 1;
  const limit = qp.success ? (qp.data.limit ?? 20) : 20;
  const search = qp.success ? qp.data.search : undefined;
  const offset = (page - 1) * limit;

  // Search by email, username, public code, or numeric ID
  let whereClause: any = undefined;
  if (search && search.trim()) {
    const s = search.trim();
    const like = `%${s}%`;
    const numericId = /^\d+$/.test(s) ? parseInt(s, 10) : null;
    const orParts: any[] = [
      ilike(usersTable.email, like),
      ilike(usersTable.username, like),
      ilike(usersTable.publicCode, like),
    ];
    if (numericId !== null) {
      orParts.push(eq(usersTable.id, numericId));
    }
    whereClause = or(...orParts);
  }

  const totalQ = whereClause
    ? db.select({ count: count() }).from(usersTable).where(whereClause)
    : db.select({ count: count() }).from(usersTable);

  const usersQ = whereClause
    ? db.select().from(usersTable).where(whereClause).orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset)
    : db.select().from(usersTable).orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset);

  const [[totalResult], users] = await Promise.all([totalQ, usersQ]);

  res.json({
    users: users.map(u => ({
      id: u.id,
      publicCode: u.publicCode,
      username: u.username,
      email: u.email,
      role: u.role,
      balance: parseFloat(u.balance ?? "0"),
      vipLevel: u.vipLevel ?? 0,
      vipLocked: u.vipLocked ?? false,
      totalSpentUsd: parseFloat(u.totalSpentUsd ?? "0"),
      isSuspended: u.isSuspended,
      createdAt: u.createdAt,
    })),
    total: totalResult?.count ?? 0,
    page,
    limit,
  });
});

router.patch("/admin/users/:id/vip", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const userId = parseInt(rawId, 10);
  if (!Number.isFinite(userId)) {
    res.status(400).json({ error: "Invalid user id" });
    return;
  }

  const schema = z.object({
    level: z.number().int().min(0).max(10).optional(),
    locked: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const updates: Record<string, unknown> = {};
  if (parsed.data.level !== undefined) updates.vipLevel = parsed.data.level;
  if (parsed.data.locked !== undefined) updates.vipLocked = parsed.data.locked;
  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "Nothing to update" });
    return;
  }

  const [oldUser] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  const oldLevel = oldUser?.vipLevel ?? 0;

  const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, userId)).returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  await db.insert(notificationsTable).values({
    userId,
    type: "balance_updated",
    title: "تم تحديث مستوى VIP",
    message: parsed.data.level !== undefined
      ? `تم ضبط مستواك إلى VIP ${parsed.data.level} من قبل الإدارة`
      : `تم تحديث إعدادات VIP الخاصة بك`,
    isRead: false,
  });

  notifyVipChange({
    username: user.username,
    publicCode: user.publicCode,
    oldLevel,
    newLevel: user.vipLevel ?? 0,
    locked: user.vipLocked ?? false,
    adminUsername: req.user!.username,
  }).catch(() => {});

  logger.info({ userId, updates, adminId: req.user!.id }, "VIP level updated by admin");

  res.json({
    id: user.id,
    publicCode: user.publicCode,
    username: user.username,
    email: user.email,
    vipLevel: user.vipLevel ?? 0,
    vipLocked: user.vipLocked ?? false,
  });
});

router.patch("/admin/users/:id/balance", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const userId = parseInt(rawId, 10);

  const parsed = UpdateUserBalanceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { amount, operation, reason } = parsed.data;

  let newBalanceSql;
  if (operation === "add") {
    newBalanceSql = sql`${usersTable.balance} + ${amount.toString()}`;
  } else if (operation === "subtract") {
    newBalanceSql = sql`${usersTable.balance} - ${amount.toString()}`;
  } else {
    newBalanceSql = sql`${amount.toString()}`;
  }

  const [user] = await db
    .update(usersTable)
    .set({ balance: newBalanceSql })
    .where(eq(usersTable.id, userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  await db.insert(walletTransactionsTable).values({
    userId,
    type: operation === "subtract" ? "purchase" : "deposit",
    amount: (operation === "subtract" ? -amount : amount).toString(),
    currency: "USD",
    description: reason ?? `Admin balance adjustment (${operation})`,
  });

  await db.insert(notificationsTable).values({
    userId,
    type: "balance_updated",
    title: "تم تحديث الرصيد",
    message: operation === "add"
      ? `تم إضافة $${amount.toFixed(2)} إلى رصيدك من قبل الإدارة. الرصيد الحالي: $${parseFloat(user.balance ?? "0").toFixed(2)}`
      : operation === "subtract"
        ? `تم خصم $${amount.toFixed(2)} من رصيدك من قبل الإدارة. الرصيد الحالي: $${parseFloat(user.balance ?? "0").toFixed(2)}`
        : `تم تحديد رصيدك إلى $${amount.toFixed(2)} من قبل الإدارة.`,
    isRead: false,
  });

  notifyBalanceChange({
    username: user.username,
    publicCode: user.publicCode,
    operation,
    amount,
    newBalance: parseFloat(user.balance ?? "0"),
    reason,
    adminUsername: req.user!.username,
  }).catch(() => {});

  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    balance: parseFloat(user.balance ?? "0"),
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });
});

router.patch("/admin/users/:id/suspend", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const userId = parseInt(rawId, 10);

  const parsed = SuspendUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set({ isSuspended: parsed.data.suspended })
    .where(eq(usersTable.id, userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    balance: parseFloat(user.balance ?? "0"),
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });
});


router.get("/admin/revenue-chart", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const period = (req.query.period as string) ?? "30d";
  const days = period === "7d" ? 7 : period === "90d" ? 90 : 30;

  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const result = await db
    .select({
      date: sql<string>`DATE(${ordersTable.createdAt})`.as("date"),
      revenue: sum(ordersTable.totalPrice),
      orders: count(),
    })
    .from(ordersTable)
    .where(and(gte(ordersTable.createdAt, startDate), eq(ordersTable.status, "completed")))
    .groupBy(sql`DATE(${ordersTable.createdAt})`)
    .orderBy(sql`DATE(${ordersTable.createdAt})`);

  res.json(result.map(r => ({
    date: r.date,
    revenue: parseFloat(r.revenue ?? "0"),
    orders: r.orders,
  })));
});

router.post("/admin/products/create", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { name, nameAr, description, image, imageOverride, priceUsd, category, provider, providerProductId, requiredFields, customFields, status, profitMargin, sortOrder, subGroup } = req.body;

  if (!name || priceUsd === undefined || !category) {
    res.status(400).json({ error: "name, priceUsd, and category are required" });
    return;
  }

  const id = uuidv4();
  const [product] = await db
    .insert(productsTable)
    .values({
      id,
      name,
      nameAr: nameAr ?? null,
      description: description ?? null,
      image: image ?? null,
      imageOverride: imageOverride ?? null,
      priceUsd: String(priceUsd),
      category: category ?? "general",
      provider: provider ?? "manual",
      providerProductId: providerProductId ?? id,
      requiredFields: Array.isArray(requiredFields) ? requiredFields : [],
      customFields: Array.isArray(customFields) ? customFields : [],
      status: status ?? "active",
      profitMargin: String(profitMargin ?? 10),
      sortOrder: sortOrder ?? 0,
      isManual: true,
      subGroup: subGroup || null,
    })
    .returning();

  res.status(201).json({
    ...product,
    priceUsd: parseFloat(product.priceUsd ?? "0"),
    profitMargin: parseFloat(product.profitMargin ?? "10"),
    requiredFields: product.requiredFields ?? [],
  });
});

router.put("/admin/products/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = req.params.id as string;
  const { name, nameAr, description, image, imageOverride, priceUsd, category, status, profitMargin, sortOrder, isManual, requiredFields, customFields, subGroup, autoApprove } = req.body;

  const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const updateData: Record<string, unknown> = {};
  // Fields that — once edited — must be protected from auto-sync overwrites.
  const PROTECTED_FIELDS = ["name", "nameAr", "description", "image", "priceUsd", "category", "status"] as const;
  const newlyOverridden: string[] = [];
  const trackOverride = (field: string) => {
    if (PROTECTED_FIELDS.includes(field as any) && !newlyOverridden.includes(field)) newlyOverridden.push(field);
  };

  if (name !== undefined) { updateData.name = name; trackOverride("name"); }
  if (nameAr !== undefined) { updateData.nameAr = nameAr; trackOverride("nameAr"); }
  if (description !== undefined) { updateData.description = description; trackOverride("description"); }
  if (image !== undefined) { updateData.image = image; trackOverride("image"); }
  if (imageOverride !== undefined) updateData.imageOverride = imageOverride || null;
  if (priceUsd !== undefined) { updateData.priceUsd = String(priceUsd); trackOverride("priceUsd"); }
  if (category !== undefined) { updateData.category = category; trackOverride("category"); }
  if (status !== undefined) { updateData.status = status; trackOverride("status"); }
  if (profitMargin !== undefined) updateData.profitMargin = String(profitMargin);
  if (sortOrder !== undefined) updateData.sortOrder = sortOrder;
  if (isManual !== undefined) updateData.isManual = isManual;
  if (requiredFields !== undefined) updateData.requiredFields = Array.isArray(requiredFields) ? requiredFields : [];
  if (customFields !== undefined) updateData.customFields = Array.isArray(customFields) ? customFields : [];
  if (subGroup !== undefined) updateData.subGroup = subGroup || null;
  if (autoApprove !== undefined) updateData.autoApprove = !!autoApprove;

  // Merge newly-overridden fields with existing manualOverrides so the sync
  // never undoes the admin's edits. Allow explicit ?clearOverrides=1 to reset.
  const clearOverrides = req.query.clearOverrides === "1" || req.body?.clearOverrides === true;
  if (clearOverrides) {
    updateData.manualOverrides = [];
  } else if (newlyOverridden.length > 0) {
    const merged = Array.from(new Set([...(existing.manualOverrides ?? []), ...newlyOverridden]));
    updateData.manualOverrides = merged;
  }

  const [updated] = await db
    .update(productsTable)
    .set(updateData)
    .where(eq(productsTable.id, productId))
    .returning();

  // ── Log significant changes for audit trail ──
  const trackedFields: Array<keyof typeof updateData> = ["priceUsd", "profitMargin", "status", "name", "category", "isManual"];
  const changeRows: Array<{ productId: string; productName: string; adminId: number; adminUsername: string; field: string; oldValue: string | null; newValue: string | null }> = [];
  for (const f of trackedFields) {
    if (updateData[f] === undefined) continue;
    const oldV = (existing as any)[f];
    const newV = (updated as any)[f];
    const oldStr = oldV == null ? null : String(oldV);
    const newStr = newV == null ? null : String(newV);
    if (oldStr !== newStr) {
      changeRows.push({
        productId, productName: existing.name,
        adminId: req.user!.id, adminUsername: req.user!.username,
        field: String(f), oldValue: oldStr, newValue: newStr,
      });
    }
  }
  if (changeRows.length > 0) {
    db.insert(productChangeLogTable).values(changeRows).catch(() => {});
  }

  res.json({
    ...updated,
    priceUsd: parseFloat(updated.priceUsd ?? "0"),
    profitMargin: parseFloat(updated.profitMargin ?? "10"),
    requiredFields: updated.requiredFields ?? [],
  });
});

// ─── Bulk price/margin update ────────────────────────────────────────────────
router.post("/admin/products/reorder", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { orders } = req.body as { orders?: Array<{ id: string; sortOrder: number }> };
  if (!Array.isArray(orders) || orders.length === 0) {
    res.status(400).json({ error: "orders required" });
    return;
  }
  let updated = 0;
  for (const o of orders) {
    if (!o || typeof o.id !== "string" || !Number.isFinite(o.sortOrder)) continue;
    const r = await db.update(productsTable).set({ sortOrder: Math.floor(o.sortOrder) }).where(eq(productsTable.id, o.id)).returning({ id: productsTable.id });
    updated += r.length;
  }
  res.json({ success: true, updated });
});

router.post("/admin/products/bulk-update", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { productIds, field, mode, value, valueText, valueBool } = req.body as {
    productIds?: string[];
    field?: "priceUsd" | "profitMargin" | "subGroup" | "category" | "status" | "autoApprove";
    mode?: "set" | "increase_pct" | "decrease_pct";
    value?: number;
    valueText?: string | null;
    valueBool?: boolean;
  };

  if (!Array.isArray(productIds) || productIds.length === 0) {
    res.status(400).json({ error: "productIds required" });
    return;
  }

  // ── Boolean bulk update (autoApprove) ──────────────────────────────────
  if (field === "autoApprove") {
    const v = !!valueBool;
    const result = await db
      .update(productsTable)
      .set({ autoApprove: v })
      .where(inArray(productsTable.id, productIds))
      .returning({ id: productsTable.id });
    res.json({ success: true, updated: result.length });
    return;
  }

  // ── Text/enum bulk update (subGroup, category, status) ─────────────────
  if (field === "subGroup" || field === "category" || field === "status") {
    if (mode !== "set") {
      res.status(400).json({ error: "text fields only support mode=set" });
      return;
    }
    const v = (typeof valueText === "string" ? valueText.trim() : "");
    const updateData: Record<string, unknown> = {};
    if (field === "subGroup") {
      updateData.subGroup = v ? v : null;
    } else if (field === "category") {
      if (!v) { res.status(400).json({ error: "category cannot be empty" }); return; }
      updateData.category = v;
    } else {
      if (v !== "active" && v !== "inactive") { res.status(400).json({ error: "status must be active or inactive" }); return; }
      updateData.status = v;
    }
    const result = await db
      .update(productsTable)
      .set(updateData)
      .where(inArray(productsTable.id, productIds))
      .returning({ id: productsTable.id });
    res.json({ success: true, updated: result.length });
    return;
  }

  if (field !== "priceUsd" && field !== "profitMargin") {
    res.status(400).json({ error: "field must be priceUsd, profitMargin, subGroup, category, or status" });
    return;
  }
  if (mode !== "set" && mode !== "increase_pct" && mode !== "decrease_pct") {
    res.status(400).json({ error: "invalid mode" });
    return;
  }
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) {
    res.status(400).json({ error: "value must be a non-negative number" });
    return;
  }

  const column = field === "priceUsd" ? productsTable.priceUsd : productsTable.profitMargin;
  let setExpr;
  if (mode === "set") {
    setExpr = sql`${String(num)}`;
  } else if (mode === "increase_pct") {
    setExpr = sql`CAST(${column} AS NUMERIC) * (1 + ${num} / 100.0)`;
  } else {
    setExpr = sql`CAST(${column} AS NUMERIC) * (1 - ${num} / 100.0)`;
  }

  const updateData: Record<string, unknown> = {};
  if (field === "priceUsd") {
    updateData.priceUsd = setExpr;
  } else {
    updateData.profitMargin = setExpr;
  }

  const result = await db
    .update(productsTable)
    .set(updateData)
    .where(inArray(productsTable.id, productIds))
    .returning({ id: productsTable.id });

  res.json({ success: true, updated: result.length });
});

// ─── Bulk product delete (destructive — max 100 products per request) ─────────
router.delete("/admin/products/bulk-delete", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const rawIds = req.body?.productIds;
  if (!Array.isArray(rawIds) || rawIds.length === 0 || rawIds.length > 100) {
    res.status(400).json({ error: "productIds array required (1-100)" });
    return;
  }

  const productIds = Array.from(new Set(
    rawIds.filter((id): id is string => typeof id === "string" && id.trim().length > 0).map(id => id.trim()),
  ));
  if (productIds.length === 0 || productIds.length > 100) {
    res.status(400).json({ error: "productIds must contain 1-100 valid IDs" });
    return;
  }

  const existing = await db
    .select({ id: productsTable.id, name: productsTable.name })
    .from(productsTable)
    .where(inArray(productsTable.id, productIds));
  if (existing.length === 0) {
    res.status(404).json({ error: "No matching products found" });
    return;
  }

  const deleted = await db
    .delete(productsTable)
    .where(inArray(productsTable.id, existing.map(product => product.id)))
    .returning({ id: productsTable.id });

  logAdminAction({
    adminId: req.user!.id,
    adminUsername: req.user!.username,
    action: "bulk_delete",
    entity: "product",
    details: {
      requestedCount: productIds.length,
      deletedCount: deleted.length,
      productIds: existing.map(product => product.id),
      productNames: existing.map(product => product.name),
    },
    ip: req.ip,
  }).catch(() => {});

  res.json({ success: true, deletedCount: deleted.length, missingCount: productIds.length - existing.length });
});

// ─── Flash sale: set / clear ─────────────────────────────────────────────────
router.post("/admin/products/:id/sale", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = req.params.id as string;
  const { discountPct, durationHours, salePriceUsd, saleEndsAt } = req.body as {
    discountPct?: number;
    durationHours?: number;
    salePriceUsd?: number;
    saleEndsAt?: string;
  };

  const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const basePrice = parseFloat(existing.priceUsd ?? "0");
  let finalSalePrice: number;
  if (typeof salePriceUsd === "number" && salePriceUsd > 0) {
    finalSalePrice = salePriceUsd;
  } else if (typeof discountPct === "number" && discountPct > 0 && discountPct < 100) {
    finalSalePrice = +(basePrice * (1 - discountPct / 100)).toFixed(4);
  } else {
    res.status(400).json({ error: "Provide discountPct (1-99) or salePriceUsd" });
    return;
  }
  if (finalSalePrice >= basePrice) {
    res.status(400).json({ error: "Sale price must be lower than current price" });
    return;
  }

  let endsAt: Date;
  if (saleEndsAt) {
    endsAt = new Date(saleEndsAt);
    if (Number.isNaN(endsAt.getTime()) || endsAt.getTime() <= Date.now()) {
      res.status(400).json({ error: "saleEndsAt must be a future date" });
      return;
    }
  } else if (typeof durationHours === "number" && durationHours > 0) {
    endsAt = new Date(Date.now() + durationHours * 3600 * 1000);
  } else {
    res.status(400).json({ error: "Provide durationHours or saleEndsAt" });
    return;
  }

  const [updated] = await db
    .update(productsTable)
    .set({ salePriceUsd: String(finalSalePrice), saleEndsAt: endsAt })
    .where(eq(productsTable.id, productId))
    .returning();

  res.json({
    success: true,
    product: {
      id: updated.id,
      salePriceUsd: parseFloat(updated.salePriceUsd ?? "0"),
      saleEndsAt: updated.saleEndsAt,
    },
  });
});

router.delete("/admin/products/:id/sale", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = req.params.id as string;
  await db
    .update(productsTable)
    .set({ salePriceUsd: null, saleEndsAt: null })
    .where(eq(productsTable.id, productId));
  res.json({ success: true });
});

router.post("/admin/notifications/broadcast", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { title, message, type = "announcement", targetUserId } = req.body as {
    title: string;
    message: string;
    type?: string;
    targetUserId?: number;
  };

  if (!title?.trim() || !message?.trim()) {
    res.status(400).json({ error: "Title and message are required" });
    return;
  }

  if (targetUserId) {
    const [user] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.id, targetUserId));
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    await db.insert(notificationsTable).values({ userId: targetUserId, type, title, message, isRead: false });
    res.json({ success: true, sent: 1 });
    return;
  }

  const allUsers = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.role, "user"));
  if (allUsers.length === 0) {
    res.json({ success: true, sent: 0 });
    return;
  }

  await db.insert(notificationsTable).values(
    allUsers.map(u => ({ userId: u.id, type, title, message, isRead: false }))
  );

  res.json({ success: true, sent: allUsers.length });
});

router.get("/admin/notifications/history", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const limit = parseInt(req.query.limit as string || '50', 10);
  const notifications = await db
    .select({
      id: notificationsTable.id,
      title: notificationsTable.title,
      message: notificationsTable.message,
      type: notificationsTable.type,
      createdAt: notificationsTable.createdAt,
      userId: notificationsTable.userId,
      username: usersTable.username,
    })
    .from(notificationsTable)
    .leftJoin(usersTable, eq(notificationsTable.userId, usersTable.id))
    .where(sql`${notificationsTable.type} IN ('announcement', 'offer', 'info', 'warning')`)
    .orderBy(desc(notificationsTable.createdAt))
    .limit(limit);

  res.json(notifications);
});

router.delete("/admin/products/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = req.params.id as string;

  const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  await db.delete(productsTable).where(eq(productsTable.id, productId));
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "delete", entity: "product", entityId: productId, details: { name: existing.name } }).catch(() => {});
  res.json({ success: true });
});

// ─── Admin Activity Log ────────────────────────────────────────────────────────
router.get("/admin/activity-log", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const limit = Math.min(parseInt(req.query.limit as string || '100', 10), 500);
  const page = Math.max(parseInt(req.query.page as string || '1', 10), 1);
  const offset = (page - 1) * limit;

  const [totalResult] = await db.select({ count: count() }).from(adminActivityLogTable);
  const logs = await db
    .select()
    .from(adminActivityLogTable)
    .orderBy(desc(adminActivityLogTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json({ logs, total: totalResult?.count ?? 0, page, limit });
});

// ─── Orders CSV Export ─────────────────────────────────────────────────────────
router.get("/admin/orders/export", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const conditions = status ? [eq(ordersTable.status, status)] : [];
  const whereClause = conditions.length > 0 ? conditions[0] : undefined;

  const orders = whereClause
    ? await db.select().from(ordersTable).where(whereClause).orderBy(desc(ordersTable.createdAt)).limit(5000)
    : await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(5000);

  const headers = ["id", "userId", "productId", "productName", "qty", "totalPrice", "currency", "status", "providerOrderId", "createdAt"];
  const rows = orders.map(o => [
    o.id, o.userId, o.productId, `"${(o.productName ?? "").replace(/"/g, '""')}"`,
    o.qty, parseFloat(o.totalPrice ?? "0").toFixed(2), o.currency ?? "USD",
    o.status, o.providerOrderId ?? "",
    o.createdAt ? new Date(o.createdAt).toISOString() : "",
  ]);

  const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="orders_${new Date().toISOString().split("T")[0]}.csv"`);
  res.send("\uFEFF" + csv);

  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "export", entity: "orders", details: { count: orders.length, status: status ?? "all" } }).catch(() => {});
});

// ─── Per-category profit margin bulk update ────────────────────────────────────
router.post("/admin/categories/:id/apply-profit", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const catId = parseInt(req.params.id as string, 10);
  const { profitMargin, applyToProducts } = req.body as { profitMargin: number; applyToProducts?: boolean };

  if (!Number.isFinite(profitMargin) || profitMargin < 0 || profitMargin > 1000) {
    res.status(400).json({ error: "profitMargin must be between 0 and 1000" });
    return;
  }

  const [cat] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, catId));
  if (!cat) { res.status(404).json({ error: "Category not found" }); return; }

  await db.update(categoriesTable).set({ profitMargin: String(profitMargin) }).where(eq(categoriesTable.id, catId));

  let updatedProducts = 0;
  if (applyToProducts && cat.href) {
    const urlCategory = cat.href.split("category=")[1]?.split("&")[0];
    if (urlCategory) {
      const result = await db.update(productsTable)
        .set({ profitMargin: String(profitMargin), updatedAt: new Date() })
        .where(eq(productsTable.category, urlCategory))
        .returning();
      updatedProducts = result.length;
    }
  }

  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_profit", entity: "category", entityId: String(catId), details: { profitMargin, updatedProducts } }).catch(() => {});
  res.json({ success: true, profitMargin, updatedProducts });
});

// ─── Category reorder (drag & drop) ───────────────────────────────────────────
router.post("/admin/categories/reorder", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { order } = req.body as { order: number[] };
  if (!Array.isArray(order) || order.some(id => typeof id !== "number")) {
    res.status(400).json({ error: "order must be an array of category IDs" });
    return;
  }
  try {
    await Promise.all(
      order.map((id, idx) =>
        db.update(categoriesTable).set({ sortOrder: idx }).where(eq(categoriesTable.id, id))
      )
    );
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "reorder_categories", entity: "category", entityId: "all", details: { order } }).catch(() => {});
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Reorder failed" });
  }
});

// ─── Sync All Products (smart unified sync from all providers) ─────────────────
router.post("/admin/sync-products", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const provider = req.body?.provider as string | undefined;
  try {
    logger.info({ provider: provider ?? "all" }, "Admin triggered product sync");
    const result = await syncProductsFromAPIs(provider);
    logAdminAction({
      adminId: req.user!.id,
      adminUsername: req.user!.username,
      action: "sync_products",
      entity: "product",
      entityId: "all",
      details: { provider: provider ?? "all", imported: result.imported, errors: result.errors },
    }).catch(() => {});
    res.json({ success: true, imported: result.imported, errors: result.errors });
  } catch (err: any) {
    logger.error({ err }, "sync-products failed");
    res.status(500).json({ error: err?.message ?? "Sync failed" });
  }
});

// ─── Telegram Bot Management ───────────────────────────────────────────────────
router.get("/admin/telegram/info", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const info = await getTelegramWebhookInfo();
    res.json(info);
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed to get webhook info" });
  }
});

router.post("/admin/telegram/setup-webhook", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const { siteUrl } = req.body as { siteUrl?: string };
    if (siteUrl) {
      process.env.SITE_URL = siteUrl.trim().replace(/\/$/, "");
    }
    await configureTelegramWebhook();
    const info = await getTelegramWebhookInfo();
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "setup_webhook", entity: "telegram", entityId: "webhook", details: { siteUrl } }).catch(() => {});
    res.json({ success: true, webhookInfo: info });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed to setup webhook" });
  }
});

router.delete("/admin/telegram/webhook", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const result = await deleteTelegramWebhook();
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed to delete webhook" });
  }
});

router.post("/admin/telegram/test", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const ok = await sendTestMessage();
    res.json({ success: ok });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed to send test message" });
  }
});

router.post("/admin/telegram/report/daily", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  try { await sendDailyReport(); res.json({ success: true }); }
  catch (err: any) { res.status(500).json({ error: err?.message ?? "Failed" }); }
});

router.post("/admin/telegram/report/weekly", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  try { await sendWeeklyReport(); res.json({ success: true }); }
  catch (err: any) { res.status(500).json({ error: err?.message ?? "Failed" }); }
});

// ─── Project Archive Download (built fresh on every request) ───────────────────
router.get("/admin/download/project", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { spawn } = await import("child_process");
  const projectRoot = path.resolve(process.cwd(), "..", "..");
  const dataDir = path.join(projectRoot, "data");
  const dumpPath = path.join(dataDir, "initial_data.sql.gz");

  try {
    fs.mkdirSync(dataDir, { recursive: true });

    // 1) Fresh DB dump
    const dbUrl = process.env.DATABASE_URL;
    if (dbUrl) {
      await new Promise<void>((resolve, reject) => {
        const dump = spawn("bash", ["-c", `pg_dump --no-owner --no-acl "${dbUrl}" | gzip > "${dumpPath}"`]);
        let stderr = "";
        dump.stderr.on("data", d => { stderr += d.toString(); });
        dump.on("close", code => code === 0 ? resolve() : reject(new Error(`pg_dump exit ${code}: ${stderr.slice(0, 300)}`)));
        dump.on("error", reject);
      });
    }

    // 2) Build archive name with timestamp
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const filename = `elite-store-${stamp}.tar.gz`;

    res.setHeader("Content-Type", "application/gzip");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Cache-Control", "no-store");

    // 3) Stream tar.gz of source — exclude heavy/generated/secret items
    const excludes = [
      "node_modules", "dist", ".git", ".cache", ".turbo", ".pnpm-store",
      "exports", "tmp", ".local", ".upm", ".config",
      "*.tar.gz", "*.zip", ".env", ".env.local", ".env.production",
      "logs", "*.log",
    ];
    const tarArgs = ["-czf", "-"];
    for (const e of excludes) tarArgs.push(`--exclude=${e}`);
    tarArgs.push("-C", projectRoot, ".");

    const tar = spawn("tar", tarArgs);
    let tarErr = "";
    tar.stderr.on("data", d => { tarErr += d.toString(); });
    tar.stdout.pipe(res);
    tar.on("error", err => {
      if (!res.headersSent) res.status(500).json({ error: err.message });
      else res.end();
    });
    tar.on("close", code => {
      if (code !== 0 && !res.writableEnded) res.end();
      logAdminAction({
        adminId: req.user!.id, adminUsername: req.user!.username,
        action: "download_project", entity: "system", entityId: filename,
        details: { code, stderr: tarErr.slice(0, 200) },
      }).catch(() => {});
    });

    req.on("close", () => { try { tar.kill(); } catch {} });
  } catch (err: any) {
    if (!res.headersSent) res.status(500).json({ error: err?.message ?? "Failed to build archive" });
  }
});

// ─── Payment Methods CRUD ──────────────────────────────────────────────────────
router.get("/admin/payment-methods", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const methods = await db.select().from(paymentMethodsTable).orderBy(paymentMethodsTable.sortOrder);
    res.json(methods.map(m => ({ ...m, details: JSON.parse(m.details || "[]") })));
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.post("/admin/payment-methods", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const { slug, nameAr, nameEn, emoji, color, imageUrl, currency, isActive, details } = req.body;
    if (!slug || !nameAr || !nameEn) { res.status(400).json({ error: "slug, nameAr, nameEn required" }); return; }
    const [method] = await db.insert(paymentMethodsTable).values({
      slug, nameAr, nameEn,
      emoji: emoji || "💳",
      color: color || "#6366f1",
      imageUrl: imageUrl || null,
      currency: currency || "SYP",
      isActive: isActive !== false,
      details: JSON.stringify(details || []),
      sortOrder: 0,
    }).returning();
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "create_payment_method", entity: "payment_method", entityId: String(method.id) }).catch(() => {});
    res.json({ ...method, details: JSON.parse(method.details || "[]") });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.put("/admin/payment-methods/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string);
    const { slug, nameAr, nameEn, emoji, color, imageUrl, currency, isActive, details } = req.body;
    const [method] = await db.update(paymentMethodsTable).set({
      ...(slug && { slug }), ...(nameAr && { nameAr }), ...(nameEn && { nameEn }),
      ...(emoji !== undefined && { emoji }), ...(color !== undefined && { color }),
      ...(imageUrl !== undefined && { imageUrl: imageUrl || null }),
      ...(currency !== undefined && { currency }), ...(isActive !== undefined && { isActive }),
      ...(details !== undefined && { details: JSON.stringify(details) }),
    }).where(eq(paymentMethodsTable.id, id)).returning();
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_payment_method", entity: "payment_method", entityId: String(id) }).catch(() => {});
    res.json({ ...method, details: JSON.parse(method.details || "[]") });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.delete("/admin/payment-methods/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string);
    await db.delete(paymentMethodsTable).where(eq(paymentMethodsTable.id, id));
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "delete_payment_method", entity: "payment_method", entityId: String(id) }).catch(() => {});
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.post("/admin/payment-methods/reorder", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const { order } = req.body as { order: number[] };
    if (!Array.isArray(order)) { res.status(400).json({ error: "order must be array of ids" }); return; }
    await Promise.all(order.map((id, idx) => db.update(paymentMethodsTable).set({ sortOrder: idx }).where(eq(paymentMethodsTable.id, id))));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

// ─── Categories CRUD ───────────────────────────────────────────────────────────
router.get("/admin/categories", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const cats = await db.select().from(categoriesTable).orderBy(categoriesTable.sortOrder);
    res.json(cats);
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.post("/admin/categories", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const { nameAr, nameEn, href, color, bgGradient, imageUrl, icon1, icon2, icon3, icon4, iconLabel1, iconLabel2, iconLabel3, iconLabel4, isActive, profitMargin, bannerImage, bannerTitle, bannerSubtitle } = req.body;
    if (!nameAr || !nameEn) { res.status(400).json({ error: "nameAr and nameEn required" }); return; }
    const [cat] = await db.insert(categoriesTable).values({
      nameAr, nameEn,
      href: href || "/products",
      color: color || "#6C5CE7",
      bgGradient: bgGradient || "linear-gradient(145deg, #1a0040, #2d0080)",
      imageUrl: imageUrl || null,
      icon1: icon1 || "", icon2: icon2 || "", icon3: icon3 || "", icon4: icon4 || "",
      iconLabel1: iconLabel1 || "", iconLabel2: iconLabel2 || "", iconLabel3: iconLabel3 || "", iconLabel4: iconLabel4 || "",
      isActive: isActive !== false,
      profitMargin: profitMargin ? String(profitMargin) : null,
      sortOrder: 0,
      bannerImage: bannerImage || null,
      bannerTitle: bannerTitle || null,
      bannerSubtitle: bannerSubtitle || null,
    }).returning();
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "create_category", entity: "category", entityId: String(cat.id) }).catch(() => {});
    res.json(cat);
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.put("/admin/categories/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string);
    const { nameAr, nameEn, href, color, bgGradient, imageUrl, icon1, icon2, icon3, icon4, iconLabel1, iconLabel2, iconLabel3, iconLabel4, isActive, profitMargin, sortOrder, bannerImage, bannerTitle, bannerSubtitle } = req.body;
    const [cat] = await db.update(categoriesTable).set({
      ...(nameAr !== undefined && { nameAr }),
      ...(nameEn !== undefined && { nameEn }),
      ...(href !== undefined && { href }),
      ...(color !== undefined && { color }),
      ...(bgGradient !== undefined && { bgGradient }),
      ...(imageUrl !== undefined && { imageUrl: imageUrl || null }),
      ...(icon1 !== undefined && { icon1 }), ...(icon2 !== undefined && { icon2 }),
      ...(icon3 !== undefined && { icon3 }), ...(icon4 !== undefined && { icon4 }),
      ...(iconLabel1 !== undefined && { iconLabel1 }), ...(iconLabel2 !== undefined && { iconLabel2 }),
      ...(iconLabel3 !== undefined && { iconLabel3 }), ...(iconLabel4 !== undefined && { iconLabel4 }),
      ...(isActive !== undefined && { isActive }),
      ...(profitMargin !== undefined && { profitMargin: profitMargin ? String(profitMargin) : null }),
      ...(sortOrder !== undefined && { sortOrder }),
      ...(bannerImage !== undefined && { bannerImage: bannerImage || null }),
      ...(bannerTitle !== undefined && { bannerTitle: bannerTitle || null }),
      ...(bannerSubtitle !== undefined && { bannerSubtitle: bannerSubtitle || null }),
    }).where(eq(categoriesTable.id, id)).returning();
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_category", entity: "category", entityId: String(id) }).catch(() => {});
    res.json(cat);
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.delete("/admin/categories/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string);
    await db.delete(categoriesTable).where(eq(categoriesTable.id, id));
    logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "delete_category", entity: "category", entityId: String(id) }).catch(() => {});
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

router.patch("/admin/categories/:id/toggle", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string);
    const [cat] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, id));
    if (!cat) { res.status(404).json({ error: "Not found" }); return; }
    const [updated] = await db.update(categoriesTable).set({ isActive: !cat.isActive }).where(eq(categoriesTable.id, id)).returning();
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

// ─── Sub-groups list (settings-backed, public read) ──────────────────────────
const DEFAULT_SUB_GROUPS = ["شدات", "عضويات", "بطاقات", "كنوز", "هدايا", "يدوي", "روبوت", "عالمي"];

router.get("/sub-groups", async (_req, res): Promise<void> => {
  const v = await getSettingValue("product_sub_groups", "");
  let list: string[] = DEFAULT_SUB_GROUPS;
  if (v) {
    try {
      const parsed = JSON.parse(v);
      if (Array.isArray(parsed)) list = parsed.filter(s => typeof s === "string" && s.trim()).map(s => s.trim());
    } catch { /* ignore */ }
  }
  res.json({ items: list });
});

router.put("/admin/sub-groups", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { items } = (req.body || {}) as { items?: unknown };
  if (!Array.isArray(items)) { res.status(400).json({ error: "items must be array of strings" }); return; }
  const cleaned = Array.from(new Set(
    items.filter(s => typeof s === "string").map(s => (s as string).trim()).filter(Boolean)
  ));
  await db
    .insert(settingsTable)
    .values({ key: "product_sub_groups", value: JSON.stringify(cleaned) })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: JSON.stringify(cleaned), updatedAt: new Date() } });
  res.json({ items: cleaned });
});

// ─── Featured games (admin-controlled cards on /games page) ─────────────────
const DEFAULT_FEATURED_GAMES = [
  { id: "pubg", nameAr: "ببجي موبايل", nameEn: "PUBG Mobile", color: "#F5A623", emoji: "🎯", category: "mobile_games", keywords: ["شدات", "ببجي", "pubg"], sortOrder: 0, isActive: true },
  { id: "freefire", nameAr: "فري فاير", nameEn: "Free Fire", color: "#F97316", emoji: "🔥", category: "mobile_games", keywords: ["فري فاير", "free fire", "garena free fire"], sortOrder: 1, isActive: true },
];

router.get("/featured-games", async (_req, res): Promise<void> => {
  const v = await getSettingValue("featured_games", "");
  let list = DEFAULT_FEATURED_GAMES;
  if (v) {
    try {
      const parsed = JSON.parse(v);
      if (Array.isArray(parsed)) list = parsed;
    } catch { /* ignore */ }
  }
  res.json({ items: list });
});

router.put("/admin/featured-games", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { items } = (req.body || {}) as { items?: unknown };
  if (!Array.isArray(items)) { res.status(400).json({ error: "items must be array" }); return; }
  const cleaned = items
    .filter((it: any) => it && typeof it.id === "string" && it.id.trim())
    .map((it: any, idx: number) => ({
      id: String(it.id).trim(),
      nameAr: String(it.nameAr ?? "").trim(),
      nameEn: String(it.nameEn ?? "").trim(),
      color: String(it.color ?? "#8b5cf6").trim(),
      emoji: String(it.emoji ?? "🎮").trim(),
      category: String(it.category ?? "mobile_games").trim(),
      keywords: Array.isArray(it.keywords) ? it.keywords.map((k: any) => String(k).trim()).filter(Boolean) : [],
      sortOrder: Number.isFinite(it.sortOrder) ? Number(it.sortOrder) : idx,
      isActive: it.isActive !== false,
    }));
  await db
    .insert(settingsTable)
    .values({ key: "featured_games", value: JSON.stringify(cleaned) })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: JSON.stringify(cleaned), updatedAt: new Date() } });
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_featured_games", entity: "settings", details: { count: cleaned.length } }).catch(() => {});
  res.json({ items: cleaned });
});

// ─── Auto-generate featured cards from synced provider data ────────────────
//   Suggests one card per distinct provider_category_name found in products.
router.get("/admin/featured-games/auto-generate", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const provider = typeof req.query.provider === "string" ? req.query.provider.trim() : "";
  const category = typeof req.query.category === "string" ? req.query.category.trim() : "";
  const minProducts = Math.max(1, parseInt(String(req.query.min || "2"), 10) || 2);
  const conds: any[] = [eq(productsTable.status, "active"), isNotNull(productsTable.providerCategoryName)];
  if (provider) conds.push(eq(productsTable.provider, provider));
  if (category) conds.push(eq(productsTable.category, category));
  const rows = await db
    .select({
      providerCategoryName: productsTable.providerCategoryName,
      category: productsTable.category,
      provider: productsTable.provider,
      cnt: sql<number>`count(*)::int`,
    })
    .from(productsTable)
    .where(and(...conds))
    .groupBy(productsTable.providerCategoryName, productsTable.category, productsTable.provider)
    .orderBy(sql`count(*) DESC`);

  const colorByCategory: Record<string, string> = {
    mobile_games: "#8b5cf6", pc_games: "#06b6d4", gift_cards: "#f59e0b",
    services: "#10b981", general: "#ef4444",
  };
  const emojiByCategory: Record<string, string> = {
    mobile_games: "📱", pc_games: "💻", gift_cards: "🎁",
    services: "✨", general: "🛒",
  };
  // ── Existing IDs to avoid collisions
  const existingRaw = await getSettingValue("featured_games", "");
  let existing: any[] = [];
  try { const p = JSON.parse(existingRaw); if (Array.isArray(p)) existing = p; } catch { /* ignore */ }
  const existingIds = new Set(existing.map(g => String(g.id)));
  const existingKeywords = new Set(
    existing.flatMap(g => (Array.isArray(g.keywords) ? g.keywords : []).map((k: string) => k.toLowerCase().trim()))
  );

  const slugify = (s: string) => s.toLowerCase()
    .replace(/[\u064B-\u0652]/g, "")
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40) || `card_${Date.now()}`;

  const suggestions = rows
    .filter(r => r.providerCategoryName && (r.cnt as any) >= minProducts)
    .map((r, idx) => {
      const name = String(r.providerCategoryName);
      let id = slugify(name);
      let n = 2;
      while (existingIds.has(id)) { id = `${slugify(name)}_${n++}`; }
      existingIds.add(id);
      const cat = String(r.category || "mobile_games");
      const isDup = existingKeywords.has(name.toLowerCase().trim());
      return {
        id, nameAr: name, nameEn: name,
        color: colorByCategory[cat] || "#8b5cf6",
        emoji: emojiByCategory[cat] || "🎮",
        category: cat,
        keywords: [name],
        sortOrder: existing.length + idx,
        isActive: true,
        productCount: r.cnt,
        provider: r.provider,
        alreadyExists: isDup,
      };
    });
  res.json({ suggestions });
});

// ─── Per-product manual assignment to a featured card ───────────────────────
//   Stored in setting `featured_card_assignments` = { cardId: [productId, ...] }
//   Filter in /api/products?game_group=X also includes products listed under X.
router.post("/admin/featured-games/assign-product", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { productId, cardId } = (req.body || {}) as { productId?: string; cardId?: string | null };
  if (!productId || typeof productId !== "string") { res.status(400).json({ error: "productId required" }); return; }
  const raw = await getSettingValue("featured_card_assignments", "");
  let map: Record<string, string[]> = {};
  if (raw) { try { const p = JSON.parse(raw); if (p && typeof p === "object") map = p; } catch { /* ignore */ } }
  // Remove from any existing card
  for (const k of Object.keys(map)) {
    map[k] = (map[k] || []).filter(id => id !== productId);
    if (map[k].length === 0) delete map[k];
  }
  // Add to target card (null = unassign only)
  if (cardId && typeof cardId === "string") {
    map[cardId] = Array.from(new Set([...(map[cardId] || []), productId]));
  }
  const value = JSON.stringify(map);
  await db
    .insert(settingsTable)
    .values({ key: "featured_card_assignments", value })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "assign_product_to_card", entity: "products", entityId: productId, details: { cardId } }).catch(() => {});
  res.json({ ok: true, assignments: map });
});

// ─── Game-group sub-tabs (admin-controlled tabs in /products?game_group=X) ──
const DEFAULT_GAME_SUBTABS: Record<string, any[]> = {
  pubg: [
    { key: "all",    labelAr: "الكل",     labelEn: "All",        keywords: [], subGroups: [], sortOrder: 0, isActive: true },
    { key: "uc",     labelAr: "شدات UC",  labelEn: "UC",         keywords: ["شدات", "uc"], subGroups: ["شدات"], sortOrder: 1, isActive: true },
    { key: "robot",  labelAr: "روبوت",    labelEn: "Robot",      keywords: ["روبوت"],      subGroups: ["روبوت"], sortOrder: 2, isActive: true },
    { key: "manual", labelAr: "يدوي",     labelEn: "Manual",     keywords: ["يدوي"],       subGroups: ["يدوي"], sortOrder: 3, isActive: true },
    { key: "mem",    labelAr: "عضويات",   labelEn: "Membership", keywords: ["عضوي"],       subGroups: ["عضويات"], sortOrder: 4, isActive: true },
  ],
  freefire: [
    { key: "all",    labelAr: "الكل",        labelEn: "All",        keywords: [], subGroups: [], sortOrder: 0, isActive: true },
    { key: "codes",  labelAr: "اكواد",        labelEn: "Codes",      keywords: ["اكواد", "code"], subGroups: ["بطاقات"], sortOrder: 1, isActive: true },
    { key: "mem",    labelAr: "عضويات",       labelEn: "Membership", keywords: ["عضوي"],          subGroups: ["عضويات"], sortOrder: 2, isActive: true },
    { key: "global", labelAr: "عالمي",         labelEn: "Global",     keywords: ["عالمي", "global"], subGroups: ["عالمي"], sortOrder: 3, isActive: true },
    { key: "robot",  labelAr: "روبوت",         labelEn: "Robot",      keywords: ["روبوت"],         subGroups: ["روبوت"], sortOrder: 4, isActive: true },
  ],
};

router.get("/game-group-subtabs", async (_req, res): Promise<void> => {
  const v = await getSettingValue("game_group_subtabs", "");
  let map: Record<string, any[]> = DEFAULT_GAME_SUBTABS;
  if (v) {
    try {
      const parsed = JSON.parse(v);
      if (parsed && typeof parsed === "object") map = parsed;
    } catch { /* ignore */ }
  }
  res.json({ groups: map });
});

router.put("/admin/game-group-subtabs", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { groups } = (req.body || {}) as { groups?: unknown };
  if (!groups || typeof groups !== "object" || Array.isArray(groups)) {
    res.status(400).json({ error: "groups must be an object map" }); return;
  }
  const cleaned: Record<string, any[]> = {};
  for (const [gid, tabs] of Object.entries(groups as Record<string, unknown>)) {
    if (!Array.isArray(tabs)) continue;
    cleaned[gid] = (tabs as any[])
      .filter(t => t && typeof t.key === "string" && t.key.trim())
      .map((t, idx) => ({
        key: String(t.key).trim(),
        labelAr: String(t.labelAr ?? "").trim(),
        labelEn: String(t.labelEn ?? "").trim(),
        keywords: Array.isArray(t.keywords) ? t.keywords.map((k: any) => String(k).trim()).filter(Boolean) : [],
        subGroups: Array.isArray(t.subGroups) ? t.subGroups.map((k: any) => String(k).trim()).filter(Boolean) : [],
        sortOrder: Number.isFinite(t.sortOrder) ? Number(t.sortOrder) : idx,
        isActive: t.isActive !== false,
      }));
  }
  await db
    .insert(settingsTable)
    .values({ key: "game_group_subtabs", value: JSON.stringify(cleaned) })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: JSON.stringify(cleaned), updatedAt: new Date() } });
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_game_subtabs", entity: "settings" }).catch(() => {});
  res.json({ groups: cleaned });
});

// Rename a sub-group across all products in a single transaction
router.post("/admin/sub-groups/rename", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { from, to } = (req.body || {}) as { from?: string; to?: string };
  const f = (from || "").trim();
  const t = (to || "").trim();
  if (!f || !t) { res.status(400).json({ error: "from and to are required" }); return; }
  if (f === t) { res.json({ updated: 0 }); return; }
  const updated = await db
    .update(productsTable)
    .set({ subGroup: t })
    .where(eq(productsTable.subGroup, f))
    .returning({ id: productsTable.id });
  // Update settings list too
  const v = await getSettingValue("product_sub_groups", "");
  let list: string[] = DEFAULT_SUB_GROUPS;
  if (v) { try { const p = JSON.parse(v); if (Array.isArray(p)) list = p; } catch { /* ignore */ } }
  const next = Array.from(new Set(list.map(s => (s === f ? t : s)).filter(Boolean)));
  await db
    .insert(settingsTable)
    .values({ key: "product_sub_groups", value: JSON.stringify(next) })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: JSON.stringify(next), updatedAt: new Date() } });
  res.json({ updated: updated.length, items: next });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 1. CSV EXPORT/IMPORT FOR PRODUCTS
// ═══════════════════════════════════════════════════════════════════════════════

function csvEscape(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

router.get("/admin/products/export-csv", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const products = await db.select().from(productsTable).orderBy(productsTable.category, productsTable.sortOrder);
  const headers = ["id", "name", "nameAr", "category", "subGroup", "priceUsd", "unitPriceUsd", "profitMargin", "status", "sortOrder", "isFeatured", "stockQty", "provider", "providerProductId", "productType"];
  const lines = [headers.join(",")];
  for (const p of products) {
    lines.push(headers.map(h => csvEscape((p as any)[h])).join(","));
  }
  const csv = "\uFEFF" + lines.join("\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="products_${new Date().toISOString().split("T")[0]}.csv"`);
  res.send(csv);
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "export", entity: "products", details: { count: products.length } }).catch(() => {});
});

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let inQuotes = false;
  const t = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (inQuotes) {
      if (c === '"' && t[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') inQuotes = false;
      else cur += c;
    } else {
      if (c === '"') inQuotes = true;
      else if (c === ",") { row.push(cur); cur = ""; }
      else if (c === "\n") { row.push(cur); rows.push(row); row = []; cur = ""; }
      else if (c === "\r") { /* skip */ }
      else cur += c;
    }
  }
  if (cur.length > 0 || row.length > 0) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.length > 0 && r.some(x => x.length > 0));
}

router.post("/admin/products/import-csv", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const csvText = (req.body?.csv as string) || "";
  if (!csvText.trim()) { res.status(400).json({ error: "CSV content is required" }); return; }
  const rows = parseCsv(csvText);
  if (rows.length < 2) { res.status(400).json({ error: "CSV must include header + at least one row" }); return; }
  const headers = rows[0].map(h => h.trim());
  const idIdx = headers.indexOf("id");
  if (idIdx < 0) { res.status(400).json({ error: "CSV must include 'id' column" }); return; }

  const editable = new Set(["name", "nameAr", "priceUsd", "profitMargin", "status", "sortOrder", "isFeatured", "stockQty", "subGroup"]);
  let updated = 0; let skipped = 0; const errors: string[] = [];
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    const id = (row[idIdx] || "").trim();
    if (!id) { skipped++; continue; }
    const patch: Record<string, any> = {};
    for (let c = 0; c < headers.length; c++) {
      const h = headers[c];
      if (!editable.has(h)) continue;
      const raw = row[c]; if (raw === undefined) continue;
      const v = raw.trim();
      if (h === "isFeatured") patch[h] = /^(true|1|yes|نعم)$/i.test(v);
      else if (h === "sortOrder" || h === "stockQty") {
        const n = parseInt(v, 10); if (Number.isFinite(n)) patch[h] = n;
      } else if (h === "priceUsd" || h === "profitMargin") {
        const n = parseFloat(v); if (Number.isFinite(n) && n >= 0) patch[h] = String(n);
      } else if (v.length > 0) patch[h] = v;
    }
    if (Object.keys(patch).length === 0) { skipped++; continue; }
    try {
      const result = await db.update(productsTable).set(patch).where(eq(productsTable.id, id)).returning({ id: productsTable.id });
      if (result.length > 0) updated++; else { skipped++; errors.push(`#${r + 1}: id ${id} not found`); }
    } catch (e: any) {
      skipped++; errors.push(`#${r + 1}: ${e?.message || "update failed"}`);
    }
  }
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "import", entity: "products", details: { updated, skipped } }).catch(() => {});
  res.json({ updated, skipped, errors: errors.slice(0, 20) });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 2. PRODUCT PRICE/CHANGE AUDIT LOG
// ═══════════════════════════════════════════════════════════════════════════════

router.get("/admin/product-changes", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const limit = Math.min(parseInt((req.query.limit as string) || "100", 10), 500);
  const page = Math.max(parseInt((req.query.page as string) || "1", 10), 1);
  const offset = (page - 1) * limit;
  const [[totalResult], rows] = await Promise.all([
    db.select({ count: count() }).from(productChangeLogTable),
    db.select().from(productChangeLogTable).orderBy(desc(productChangeLogTable.createdAt)).limit(limit).offset(offset),
  ]);
  res.json({ changes: rows, total: totalResult?.count ?? 0, page, limit });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 3. DAILY NET PROFIT REPORT
// ═══════════════════════════════════════════════════════════════════════════════

router.get("/admin/profit-daily", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const days = Math.min(Math.max(parseInt((req.query.days as string) || "30", 10), 1), 180);
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  // Pull completed orders + their product unit cost
  const rows = await db
    .select({
      day: sql<string>`to_char(${ordersTable.createdAt} AT TIME ZONE 'UTC', 'YYYY-MM-DD')`,
      revenue: sql<string>`COALESCE(SUM(${ordersTable.totalPrice}::numeric), 0)`,
      cost: sql<string>`COALESCE(SUM(${ordersTable.qty} * COALESCE(${productsTable.unitPriceUsd}::numeric, ${productsTable.priceUsd}::numeric / NULLIF(1 + ${productsTable.profitMargin}::numeric / 100, 0))), 0)`,
      orders: sql<number>`COUNT(*)`,
    })
    .from(ordersTable)
    .leftJoin(productsTable, eq(productsTable.id, ordersTable.productId))
    .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since)))
    .groupBy(sql`to_char(${ordersTable.createdAt} AT TIME ZONE 'UTC', 'YYYY-MM-DD')`)
    .orderBy(sql`to_char(${ordersTable.createdAt} AT TIME ZONE 'UTC', 'YYYY-MM-DD')`);

  const daily = rows.map(r => {
    const rev = parseFloat(r.revenue || "0");
    const cost = parseFloat(r.cost || "0");
    return { day: r.day, revenue: rev, cost, profit: rev - cost, orders: Number(r.orders) || 0 };
  });
  const totals = daily.reduce((a, d) => ({ revenue: a.revenue + d.revenue, cost: a.cost + d.cost, profit: a.profit + d.profit, orders: a.orders + d.orders }), { revenue: 0, cost: 0, profit: 0, orders: 0 });
  res.json({ days, daily, totals });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 5. WHATSAPP / TELEGRAM MESSAGE TEMPLATES
// ═══════════════════════════════════════════════════════════════════════════════

const DEFAULT_TEMPLATES = [
  { id: "order_ready", title: "الطلب جاهز", body: "مرحباً {name} 👋\nطلبك {order} ({product}) تم تنفيذه بنجاح ✅\nشكراً لاختيارك Elite Store." },
  { id: "order_pending", title: "الطلب قيد المعالجة", body: "مرحباً {name} 👋\nطلبك {order} ({product}) قيد المعالجة الآن، رح نخبرك فور إكتماله." },
  { id: "need_info", title: "بحاجة لمعلومات إضافية", body: "مرحباً {name} 👋\nبخصوص طلبك {order} ({product})، ممكن ترسل لنا رقم اللاعب / المعرّف الصحيح؟" },
  { id: "payment_received", title: "تم استلام الدفع", body: "مرحباً {name} 👋\nتم استلام دفعتك بنجاح ✅\nرصيدك متوفر الآن في حسابك." },
  { id: "issue_resolved", title: "تم حل المشكلة", body: "مرحباً {name} 👋\nطلبك {order} اللي كان فيه مشكلة، تمت معالجته وحلّه. شكراً لصبرك 🙏" },
];

router.get("/admin/message-templates", requireAdmin, async (_req, res): Promise<void> => {
  const v = await getSettingValue("message_templates", "");
  let list = DEFAULT_TEMPLATES;
  if (v) { try { const p = JSON.parse(v); if (Array.isArray(p) && p.length > 0) list = p; } catch { /* ignore */ } }
  res.json({ templates: list });
});

router.put("/admin/message-templates", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const items = (req.body?.templates ?? []) as Array<{ id?: string; title?: string; body?: string }>;
  const cleaned = items
    .map((t, i) => ({ id: String(t.id || `tpl_${i + 1}`).slice(0, 40), title: String(t.title || "").slice(0, 80), body: String(t.body || "").slice(0, 1500) }))
    .filter(t => t.title && t.body);
  await db.insert(settingsTable).values({ key: "message_templates", value: JSON.stringify(cleaned) })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: JSON.stringify(cleaned), updatedAt: new Date() } });
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_message_templates", entity: "settings" }).catch(() => {});
  res.json({ templates: cleaned });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 6. SECURITY: BLOCKED IPs PANEL
// ═══════════════════════════════════════════════════════════════════════════════

router.get("/admin/security/blocked-ips", requireAdmin, async (_req, res): Promise<void> => {
  const windowMs = 15 * 60 * 1000;
  const since = new Date(Date.now() - windowMs);
  const MAX_FAILS_PER_IP = 10;
  const MAX_FAILS_PER_USERNAME = 5;
  const ipRows = await db
    .select({ ip: loginAttemptsTable.ip, fails: count(), last: sql<Date>`MAX(${loginAttemptsTable.createdAt})` })
    .from(loginAttemptsTable)
    .where(and(eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since)))
    .groupBy(loginAttemptsTable.ip)
    .orderBy(desc(count()));
  const userRows = await db
    .select({ username: loginAttemptsTable.username, fails: count(), last: sql<Date>`MAX(${loginAttemptsTable.createdAt})` })
    .from(loginAttemptsTable)
    .where(and(eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since)))
    .groupBy(loginAttemptsTable.username)
    .orderBy(desc(count()));
  res.json({
    windowMinutes: 15,
    ips: ipRows.map(r => ({ ip: r.ip, fails: Number(r.fails), last: r.last, blocked: Number(r.fails) >= MAX_FAILS_PER_IP })),
    accounts: userRows.map(r => ({ username: r.username, fails: Number(r.fails), last: r.last, blocked: Number(r.fails) >= MAX_FAILS_PER_USERNAME })),
  });
});

router.post("/admin/security/unblock", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const ip = (req.body?.ip as string) || "";
  const username = (req.body?.username as string) || "";
  if (!ip && !username) { res.status(400).json({ error: "ip or username required" }); return; }
  const since = new Date(Date.now() - 15 * 60 * 1000);
  const conds = [eq(loginAttemptsTable.success, false), gte(loginAttemptsTable.createdAt, since)];
  if (ip) conds.push(eq(loginAttemptsTable.ip, ip));
  if (username) conds.push(eq(loginAttemptsTable.username, username));
  const deleted = await db.delete(loginAttemptsTable).where(and(...conds)).returning({ id: loginAttemptsTable.id });
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "unblock", entity: "security", details: { ip, username, cleared: deleted.length } }).catch(() => {});
  res.json({ cleared: deleted.length });
});

// ═══════════════════════════════════════════════════════════════════════════════
// 7. PROVIDER HEALTH TEST
// ═══════════════════════════════════════════════════════════════════════════════

router.post("/admin/providers/test", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { testConnection, fetchBalance } = await import("../lib/providers");
  const requested = (req.body?.provider as ProviderName) || undefined;
  const [health, balance] = await Promise.all([
    testConnection(requested),
    fetchBalance(requested),
  ]);
  const result = {
    provider: balance.provider,
    displayName: health.displayName,
    ok: health.ok,
    health: health.status,
    responseMs: health.responseMs,
    configured: health.configured,
    enabled: health.enabled,
    balanceSyp: balance.balanceSyp,
    balanceUsd: balance.balanceUsd,
    sypRate: balance.sypRate,
    currency: balance.currency,
    email: balance.email ?? null,
    error: health.error ?? balance.error ?? null,
    checkedAt: new Date().toISOString(),
  };
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "test_providers", entity: "system", details: { provider: result.provider, ok: result.ok, responseMs: result.responseMs } }).catch(() => {});
  res.json({ results: [result], result });
});

// ═══════════════════════════════════════════════════════════════════════════════
// ─── Sync safety / category-mapping admin endpoints ──────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

// GET current manual overrides (which fields are "locked" against sync)
router.get("/admin/products/:id/overrides", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const [p] = await db
    .select({
      id: productsTable.id,
      manualOverrides: productsTable.manualOverrides,
      providerCategoryId: productsTable.providerCategoryId,
      providerCategoryName: productsTable.providerCategoryName,
    })
    .from(productsTable)
    .where(eq(productsTable.id, req.params.id as string));
  if (!p) { res.status(404).json({ error: "Product not found" }); return; }
  res.json(p);
});

// PUT replace manual overrides list explicitly (admin can re-open a field for sync)
router.put("/admin/products/:id/overrides", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const fields = Array.isArray(req.body?.fields) ? req.body.fields.map((f: unknown) => String(f)) : null;
  if (!fields) { res.status(400).json({ error: "fields[] required" }); return; }
  const [updated] = await db
    .update(productsTable)
    .set({ manualOverrides: fields })
    .where(eq(productsTable.id, req.params.id as string))
    .returning({ id: productsTable.id, manualOverrides: productsTable.manualOverrides });
  if (!updated) { res.status(404).json({ error: "Product not found" }); return; }
  res.json(updated);
});

// GET / PUT settings-driven category mapping per provider:
//   { "<provider raw category lowercased>": "<one of mobile_games|pc_games|gift_cards|services|general>" }
router.get("/admin/sync/category-map/:provider", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { getProviderConfig } = await import("../lib/providers");
  const cfg = await getProviderConfig();
  const provider = String(req.params.provider || "").toLowerCase();
  if (provider !== cfg.name) {
    res.status(400).json({ error: "Unknown provider" }); return;
  }
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, `category_mapping_${provider}`));
  let mapping: Record<string, string> = {};
  try { if (row?.value) mapping = JSON.parse(row.value); } catch { /* ignore */ }

  // Also return the distinct provider categories we've actually seen so the
  // admin UI can offer a checklist instead of free-text.
  const seen = await db
    .selectDistinct({ name: productsTable.providerCategoryName })
    .from(productsTable)
    .where(and(eq(productsTable.provider, provider), isNotNull(productsTable.providerCategoryName)));

  res.json({
    provider,
    mapping,
    seenCategories: seen.map(s => s.name).filter(Boolean).sort(),
  });
});

router.put("/admin/sync/category-map/:provider", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { getProviderConfig } = await import("../lib/providers");
  const cfg = await getProviderConfig();
  const provider = String(req.params.provider || "").toLowerCase();
  if (provider !== cfg.name) {
    res.status(400).json({ error: "Unknown provider" }); return;
  }
  const mapping = req.body?.mapping;
  if (!mapping || typeof mapping !== "object" || Array.isArray(mapping)) {
    res.status(400).json({ error: "mapping object required" }); return;
  }
  // Sanitize: keys lowercased, values restricted to known categories
  const ALLOWED = new Set(["mobile_games", "pc_games", "gift_cards", "services", "general"]);
  const clean: Record<string, string> = {};
  for (const [k, v] of Object.entries(mapping)) {
    const target = String(v);
    if (!ALLOWED.has(target)) continue;
    const key = String(k).trim().toLowerCase();
    if (key) clean[key] = target;
  }
  await db
    .insert(settingsTable)
    .values({ key: `category_mapping_${provider}`, value: JSON.stringify(clean) })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: JSON.stringify(clean), updatedAt: new Date() } });
  logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "update_category_map", entity: "settings", details: { provider, count: Object.keys(clean).length } }).catch(() => {});
  res.json({ ok: true, provider, mapping: clean });
});

// ─── Products: delete ALL products (destructive — requires confirmation token) ─
router.delete("/admin/products/clear-all", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const confirm = req.query.confirm as string;
  if (confirm !== "DELETE_ALL_PRODUCTS") {
    res.status(400).json({ error: "Pass ?confirm=DELETE_ALL_PRODUCTS to confirm this destructive operation" });
    return;
  }
  const [countRow] = await db.select({ count: count() }).from(productsTable);
  const total = Number(countRow?.count ?? 0);
  await db.delete(productsTable);
  logAdminAction({
    adminId: req.user!.id,
    adminUsername: req.user!.username,
    action: "delete_all_products",
    entity: "product",
    details: { deletedCount: total },
  }).catch(() => {});
  req.log.info({ adminId: req.user!.id, deletedCount: total }, "Admin deleted all products");
  res.json({ ok: true, deletedCount: total });
});

// ─── Provider: test a custom base URL without saving it ───────────────────────
router.post("/admin/providers/test-url", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { baseUrl, token: customToken } = req.body as { baseUrl?: string; token?: string };
  if (!baseUrl) { res.status(400).json({ error: "baseUrl required" }); return; }
  const { getProviderConfig } = await import("../lib/providers");
  const cfg = await getProviderConfig();
  const testToken = (customToken || cfg.token || "").trim();
  const cleanBase = baseUrl.trim().replace(/\/$/, "");
  const urlsToTry = [
    `${cleanBase}/games`,
    `${cleanBase}/Games`,
  ];
  const results: { url: string; ok: boolean; status?: number; body?: string; ms: number }[] = [];
  for (const url of urlsToTry) {
    const t0 = Date.now();
    try {
      const r = await fetch(url, {
        headers: { "api-token": testToken, Accept: "application/json" },
        signal: AbortSignal.timeout(6000),
      });
      const bodyText = await r.text().catch(() => "");
      results.push({ url, ok: r.ok, status: r.status, body: bodyText.slice(0, 200), ms: Date.now() - t0 });
    } catch (e: any) {
      results.push({ url, ok: false, body: e?.message?.slice(0, 100) ?? "Error", ms: Date.now() - t0 });
    }
  }
  res.json({ results, testedBaseUrl: cleanBase });
});

// ─── Image Tools: scan for broken images ─────────────────────────────────────
router.get("/admin/images/scan", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const allProducts = await db.select({
      id: productsTable.id,
      name: productsTable.name,
      image: productsTable.image,
      imageOverride: productsTable.imageOverride,
    }).from(productsTable).limit(2000);

    const allCats = await db.select({
      id: categoriesTable.id,
      nameAr: categoriesTable.nameAr,
      imageUrl: categoriesTable.imageUrl,
      bannerImage: categoriesTable.bannerImage,
    }).from(categoriesTable);

    type BrokenItem = { id: string; name: string; type: 'product' | 'category'; imageUrl: string; reason: string };
    const broken: BrokenItem[] = [];
    let total = 0;

    const checkUrl = async (url: string | null | undefined): Promise<{ ok: boolean; reason: string }> => {
      if (!url) return { ok: true, reason: '' };
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const r = await fetch(url, { method: 'HEAD', signal: controller.signal });
        clearTimeout(timeout);
        if (!r.ok) return { ok: false, reason: `HTTP ${r.status}` };
        return { ok: true, reason: '' };
      } catch (e: any) {
        return { ok: false, reason: e.message?.slice(0, 80) ?? 'Network error' };
      }
    };

    // Check product images (limit to first 200 to avoid timeout)
    const prodsToCheck = allProducts.slice(0, 200);
    for (const p of prodsToCheck) {
      const imgUrl = (p as any).imageOverride || p.image;
      if (!imgUrl) continue;
      total++;
      const { ok, reason } = await checkUrl(imgUrl);
      if (!ok) broken.push({ id: p.id, name: p.name, type: 'product', imageUrl: imgUrl, reason });
    }

    // Check category images
    for (const c of allCats) {
      if (c.imageUrl) {
        total++;
        const { ok, reason } = await checkUrl(c.imageUrl);
        if (!ok) broken.push({ id: String(c.id), name: c.nameAr, type: 'category', imageUrl: c.imageUrl, reason });
      }
      if ((c as any).bannerImage) {
        total++;
        const { ok, reason } = await checkUrl((c as any).bannerImage);
        if (!ok) broken.push({ id: String(c.id), name: `${c.nameAr} (بانر)`, type: 'category', imageUrl: (c as any).bannerImage, reason });
      }
    }

    res.json({ total, broken, scannedAt: new Date().toISOString() });
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Scan failed" });
  }
});

// ─── Image Tools: bulk unassign images ───────────────────────────────────────
router.post("/admin/images/bulk-unassign", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  try {
    const { target } = req.body as { target: 'products' | 'categories' };
    if (target === 'products') {
      const result = await db.update(productsTable)
        .set({ imageOverride: null } as any)
        .returning({ id: productsTable.id });
      logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "bulk_unassign_images", entity: "product", details: { count: result.length } }).catch(() => {});
      res.json({ updated: result.length });
    } else if (target === 'categories') {
      const result = await db.update(categoriesTable)
        .set({ imageUrl: null })
        .returning({ id: categoriesTable.id });
      logAdminAction({ adminId: req.user!.id, adminUsername: req.user!.username, action: "bulk_unassign_images", entity: "category", details: { count: result.length } }).catch(() => {});
      res.json({ updated: result.length });
    } else {
      res.status(400).json({ error: "target must be products or categories" });
    }
  } catch (err: any) {
    res.status(500).json({ error: err?.message ?? "Failed" });
  }
});

export default router;
