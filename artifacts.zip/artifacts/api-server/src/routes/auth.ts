import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, userSessionsTable, loginAttemptsTable } from "@workspace/db";
import { eq, and, desc, ne } from "drizzle-orm";
import { z } from "zod";
import { RegisterBody, LoginBody, GetMeResponse } from "@workspace/api-zod";
import { signSessionToken, requireAuth, AuthRequest, getRequestIp } from "../lib/auth";
import { notifyNewUser, notifyFraudAttempt, notifyAdminLoginFailed } from "../lib/telegram";
import { getUserVipProfile } from "../lib/vip";
import { emitNewUser } from "../lib/ws";

const router: IRouter = Router();

const UpdateProfileBody = z.object({
  username: z.string().min(3).max(40).optional(),
  email: z.string().email().optional(),
});

const ChangePasswordBody = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8),
});

const ForgotPasswordBody = z.object({
  email: z.string().email(),
});

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { username, email, password } = parsed.data;

  const [existing] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email));

  if (existing) {
    res.status(400).json({ error: "Email already in use", message: "This email is already registered" });
    return;
  }

  const [existingUsername] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, username));

  if (existingUsername) {
    res.status(400).json({ error: "Username taken", message: "This username is already taken" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);

  // Capture signup IP (handles X-Forwarded-For chains from Replit's proxy).
  const xff = (req.headers["x-forwarded-for"] as string | undefined) ?? "";
  const signupIp = (xff.split(",")[0].trim() || req.socket.remoteAddress || "").slice(0, 64) || null;

  const [user] = await db
    .insert(usersTable)
    .values({ username, email, passwordHash, role: "user", balance: "0", isSuspended: false, signupIp })
    .returning();

  // Fraud check: same IP signed up more than 3 accounts → alert admin
  if (signupIp) {
    try {
      const sameIp = await db
        .select({ id: usersTable.id, email: usersTable.email })
        .from(usersTable)
        .where(eq(usersTable.signupIp, signupIp));
      if (sameIp.length > 3) {
        notifyFraudAttempt({
          ip: signupIp,
          count: sameIp.length,
          emails: sameIp.map(u => u.email),
          newUsername: username,
          newEmail: email,
        }).catch(() => {});
      }
    } catch {
      // Non-fatal; never block signup on fraud-check failure.
    }
  }

  // Assign a stable, padded public code based on the new id (e.g. EL-000123).
  if (!user.publicCode) {
    const code = `EL-${String(user.id).padStart(6, "0")}`;
    await db.update(usersTable).set({ publicCode: code }).where(eq(usersTable.id, user.id));
    user.publicCode = code;
  }

  const ip = getRequestIp(req);
  const userAgent = String(req.headers["user-agent"] ?? "");
  const token = await signSessionToken(user.id, user.role, { ip, userAgent });
  const vip = await getUserVipProfile(user);
  const userOut = GetMeResponse.parse({
    id: user.id,
    publicCode: user.publicCode,
    username: user.username,
    email: user.email,
    role: user.role,
    permissions: user.permissions ?? [],
    balance: parseFloat(user.balance ?? "0"),
    vipLevel: vip.level,
    totalSpentUsd: vip.totalSpentUsd,
    vipDiscountPercent: vip.discountPercent,
    vip,
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });

  notifyNewUser({ username: user.username, email: user.email }).catch(() => {});

  res.status(201).json({ token, user: userOut });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const { email, password } = parsed.data;
  const ip = getRequestIp(req);
  const userAgent = String(req.headers["user-agent"] ?? "");

  const [byEmail] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  const [byUsername] = !byEmail
    ? await db.select().from(usersTable).where(eq(usersTable.username, email))
    : [undefined];
  const user = byEmail ?? byUsername;

  const recordAttempt = (success: boolean) => {
    db.insert(loginAttemptsTable).values({
      username: email.slice(0, 200),
      ip: ip || "unknown",
      userAgent: userAgent.slice(0, 300) || null,
      success,
    }).catch(() => {});
  };

  if (!user) {
    recordAttempt(false);
    res.status(401).json({ error: "Invalid credentials", message: "Email or password incorrect" });
    return;
  }

  if (user.isSuspended) {
    recordAttempt(false);
    if (user.role === "admin") {
      notifyAdminLoginFailed({ username: user.username, ip: ip || "unknown", userAgent }).catch(() => {});
    }
    res.status(401).json({ error: "Account suspended", message: "Your account has been suspended" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    recordAttempt(false);
    if (user.role === "admin") {
      notifyAdminLoginFailed({ username: user.username, ip: ip || "unknown", userAgent }).catch(() => {});
    }
    res.status(401).json({ error: "Invalid credentials", message: "Email or password incorrect" });
    return;
  }

  recordAttempt(true);
  const token = await signSessionToken(user.id, user.role, { ip, userAgent });
  const vip = await getUserVipProfile(user);
  const userOut = GetMeResponse.parse({
    id: user.id,
    publicCode: user.publicCode,
    username: user.username,
    email: user.email,
    role: user.role,
    permissions: user.permissions ?? [],
    balance: parseFloat(user.balance ?? "0"),
    vipLevel: vip.level,
    totalSpentUsd: vip.totalSpentUsd,
    vipDiscountPercent: vip.discountPercent,
    vip,
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });

  res.json({ token, user: userOut });
});

router.get("/auth/me", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.user!.id));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const vip = await getUserVipProfile(user);
  const userOut = GetMeResponse.parse({
    id: user.id,
    publicCode: user.publicCode,
    username: user.username,
    email: user.email,
    role: user.role,
    permissions: user.permissions ?? [],
    balance: parseFloat(user.balance ?? "0"),
    vipLevel: vip.level,
    totalSpentUsd: vip.totalSpentUsd,
    vipDiscountPercent: vip.discountPercent,
    vip,
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  });

  res.json(userOut);
});

router.get("/user/me", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.user!.id));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const vip = await getUserVipProfile(user);
  res.json(GetMeResponse.parse({
    id: user.id,
    publicCode: user.publicCode,
    username: user.username,
    email: user.email,
    role: user.role,
    permissions: user.permissions ?? [],
    balance: parseFloat(user.balance ?? "0"),
    vipLevel: vip.level,
    totalSpentUsd: vip.totalSpentUsd,
    vipDiscountPercent: vip.discountPercent,
    vip,
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  }));
});

router.patch("/auth/profile", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const updateData: { username?: string; email?: string } = {};
  if (parsed.data.username) updateData.username = parsed.data.username;
  if (parsed.data.email) updateData.email = parsed.data.email;

  if (Object.keys(updateData).length === 0) {
    res.status(400).json({ error: "No changes provided" });
    return;
  }

  if (updateData.email) {
    const [existingEmail] = await db.select().from(usersTable).where(eq(usersTable.email, updateData.email));
    if (existingEmail && existingEmail.id !== req.user!.id) {
      res.status(400).json({ error: "Email already in use" });
      return;
    }
  }

  if (updateData.username) {
    const [existingUsername] = await db.select().from(usersTable).where(eq(usersTable.username, updateData.username));
    if (existingUsername && existingUsername.id !== req.user!.id) {
      res.status(400).json({ error: "Username already in use" });
      return;
    }
  }

  const [user] = await db.update(usersTable).set(updateData).where(eq(usersTable.id, req.user!.id)).returning();
  const vip = await getUserVipProfile(user);
  res.json(GetMeResponse.parse({
    id: user.id,
    publicCode: user.publicCode,
    username: user.username,
    email: user.email,
    role: user.role,
    permissions: user.permissions ?? [],
    balance: parseFloat(user.balance ?? "0"),
    vipLevel: vip.level,
    totalSpentUsd: vip.totalSpentUsd,
    vipDiscountPercent: vip.discountPercent,
    vip,
    isSuspended: user.isSuspended,
    createdAt: user.createdAt,
  }));
});

router.post("/auth/change-password", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = ChangePasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const valid = await bcrypt.compare(parsed.data.currentPassword, user.passwordHash);
  if (!valid) {
    res.status(400).json({ error: "Invalid password", message: "Current password is incorrect" });
    return;
  }

  const passwordHash = await bcrypt.hash(parsed.data.newPassword, 12);
  await db.update(usersTable).set({ passwordHash }).where(eq(usersTable.id, req.user!.id));
  res.json({ success: true });
});

// ── Sessions / Login History ────────────────────────────────────────────────
router.get("/auth/sessions", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rows = await db
    .select()
    .from(userSessionsTable)
    .where(eq(userSessionsTable.userId, req.user!.id))
    .orderBy(desc(userSessionsTable.lastSeenAt))
    .limit(50);
  res.json({
    sessions: rows.map((s) => ({
      id: s.id,
      ip: s.ip,
      userAgent: s.userAgent,
      revoked: s.revoked,
      isCurrent: s.id === req.user!.jti,
      createdAt: s.createdAt,
      lastSeenAt: s.lastSeenAt,
      expiresAt: s.expiresAt,
    })),
  });
});

router.get("/auth/login-history", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const [me] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id));
  if (!me) { res.status(404).json({ error: "User not found" }); return; }
  const rows = await db
    .select()
    .from(loginAttemptsTable)
    .where(eq(loginAttemptsTable.username, me.email))
    .orderBy(desc(loginAttemptsTable.createdAt))
    .limit(50);
  res.json({ attempts: rows });
});

router.delete("/auth/sessions/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const id = String(req.params.id);
  const [s] = await db.select().from(userSessionsTable).where(and(eq(userSessionsTable.id, id), eq(userSessionsTable.userId, req.user!.id)));
  if (!s) { res.status(404).json({ error: "Session not found" }); return; }
  await db.update(userSessionsTable).set({ revoked: true }).where(eq(userSessionsTable.id, id));
  res.json({ success: true });
});

router.post("/auth/sessions/revoke-all", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  // Revoke every other session except the current one.
  const currentJti = req.user!.jti ?? "";
  await db.update(userSessionsTable)
    .set({ revoked: true })
    .where(and(eq(userSessionsTable.userId, req.user!.id), ne(userSessionsTable.id, currentJti)));
  res.json({ success: true });
});

router.post("/auth/logout", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  if (req.user?.jti) {
    await db.update(userSessionsTable).set({ revoked: true }).where(eq(userSessionsTable.id, req.user.jti));
  }
  res.json({ success: true });
});

router.post("/auth/forgot-password", async (req, res): Promise<void> => {
  const parsed = ForgotPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation error", message: parsed.error.message });
    return;
  }

  res.json({
    success: true,
    message: "If this email exists, the store owner will help reset the password from the admin panel.",
  });
});

export default router;
