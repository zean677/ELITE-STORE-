import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { requireAuth, requireAdmin, AuthRequest } from "../lib/auth";
import { ObjectStorageService } from "../lib/objectStorage";
import { setObjectAclPolicy } from "../lib/objectAcl";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

const UPLOADS_DIR = path.resolve(process.cwd(), "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const ALLOWED_MIME = new Set(["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"]);
const MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
    const safe = ext.replace(/[^.a-z0-9]/g, "");
    cb(null, `screenshot_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${safe}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_SIZE_BYTES },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_MIME.has(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed (JPEG, PNG, WebP, GIF)"));
    }
  },
});

router.post(
  "/upload/screenshot",
  requireAuth,
  (req: AuthRequest, res: Response, next) => {
    upload.single("screenshot")(req as Request, res, (err) => {
      if (err) {
        if (err.code === "LIMIT_FILE_SIZE") {
          res.status(413).json({ error: "File too large", message: "Maximum allowed size is 10 MB" });
        } else {
          res.status(400).json({ error: "Upload failed", message: err.message });
        }
        return;
      }
      next();
    });
  },
  (req: AuthRequest, res: Response): void => {
    if (!req.file) {
      res.status(400).json({ error: "No file provided" });
      return;
    }

    const siteUrl = (process.env.SITE_URL ?? "").replace(/\/$/, "");
    const fileUrl = siteUrl
      ? `${siteUrl}/api/uploads/${req.file.filename}`
      : `/api/uploads/${req.file.filename}`;

    res.json({
      url: fileUrl,
      filename: req.file.filename,
      size: req.file.size,
    });
  }
);

// ─── Admin Image Upload (products/categories) ──────────────────────────────────
const adminImgStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
    const safe = ext.replace(/[^.a-z0-9]/g, "");
    cb(null, `admin_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${safe}`);
  },
});

const adminUpload = multer({
  storage: adminImgStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_MIME.has(file.mimetype)) cb(null, true);
    else cb(new Error("Only image files allowed (JPEG, PNG, WebP, GIF)"));
  },
});

router.post(
  "/admin/upload/image",
  requireAdmin,
  (req: AuthRequest, res: Response, next) => {
    adminUpload.single("image")(req as Request, res, (err) => {
      if (err) {
        if (err.code === "LIMIT_FILE_SIZE") res.status(413).json({ error: "File too large (max 5MB)" });
        else res.status(400).json({ error: err.message });
        return;
      }
      next();
    });
  },
  (req: AuthRequest, res: Response): void => {
    if (!req.file) { res.status(400).json({ error: "No file provided" }); return; }
    const siteUrl = (process.env.SITE_URL ?? "").replace(/\/$/, "");
    const fileUrl = siteUrl
      ? `${siteUrl}/api/uploads/${req.file.filename}`
      : `/api/uploads/${req.file.filename}`;
    res.json({ url: fileUrl, filename: req.file.filename, size: req.file.size });
  }
);

const ALLOWED_STORAGE_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const STORAGE_IMAGE_MAX_BYTES = 5 * 1024 * 1024;

router.post(
  ["/admin/upload/storage-url", "/admin/loyalty/rewards/image-upload-url"],
  requireAdmin,
  async (req: AuthRequest, res): Promise<void> => {
  const { name, size, contentType } = req.body ?? {};
  if (
    typeof name !== "string" ||
    !name.trim() ||
    name.length > 200 ||
    !Number.isInteger(size) ||
    size <= 0 ||
    size > STORAGE_IMAGE_MAX_BYTES ||
    typeof contentType !== "string" ||
    !ALLOWED_STORAGE_IMAGE_TYPES.has(contentType)
  ) {
    res.status(400).json({ error: "Invalid image metadata. Use JPEG, PNG, WebP, or GIF up to 5 MB." });
    return;
  }

  try {
    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
    if (!objectPath.startsWith("/objects/") || objectPath.includes("..")) {
      res.status(500).json({ error: "Storage returned an invalid object path" });
      return;
    }
    res.json({ uploadURL, objectPath, name: name.trim(), size, contentType });
  } catch (error: any) {
    res.status(503).json({ error: "Image storage is temporarily unavailable", message: error?.message });
  }
  },
);

router.post(
  ["/admin/upload/storage-confirm", "/admin/loyalty/rewards/image-upload-confirm"],
  requireAdmin,
  async (req: AuthRequest, res): Promise<void> => {
  const objectPath = req.body?.objectPath;
  if (
    typeof objectPath !== "string" ||
    !objectPath.startsWith("/objects/") ||
    objectPath.includes("..") ||
    objectPath.includes("\\") ||
    objectPath.includes("?") ||
    objectPath.includes("#")
  ) {
    res.status(400).json({ error: "Invalid object path" });
    return;
  }

  try {
    const file = await objectStorageService.getObjectEntityFile(objectPath);
    const [metadata] = await file.getMetadata();
    const size = Number(metadata.size);
    const contentType = String(metadata.contentType || "");
    const [sample] = await file.download({ start: 0, end: 11 });
    const isJpeg = sample.length >= 3 && sample[0] === 0xff && sample[1] === 0xd8 && sample[2] === 0xff;
    const isPng = sample.length >= 8 && sample.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    const isGif = sample.subarray(0, 6).toString("ascii").match(/^GIF8[79]a$/) !== null;
    const isWebp = sample.length >= 12 && sample.toString("ascii", 0, 4) === "RIFF" && sample.toString("ascii", 8, 12) === "WEBP";

    if (
      !Number.isFinite(size) ||
      size <= 0 ||
      size > STORAGE_IMAGE_MAX_BYTES ||
      !ALLOWED_STORAGE_IMAGE_TYPES.has(contentType) ||
      !(isJpeg || isPng || isGif || isWebp)
    ) {
      await file.delete({ ignoreNotFound: true }).catch(() => {});
      res.status(400).json({ error: "Uploaded object is not a supported image or exceeds 5 MB" });
      return;
    }

    await setObjectAclPolicy(file, { owner: String(req.user!.id), visibility: "public" });
    res.json({
      url: `/api/storage${objectPath}`,
      objectPath,
      size,
      contentType,
    });
  } catch (error: any) {
    res.status(400).json({ error: "Could not verify the uploaded image", message: error?.message });
  }
  },
);

export { UPLOADS_DIR };
export default router;
