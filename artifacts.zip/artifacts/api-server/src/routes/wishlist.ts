import { Router, type IRouter } from "express";
import { db, wishlistsTable, productsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../lib/auth";

const router: IRouter = Router();

router.get("/wishlist", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const items = await db
    .select({
      wishlistId: wishlistsTable.id,
      productId: wishlistsTable.productId,
      addedAt: wishlistsTable.createdAt,
      name: productsTable.name,
      nameAr: productsTable.nameAr,
      priceUsd: productsTable.priceUsd,
      category: productsTable.category,
      description: productsTable.description,
      image: productsTable.image,
      status: productsTable.status,
    })
    .from(wishlistsTable)
    .leftJoin(productsTable, eq(wishlistsTable.productId, productsTable.id))
    .where(eq(wishlistsTable.userId, userId))
    .orderBy(wishlistsTable.createdAt);

  res.json(items.map(i => ({
    ...i,
    priceUsd: parseFloat(i.priceUsd ?? "0"),
  })));
});

router.post("/wishlist/:productId", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const productId = String(req.params.productId);

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const [existing] = await db
    .select()
    .from(wishlistsTable)
    .where(and(eq(wishlistsTable.userId, userId), eq(wishlistsTable.productId, productId)));

  if (existing) {
    res.json({ success: true, added: false, message: "Already in wishlist" });
    return;
  }

  await db.insert(wishlistsTable).values({ userId, productId });
  res.json({ success: true, added: true });
});

router.delete("/wishlist/:productId", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const productId = String(req.params.productId);

  await db
    .delete(wishlistsTable)
    .where(and(eq(wishlistsTable.userId, userId), eq(wishlistsTable.productId, productId)));

  res.json({ success: true });
});

router.get("/wishlist/check/:productId", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.user!.id;
  const productId = String(req.params.productId);

  const [item] = await db
    .select()
    .from(wishlistsTable)
    .where(and(eq(wishlistsTable.userId, userId), eq(wishlistsTable.productId, productId)));

  res.json({ inWishlist: !!item });
});

export default router;
