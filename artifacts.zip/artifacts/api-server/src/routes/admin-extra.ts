import { Router, type IRouter } from "express";
import {
  db, usersTable, ordersTable, paymentsTable, productsTable,
  notificationsTable, settingsTable, productChangeLogTable,
  scheduledNotificationsTable, homeBannersTable, userSessionsTable,
} from "@workspace/db";
import { eq, desc, and, or, ilike, inArray, sql, count, gte, lte, isNull } from "drizzle-orm";
import { requireAdmin, AuthRequest } from "../lib/auth";
import { PERMISSIONS } from "../lib/permissions";
import { approveOrderById, rejectOrderById } from "../lib/order-actions";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ─── 1. Global Search ─────────────────────────────────────────────────────────
router.get("/admin/search", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const q = (req.query.q as string ?? "").trim();
  if (q.length < 2) {
    res.json(req.query.scope === "users" ? { users: [] } : { orders: [], users: [], products: [], payments: [] });
    return;
  }
  const like = `%${q}%`;
  const isNum = /^\d+$/.test(q);

  const userSearch = db.select({
    id: usersTable.id,
    username: usersTable.username,
    email: usersTable.email,
    publicCode: usersTable.publicCode,
    vipLevel: usersTable.vipLevel,
    balance: usersTable.balance,
    role: usersTable.role,
    permissions: usersTable.permissions,
    isSuspended: usersTable.isSuspended,
  })
    .from(usersTable)
    .where(or(
      ilike(usersTable.username, like),
      ilike(usersTable.email, like),
      ilike(usersTable.publicCode, like),
      ...(isNum ? [eq(usersTable.id, Number(q))] : []),
    ))
    .orderBy(usersTable.username)
    .limit(10);

  if (req.query.scope === "users") {
    res.json({ users: await userSearch });
    return;
  }

  const [orders, users, products, payments] = await Promise.all([
    db.select({ id: ordersTable.id, productName: ordersTable.productName, status: ordersTable.status, totalPrice: ordersTable.totalPrice, createdAt: ordersTable.createdAt })
      .from(ordersTable)
      .where(or(ilike(ordersTable.id, like), ilike(ordersTable.productName, like), ilike(ordersTable.playerId, like)))
      .orderBy(desc(ordersTable.createdAt)).limit(10),
    userSearch,
    db.select({ id: productsTable.id, name: productsTable.name, status: productsTable.status, priceUsd: productsTable.priceUsd, provider: productsTable.provider })
      .from(productsTable)
      .where(or(ilike(productsTable.name, like), ilike(productsTable.id, like)))
      .limit(10),
    db.select({ id: paymentsTable.id, amount: paymentsTable.amount, status: paymentsTable.status, createdAt: paymentsTable.createdAt, userId: paymentsTable.userId })
      .from(paymentsTable)
      .where(isNum
        ? or(eq(paymentsTable.id, Number(q)), eq(paymentsTable.userId, Number(q)))
        : eq(paymentsTable.id, -1))
      .orderBy(desc(paymentsTable.createdAt)).limit(10),
  ]);
  res.json({ orders, users, products, payments });
});

// ─── 2. Bulk Actions on Orders ────────────────────────────────────────────────
router.post("/admin/orders/bulk-action", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { ids, action } = req.body as { ids: string[]; action: "approve" | "reject" | "retry" };
  if (!Array.isArray(ids) || ids.length === 0 || ids.length > 100) {
    res.status(400).json({ error: "ids array required (max 100)" }); return;
  }
  if (!["approve", "reject", "retry"].includes(action)) {
    res.status(400).json({ error: "invalid action" }); return;
  }
  const results = { ok: 0, fail: 0, errors: [] as string[] };
  for (const id of ids) {
    try {
      if (action === "approve") {
        const r = await approveOrderById(id, { id: req.user!.id, username: req.user!.username });
        if (r.ok) results.ok++; else { results.fail++; results.errors.push(`${id}: ${r.reason}`); }
      } else if (action === "reject") {
        const r = await rejectOrderById(id, "إلغاء جماعي من الإدارة", { id: req.user!.id, username: req.user!.username });
        if (r.ok) results.ok++; else { results.fail++; results.errors.push(`${id}: ${r.reason}`); }
      } else {
        await db.update(ordersTable).set({ status: "processing", retryCount: 0, nextRetryAt: new Date() }).where(eq(ordersTable.id, id));
        results.ok++;
      }
    } catch (e: any) { results.fail++; results.errors.push(`${id}: ${e?.message ?? "error"}`); }
  }
  res.json({ success: true, ...results });
});

// ─── 3. Urgent Issues Panel ───────────────────────────────────────────────────
router.get("/admin/dashboard/urgent", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [stalePending, pendingPayments, failedOrders, lowBalUsers, recentRetries] = await Promise.all([
    db.select({ count: count() }).from(ordersTable).where(and(eq(ordersTable.status, "processing"), lte(ordersTable.createdAt, oneHourAgo))),
    db.select({ count: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending")),
    db.select({ count: count() }).from(ordersTable).where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, oneDayAgo))),
    db.select({ count: count() }).from(usersTable).where(and(eq(usersTable.role, "user"), sql`CAST(${usersTable.balance} AS NUMERIC) < 1`)),
    db.select({ count: count() }).from(ordersTable).where(sql`${ordersTable.retryCount} > 0 AND ${ordersTable.createdAt} >= ${oneDayAgo}`),
  ]);

  res.json({
    stalePendingOrders: stalePending[0]?.count ?? 0,
    pendingPayments: pendingPayments[0]?.count ?? 0,
    failedOrdersToday: failedOrders[0]?.count ?? 0,
    lowBalanceCustomers: lowBalUsers[0]?.count ?? 0,
    ordersRetriedToday: recentRetries[0]?.count ?? 0,
  });
});

// ─── 4. Multi-admin Roles & Permissions ───────────────────────────────────────
router.get("/admin/permissions/list", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  res.json({ permissions: PERMISSIONS });
});

router.patch("/admin/users/:id/permissions", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(String(req.params.id), 10);
  const { permissions, role } = req.body as { permissions?: string[]; role?: "user" | "staff" | "admin" };
  if (!Number.isFinite(id)) { res.status(400).json({ error: "invalid id" }); return; }
  if (id === req.user!.id) {
    res.status(400).json({ error: "You cannot change your own role or permissions" });
    return;
  }
  if (role !== undefined && !["user", "staff", "admin"].includes(role)) {
    res.status(400).json({ error: "Invalid role" }); return;
  }
  if (permissions !== undefined &&
      (!Array.isArray(permissions) || permissions.some((p) => !(PERMISSIONS as readonly string[]).includes(p)))) {
    res.status(400).json({ error: "One or more permissions are invalid" }); return;
  }

  const [target] = await db.select({
    id: usersTable.id,
    role: usersTable.role,
    permissions: usersTable.permissions,
  }).from(usersTable).where(eq(usersTable.id, id));
  if (!target) { res.status(404).json({ error: "User not found" }); return; }
  if (role === undefined && permissions === undefined) {
    res.status(400).json({ error: "Nothing to update" }); return;
  }
  const nextRole = role ?? target.role;
  if (permissions !== undefined && nextRole !== "staff") {
    res.status(400).json({ error: "Only staff accounts can receive staff permissions" }); return;
  }
  const nextPermissions = nextRole === "staff"
    ? (permissions ?? target.permissions ?? [])
    : [];
  const roleChanged = nextRole !== target.role;

  const u = await db.transaction(async (tx) => {
    const [updated] = await tx.update(usersTable)
      .set({ role: nextRole, permissions: nextPermissions })
      .where(eq(usersTable.id, id))
      .returning({
        id: usersTable.id,
        role: usersTable.role,
        permissions: usersTable.permissions,
        isSuspended: usersTable.isSuspended,
      });
    if (!updated) return undefined;
    if (roleChanged || permissions !== undefined) {
      await tx.update(userSessionsTable)
        .set({ revoked: true })
        .where(eq(userSessionsTable.userId, id));
    }
    return updated;
  });
  if (!u) { res.status(404).json({ error: "User not found" }); return; }
  logger.info({
    actorId: req.user!.id,
    targetId: id,
    previousRole: target.role,
    role: u.role,
    permissionCount: u.permissions.length,
  }, "User role and permissions updated");
  res.json({ success: true, user: u });
});

router.get("/admin/staff", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const staff = await db.select({
    id: usersTable.id, username: usersTable.username, email: usersTable.email,
    role: usersTable.role, permissions: usersTable.permissions, isSuspended: usersTable.isSuspended,
    createdAt: usersTable.createdAt,
  }).from(usersTable)
    .where(or(eq(usersTable.role, "admin"), eq(usersTable.role, "staff")))
    .orderBy(usersTable.username)
    .limit(500);
  res.json({ staff });
});

// ─── 5. Internal Customer Notes ───────────────────────────────────────────────
router.patch("/admin/users/:id/notes", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(String(req.params.id), 10);
  const notes = String((req.body?.notes ?? "")).slice(0, 5000);
  await db.update(usersTable).set({ notes: notes || null }).where(eq(usersTable.id, id));
  res.json({ success: true });
});

// ─── 6. Drag-and-Drop Banner / Section Reordering ─────────────────────────────
router.post("/admin/banners/reorder", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { ids } = req.body as { ids: number[] };
  if (!Array.isArray(ids)) { res.status(400).json({ error: "ids array required" }); return; }
  for (let i = 0; i < ids.length; i++) {
    await db.update(homeBannersTable).set({ sortOrder: i }).where(eq(homeBannersTable.id, ids[i]));
  }
  res.json({ success: true });
});

// ─── 7. CSV Export (users / payments / products) ──────────────────────────────
function toCsv(rows: Record<string, unknown>[], headers: string[]): string {
  const esc = (v: unknown) => {
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(","), ...rows.map(r => headers.map(h => esc(r[h])).join(","))].join("\n");
}

router.get("/admin/export/users", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rows = await db.select().from(usersTable).orderBy(desc(usersTable.createdAt)).limit(10000);
  const csv = toCsv(rows as any, ["id", "username", "email", "role", "vipLevel", "balance", "totalSpentUsd", "isSuspended", "createdAt"]);
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="users-${Date.now()}.csv"`);
  res.send("\uFEFF" + csv);
});

router.get("/admin/export/payments", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rows = await db.select().from(paymentsTable).orderBy(desc(paymentsTable.createdAt)).limit(10000);
  const csv = toCsv(rows as any, ["id", "userId", "amount", "currency", "method", "status", "createdAt"]);
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="payments-${Date.now()}.csv"`);
  res.send("\uFEFF" + csv);
});

router.get("/admin/export/products", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const rows = await db.select().from(productsTable).limit(20000);
  const csv = toCsv(rows as any, ["id", "name", "category", "provider", "priceUsd", "unitPriceUsd", "profitMargin", "status", "isFeatured", "stockQty"]);
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="products-${Date.now()}.csv"`);
  res.send("\uFEFF" + csv);
});

// ─── 8. Scheduled Notifications ───────────────────────────────────────────────
router.get("/admin/scheduled-notifications", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const list = await db.select().from(scheduledNotificationsTable).orderBy(desc(scheduledNotificationsTable.sendAt)).limit(100);
  res.json({ scheduled: list });
});

router.post("/admin/scheduled-notifications", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { title, message, type, sendAt, targetUserId } = req.body as {
    title: string; message: string; type?: string; sendAt: string; targetUserId?: number;
  };
  if (!title?.trim() || !message?.trim() || !sendAt) {
    res.status(400).json({ error: "title, message, sendAt required" }); return;
  }
  const when = new Date(sendAt);
  if (Number.isNaN(when.getTime())) { res.status(400).json({ error: "invalid sendAt" }); return; }
  const [row] = await db.insert(scheduledNotificationsTable).values({
    title: title.trim(), message: message.trim(), type: type || "announcement",
    sendAt: when, targetUserId: targetUserId ?? null, createdById: req.user!.id,
  }).returning();
  res.json({ success: true, scheduled: row });
});

router.delete("/admin/scheduled-notifications/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = parseInt(String(req.params.id), 10);
  if (!Number.isInteger(id)) { res.status(400).json({ error: "invalid id" }); return; }
  const [updated] = await db.update(scheduledNotificationsTable)
    .set({ cancelled: "yes", status: "cancelled" })
    .where(and(eq(scheduledNotificationsTable.id, id), isNull(scheduledNotificationsTable.sentAt)))
    .returning({ id: scheduledNotificationsTable.id });
  if (!updated) { res.status(404).json({ error: "Notification not found or already sent" }); return; }
  res.json({ success: true });
});

// ─── 9. Product Change History ────────────────────────────────────────────────
router.get("/admin/products/:id/history", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const productId = String(req.params.id);
  const logs = await db.select().from(productChangeLogTable)
    .where(eq(productChangeLogTable.productId, productId))
    .orderBy(desc(productChangeLogTable.createdAt)).limit(200);
  res.json({ logs });
});

// ─── 10. Smart Price Suggestions ──────────────────────────────────────────────
router.post("/admin/products/suggest-prices", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const margin = Number(req.body?.margin);
  const apply = Boolean(req.body?.apply);
  const productIds = Array.isArray(req.body?.productIds) ? req.body.productIds as string[] : null;
  if (!Number.isFinite(margin) || margin < 0 || margin > 500) {
    res.status(400).json({ error: "margin must be 0-500" }); return;
  }

  const baseSelect = () => db.select({
    id: productsTable.id, name: productsTable.name,
    cost: productsTable.unitPriceUsd, current: productsTable.priceUsd,
    isManual: productsTable.isManual,
  }).from(productsTable);
  const products = productIds && productIds.length > 0
    ? await baseSelect().where(and(eq(productsTable.status, "active"), inArray(productsTable.id, productIds)))
    : await baseSelect().where(eq(productsTable.status, "active"));

  const suggestions = products
    .filter(p => parseFloat(p.cost ?? "0") > 0)
    .map(p => {
      const cost = parseFloat(p.cost ?? "0");
      const suggested = +(cost * (1 + margin / 100)).toFixed(4);
      return { id: p.id, name: p.name, cost, current: parseFloat(p.current ?? "0"), suggested };
    });

  if (apply) {
    let updated = 0;
    for (const s of suggestions) {
      await db.update(productsTable).set({ priceUsd: String(s.suggested), profitMargin: String(margin) })
        .where(eq(productsTable.id, s.id));
      updated++;
    }
    res.json({ success: true, applied: updated, count: suggestions.length });
    return;
  }
  res.json({ success: true, suggestions, count: suggestions.length });
});

// ─── 11. Maintenance Mode ─────────────────────────────────────────────────────
router.get("/admin/maintenance", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const [enabled] = await db.select().from(settingsTable).where(eq(settingsTable.key, "maintenance.enabled"));
  const [msg] = await db.select().from(settingsTable).where(eq(settingsTable.key, "maintenance.message"));
  res.json({
    enabled: enabled?.value === "true",
    message: msg?.value || "المتجر تحت الصيانة مؤقتاً، يرجى المحاولة لاحقاً.",
  });
});

router.post("/admin/maintenance", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { enabled, message } = req.body as { enabled: boolean; message?: string };
  for (const [key, value] of [
    ["maintenance.enabled", String(!!enabled)],
    ...(message !== undefined ? [["maintenance.message", String(message).slice(0, 500)]] : []),
  ] as [string, string][]) {
    const exists = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
    if (exists.length > 0) await db.update(settingsTable).set({ value }).where(eq(settingsTable.key, key));
    else await db.insert(settingsTable).values({ key, value });
  }
  logger.warn({ enabled, by: req?.user?.username }, "Maintenance mode toggled");
  res.json({ success: true });
});

// ─── Dead Products Report — products with no orders in last N days ────────────
router.get("/admin/reports/dead-products", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const days = Math.max(1, Math.min(365, parseInt((req.query.days as string) || "30", 10)));
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const rows = await db.execute(sql`
    SELECT p.id, p.name, p.image AS "imageUrl", p.price_usd AS "priceUsd",
           p.status, p.provider, p.featured_card AS "featuredCard",
           COALESCE(MAX(o.created_at), p.created_at) AS "lastActivity",
           COUNT(o.id)::int AS "orderCount"
    FROM products p
    LEFT JOIN orders o ON o.product_id = p.id AND o.created_at >= ${since}
    GROUP BY p.id
    HAVING COUNT(o.id) = 0
    ORDER BY p.created_at ASC
    LIMIT 500
  `);
  const rowsArr = ((rows as any).rows ?? (Array.isArray(rows) ? rows : [])) as any[];
  res.json({ days, count: rowsArr.length, products: rowsArr });
});

// ─── Test Order — admin simulates an order without charging or dispatching ────
router.post("/admin/products/:id/test-order", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const id = String(req.params.id);
  const [p] = await db.select().from(productsTable).where(eq(productsTable.id, id)).limit(1);
  if (!p) { res.status(404).json({ error: "product not found" }); return; }
  const checks: Array<{ name: string; ok: boolean; detail?: string }> = [];
  checks.push({ name: "المنتج موجود", ok: true, detail: p.name });
  checks.push({ name: "الحالة فعّالة", ok: p.status === "active", detail: p.status });
  checks.push({ name: "عنده سعر", ok: Number(p.priceUsd) > 0, detail: `$${p.priceUsd}` });
  checks.push({ name: "عنده صورة", ok: !!p.image });
  checks.push({ name: "مزوّد محدد", ok: !!p.provider, detail: p.provider || "—" });
  if (p.provider && p.providerProductId) {
    checks.push({ name: "ID المنتج عند المزوّد", ok: true, detail: String(p.providerProductId) });
  } else if (p.provider) {
    checks.push({ name: "ID المنتج عند المزوّد", ok: false, detail: "مفقود — لن يصل للمزوّد" });
  }
  const allOk = checks.every((c) => c.ok);
  res.json({
    success: allOk,
    productId: p.id,
    productName: p.name,
    autoApprove: p.autoApprove ?? false,
    checks,
    message: allOk
      ? `✅ المنتج جاهز للبيع. ${p.autoApprove ? "سيتم التنفيذ تلقائياً" : "يحتاج موافقتك يدوياً"}.`
      : `⚠️ في مشاكل لازم تنحل قبل ما يقدر العميل يطلب.`,
  });
});

// ─── Real-Time Order Queue ────────────────────────────────────────────────────
router.get("/admin/order-queue", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const active = await db
    .select({
      id: ordersTable.id,
      orderNumber: ordersTable.orderNumber,
      productName: ordersTable.productName,
      qty: ordersTable.qty,
      playerId: ordersTable.playerId,
      totalPrice: ordersTable.totalPrice,
      status: ordersTable.status,
      retryCount: ordersTable.retryCount,
      lastDispatchError: ordersTable.lastDispatchError,
      providerOrderId: ordersTable.providerOrderId,
      completedAt: ordersTable.completedAt,
      createdAt: ordersTable.createdAt,
      updatedAt: ordersTable.updatedAt,
    })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, since))
    .orderBy(desc(ordersTable.createdAt))
    .limit(150);

  const byStatus: Record<string, typeof active> = {
    pending: [],
    processing: [],
    completed: [],
    failed: [],
    refunded: [],
  };
  for (const o of active) {
    const bucket = byStatus[o.status] ?? (byStatus[o.status] = []);
    bucket.push(o);
  }

  const counts = Object.fromEntries(
    Object.entries(byStatus).map(([k, v]) => [k, v.length])
  );

  res.json({ orders: active, byStatus, counts, generatedAt: new Date().toISOString() });
});

// ─── Public Status Page endpoint ──────────────────────────────────────────────
router.get("/status", async (_req, res): Promise<void> => {
  const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [total24] = await db.select({ c: count() }).from(ordersTable).where(gte(ordersTable.createdAt, since24h));
  const [completed24] = await db.select({ c: count() }).from(ordersTable).where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, since24h)));
  const [failed24] = await db.select({ c: count() }).from(ordersTable).where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, since24h)));
  const [pending24] = await db.select({ c: count() }).from(ordersTable).where(and(eq(ordersTable.status, "pending"), gte(ordersTable.createdAt, since24h)));

  const totalN = Number(total24?.c ?? 0);
  const completedN = Number(completed24?.c ?? 0);
  const failedN = Number(failed24?.c ?? 0);
  const pendingN = Number(pending24?.c ?? 0);
  const successRate = totalN > 0 ? Math.round((completedN / totalN) * 100) : 100;

  const [providerTokenRow] = await db.select().from(settingsTable).where(eq(settingsTable.key, "provider_api_token"));
  const [providerBaseRow] = await db.select().from(settingsTable).where(eq(settingsTable.key, "provider_base_url"));
  const providerToken = providerTokenRow?.value?.trim() || "";
  const providerBase = providerBaseRow?.value?.trim() || "";
  const providerConfigured = !!(providerToken && providerBase);

  const botOk = !!(process.env.TELEGRAM_BOT_TOKEN?.trim());
  const adminChatOk = !!(process.env.TELEGRAM_ADMIN_CHAT_ID?.trim() || "2113043286");

  res.json({
    generatedAt: new Date().toISOString(),
    services: {
      api: { status: "operational", label: "API المتجر" },
      provider: {
        status: providerConfigured ? "operational" : "degraded",
        label: "مزوّد الشحن",
        detail: providerConfigured ? "متصل" : "يحتاج إعداد",
      },
      telegram: {
        status: botOk && adminChatOk ? "operational" : botOk ? "degraded" : "down",
        label: "Telegram Bot",
        detail: botOk ? (adminChatOk ? "يعمل بشكل طبيعي" : "بدون admin chat") : "غير مفعّل",
      },
    },
    orders24h: {
      total: totalN,
      completed: completedN,
      failed: failedN,
      pending: pendingN,
      successRate,
    },
  });
});

// Public read-only check (used by frontend to show banner)
router.get("/maintenance-status", async (_req, res): Promise<void> => {
  const [enabled] = await db.select().from(settingsTable).where(eq(settingsTable.key, "maintenance.enabled"));
  const [msg] = await db.select().from(settingsTable).where(eq(settingsTable.key, "maintenance.message"));
  res.json({
    enabled: enabled?.value === "true",
    message: msg?.value || "المتجر تحت الصيانة مؤقتاً.",
  });
});

export default router;
