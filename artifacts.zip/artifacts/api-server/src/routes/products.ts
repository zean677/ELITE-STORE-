import { Router, type IRouter } from "express";
import { db, productsTable, settingsTable, ordersTable, productChangeLogTable } from "@workspace/db";
import { eq, ilike, and, count, sql, or, isNotNull, desc, inArray, like } from "drizzle-orm";
import { GetProductsQueryParams } from "@workspace/api-zod";
import { requireAdmin, AuthRequest } from "../lib/auth";
import { getProviderConfig, providerFetch, getSypRate, setSettingValue as setProviderSetting, DEFAULT_PROVIDER_NAME } from "../lib/providers";

const router: IRouter = Router();

// ── Field-protection helper ──────────────────────────────────────────────────
// Returns a SQL expression that resolves to the new value ONLY when the field
// is not present in `products.manual_overrides`. This makes the sync upsert
// non-destructive: any field the admin manually edited stays as-is.
function protectedSet(field: string, newValueSql: any) {
  return sql`CASE WHEN ${sql.raw(`'${field}'`)} = ANY(COALESCE(products.manual_overrides, ARRAY[]::text[])) THEN ${sql.raw(`products.${toSnake(field)}`)} ELSE ${newValueSql} END`;
}

function toSnake(s: string): string {
  return s.replace(/[A-Z]/g, m => "_" + m.toLowerCase());
}

async function getSettingValue(key: string, def: string): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  return row?.value ?? def;
}

async function setSettingValue(key: string, value: string): Promise<void> {
  await db
    .insert(settingsTable)
    .values({ key, value })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
}

export type ProviderSyncStatus = {
  at: string;
  durationMs: number;
  fetched: number;
  created: number;
  updated: number;
  skipped: number;
  priceChanges: number;
  errors: string[];
};

const SYNC_PRICE_CHANGE_THRESHOLD = 0.0001; // ignore micro float diffs

async function logSyncPriceChanges(
  provider: string,
  rows: Array<{ id: string; name: string; unitPriceUsd: string }>,
): Promise<number> {
  if (rows.length === 0) return 0;
  const ids = rows.map(r => r.id);
  const existing = await db
    .select({ id: productsTable.id, unitPriceUsd: productsTable.unitPriceUsd })
    .from(productsTable)
    .where(inArray(productsTable.id, ids));
  const map = new Map(existing.map(e => [e.id, e.unitPriceUsd]));
  const changes: any[] = [];
  for (const row of rows) {
    const oldStr = map.get(row.id);
    if (oldStr == null) continue; // brand new product — not a "change"
    const oldNum = parseFloat(String(oldStr));
    const newNum = parseFloat(row.unitPriceUsd);
    if (!isFinite(oldNum) || !isFinite(newNum)) continue;
    if (Math.abs(oldNum - newNum) < SYNC_PRICE_CHANGE_THRESHOLD) continue;
    changes.push({
      productId: row.id,
      productName: row.name,
      adminId: 0,
      adminUsername: `sync:${provider}`,
      field: "unitPriceUsd",
      oldValue: oldNum.toFixed(6),
      newValue: newNum.toFixed(6),
    });
  }
  if (changes.length > 0) {
    try { await db.insert(productChangeLogTable).values(changes); } catch { /* ignore */ }
  }
  return changes.length;
}

async function saveProviderSyncStatus(provider: string, status: ProviderSyncStatus): Promise<void> {
  try {
    await setSettingValue(`sync_status_${provider}`, JSON.stringify(status));
  } catch { /* ignore */ }
}

export async function getProviderSyncStatus(provider: string): Promise<ProviderSyncStatus | null> {
  try {
    const raw = await getSettingValue(`sync_status_${provider}`, "");
    if (!raw) return null;
    return JSON.parse(raw) as ProviderSyncStatus;
  } catch { return null; }
}

// ─── Admin-configurable provider category → our category map ─────────────────
//   Settings key:  category_mapping_<provider>
//   Format:        { "<rawCategoryName lowercased>": "<our_category_id>" }
async function loadCategoryOverrides(provider: string): Promise<Record<string, string>> {
  try {
    const raw = await getSettingValue(`category_mapping_${provider}`, "");
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return Object.fromEntries(
        Object.entries(parsed).map(([k, v]) => [String(k).trim().toLowerCase(), String(v)])
      );
    }
  } catch { /* ignore */ }
  return {};
}

function applyCategoryOverride(
  overrides: Record<string, string>,
  rawCategory: string,
  fallback: string,
): string {
  const key = (rawCategory ?? "").trim().toLowerCase();
  if (!key) return fallback;
  if (overrides[key]) return overrides[key];
  // Allow wildcard fuzzy match: any override key contained in rawCategory
  for (const [needle, target] of Object.entries(overrides)) {
    if (needle && key.includes(needle)) return target;
  }
  return fallback;
}

// ─── Normalize game description so all upstream feeds use canonical names ──
function normalizeGameDescription(name: string, rawCategory: string): string {
  const combined = (name + " " + rawCategory).toLowerCase();
  if (/pubg|ببجي|playerunknown|شدات.*uc|uc.*شدات|battlegrounds/i.test(combined)) return "PUBG Mobile";
  if (/free.?fire|فري.?فاير|garena.*free|ff.*diamond|diamond.*ff/i.test(combined)) return "Free Fire";
  if (/mobile.?legend|mlbb|ماين|ليجند|moonton/i.test(combined)) return "Mobile Legends";
  if (/clash.*royale|كلاش.*رويال/i.test(combined)) return "Clash Royale";
  if (/clash.*of.*clan|كلاش.*اوف|كلاش.*كلان/i.test(combined)) return "Clash of Clans";
  if (/roblox|روبلوكس/i.test(combined)) return "Roblox";
  if (/minecraft|ماين.*كرافت/i.test(combined)) return "Minecraft";
  if (/fortnite|فورت.*نايت/i.test(combined)) return "Fortnite";
  if (/cod\b|call.*of.*duty|كول.*اوف|كود.*موبايل/i.test(combined)) return "Call of Duty Mobile";
  if (/genshin|جنشن/i.test(combined)) return "Genshin Impact";
  if (/standoff|ستاندوف/i.test(combined)) return "Standoff 2";
  if (/arena.*valor|honor.*king|اريناء/i.test(combined)) return "Arena of Valor";
  if (/brawl.?stars|براول/i.test(combined)) return "Brawl Stars";
  if (/netflix|نتفلكس/i.test(combined)) return "Netflix";
  if (/spotify|سبوتيفاي/i.test(combined)) return "Spotify";
  if (/youtube.*premium|يوتيوب.*بريميوم/i.test(combined)) return "YouTube Premium";
  if (/apple.*music|ابل.*ميوزك/i.test(combined)) return "Apple Music";
  if (/disney.*plus|ديزني/i.test(combined)) return "Disney+";
  if (/amazon.*prime|امازون.*برايم/i.test(combined)) return "Amazon Prime";
  if (/steam|ستيم/i.test(combined)) return "Steam";
  if (/valorant|فالورانت/i.test(combined)) return "Valorant";
  if (/league.*legend|\blol\b|ليغ.*اوف/i.test(combined)) return "League of Legends";
  return rawCategory || name;
}

// ─── Cross-provider dedup helper (no-op in single-provider mode) ─────────────
//   Kept exported for back-compat with any caller that still references it.
export async function deduplicateCrossProviderProducts(): Promise<number> {
  return 0;
}

// ─── Name-based rules for Ahminix / generic providers ─────────────────────────
const NAME_CATEGORY_RULES: [RegExp, string][] = [
  [/pubg|free.?fire|cod\b|fortnite|minecraft|roblox|mobile.*legend|mlbb|genshin|clash|arena.*of.*valor|honor.*of.*kings|standoff/i, "mobile_games"],
  [/steam|valorant|league.*legend|\blol\b|world.*of.*warcraft|\bwow\b|counter.*strike|cs.*go|dota|origin|epic.*game|uplay|battlenet/i, "pc_games"],
  [/netflix|spotify|youtube.*premium|apple.*music|disney|hbo|amazon.*prime|hulu|crunchyroll|deezer|tidal|subscri/i, "services"],
  [/chatgpt|openai|midjourney|canva|adobe|notion|figma|grammarly|copilot|gemini|ai.*tool/i, "services"],
  [/instagram|facebook|tiktok|twitter|snapchat|telegram.*premium|social/i, "services"],
  [/amazon.*gift|google.*play|apple.*gift|itunes|ebay.*gift|paypal.*gift|razer.*gold|karma.*koin|garena|gift.*card|voucher/i, "gift_cards"],
  [/usdt|bitcoin|eth\b|crypto|binance|coinbase/i, "general"],
  [/number|virtual.*number|sms.*verif/i, "general"],
];

function detectCategoryFromName(name: string, rawCategory: string): string {
  const key = (rawCategory ?? "").toLowerCase().replace(/[^a-z_]/g, "_").replace(/__+/g, "_");
  const MAP: Record<string, string> = {
    mobile_games: "mobile_games", mobile: "mobile_games", games: "mobile_games",
    pc_games: "pc_games", pc: "pc_games", computer: "pc_games",
    gift_cards: "gift_cards", gift: "gift_cards", vouchers: "gift_cards", cards: "gift_cards",
    services: "services", apps: "services", social: "services", subscriptions: "services",
    streaming: "services", ai: "services",
    general: "general", telecom: "general", crypto: "general",
  };
  const base = MAP[key];
  if (base && base !== "general") return base;
  for (const [regex, cat] of NAME_CATEGORY_RULES) {
    if (regex.test(name)) return cat;
  }
  return base ?? "general";
}

// ─── Fetch helper — handles both paginated & single-call APIs ─────────────────
function extractItems(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== "object") return [];
  // Direct array fields
  for (const key of ["products", "games", "items", "result", "list", "rows"]) {
    if (Array.isArray(data[key])) return data[key];
  }
  // Nested under `data` (Mega Game API style: {error, message, data: {products:[...]}})
  if (data.data) {
    if (Array.isArray(data.data)) return data.data;
    for (const key of ["products", "games", "items", "result", "list", "rows"]) {
      if (Array.isArray(data.data?.[key])) return data.data[key];
    }
  }
  return [];
}

async function fetchAllPages(
  baseUrl: string,
  headers: Record<string, string>,
): Promise<any[]> {
  const PAGE_SIZE = 100;
  // Always include page=1 so paginated APIs also respond correctly on first call
  const firstUrl = `${baseUrl}?page=1&limit=${PAGE_SIZE}&per_page=${PAGE_SIZE}`;
  let firstResp = await fetch(firstUrl, { headers, signal: AbortSignal.timeout(120000) });
  // If page-param URL fails, fall back to base URL (some APIs don't accept params)
  if (!firstResp.ok) {
    firstResp = await fetch(baseUrl, { headers, signal: AbortSignal.timeout(120000) });
    if (!firstResp.ok) return [];
    const rawData = await firstResp.json();
    return extractItems(rawData);
  }

  const firstData = await firstResp.json() as any;
  const firstItems = extractItems(firstData);

  // Check for pagination metadata
  const meta = firstData?.meta ?? firstData?.pagination ?? firstData?.paginate ?? null;
  const totalPages: number =
    meta?.last_page ?? meta?.totalPages ?? meta?.total_pages ?? meta?.lastPage ??
    (meta?.total && meta?.per_page ? Math.ceil(meta.total / meta.per_page) : null) ??
    1;

  // No pagination or single page
  if (!meta || totalPages <= 1) {
    // If we got < PAGE_SIZE items, definitely all of them
    if (firstItems.length < PAGE_SIZE) return firstItems;
    // If exactly PAGE_SIZE or more came back without pagination meta,
    // try fetching page 2 to check if there's more
    try {
      const p2 = await fetch(`${baseUrl}?page=2&limit=${PAGE_SIZE}&per_page=${PAGE_SIZE}`, {
        headers, signal: AbortSignal.timeout(45000),
      });
      if (!p2.ok) return firstItems;
      const p2Data = await p2.json();
      const p2Items = extractItems(p2Data);
      if (p2Items.length === 0) return firstItems;
      // There are more pages — fetch all
      const allItems = [...firstItems, ...p2Items];
      for (let page = 3; page <= 300; page++) {
        try {
          const resp = await fetch(`${baseUrl}?page=${page}&limit=${PAGE_SIZE}&per_page=${PAGE_SIZE}`, {
            headers, signal: AbortSignal.timeout(45000),
          });
          if (!resp.ok) break;
          const data = await resp.json();
          const items = extractItems(data);
          if (items.length === 0) break;
          allItems.push(...items);
          if (items.length < PAGE_SIZE) break;
        } catch { break; }
      }
      return allItems;
    } catch {
      return firstItems;
    }
  }

  // Paginated API — fetch all remaining pages in sequence
  const allItems = [...firstItems];
  for (let page = 2; page <= Math.min(totalPages, 300); page++) {
    try {
      const url = `${baseUrl}?page=${page}&limit=${PAGE_SIZE}&per_page=${PAGE_SIZE}`;
      const resp = await fetch(url, { headers, signal: AbortSignal.timeout(45000) });
      if (!resp.ok) break;
      const data = await resp.json();
      const items = extractItems(data);
      if (items.length === 0) break;
      allItems.push(...items);
      if (items.length < PAGE_SIZE) break;
    } catch { break; }
  }
  return allItems;
}

// ─── Main sync function (single-provider system) ────────────────────────────
//   Reads provider config from `settings`, fetches /games + /products?game_id
//   for each game, upserts under `<provider>_<id>` keys. Provider returns
//   prices in SYP — we convert to USD via `syp_rate` before storing.
//   Legacy products from removed providers (shams4store, ahminix) are kept
//   in the database (foreign-key constraints from orders) but flipped to
//   `inactive` so they no longer appear in the storefront.
export async function syncProductsFromAPIs(
  _providerArg?: string,
): Promise<{ imported: number; errors: string[] }> {
  const results = { imported: 0, errors: [] as string[] };

  const cfg = await getProviderConfig();
  if (!cfg.configured) {
    results.errors.push(`${cfg.displayName}: missing API token or base URL`);
    return results;
  }
  if (!cfg.enabled) {
    results.errors.push(`${cfg.displayName}: provider is disabled by admin`);
    return results;
  }

  const provider = cfg.name;
  const sypRate = await getSypRate();
  const defaultMargin = parseFloat(await getSettingValue("default_profit_margin", "10")) || 10;
  const defaultMarginFactor = 1 + defaultMargin / 100;
  const autoStopLoss = (await getSettingValue("auto_stop_loss_products", "true")) !== "false";
  const autoHideUnavailable = (await getSettingValue("auto_hide_unavailable_products", "false")) === "true";

  const status: ProviderSyncStatus = {
    at: new Date().toISOString(), durationMs: 0, fetched: 0,
    created: 0, updated: 0, skipped: 0, priceChanges: 0, errors: [],
  };
  const tStart = Date.now();

  try {
    // 1) Pull the list of games (categories) from the upstream provider
    const gamesUrl = `${cfg.baseUrl}${cfg.endpoints.games}`;
    const gamesRes = await providerFetch<any>(gamesUrl, cfg.token, {
      operation: "syncProducts:games",
      provider,
      timeoutMs: 60000,
    });
    if (!gamesRes.ok || !gamesRes.data) {
      const msg = gamesRes.error ?? `HTTP ${gamesRes.status}`;
      results.errors.push(`Failed to fetch games: ${msg}`);
      status.errors.push(`games: ${msg}`);
    } else {
      const gamesArr: any[] = extractItems(gamesRes.data);
      const catOverrides = await loadCategoryOverrides(provider);
      const allRows: any[] = [];

      // 2) For each game, pull its product catalog
      for (const game of gamesArr) {
        const gameId = game.id ?? game.game_id ?? game.gameId;
        if (gameId == null) continue;
        const gameName: string = game.name ?? game.title ?? game.name_ar ?? String(gameId);
        const productsUrl = `${cfg.baseUrl}${cfg.endpoints.products}?game_id=${encodeURIComponent(String(gameId))}`;
        const pRes = await providerFetch<any>(productsUrl, cfg.token, {
          operation: "syncProducts:products",
          provider,
          timeoutMs: 45000,
          context: { gameId, gameName },
        });
        if (!pRes.ok || !pRes.data) {
          const msg = pRes.error ?? `HTTP ${pRes.status}`;
          status.errors.push(`game ${gameId}: ${msg}`);
          continue;
        }
        const items = extractItems(pRes.data);
        status.fetched += items.length;

        for (const item of items) {
          try {
            const id = item.id ?? item.product_id;
            if (id == null) { status.skipped++; continue; }
            const upstreamGameName: string = item.gameName ?? game.name ?? gameName;
            const name: string = item.name ?? item.title ?? `${upstreamGameName} ${id}`;
            const rawCat: string = String(game.category ?? game.type ?? upstreamGameName ?? "");
            const baseCat = detectCategoryFromName(`${name} ${upstreamGameName}`, rawCat);
            const category = applyCategoryOverride(catOverrides, rawCat, baseCat);
            const description = normalizeGameDescription(name, upstreamGameName);
            const priceSyp = parseFloat(String(item.price ?? item.cost ?? 0));
            const safeSyp = isFinite(priceSyp) ? priceSyp : 0;
            // Convert provider's SYP price → USD using the admin-managed rate
            const unitUsd = sypRate > 0 ? safeSyp / sypRate : safeSyp;
            // ── Dynamic fields (Mega Game uses `daynamicFields`, fall back to `params`) ──
            const rawDyn = (item as any).daynamicFields ?? (item as any).dynamicFields ?? item.params;
            const requiredFields: string[] = (() => {
              if (Array.isArray(rawDyn) && rawDyn.length > 0) {
                // Could be ["playerId","email"] OR [{ key: "...", ...}]
                return rawDyn.map((f: any) => typeof f === "string" ? f : (f?.key ?? f?.name ?? "")).filter(Boolean);
              }
              return ["playerId"];
            })();
            const productType = (item.product_type === "amount" || item.type === "amount") ? "amount" : "package";

            // ── Quantity bounds (Mega Game: minCount / maxCount) ──
            const minCountRaw = (item as any).minCount ?? item.qty_values?.min ?? item.qty_min;
            const maxCountRaw = (item as any).maxCount ?? item.qty_values?.max ?? item.qty_max;
            const qtyMin = minCountRaw != null ? String(minCountRaw) : null;
            const qtyMax = maxCountRaw != null ? String(maxCountRaw) : null;

            // ── Status mapping ──
            //   isActive (Mega Game)  · available · status === "active"
            // Price Protection: a product priced at 0 SYP is auto-deactivated
            // because it cannot be sold profitably.
            const isActiveUpstream =
              (item as any).isActive === undefined ? true : Boolean((item as any).isActive);
            const isAvailable = item.available !== false && item.status !== "inactive";
            const priceProtectionOk = safeSyp > 0;
             const status_ = (
               isActiveUpstream &&
               (!autoHideUnavailable || isAvailable) &&
               (!autoStopLoss || priceProtectionOk)
             ) ? "active" : "inactive";

            allRows.push({
              id: `${provider}_${id}`,
              name,
              nameAr: item.name_ar ?? item.nameAr ?? name,
              description,
              priceUsd: String(+(unitUsd * defaultMarginFactor).toFixed(6)),
              unitPriceUsd: String(unitUsd),
              profitMargin: String(defaultMargin),
              category,
              provider,
              providerProductId: String(id),
              providerCategoryId: String(gameId),
              providerCategoryName: upstreamGameName || null,
              requiredFields,
              status: status_,
              productType,
              qtyMin,
              qtyMax,
              image: item.image ?? item.logo ?? item.thumbnail ?? game.image ?? null,
            });
          } catch (e: any) {
            status.errors.push(`item ${item?.id}: ${e.message}`);
          }
        }
      }

      // 3) Batch upsert (200 rows at a time, field-protected for admin overrides)
      const BATCH = 200;
      for (let i = 0; i < allRows.length; i += BATCH) {
        const chunk = allRows.slice(i, i + BATCH);
        try {
          status.priceChanges += await logSyncPriceChanges(
            provider,
            chunk.map(c => ({ id: c.id, name: c.name, unitPriceUsd: c.unitPriceUsd })),
          );
          const returned = await db
            .insert(productsTable)
            .values(chunk)
            .onConflictDoUpdate({
              target: productsTable.id,
              set: {
                name: protectedSet("name", sql`excluded.name`),
                nameAr: protectedSet("nameAr", sql`excluded.name_ar`),
                description: protectedSet("description", sql`excluded.description`),
                category: protectedSet("category", sql`excluded.category`),
                status: protectedSet("status", sql`excluded.status`),
                image: protectedSet("image", sql`excluded.image`),
                unitPriceUsd: sql`excluded.unit_price_usd`,
                priceUsd: sql`CASE WHEN 'priceUsd' = ANY(COALESCE(products.manual_overrides, ARRAY[]::text[])) THEN products.price_usd ELSE CAST(excluded.unit_price_usd AS NUMERIC) * (1 + COALESCE(CAST(products.profit_margin AS NUMERIC), 10) / 100) END`,
                requiredFields: sql`excluded.required_fields`,
                productType: sql`excluded.product_type`,
                qtyMin: sql`excluded.qty_min`,
                qtyMax: sql`excluded.qty_max`,
                providerCategoryId: sql`excluded.provider_category_id`,
                providerCategoryName: sql`excluded.provider_category_name`,
                provider: sql`excluded.provider`,
                updatedAt: new Date(),
              },
            })
            .returning({ inserted: sql<boolean>`(xmax = 0)` });
          for (const r of returned) {
            if ((r as any).inserted) status.created++;
            else status.updated++;
          }
          results.imported += chunk.length;
        } catch (e: any) {
          results.errors.push(`batch ${i}: ${e.message}`);
          status.errors.push(`batch ${i}: ${e.message}`);
        }
      }
    }
  } catch (e: any) {
    results.errors.push(`${cfg.displayName} sync error: ${e.message}`);
    status.errors.push(e.message);
  }

  // 4) Deactivate any leftover products from removed legacy providers.
  //    We don't delete them — orders reference them via FK.
  try {
    const legacy = await db
      .update(productsTable)
      .set({ status: "inactive", updatedAt: new Date() })
      .where(and(
        inArray(productsTable.provider, ["shams4store", "ahminix"]),
        eq(productsTable.status, "active"),
      ))
      .returning({ id: productsTable.id });
    if (legacy.length > 0) {
      results.errors.push(`[INFO] Deactivated ${legacy.length} legacy products from removed providers`);
    }
  } catch { /* ignore */ }

  status.durationMs = Date.now() - tStart;
  await saveProviderSyncStatus(provider, status);
  await setProviderSetting("provider_last_sync", new Date().toISOString());

  return results;
}


// ─── Category list endpoint ───────────────────────────────────────────────────
router.get("/products/categories", async (req, res): Promise<void> => {
  const catMap: Record<string, { name: string; nameAr: string; icon: string }> = {
    mobile_games: { name: "Mobile Games",  nameAr: "ألعاب الهاتف",     icon: "🎮" },
    pc_games:     { name: "PC Games",      nameAr: "ألعاب الكمبيوتر",  icon: "🖥️" },
    gift_cards:   { name: "Gift Cards",    nameAr: "بطاقات هدية",      icon: "🎁" },
    services:     { name: "Services",      nameAr: "خدمات",            icon: "⚡" },
    general:      { name: "General",       nameAr: "عام",              icon: "🛍️" },
  };

  const result = await db
    .select({ category: productsTable.category, cnt: count() })
    .from(productsTable)
    .where(eq(productsTable.status, "active"))
    .groupBy(productsTable.category);

  const out = result
    .map(r => ({
      id: r.category,
      name: catMap[r.category]?.name ?? r.category,
      nameAr: catMap[r.category]?.nameAr ?? r.category,
      icon: catMap[r.category]?.icon ?? "🛒",
      productCount: r.cnt,
    }))
    .sort((a, b) => b.productCount - a.productCount);

  res.json(out);
});

router.get("/products/games", async (req, res): Promise<void> => {
  const category = typeof req.query.category === "string" ? req.query.category : undefined;
  const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
  const limitRaw = typeof req.query.limit === "string" ? Number(req.query.limit) : 500;
  const limit = Math.min(Number.isFinite(limitRaw) && limitRaw > 0 ? limitRaw : 500, 1000);

  const gameLabel = sql<string>`COALESCE(NULLIF(TRIM(${productsTable.description}), ''), ${productsTable.name})`;
  const conditions = [eq(productsTable.status, "active")];

  if (category) conditions.push(eq(productsTable.category, category));
  if (search) {
    conditions.push(
      or(
        ilike(productsTable.name, `%${search}%`),
        ilike(productsTable.nameAr, `%${search}%`),
        ilike(productsTable.description, `%${search}%`),
      )!,
    );
  }

  const whereClause = conditions.length === 1 ? conditions[0] : and(...conditions);

  const games = await db
    .select({
      label: gameLabel,
      category: productsTable.category,
      count: count(),
      image: sql<string | null>`MIN(${productsTable.image})`,
    })
    .from(productsTable)
    .where(whereClause)
    .groupBy(gameLabel, productsTable.category)
    .orderBy(sql`COUNT(*) DESC`, gameLabel)
    .limit(limit);

  res.json(games.filter(g => g.label && !/^\d+$/.test(g.label)));
});

// ─── Featured products ─────────────────────────────────────────────────────────
router.get("/products/count", async (_req, res): Promise<void> => {
  const rows = await db.select({ id: productsTable.id }).from(productsTable).where(eq(productsTable.status, "active"));
  res.json({ count: rows.length });
});

router.get("/products/featured", async (req, res): Promise<void> => {
  const products = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.status, "active"))
    .limit(8);

  res.json(products.map(p => ({
    ...p,
    priceUsd: parseFloat(p.priceUsd ?? "0"),
    profitMargin: parseFloat(p.profitMargin ?? "10"),
    salePriceUsd: p.salePriceUsd != null ? parseFloat(p.salePriceUsd) : null,
    saleEndsAt: p.saleEndsAt ?? null,
    requiredFields: p.requiredFields ?? [],
  })));
});

// ─── Public flash-sales feed (active sales only) ──────────────────────────────
router.get("/products/flash-sales", async (_req, res): Promise<void> => {
  const now = new Date();
  const products = await db
    .select()
    .from(productsTable)
    .where(
      and(
        eq(productsTable.status, "active"),
        isNotNull(productsTable.salePriceUsd),
        isNotNull(productsTable.saleEndsAt),
        sql`${productsTable.saleEndsAt} > ${now}`,
      ),
    )
    .orderBy(productsTable.saleEndsAt)
    .limit(12);

  res.json(products.map(p => {
    const price = parseFloat(p.priceUsd ?? "0");
    const sale = parseFloat(p.salePriceUsd ?? "0");
    const discountPct = price > 0 ? Math.round(((price - sale) / price) * 100) : 0;
    return {
      ...p,
      priceUsd: price,
      profitMargin: parseFloat(p.profitMargin ?? "10"),
      salePriceUsd: sale,
      saleEndsAt: p.saleEndsAt,
      discountPct,
      requiredFields: p.requiredFields ?? [],
    };
  }));
});

// ─── Product list ─────────────────────────────────────────────────────────────
router.get("/products", async (req, res): Promise<void> => {
  const qp = GetProductsQueryParams.safeParse(req.query);
  const page = qp.success ? (qp.data.page ?? 1) : 1;
  const limit = Math.min(qp.success ? (qp.data.limit ?? 48) : 48, 1000);
  const category = qp.success ? qp.data.category : undefined;
  const provider = qp.success ? qp.data.provider : undefined;
  const search = qp.success ? qp.data.search : undefined;
  const game = typeof req.query.game === "string" ? req.query.game.trim() : "";
  const gameGroup = typeof req.query.game_group === "string" ? req.query.game_group.trim() : "";
  const offset = (page - 1) * limit;

  const FALLBACK_PATTERNS: Record<string, string[]> = {
    pubg: ["شدات", "ببجي", "pubg"],
    freefire: ["فري فاير", "Free Fire", "Garena Free Fire"],
  };
  let groupPatterns: string[] = [];
  let groupAssignedIds: string[] = [];
  let groupCardCategory: string | null = null;
  if (gameGroup) {
    try {
      const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, "featured_games"));
      if (row?.value) {
        const parsed = JSON.parse(row.value);
        if (Array.isArray(parsed)) {
          const cfg = parsed.find((p: any) => p && p.id === gameGroup);
          if (cfg) {
            if (Array.isArray(cfg.keywords) && cfg.keywords.length) {
              groupPatterns = cfg.keywords.map((k: any) => String(k));
            }
            if (typeof cfg.category === "string" && cfg.category) groupCardCategory = cfg.category;
          }
        }
      }
    } catch { /* ignore */ }
    if (!groupPatterns.length) groupPatterns = FALLBACK_PATTERNS[gameGroup] ?? [gameGroup];
    // Manual product-to-card assignments override keyword matching
    try {
      const [a] = await db.select().from(settingsTable).where(eq(settingsTable.key, "featured_card_assignments"));
      if (a?.value) {
        const parsed = JSON.parse(a.value);
        if (parsed && typeof parsed === "object" && Array.isArray(parsed[gameGroup])) {
          groupAssignedIds = parsed[gameGroup].map((id: any) => String(id)).filter(Boolean);
        }
      }
    } catch { /* ignore */ }
  }

  const conditions = [eq(productsTable.status, "active")];
  if (category) conditions.push(eq(productsTable.category, category));
  if (provider) conditions.push(eq(productsTable.provider, provider));
  if (game) conditions.push(eq(productsTable.description, game));
  if (gameGroup) {
    const matchClauses: any[] = [];
    if (groupPatterns.length) {
      const kwClause = or(
        ...groupPatterns.flatMap(p => [
          ilike(productsTable.description, `%${p}%`),
          ilike(productsTable.providerCategoryName, `%${p}%`),
        ])
      )!;
      // Only include keyword matches that ALSO belong to the card's category (if set),
      // so generic words like a category-name don't pull in unrelated products.
      matchClauses.push(
        groupCardCategory
          ? and(eq(productsTable.category, groupCardCategory), kwClause)!
          : kwClause
      );
    }
    if (groupAssignedIds.length) matchClauses.push(inArray(productsTable.id, groupAssignedIds));
    if (matchClauses.length) conditions.push(matchClauses.length === 1 ? matchClauses[0] : or(...matchClauses)!);
  }
  if (search) {
    conditions.push(
      or(
        ilike(productsTable.name, `%${search}%`),
        ilike(productsTable.nameAr, `%${search}%`),
        ilike(productsTable.description, `%${search}%`),
        ilike(productsTable.category, `%${search}%`),
        ilike(productsTable.provider, `%${search}%`),
      )!,
    );
  }

  const whereClause = conditions.length === 1 ? conditions[0] : and(...conditions);

  const [totalResult] = await db
    .select({ count: count() })
    .from(productsTable)
    .where(whereClause);

  // Custom ordering: sortOrder first (manual), then category priority, then game, then price
  const catOrder = sql`CASE ${productsTable.category}
    WHEN 'mobile_games' THEN 1
    WHEN 'services' THEN 2
    WHEN 'gift_cards' THEN 3
    WHEN 'pc_games' THEN 4
    ELSE 5 END`;

  const products = await db
    .select()
    .from(productsTable)
    .where(whereClause)
    .orderBy(productsTable.sortOrder, catOrder, productsTable.description, productsTable.priceUsd)
    .limit(limit)
    .offset(offset);

  const categories = await db
    .selectDistinct({ category: productsTable.category })
    .from(productsTable)
    .where(eq(productsTable.status, "active"));

  const providers = await db
    .selectDistinct({ provider: productsTable.provider })
    .from(productsTable)
    .where(eq(productsTable.status, "active"));

  res.json({
    products: products.map(p => ({
      ...p,
      priceUsd: parseFloat(p.priceUsd ?? "0"),
      profitMargin: parseFloat(p.profitMargin ?? "10"),
      salePriceUsd: p.salePriceUsd != null ? parseFloat(p.salePriceUsd) : null,
      saleEndsAt: p.saleEndsAt ?? null,
      requiredFields: p.requiredFields ?? [],
    })),
    total: totalResult?.count ?? 0,
    page,
    limit,
    categories: categories.map(c => c.category),
    filters: {
      categories: categories.map(c => c.category),
      providers: providers.map(p => p.provider),
    },
  });
});

// ─── Single product ───────────────────────────────────────────────────────────
router.get("/products/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, rawId));

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const related = await db
    .select()
    .from(productsTable)
    .where(
      and(
        eq(productsTable.status, "active"),
        eq(productsTable.category, product.category),
        sql`${productsTable.id} <> ${rawId}`,
      ),
    )
    .limit(8);

  // ─── Compute average actual delivery time from last 20 completed orders ──
  let avgDeliveryMinutes: number | null = null;
  let deliverySampleSize = 0;
  try {
    const recentDelivered = await db
      .select({
        createdAt: ordersTable.createdAt,
        completedAt: ordersTable.completedAt,
      })
      .from(ordersTable)
      .where(
        and(
          eq(ordersTable.productId, rawId),
          eq(ordersTable.status, "delivered"),
          isNotNull(ordersTable.completedAt),
        ),
      )
      .orderBy(desc(ordersTable.completedAt))
      .limit(20);

    if (recentDelivered.length > 0) {
      const totalMs = recentDelivered.reduce((sum, o) => {
        const start = new Date(o.createdAt).getTime();
        const end = new Date(o.completedAt as Date).getTime();
        const diff = end - start;
        return sum + (diff > 0 ? diff : 0);
      }, 0);
      avgDeliveryMinutes = Math.round(totalMs / recentDelivered.length / 60000);
      deliverySampleSize = recentDelivered.length;
    }
  } catch (err) {
    req.log.error({ err }, "avg delivery calc failed");
  }

  res.json({
    ...product,
    priceUsd: parseFloat(product.priceUsd ?? "0"),
    unitPriceUsd: parseFloat(product.unitPriceUsd ?? "0"),
    profitMargin: parseFloat(product.profitMargin ?? "10"),
    salePriceUsd: product.salePriceUsd != null ? parseFloat(product.salePriceUsd) : null,
    saleEndsAt: product.saleEndsAt ?? null,
    requiredFields: product.requiredFields ?? [],
    avgDeliveryMinutes,
    deliverySampleSize,
    relatedProducts: related.map(p => ({
      ...p,
      priceUsd: parseFloat(p.priceUsd ?? "0"),
      unitPriceUsd: parseFloat(p.unitPriceUsd ?? "0"),
      profitMargin: parseFloat(p.profitMargin ?? "10"),
      salePriceUsd: p.salePriceUsd != null ? parseFloat(p.salePriceUsd) : null,
      saleEndsAt: p.saleEndsAt ?? null,
      requiredFields: p.requiredFields ?? [],
    })),
  });
});

// ─── Price history (from change log, price_usd field) ────────────────────────
router.get("/products/:id/price-history", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const history = await db
    .select({
      field: productChangeLogTable.field,
      oldValue: productChangeLogTable.oldValue,
      newValue: productChangeLogTable.newValue,
      createdAt: productChangeLogTable.createdAt,
    })
    .from(productChangeLogTable)
    .where(
      and(
        eq(productChangeLogTable.productId, rawId),
        like(productChangeLogTable.field, "%price%"),
      ),
    )
    .orderBy(productChangeLogTable.createdAt)
    .limit(90);

  // Normalise to { date, price } data points
  const points = history
    .map(h => ({ date: h.createdAt, price: parseFloat(h.newValue ?? "0") }))
    .filter(p => p.price > 0);

  res.json({ history: points });
});

// ─── In-memory sync status ────────────────────────────────────────────────────
let syncStatus: { running: boolean; lastResult?: { imported: number; errors: string[]; completedAt: string } } = {
  running: false,
};

// ─── Admin: trigger sync (non-blocking) ──────────────────────────────────────
router.post("/admin/products/sync", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const { provider } = req.body as { provider?: string };

  if (syncStatus.running) {
    res.json({ success: false, message: "Sync already in progress" });
    return;
  }

  // Start sync in background
  syncStatus.running = true;
  syncProductsFromAPIs(provider).then(result => {
    syncStatus = {
      running: false,
      lastResult: { ...result, completedAt: new Date().toISOString() },
    };
  }).catch(() => {
    syncStatus.running = false;
  });

  res.json({ success: true, message: "Sync started in background", provider: provider ?? "all" });
});

router.get("/admin/products/sync/status", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const cfg = await getProviderConfig();
  const providerStatus = await getProviderSyncStatus(cfg.name);
  res.json({
    ...syncStatus,
    provider: { name: cfg.name, displayName: cfg.displayName, status: providerStatus },
    providers: {
      [cfg.name]: {
        displayName: cfg.displayName,
        lastSync: providerStatus,
        ...(providerStatus ?? {}),
      },
    },
  });
});

export default router;
