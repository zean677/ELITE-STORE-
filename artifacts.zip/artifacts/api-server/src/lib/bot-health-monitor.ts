import { logger } from "./logger";
import { setBotHealth, flushQueue, getBotHealth } from "./telegram-queue";

const PING_INTERVAL_MS = 5 * 60 * 1000;
const FLUSH_INTERVAL_MS = 30 * 1000;

async function pingBot(): Promise<void> {
  const token = (process.env.TELEGRAM_BOT_TOKEN ?? "").trim();
  if (!token) return;
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/getMe`, { signal: AbortSignal.timeout(8000) });
    if (r.ok) {
      const json: any = await r.json().catch(() => null);
      if (json?.ok) {
        setBotHealth(true);
        return;
      }
    }
    setBotHealth(false, `getMe HTTP ${r.status}`);
  } catch (e: any) {
    setBotHealth(false, e?.message?.slice(0, 200) ?? "network error");
  }
}

async function tryFlush(): Promise<void> {
  if (!getBotHealth().healthy) return;
  try {
    const { telegramRequestRaw } = await import("./telegram");
    await flushQueue(telegramRequestRaw);
  } catch (e: any) {
    logger.warn({ err: e?.message }, "Telegram queue flush failed");
  }
}

export function startBotHealthMonitor(): void {
  setTimeout(() => {
    pingBot();
    setInterval(() => { pingBot(); }, PING_INTERVAL_MS);
    setInterval(() => { tryFlush(); }, FLUSH_INTERVAL_MS);
  }, 10_000);
  logger.info("Telegram bot health monitor scheduled (5min ping, 30s queue flush)");
}
