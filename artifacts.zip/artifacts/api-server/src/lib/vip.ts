import { db, ordersTable, settingsTable, usersTable, loyaltyTransactionsTable } from "@workspace/db";
import { eq, sql, sum, and } from "drizzle-orm";

export const POINTS_PER_USD = 1; // 1 point per $1 spent
export const POINTS_PER_USD_REDEEM = 100; // 100 points = $1 redeemable

export type VipTier = {
  level: number;
  thresholdUsd: number;
  discountPercent: number;
};

const DEFAULT_TIERS: VipTier[] = [
  { level: 1, thresholdUsd: 100, discountPercent: 2 },
  { level: 2, thresholdUsd: 300, discountPercent: 4 },
  { level: 3, thresholdUsd: 700, discountPercent: 6 },
  { level: 4, thresholdUsd: 1500, discountPercent: 8 },
];

function asNumber(value: unknown, fallback: number): number {
  const parsed = Number(value ?? fallback);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export async function getVipTiers(): Promise<VipTier[]> {
  const rows = await db.select().from(settingsTable);
  const settings = new Map(rows.map(row => [row.key, row.value]));
  return DEFAULT_TIERS.map(tier => ({
    level: tier.level,
    thresholdUsd: Math.max(0, asNumber(settings.get(`vip_level_${tier.level}_threshold`), tier.thresholdUsd)),
    discountPercent: Math.max(0, asNumber(settings.get(`vip_level_${tier.level}_discount`), tier.discountPercent)),
  })).sort((a, b) => a.thresholdUsd - b.thresholdUsd);
}

export function calculateVipProfile(totalSpentUsd: number, tiers: VipTier[]) {
  const current = [...tiers].reverse().find(tier => totalSpentUsd >= tier.thresholdUsd);
  const next = tiers.find(tier => totalSpentUsd < tier.thresholdUsd);
  const level = current?.level ?? 0;
  const discountPercent = current?.discountPercent ?? 0;
  const currentThreshold = current?.thresholdUsd ?? 0;
  const nextThreshold = next?.thresholdUsd ?? null;
  const remainingToNext = nextThreshold === null ? 0 : Math.max(0, nextThreshold - totalSpentUsd);
  const progressToNext = nextThreshold === null
    ? 100
    : Math.max(0, Math.min(100, ((totalSpentUsd - currentThreshold) / Math.max(1, nextThreshold - currentThreshold)) * 100));

  return {
    level,
    label: level > 0 ? `VIP ${level}` : "Regular",
    totalSpentUsd,
    discountPercent,
    currentThresholdUsd: currentThreshold,
    nextThresholdUsd: nextThreshold,
    remainingToNextUsd: remainingToNext,
    progressToNext,
    tiers,
  };
}

export async function getHistoricalSpendUsd(userId: number): Promise<number> {
  const [result] = await db
    .select({ total: sum(ordersTable.totalPrice) })
    .from(ordersTable)
    .where(and(eq(ordersTable.userId, userId), eq(ordersTable.status, "completed")));
  return asNumber(result?.total, 0);
}

export async function getUserVipProfile(user: typeof usersTable.$inferSelect) {
  const tiers = await getVipTiers();
  const storedSpend = asNumber(user.totalSpentUsd, 0);
  const historicalSpend = storedSpend > 0 ? 0 : await getHistoricalSpendUsd(user.id);
  const totalSpentUsd = Math.max(storedSpend, historicalSpend);
  const autoProfile = calculateVipProfile(totalSpentUsd, tiers);

  // If admin manually locked the VIP level, expose the manual level but keep auto-discount calc consistent.
  if (user.vipLocked) {
    const manualLevel = user.vipLevel ?? 0;
    const manualTier = tiers.find(t => t.level === manualLevel);
    const profile = {
      ...autoProfile,
      level: manualLevel,
      label: manualLevel > 0 ? `VIP ${manualLevel}` : "Regular",
      discountPercent: manualTier?.discountPercent ?? 0,
      manual: true as const,
    };
    if (totalSpentUsd !== storedSpend) {
      await db.update(usersTable).set({ totalSpentUsd: totalSpentUsd.toFixed(6) }).where(eq(usersTable.id, user.id));
    }
    return profile;
  }

  if (autoProfile.level !== (user.vipLevel ?? 0) || totalSpentUsd !== storedSpend) {
    await db
      .update(usersTable)
      .set({ vipLevel: autoProfile.level, totalSpentUsd: totalSpentUsd.toFixed(6) })
      .where(eq(usersTable.id, user.id));
  }
  return autoProfile;
}

export async function applyCompletedOrderSpend(userId: number, amountUsd: number, orderId?: string) {
  const earnedPoints = Math.max(0, Math.floor(amountUsd * POINTS_PER_USD));

  const [user] = await db
    .update(usersTable)
    .set({
      totalSpentUsd: sql`${usersTable.totalSpentUsd} + ${amountUsd.toFixed(6)}`,
      loyaltyPoints: sql`${usersTable.loyaltyPoints} + ${earnedPoints}`,
    })
    .where(eq(usersTable.id, userId))
    .returning();

  if (!user) return null;

  // Log loyalty transaction (earn)
  if (earnedPoints > 0) {
    await db.insert(loyaltyTransactionsTable).values({
      userId,
      type: "earn",
      points: earnedPoints,
      balanceAfter: user.loyaltyPoints,
      description: `كسب نقاط من إكمال طلب بقيمة $${amountUsd.toFixed(2)}`,
      orderId: orderId ?? null,
    }).catch(() => {});
  }

  const tiers = await getVipTiers();
  const profile = calculateVipProfile(asNumber(user.totalSpentUsd, amountUsd), tiers);
  if (!user.vipLocked && profile.level !== (user.vipLevel ?? 0)) {
    await db.update(usersTable).set({ vipLevel: profile.level }).where(eq(usersTable.id, userId));
  }
  return { ...profile, earnedPoints, totalPoints: user.loyaltyPoints };
}