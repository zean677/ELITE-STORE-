import { db, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export type QueuedMessage = {
  method: "sendMessage" | "sendPhoto";
  body: Record<string, unknown>;
  enqueuedAt: number;
  attempts: number;
};

const queue: QueuedMessage[] = [];
const MAX_QUEUE = 200;
const MAX_ATTEMPTS = 5;

const recentHashes = new Map<string, number>();
const ANTI_SPAM_WINDOW_MS = 60_000;

const lastTypeAt = new Map<string, number>();

let botIsHealthy = true;
let lastHealthAt = Date.now();
let lastHealthError: string | null = null;
let consecutiveFailures = 0;
let totalSent = 0;
let totalFailed = 0;
let totalQueued = 0;
let totalDeduped = 0;

export function setBotHealth(healthy: boolean, error?: string): void {
  if (healthy) {
    botIsHealthy = true;
    lastHealthError = null;
    consecutiveFailures = 0;
  } else {
    botIsHealthy = false;
    lastHealthError = error ?? null;
    consecutiveFailures += 1;
  }
  lastHealthAt = Date.now();
}

export function getBotHealth() {
  return {
    healthy: botIsHealthy,
    lastChecked: lastHealthAt,
    lastError: lastHealthError,
    consecutiveFailures,
    queueSize: queue.length,
    totalSent,
    totalFailed,
    totalQueued,
    totalDeduped,
  };
}

export function getQueueStats() {
  return {
    size: queue.length,
    capacity: 200,
    totalQueued,
    totalSent,
    totalFailed,
    totalDeduped,
  };
}

function hashContent(method: string, body: Record<string, unknown>): string {
  const text = String(body.text ?? body.caption ?? "");
  const chat = String(body.chat_id ?? "");
  return `${method}|${chat}|${text.slice(0, 200)}`;
}

export function isDuplicate(method: string, body: Record<string, unknown>): boolean {
  const key = hashContent(method, body);
  const now = Date.now();
  for (const [k, ts] of recentHashes) {
    if (now - ts > ANTI_SPAM_WINDOW_MS) recentHashes.delete(k);
  }
  if (recentHashes.has(key)) {
    totalDeduped += 1;
    return true;
  }
  recentHashes.set(key, now);
  return false;
}

export function shouldThrottleType(typeKey: string, minIntervalMs = 5000): boolean {
  const now = Date.now();
  const last = lastTypeAt.get(typeKey) ?? 0;
  if (now - last < minIntervalMs) return true;
  lastTypeAt.set(typeKey, now);
  return false;
}

async function getSilentHours(): Promise<{ start: number; end: number } | null> {
  try {
    const rows = await db.select().from(settingsTable).where(eq(settingsTable.key, "telegram_silent_start"));
    const startStr = rows[0]?.value ?? "";
    const endRows = await db.select().from(settingsTable).where(eq(settingsTable.key, "telegram_silent_end"));
    const endStr = endRows[0]?.value ?? "";
    if (!startStr || !endStr) return null;
    const start = parseInt(startStr, 10);
    const end = parseInt(endStr, 10);
    if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
    return { start, end };
  } catch {
    return null;
  }
}

export async function isSilentNow(): Promise<boolean> {
  const sh = await getSilentHours();
  if (!sh) return false;
  const damascusHour = parseInt(
    new Date().toLocaleString("en-US", { timeZone: "Asia/Damascus", hour: "2-digit", hour12: false }),
    10,
  );
  if (sh.start === sh.end) return false;
  if (sh.start < sh.end) return damascusHour >= sh.start && damascusHour < sh.end;
  // wrap around midnight (e.g. 22 → 7)
  return damascusHour >= sh.start || damascusHour < sh.end;
}

export function enqueueMessage(method: "sendMessage" | "sendPhoto", body: Record<string, unknown>): void {
  if (queue.length >= MAX_QUEUE) {
    queue.shift();
  }
  queue.push({ method, body, enqueuedAt: Date.now(), attempts: 0 });
  totalQueued += 1;
}

export function recordSent(): void { totalSent += 1; }
export function recordFailed(): void { totalFailed += 1; }

type Sender = (method: string, body: Record<string, unknown>) => Promise<any>;

export async function flushQueue(send: Sender): Promise<{ sent: number; remaining: number }> {
  if (!botIsHealthy) return { sent: 0, remaining: queue.length };
  let sent = 0;
  while (queue.length > 0) {
    const item = queue[0];
    try {
      const r = await send(item.method, item.body);
      if (r && r.ok !== false) {
        queue.shift();
        sent += 1;
        totalSent += 1;
      } else {
        item.attempts += 1;
        if (item.attempts >= MAX_ATTEMPTS) {
          queue.shift();
          totalFailed += 1;
        } else {
          break;
        }
      }
    } catch {
      item.attempts += 1;
      if (item.attempts >= MAX_ATTEMPTS) {
        queue.shift();
        totalFailed += 1;
      } else {
        setBotHealth(false, "flush failed");
        break;
      }
    }
  }
  return { sent, remaining: queue.length };
}

export function clearQueue(): number {
  const n = queue.length;
  queue.length = 0;
  return n;
}
