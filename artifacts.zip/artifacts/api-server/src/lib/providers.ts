import { db, settingsTable, providerErrorsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";
import fs from "fs";
import path from "path";

// ─────────────────────────────────────────────────────────────────────────────
//   Single-provider system. Provider name is stored in `provider_name`
//   (default "megagame"). All configuration lives in the `settings` table so
//   the admin can swap providers, change base URLs, tokens, endpoints, and
//   enable/disable from the UI without touching code.
// ─────────────────────────────────────────────────────────────────────────────

export type ProviderName = string;

export const DEFAULT_PROVIDER_NAME = "megagame";

export interface ProviderEndpoints {
  games: string;       // GET list of games
  products: string;    // GET ?game_id=X — list of products for a game
  profile: string;     // GET balance / account info (returns SYP balance)
  newOrder: string;    // POST /newOrder/{product_id} — dispatch a new order
  check: string;       // GET ?orders=[...] — check status of orders
}

const DEFAULT_ENDPOINTS: ProviderEndpoints = {
  games: "/fastapi/products",
  products: "/fastapi/products",
  profile: "/fastapi/balance",
  newOrder: "/fastapi/requestorder",
  check: "/fastapi/checkorders",
};

export interface ProviderConfig {
  name: ProviderName;
  displayName: string;
  baseUrl: string;
  token: string;
  enabled: boolean;
  configured: boolean;
  endpoints: ProviderEndpoints;
}

export interface DispatchResult {
  success: boolean;
  providerOrderId?: string;
  error?: string;
}

export type RemoteOrderStatus = "processing" | "completed" | "failed" | "unknown";

export interface RemoteOrderInfo {
  status: RemoteOrderStatus;
  providerOrderId: string;
  deliveredCode?: string | null;
  raw?: any;
}

export interface BalanceInfo {
  provider: ProviderName;
  displayName: string;
  configured: boolean;
  enabled: boolean;
  balanceSyp: number | null;
  balanceUsd: number | null;
  sypRate: number;
  currency: string;
  email?: string | null;
  error?: string;
  responseMs?: number;
}

export interface HealthInfo {
  ok: boolean;
  status: "green" | "yellow" | "red";
  responseMs: number | null;
  error?: string;
}

// ─── Settings helpers ────────────────────────────────────────────────────────
async function getSettingValue(key: string, def = ""): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  // Use || so an empty string in DB falls back to the default (same as if not set).
  // Only non-empty stored values override the default.
  return row?.value || def;
}

export async function setSettingValue(key: string, value: string): Promise<void> {
  await db.insert(settingsTable)
    .values({ key, value })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
}

export async function getSypRate(): Promise<number> {
  const v = parseFloat(await getSettingValue("syp_rate", "13000"));
  return Number.isFinite(v) && v > 0 ? v : 13000;
}

export async function getProviderConfig(name?: ProviderName): Promise<ProviderConfig> {
  const providerName = (name || (await getSettingValue("provider_name", DEFAULT_PROVIDER_NAME)) || DEFAULT_PROVIDER_NAME).trim();

  // Defaults for the bundled provider (Mega Game / Fast API)
  // NOTE: Mega Game's official base URL uses uppercase "/API/".
  const isMegaGame = providerName === "megagame";
  const defaultBase = isMegaGame ? "https://mega-game.net/api" : "";
  const defaultToken = isMegaGame ? "hd9aq9gai0j1755imsbokgsjj" : "";
  const defaultDisplay = isMegaGame ? "Fast API (Mega Game)" : providerName;

  const baseUrlRaw = (await getSettingValue("provider_base_url", defaultBase)).trim();
  const baseUrl = baseUrlRaw.replace(/\/$/, "");
  const tokenRaw = (await getSettingValue("provider_api_token", defaultToken)).trim();
  const token = tokenRaw || (process.env.PROVIDER_API_TOKEN ?? "").trim();
  const enabled = (await getSettingValue("provider_enabled", "true")).toLowerCase() !== "false";
  const displayName = (await getSettingValue("provider_display_name", defaultDisplay)) || defaultDisplay;

  const endpoints: ProviderEndpoints = {
    games:    await getSettingValue("provider_endpoint_games",    DEFAULT_ENDPOINTS.games),
    products: await getSettingValue("provider_endpoint_products", DEFAULT_ENDPOINTS.products),
    profile:  await getSettingValue("provider_endpoint_profile",  DEFAULT_ENDPOINTS.profile),
    newOrder: await getSettingValue("provider_endpoint_newOrder", DEFAULT_ENDPOINTS.newOrder),
    check:    await getSettingValue("provider_endpoint_check",    DEFAULT_ENDPOINTS.check),
  };

  return {
    name: providerName,
    displayName,
    baseUrl,
    token,
    enabled,
    configured: !!(token && baseUrl),
    endpoints,
  };
}

function authHeaders(token: string): Record<string, string> {
  return {
    "apiToken": token,
    "Accept": "application/json",
    "Content-Type": "application/json",
  };
}

// ─── Response logger (JSON-line file) ────────────────────────────────────────
const LOG_DIR = process.env.PROVIDER_LOG_DIR || path.resolve(process.cwd(), "logs");
const LOG_FILE = path.join(LOG_DIR, "provider-requests.log");
let logDirReady = false;

function ensureLogDir(): void {
  if (logDirReady) return;
  try {
    if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
    logDirReady = true;
  } catch (e) {
    logger.warn({ e }, "Could not create provider log dir");
  }
}

function logResponse(entry: {
  provider: string;
  operation: string;
  method: string;
  url: string;
  status?: number;
  ok: boolean;
  durationMs: number;
  attempt: number;
  error?: string;
}): void {
  ensureLogDir();
  try {
    const line = JSON.stringify({ ts: new Date().toISOString(), ...entry }) + "\n";
    fs.appendFile(LOG_FILE, line, () => {});
  } catch { /* ignore — non-critical */ }
}

async function logProviderError(
  provider: ProviderName, operation: string, message: string, status?: number, context?: any,
) {
  try {
    await db.insert(providerErrorsTable).values({
      provider,
      operation,
      status: status ?? null,
      message: String(message).slice(0, 1000),
      context: context ? JSON.stringify(context).slice(0, 2000) : null,
    });
  } catch (e) {
    logger.warn({ e }, "Failed to persist provider error");
  }
}

// ─── In-memory token-bucket rate limiter ─────────────────────────────────────
//   Caps requests at ~RATE_LIMIT_RPS sustained, with a small burst capacity.
const RATE_LIMIT_RPS = parseFloat(process.env.PROVIDER_RATE_LIMIT_RPS ?? "8");
const BUCKET_CAPACITY = Math.max(4, RATE_LIMIT_RPS * 2);
let tokens = BUCKET_CAPACITY;
let lastRefill = Date.now();

async function rateLimitWait(): Promise<void> {
  while (true) {
    const now = Date.now();
    const elapsed = (now - lastRefill) / 1000;
    if (elapsed > 0) {
      tokens = Math.min(BUCKET_CAPACITY, tokens + elapsed * RATE_LIMIT_RPS);
      lastRefill = now;
    }
    if (tokens >= 1) {
      tokens -= 1;
      return;
    }
    const need = 1 - tokens;
    const waitMs = Math.ceil((need / RATE_LIMIT_RPS) * 1000);
    await new Promise(r => setTimeout(r, Math.max(20, waitMs)));
  }
}

// ─── Core fetch wrapper: rate-limit + 3 retries + exp backoff + timeout ──────
const DEFAULT_TIMEOUT_MS = 15000;
const MAX_ATTEMPTS = 3;

export interface ProviderFetchOptions {
  method?: "GET" | "POST";
  body?: any;
  timeoutMs?: number;
  operation: string;
  provider: string;
  context?: any;
}

export interface ProviderFetchResult<T = any> {
  ok: boolean;
  status: number;
  data: T | null;
  text?: string;
  error?: string;
  responseMs: number;
  attempts: number;
}

export async function providerFetch<T = any>(
  url: string,
  token: string,
  opts: ProviderFetchOptions,
): Promise<ProviderFetchResult<T>> {
  const { method = "GET", body, timeoutMs = DEFAULT_TIMEOUT_MS, operation, provider, context } = opts;
  const headers = authHeaders(token);
  let lastError: string | undefined;
  let lastStatus = 0;
  let lastText = "";
  let attempt = 0;
  const t0 = Date.now();

  for (attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    await rateLimitWait();
    const reqStart = Date.now();
    try {
      const init: RequestInit = {
        method,
        headers,
        signal: AbortSignal.timeout(timeoutMs),
      };
      if (body !== undefined && method !== "GET") {
        init.body = typeof body === "string" ? body : JSON.stringify(body);
      }
      const response = await fetch(url, init);
      const dur = Date.now() - reqStart;
      lastStatus = response.status;

      logResponse({
        provider, operation, method, url, status: response.status, ok: response.ok,
        durationMs: dur, attempt,
      });

      if (response.ok) {
        let data: any = null;
        try { data = await response.json(); }
        catch { data = null; }
        return {
          ok: true,
          status: response.status,
          data,
          responseMs: Date.now() - t0,
          attempts: attempt,
        };
      }

      lastText = await response.text().catch(() => "");
      lastError = `HTTP ${response.status}: ${lastText.slice(0, 200)}`;

      // 4xx (auth, not found, bad input) → don't retry, hand back to caller
      if (response.status >= 400 && response.status < 500) break;
    } catch (err: any) {
      const dur = Date.now() - reqStart;
      lastError = err?.message ?? String(err);
      logResponse({
        provider, operation, method, url, ok: false,
        durationMs: dur, attempt, error: lastError,
      });
    }

    // exponential backoff: 500ms, 1000ms (only between attempts)
    if (attempt < MAX_ATTEMPTS) {
      await new Promise(r => setTimeout(r, 500 * attempt));
    }
  }

  await logProviderError(provider, operation, lastError ?? "Unknown error", lastStatus || undefined, context);

  // Send outage alert to Telegram (cooldown 15min per provider+operation key)
  const isServerError = lastStatus === 0 || lastStatus >= 500;
  if (isServerError) maybeNotifyOutage(provider, operation, lastError ?? `HTTP ${lastStatus}`);

  return {
    ok: false,
    status: lastStatus,
    data: null,
    text: lastText,
    error: lastError,
    responseMs: Date.now() - t0,
    attempts: attempt - 1,
  };
}

const _outageAlertedAt = new Map<string, number>();
const OUTAGE_COOLDOWN_MS = 15 * 60 * 1000;
function maybeNotifyOutage(provider: string, operation: string, error: string): void {
  const key = `${provider}:${operation}`;
  const last = _outageAlertedAt.get(key) ?? 0;
  const now = Date.now();
  if (now - last < OUTAGE_COOLDOWN_MS) return;
  _outageAlertedAt.set(key, now);
  // Dynamic import to avoid circular dependency telegram <-> providers
  import("./telegram").then(({ notifyApiOutage }) => {
    notifyApiOutage({ provider, operation, error }).catch(() => {});
  }).catch(() => {});
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function dispatchOrder(
  provider: ProviderName,
  product: { providerProductId: string | null },
  order: { id: string; qty: number; playerId?: string | null; fieldValues?: Record<string, string> | null },
): Promise<DispatchResult> {
  const cfg = await getProviderConfig(provider);
  if (!cfg.configured) return { success: false, error: `${cfg.displayName} is not configured` };
  if (!cfg.enabled)    return { success: false, error: `${cfg.displayName} is disabled by admin` };
  if (!product.providerProductId) return { success: false, error: "Missing providerProductId" };

  // Fast API uses GET: /fastapi/requestorder/{product_id}/params?qty=X&field=val&uuid=order_id
  const params = new URLSearchParams();
  params.set("qty", String(order.qty));
  params.set("uuid", order.id); // idempotency key
  if (order.playerId) params.set("playerId", order.playerId);
  if (order.fieldValues && typeof order.fieldValues === "object") {
    for (const [k, v] of Object.entries(order.fieldValues)) {
      if (k && v != null) params.set(k, String(v));
    }
  }
  const url = `${cfg.baseUrl}${cfg.endpoints.newOrder}/${encodeURIComponent(product.providerProductId)}/params?${params.toString()}`;

  const result = await providerFetch(url, cfg.token, {
    method: "GET",
    operation: "dispatchOrder",
    provider: cfg.name,
    context: { orderId: order.id, productId: product.providerProductId },
  });

  if (!result.ok) {
    return { success: false, error: result.error ?? `Provider returned ${result.status}` };
  }
  const data: any = result.data ?? {};
  const inner = data?.data ?? data;

  // Mega Game responses use `err` as the canonical success flag:
  //   err === 0  → accepted
  //   err !== 0  → rejected (with `message` describing why)
  const errCode = data?.err ?? inner?.err;
  if (errCode !== undefined && errCode !== null && Number(errCode) !== 0) {
    const errMsg = String(data?.message ?? inner?.message ?? data?.error ?? `err=${errCode}`).slice(0, 300);
    return { success: false, error: errMsg };
  }

  // Use the upstream order id when present; otherwise fall back to our UUID
  // (Mega Game accepts /check?orders=[…]&uuid=1 lookups by our UUID).
  const providerOrderId = String(
    inner?.order_id ?? inner?.id ?? data?.order_id ?? data?.id ?? order.id,
  );
  return { success: true, providerOrderId };
}

// Numeric-status mapping (Fast API / Mega Game):
//   0 → جاري المعالجة (queued)
//   1 → جاري التنفيذ  (executing)
//   2 → مقبول         (accepted / completed)
//   3 → مرفوض         (rejected / failed)
function normalizeRemoteStatus(raw: string | number | undefined | null): RemoteOrderStatus {
  if (raw === undefined || raw === null || raw === "") return "unknown";
  // Numeric (Fast API)
  if (typeof raw === "number" || /^\d+$/.test(String(raw))) {
    const n = Number(raw);
    if (n === 0 || n === 1) return "processing";
    if (n === 2) return "completed";
    if (n === 3) return "failed";
    return "unknown";
  }
  const s = String(raw).toLowerCase();
  if (["accept", "accepted", "completed", "complete", "success", "done", "delivered"].includes(s)) return "completed";
  if (["reject", "rejected", "failed", "fail", "cancel", "cancelled", "canceled", "error"].includes(s)) return "failed";
  if (["processing", "pending", "in_progress", "inprogress", "queue", "queued", "wait", "waiting", "executing"].includes(s)) return "processing";
  return "unknown";
}

// ─── Batch status check — Fast API supports /check?orders=[id1,id2,...] ──────
// Returns a map keyed by the input ID (UUID or providerOrderId). Items not
// found in the response default to { status: "unknown" }.
export async function checkOrdersBatch(
  provider: ProviderName,
  ids: string[],
  isUuid = false,
): Promise<Record<string, RemoteOrderInfo>> {
  const out: Record<string, RemoteOrderInfo> = {};
  if (ids.length === 0) return out;
  const cfg = await getProviderConfig(provider);
  if (!cfg.configured || !cfg.enabled) {
    for (const id of ids) out[id] = { status: "unknown", providerOrderId: id };
    return out;
  }
  // Fast API caps practical batch size; chunk into groups of 50.
  const CHUNK = 50;
  for (let i = 0; i < ids.length; i += CHUNK) {
    const chunk = ids.slice(i, i + CHUNK);
    // Fast API: ?order_ids=123,456,789  (comma-separated numeric IDs)
    const url = `${cfg.baseUrl}${cfg.endpoints.check}?order_ids=${chunk.join(",")}`;
    const result = await providerFetch(url, cfg.token, {
      operation: "checkOrdersBatch",
      provider: cfg.name,
      timeoutMs: 15000,
      context: { count: chunk.length },
    });
    if (!result.ok) {
      for (const id of chunk) out[id] = { status: "unknown", providerOrderId: id };
      continue;
    }
    const json: any = result.data ?? {};
    const arr: any[] = Array.isArray(json?.data) ? json.data
      : Array.isArray(json?.orders) ? json.orders
      : Array.isArray(json) ? json
      : [];
    for (const id of chunk) {
      const item = arr.find((x: any) =>
        String(x?.uuid ?? x?.order_uuid ?? x?.order_id ?? x?.id ?? "") === id,
      );
      if (!item) { out[id] = { status: "unknown", providerOrderId: id }; continue; }
      const replay = item.replay_api ?? item.replyApi ?? item.replay ?? item.delivered_code;
      const deliveredCode = Array.isArray(replay)
        ? replay.filter(Boolean).join("\n")
        : (typeof replay === "string" ? replay : null);
      out[id] = {
        status: normalizeRemoteStatus(item.status ?? item.order_status),
        providerOrderId: id,
        deliveredCode: deliveredCode || null,
        raw: item,
      };
    }
  }
  return out;
}

export async function checkOrderStatus(
  provider: ProviderName,
  providerOrderId: string,
  isUuid = false,
): Promise<RemoteOrderInfo> {
  const cfg = await getProviderConfig(provider);
  if (!cfg.configured || !cfg.enabled) return { status: "unknown", providerOrderId };

  // Fast API: ?order_ids=123 (single numeric ID)
  const url = `${cfg.baseUrl}${cfg.endpoints.check}?order_ids=${encodeURIComponent(providerOrderId)}`;

  const result = await providerFetch(url, cfg.token, {
    operation: "checkOrderStatus",
    provider: cfg.name,
    timeoutMs: 10000,
    context: { providerOrderId },
  });
  if (!result.ok) return { status: "unknown", providerOrderId };

  const json: any = result.data ?? {};
  const arr = json?.data ?? json?.orders ?? json;
  const first = Array.isArray(arr) ? arr[0] : arr;
  if (!first) return { status: "unknown", providerOrderId };

  const replay = first.replay_api ?? first.replyApi ?? first.replay ?? first.delivered_code;
  const deliveredCode = Array.isArray(replay)
    ? replay.filter(Boolean).join("\n")
    : (typeof replay === "string" ? replay : null);

  return {
    status: normalizeRemoteStatus(first.status ?? first.order_status),
    providerOrderId,
    deliveredCode: deliveredCode || null,
    raw: first,
  };
}

// ─── Balance (always SYP from provider; we convert to USD for display) ───────
export async function fetchBalance(provider?: ProviderName): Promise<BalanceInfo> {
  const cfg = await getProviderConfig(provider);
  const sypRate = await getSypRate();

  if (!cfg.configured) {
    return {
      provider: cfg.name, displayName: cfg.displayName, configured: false, enabled: cfg.enabled,
      balanceSyp: null, balanceUsd: null, sypRate, currency: "SYP",
    };
  }

  // Try the configured profile endpoint first, then a few legacy fallbacks
  const candidates = Array.from(new Set([
    cfg.endpoints.profile, "/fastapi/balance", "/balance", "/profile", "/account",
  ]));

  let lastErr: string | undefined;
  let lastResponseMs = 0;
  for (const ep of candidates) {
    const url = `${cfg.baseUrl}${ep}`;
    const result = await providerFetch(url, cfg.token, {
      operation: "fetchBalance",
      provider: cfg.name,
      timeoutMs: 8000,
      context: { endpoint: ep },
    });
    lastResponseMs = result.responseMs;
    if (!result.ok) { lastErr = result.error; continue; }
    const json: any = result.data ?? {};
    const src = json?.data ?? json;
    const value = src?.balance ?? src?.wallet ?? src?.credit ?? src?.amount ?? src?.money ?? src?.points;
    if (value === undefined || value === null) { lastErr = "Provider did not return a balance"; continue; }
    const balanceSyp = Number(value);
    if (!Number.isFinite(balanceSyp)) { lastErr = "Balance is not a number"; continue; }
    const balanceUsd = sypRate > 0 ? +(balanceSyp / sypRate).toFixed(4) : null;
    return {
      provider: cfg.name,
      displayName: cfg.displayName,
      configured: true,
      enabled: cfg.enabled,
      balanceSyp,
      balanceUsd,
      sypRate,
      currency: "SYP",
      email: src?.email ?? null,
      responseMs: result.responseMs,
    };
  }

  return {
    provider: cfg.name, displayName: cfg.displayName, configured: true, enabled: cfg.enabled,
    balanceSyp: null, balanceUsd: null, sypRate, currency: "SYP",
    error: lastErr ?? "Provider did not return a balance",
    responseMs: lastResponseMs,
  };
}

// Backward-compat helper used by existing code (system route, telegram).
export async function fetchAllBalances(): Promise<BalanceInfo[]> {
  return [await fetchBalance()];
}

// ─── Health classification: 🟢 < 500ms · 🟡 < 2000ms · 🔴 otherwise ─────────
export function classifyHealth(responseMs: number | null, ok: boolean): HealthInfo["status"] {
  if (!ok || responseMs == null) return "red";
  if (responseMs < 500) return "green";
  if (responseMs < 2000) return "yellow";
  return "red";
}

export async function testConnection(provider?: ProviderName): Promise<HealthInfo & { displayName: string; configured: boolean; enabled: boolean }> {
  const cfg = await getProviderConfig(provider);
  if (!cfg.configured) {
    return { ok: false, status: "red", responseMs: null, error: "Provider is not configured", displayName: cfg.displayName, configured: false, enabled: cfg.enabled };
  }

  // Hit the lightweight /games endpoint (publicly served by Mega Game) to
  // measure round-trip time without needing a write.
  const url = `${cfg.baseUrl}${cfg.endpoints.games}`;
  const result = await providerFetch(url, cfg.token, {
    operation: "testConnection",
    provider: cfg.name,
    timeoutMs: 8000,
  });
  return {
    ok: result.ok,
    status: classifyHealth(result.responseMs, result.ok),
    responseMs: result.responseMs,
    error: result.ok ? undefined : (result.error ?? `HTTP ${result.status}`),
    displayName: cfg.displayName,
    configured: cfg.configured,
    enabled: cfg.enabled,
  };
}
