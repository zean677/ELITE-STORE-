import { WebSocketServer, WebSocket } from "ws";
import { IncomingMessage } from "http";
import { Server } from "http";
import { verifyToken } from "./auth";

export type WsEventType =
  | "new_order"
  | "order_completed"
  | "order_failed"
  | "order_processing"
  | "new_user"
  | "new_payment"
  | "payment_approved"
  | "stats_update"
  | "ping";

export interface WsEvent {
  type: WsEventType;
  data: Record<string, unknown>;
  ts: number;
}

interface AdminClient {
  ws: WebSocket;
  adminId: number;
  connectedAt: number;
}

const clients = new Map<WebSocket, AdminClient>();

let wss: WebSocketServer | null = null;

export function initWebSocketServer(server: Server): WebSocketServer {
  // Mount under /api/ws so frontend's existing /api proxy forwards WS upgrades correctly.
  // Also accept legacy /ws connections for backward compatibility.
  wss = new WebSocketServer({ noServer: true });
  server.on("upgrade", (req, socket, head) => {
    const url = req.url ?? "";
    if (url.startsWith("/api/ws") || url.startsWith("/ws")) {
      wss!.handleUpgrade(req, socket, head, (ws) => {
        wss!.emit("connection", ws, req);
      });
    }
  });

  wss.on("connection", (ws: WebSocket, req: IncomingMessage) => {
    const url = new URL(req.url ?? "/", "http://localhost");
    const token = url.searchParams.get("token") ?? "";

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      ws.close(4401, "Unauthorized");
      return;
    }

    const client: AdminClient = { ws, adminId: payload.userId, connectedAt: Date.now() };
    clients.set(ws, client);

    ws.send(JSON.stringify({ type: "connected", data: { adminId: payload.userId, message: "Elite Store WS Ready ✅" }, ts: Date.now() }));

    ws.on("message", (msg) => {
      try {
        const parsed = JSON.parse(msg.toString());
        if (parsed.type === "ping") {
          ws.send(JSON.stringify({ type: "pong", data: {}, ts: Date.now() }));
        }
      } catch { /* ignore */ }
    });

    ws.on("close", () => {
      clients.delete(ws);
    });

    ws.on("error", () => {
      clients.delete(ws);
    });
  });

  setInterval(() => {
    for (const [ws, _client] of clients) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
      } else {
        clients.delete(ws);
      }
    }
  }, 30000);

  return wss;
}

export function broadcastToAdmins(event: WsEvent): void {
  if (!wss) return;
  const payload = JSON.stringify(event);
  for (const [ws] of clients) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

export function emitNewOrder(order: {
  id: string;
  orderNumber?: number;
  productName: string;
  username: string;
  totalPrice: string | number;
  status: string;
}): void {
  broadcastToAdmins({
    type: "new_order",
    data: {
      id: order.id,
      orderNumber: order.orderNumber,
      productName: order.productName,
      username: order.username,
      totalPrice: parseFloat(String(order.totalPrice)),
      status: order.status,
    },
    ts: Date.now(),
  });
}

export function emitOrderUpdate(orderId: string, status: "completed" | "failed" | "processing", productName: string, username: string, totalPrice: string | number): void {
  const type = status === "completed" ? "order_completed" : status === "failed" ? "order_failed" : "order_processing";
  broadcastToAdmins({
    type,
    data: { orderId, status, productName, username, totalPrice: parseFloat(String(totalPrice)) },
    ts: Date.now(),
  });
}

export function emitNewUser(user: { id: number; username: string; email: string }): void {
  broadcastToAdmins({
    type: "new_user",
    data: { id: user.id, username: user.username, email: user.email },
    ts: Date.now(),
  });
}

export function emitNewPayment(payment: {
  id: number;
  username: string;
  amount: string | number;
  currency: string;
  method: string;
}): void {
  broadcastToAdmins({
    type: "new_payment",
    data: {
      id: payment.id,
      username: payment.username,
      amount: parseFloat(String(payment.amount)),
      currency: payment.currency,
      method: payment.method,
    },
    ts: Date.now(),
  });
}

export function emitPaymentApproved(payment: {
  id: number;
  username: string;
  amount: string | number;
  currency: string;
}): void {
  broadcastToAdmins({
    type: "payment_approved",
    data: {
      id: payment.id,
      username: payment.username,
      amount: parseFloat(String(payment.amount)),
      currency: payment.currency,
    },
    ts: Date.now(),
  });
}

export function getConnectedAdminCount(): number {
  return clients.size;
}
