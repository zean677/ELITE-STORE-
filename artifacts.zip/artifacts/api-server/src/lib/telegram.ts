import { db, ordersTable, productsTable, settingsTable, usersTable, paymentsTable, providerErrorsTable } from "@workspace/db";
import { desc, eq, sql, count, sum, ilike, or, gte, and } from "drizzle-orm";
import { fetchBalance } from "./providers";
import {
  isDuplicate, enqueueMessage, recordSent, recordFailed,
  setBotHealth, isSilentNow, getBotHealth,
} from "./telegram-queue";

// Permanent owner — works even if env var is not set
const OWNER_FALLBACK_CHAT_ID = "2113043286";

function getBotToken(): string { return (process.env.TELEGRAM_BOT_TOKEN ?? "").trim(); }
function getAdminChatId(): string {
  const env = (process.env.TELEGRAM_ADMIN_CHAT_ID ?? "").trim();
  return env || OWNER_FALLBACK_CHAT_ID;
}
function getExtraAllowedChatIds(): string[] {
  // Allow any of these to control the bot, in addition to the primary admin chat
  const list = new Set<string>();
  list.add(OWNER_FALLBACK_CHAT_ID);
  const env = (process.env.TELEGRAM_ADMIN_CHAT_ID ?? "").trim();
  if (env) list.add(env);
  const extra = (process.env.TELEGRAM_EXTRA_ADMIN_IDS ?? "").trim();
  if (extra) extra.split(",").map(s => s.trim()).filter(Boolean).forEach(id => list.add(id));
  return Array.from(list);
}
function getAdminUrl(): string {
  // Use REPLIT_DOMAINS first — always matches current env (dev or prod)
  const replitDomains = (process.env.REPLIT_DOMAINS ?? "").trim();
  if (replitDomains) {
    const primary = replitDomains.split(",")[0].trim();
    if (primary) return `https://${primary}`;
  }
  const siteUrl = (process.env.SITE_URL ?? "").trim().replace(/\/$/, "");
  if (siteUrl) return siteUrl;
  return "https://elite-store.com";
}

if (!getBotToken()) {
  console.warn("[Telegram] ⚠️  TELEGRAM_BOT_TOKEN not set — bot notifications disabled");
}
if (!getAdminChatId()) {
  console.warn("[Telegram] ⚠️  TELEGRAM_ADMIN_CHAT_ID not set — admin messages disabled");
}

type InlineButton = { text: string; url?: string; callback_data?: string };
type InlineKeyboard = InlineButton[][];
type ReplyKeyboard = { keyboard: { text: string }[][]; resize_keyboard?: boolean; is_persistent?: boolean };
type TelegramMessage = { message_id?: number; chat?: { id?: number | string }; text?: string };
type TelegramCallback = { id: string; data?: string; message?: TelegramMessage; from?: { id?: number | string } };
type TelegramUpdate = { message?: TelegramMessage; callback_query?: TelegramCallback };

// Persistent bottom reply keyboard — always visible
const PERSISTENT_KEYBOARD: ReplyKeyboard = {
  keyboard: [
    [{ text: "📊 الإحصائيات" }, { text: "🛒 الطلبات" }],
    [{ text: "📦 المنتجات" }, { text: "👥 المستخدمون" }],
    [{ text: "📈 التقارير" }, { text: "⚙️ الإعدادات" }],
  ],
  resize_keyboard: true,
  is_persistent: true,
};

function escapeHtml(value: unknown): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function keyboardMarkup(keyboard?: InlineKeyboard) {
  if (!keyboard || keyboard.length === 0) return undefined;
  return {
    inline_keyboard: keyboard.map(row => row.map(btn => {
      const payload: Record<string, string> = { text: btn.text };
      if (btn.url) payload.url = btn.url;
      if (btn.callback_data) payload.callback_data = btn.callback_data;
      return payload;
    })),
  };
}

// Raw request — no queueing/dedup. Used by health monitor and queue flusher.
export async function telegramRequestRaw(method: string, body: Record<string, unknown>): Promise<any> {
  const BOT_TOKEN = getBotToken();
  if (!BOT_TOKEN) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) {
      const err = await res.text().catch(() => "");
      // permanent — drop, don't retry/queue
      if (err.includes("bot was blocked") || err.includes("chat not found")) {
        recordFailed();
        return { ok: false, permanent: true, error: err.slice(0, 120) };
      }
      console.warn(`[Telegram] ${method} failed:`, res.status, err.slice(0, 120));
      return { ok: false, error: `HTTP ${res.status}` };
    }
    const json = await res.json().catch(() => null);
    setBotHealth(true);
    recordSent();
    return json ?? { ok: true };
  } catch (e: any) {
    const msg = e?.message?.slice(0, 200) ?? "network error";
    console.warn("[Telegram] network error:", msg);
    setBotHealth(false, msg);
    return { ok: false, error: msg };
  }
}

async function telegramRequest(method: string, body: Record<string, unknown>): Promise<any> {
  const BOT_TOKEN = getBotToken();
  if (!BOT_TOKEN) return null;

  // Anti-spam dedup (skip identical messages in 60s window)
  if ((method === "sendMessage" || method === "sendPhoto") && isDuplicate(method, body)) {
    return { ok: true, deduped: true };
  }

  // Silent hours: send with disabled notification sound
  if (method === "sendMessage" || method === "sendPhoto") {
    const silent = await isSilentNow().catch(() => false);
    if (silent && body.disable_notification === undefined) {
      body.disable_notification = true;
    }
  }

  // If bot known to be unhealthy, queue immediately
  if (!getBotHealth().healthy && (method === "sendMessage" || method === "sendPhoto")) {
    enqueueMessage(method as "sendMessage" | "sendPhoto", body);
    return { ok: true, queued: true };
  }

  const result = await telegramRequestRaw(method, body);

  // Network or transient failure → queue for later (but only for messages, not for callback acks)
  if (result?.ok === false && !result.permanent && (method === "sendMessage" || method === "sendPhoto")) {
    enqueueMessage(method as "sendMessage" | "sendPhoto", body);
    return { ok: true, queued: true };
  }
  return result;
}

async function sendMessage(chatId: string, text: string, keyboard?: InlineKeyboard, replyKeyboard?: ReplyKeyboard): Promise<void> {
  if (!getBotToken() || !chatId) return;
  let reply_markup: any = undefined;
  if (replyKeyboard) reply_markup = replyKeyboard;
  else if (keyboardMarkup(keyboard)) reply_markup = keyboardMarkup(keyboard);
  await telegramRequest("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...(reply_markup ? { reply_markup } : {}),
  });
}

async function sendPhoto(chatId: string, photoUrl: string, caption: string, keyboard?: InlineKeyboard): Promise<boolean> {
  if (!getBotToken() || !chatId) return false;
  const result = await telegramRequest("sendPhoto", {
    chat_id: chatId,
    photo: photoUrl,
    caption,
    parse_mode: "HTML",
    ...(keyboardMarkup(keyboard) ? { reply_markup: keyboardMarkup(keyboard) } : {}),
  });
  return !!result?.ok;
}

async function editMessage(chatId: string, messageId: number, text: string, keyboard?: InlineKeyboard): Promise<void> {
  await telegramRequest("editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...(keyboardMarkup(keyboard) ? { reply_markup: keyboardMarkup(keyboard) } : {}),
  });
}

async function answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void> {
  await telegramRequest("answerCallbackQuery", {
    callback_query_id: callbackQueryId,
    ...(text ? { text } : {}),
  });
}

function backButton(): InlineButton {
  return { text: "🔙 القائمة الرئيسية", callback_data: "menu:main" };
}

function adminKeyboard(): InlineKeyboard {
  // Main menu — categorized
  return [
    [
      { text: "📊 الإحصائيات", callback_data: "menu:stats" },
      { text: "📈 التقارير", callback_data: "menu:reports" },
    ],
    [
      { text: "🛒 الطلبات", callback_data: "menu:orders" },
      { text: "📦 المنتجات", callback_data: "menu:products" },
    ],
    [
      { text: "👥 المستخدمون", callback_data: "menu:users" },
      { text: "💰 الأرصدة", callback_data: "balance" },
    ],
    [
      { text: "⚙️ الإعدادات السريعة", callback_data: "menu:settings" },
      { text: "🔄 مزامنة فورية", callback_data: "sync:now" },
    ],
    [
      { text: "🏠 فتح لوحة الأدمن", url: `${getAdminUrl()}/admin` },
    ],
  ];
}

function reportsMenu(): InlineKeyboard {
  return [
    [
      { text: "📅 اليوم", callback_data: "report:today" },
      { text: "📆 آخر 7 أيام", callback_data: "report:week" },
    ],
    [
      { text: "🗓️ آخر 30 يوم", callback_data: "report:month" },
      { text: "📊 إحصائيات شاملة", callback_data: "menu:stats" },
    ],
    [backButton()],
  ];
}

function ordersMenu(): InlineKeyboard {
  const url = getAdminUrl();
  return [
    [
      { text: "🧾 آخر الطلبات", callback_data: "orders:page:0" },
      { text: "⏳ المعلّقة", callback_data: "orders:pending" },
    ],
    [
      { text: "❌ الفاشلة (24س)", callback_data: "orders:failed" },
      { text: "✅ المكتملة (اليوم)", callback_data: "orders:completed" },
    ],
    [
      { text: "📋 فتح في اللوحة", url: `${url}/admin/orders` },
    ],
    [backButton()],
  ];
}

function productsMenu(): InlineKeyboard {
  const url = getAdminUrl();
  return [
    [
      { text: "📦 آخر المنتجات", callback_data: "products:list" },
      { text: "🔄 مزامنة فورية", callback_data: "sync:now" },
    ],
    [
      { text: "🏪 إدارة المنتجات", url: `${url}/admin/products` },
      { text: "📜 سجل الأسعار", url: `${url}/admin/products/history` },
    ],
    [backButton()],
  ];
}

function usersMenu(): InlineKeyboard {
  const url = getAdminUrl();
  return [
    [
      { text: "👥 آخر المسجّلين", callback_data: "users:page:0" },
    ],
    [
      { text: "📋 فتح في اللوحة", url: `${url}/admin/users` },
    ],
    [backButton()],
  ];
}

function settingsMenu(currentMarkup: string): InlineKeyboard {
  return [
    [
      { text: `🎯 هامش الربح الحالي: ${currentMarkup}%`, callback_data: "noop" },
    ],
    [
      { text: "➖ -5%", callback_data: "markup:-5" },
      { text: "➖ -1%", callback_data: "markup:-1" },
      { text: "➕ +1%", callback_data: "markup:+1" },
      { text: "➕ +5%", callback_data: "markup:+5" },
    ],
    [
      { text: "🔄 مزامنة المنتجات", callback_data: "sync:now" },
      { text: "💰 فحص الأرصدة", callback_data: "balance" },
    ],
    [
      { text: "🌐 حالة النظام", url: `${getAdminUrl()}/admin/system` },
      { text: "⚙️ كل الإعدادات", url: `${getAdminUrl()}/admin/settings` },
    ],
    [backButton()],
  ];
}

function orderActionKeyboard(orderId: string, status: string): InlineKeyboard {
  const url = getAdminUrl();
  const rows: InlineKeyboard = [];
  if (status === "pending" || status === "processing") {
    rows.push([
      { text: "✅ اعتماد", callback_data: `order:approve:${orderId}` },
      { text: "🚫 رفض واسترجاع", callback_data: `order:reject:${orderId}` },
    ]);
  }
  if (status === "failed") {
    rows.push([
      { text: "🔁 إعادة محاولة", callback_data: `order:retry:${orderId}` },
    ]);
  }
  rows.push([
    { text: "🔍 فتح الطلب في اللوحة", url: `${url}/admin/orders` },
  ]);
  rows.push([
    { text: "🔙 قائمة الطلبات", callback_data: "menu:orders" },
  ]);
  return rows;
}

function adminHelp(): string {
  const url = getAdminUrl();
  return `🛡️ <b>Elite Store — لوحة الإدارة</b>\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `📊 <b>التقارير والإحصائيات</b>\n` +
    `• /stats — إحصائيات شاملة\n` +
    `• /today — تقرير اليوم الحالي\n` +
    `• /balance — رصيد المورّد\n\n` +
    `🛒 <b>إدارة الطلبات</b>\n` +
    `• /orders — آخر 10 طلبات\n` +
    `• /order ORDER_ID — تفاصيل طلب بالـ ID\n\n` +
    `👥 <b>إدارة المستخدمين</b>\n` +
    `• /users — آخر 10 مستخدمين\n` +
    `• /user EMAIL — بحث عن مستخدم\n\n` +
    `📦 <b>إدارة المنتجات</b>\n` +
    `• /find كلمة — بحث عن منتج\n` +
    `• /product ID — تفاصيل منتج\n` +
    `• /price ID 1.25 — تعديل السعر\n` +
    `• /toggle ID — تفعيل / إيقاف\n` +
    `• /markup 12 — هامش الربح العام %\n` +
    `• /pricesync 1.05 — ضرب جميع الأسعار بمعامل (مثلاً ‎+5%‎)\n\n` +
    `📈 <b>تقارير متقدمة</b>\n` +
    `• /report today — تقرير اليوم\n` +
    `• /report week — تقرير 7 أيام + رسم بياني\n` +
    `• /report month — تقرير 30 يوم + رسم بياني\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🔗 <a href="${url}/admin">فتح لوحة التحكم</a>`;
}

function parseChatId(update: TelegramUpdate): string | null {
  const id = update.message?.chat?.id ?? update.callback_query?.message?.chat?.id ?? update.callback_query?.from?.id;
  return id === undefined || id === null ? null : String(id);
}

function isAdminChat(chatId: string | null): boolean {
  if (!chatId) return false;
  return getExtraAllowedChatIds().includes(chatId);
}

async function getSetting(key: string, fallback = ""): Promise<string> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  return row?.value ?? fallback;
}

async function setSetting(key: string, value: string): Promise<void> {
  await db.insert(settingsTable).values({ key, value }).onConflictDoUpdate({ target: settingsTable.key, set: { value } });
}

async function renderStats(): Promise<string> {
  const [ordersTotal] = await db.select({ count: count() }).from(ordersTable);
  const [usersTotal] = await db.select({ count: count() }).from(usersTable).where(eq(usersTable.role, "user"));
  const [activeProducts] = await db.select({ count: count() }).from(productsTable).where(eq(productsTable.status, "active"));
  const [disabledProducts] = await db.select({ count: count() }).from(productsTable).where(eq(productsTable.status, "inactive"));
  const [completedOrders] = await db.select({ count: count(), total: sum(ordersTable.totalPrice) }).from(ordersTable).where(eq(ordersTable.status, "completed"));
  const [processingOrders] = await db.select({ count: count() }).from(ordersTable).where(eq(ordersTable.status, "processing"));
  const [failedOrders] = await db.select({ count: count() }).from(ordersTable).where(eq(ordersTable.status, "failed"));
  const markup = await getSetting("default_profit_margin", "10");

  return `📊 <b>إحصائيات Elite Store</b>\n\n` +
    `🧾 الطلبات: <b>${ordersTotal?.count ?? 0}</b>\n` +
    `✅ مكتملة: <b>${completedOrders?.count ?? 0}</b>\n` +
    `⏳ قيد المعالجة: <b>${processingOrders?.count ?? 0}</b>\n` +
    `❌ فاشلة: <b>${failedOrders?.count ?? 0}</b>\n` +
    `💵 الإيراد المكتمل: <b>${Number(completedOrders?.total ?? 0).toFixed(2)} USD</b>\n` +
    `👥 المستخدمون: <b>${usersTotal?.count ?? 0}</b>\n` +
    `📦 المنتجات الفعالة: <b>${activeProducts?.count ?? 0}</b>\n` +
    `🚫 المنتجات الموقوفة: <b>${disabledProducts?.count ?? 0}</b>\n` +
    `📈 هامش الربح العام: <b>${escapeHtml(markup)}%</b>`;
}

async function renderRecentOrders(): Promise<string> {
  const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(10);
  if (orders.length === 0) return "🧾 لا توجد طلبات حتى الآن.";

  return `🧾 <b>آخر الطلبات</b>\n\n` + orders.map(order => {
    const statusIcon = order.status === "completed" ? "✅" : order.status === "failed" ? "❌" : "⏳";
    return `${statusIcon} <code>${escapeHtml(order.id.slice(0, 8))}</code> — <b>${escapeHtml(order.productName)}</b>\n` +
      `   الكمية: ${order.qty} | السعر: ${Number(order.totalPrice ?? 0).toFixed(2)} ${escapeHtml(order.currency)} | الحالة: ${escapeHtml(order.status)}`;
  }).join("\n\n");
}

const ORDERS_PAGE_SIZE = 8;

async function renderOrdersPage(page: number): Promise<{ text: string; keyboard: InlineKeyboard }> {
  const offset = Math.max(0, page) * ORDERS_PAGE_SIZE;
  const [{ c: total }] = await db.select({ c: count() }).from(ordersTable);
  const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(ORDERS_PAGE_SIZE).offset(offset);
  const totalPages = Math.max(1, Math.ceil((total ?? 0) / ORDERS_PAGE_SIZE));

  const body = orders.length === 0
    ? "🧾 لا توجد طلبات في هذه الصفحة."
    : orders.map(o => {
        const i = o.status === "completed" ? "✅" : o.status === "failed" ? "❌" : "⏳";
        return `${i} <code>${escapeHtml(o.id.slice(0, 8))}</code> · <b>${escapeHtml(o.productName.slice(0, 30))}</b>\n` +
          `   ${Number(o.totalPrice ?? 0).toFixed(2)} ${escapeHtml(o.currency)} · /order_${o.id.slice(0, 8)}`;
      }).join("\n\n");

  const text = `🛒 <b>الطلبات</b> · صفحة ${page + 1}/${totalPages}\n\n${body}`;

  const navRow: InlineButton[] = [];
  if (page > 0) navRow.push({ text: "⬅️ السابق", callback_data: `orders:page:${page - 1}` });
  navRow.push({ text: `📄 ${page + 1}/${totalPages}`, callback_data: "noop" });
  if (page + 1 < totalPages) navRow.push({ text: "التالي ➡️", callback_data: `orders:page:${page + 1}` });

  return {
    text,
    keyboard: [navRow, [{ text: "🔙 قائمة الطلبات", callback_data: "menu:orders" }]],
  };
}

async function renderOrdersByStatus(status: "pending" | "failed" | "completed", windowHours = 24): Promise<string> {
  const since = new Date(Date.now() - windowHours * 3600_000);
  const orders = status === "pending"
    ? await db.select().from(ordersTable).where(eq(ordersTable.status, "pending")).orderBy(desc(ordersTable.createdAt)).limit(15)
    : await db.select().from(ordersTable).where(and(eq(ordersTable.status, status), gte(ordersTable.createdAt, since))).orderBy(desc(ordersTable.createdAt)).limit(15);

  const labels = { pending: "⏳ الطلبات المعلّقة", failed: `❌ الطلبات الفاشلة (آخر ${windowHours}س)`, completed: `✅ الطلبات المكتملة (آخر ${windowHours}س)` };
  if (orders.length === 0) return `${labels[status]}\n\nلا يوجد طلبات.`;

  return `<b>${labels[status]}</b>\n\n` + orders.map(o => {
    const i = o.status === "completed" ? "✅" : o.status === "failed" ? "❌" : "⏳";
    return `${i} <code>${escapeHtml(o.id.slice(0, 8))}</code> · <b>${escapeHtml(o.productName.slice(0, 30))}</b>\n` +
      `   ${Number(o.totalPrice ?? 0).toFixed(2)} ${escapeHtml(o.currency)} · /order_${o.id.slice(0, 8)}`;
  }).join("\n\n");
}

async function adjustMarkup(delta: number): Promise<{ text: string; markup: string }> {
  const current = parseFloat(await getSetting("default_profit_margin", "10")) || 0;
  const next = Math.max(0, Math.min(500, current + delta));
  await setSetting("default_profit_margin", String(next));
  return {
    text: `✅ تم تعديل هامش الربح: <b>${current}%</b> ← <b>${next}%</b>`,
    markup: String(next),
  };
}

async function triggerSyncNow(): Promise<string> {
  try {
    const { syncProductsFromAPIs } = await import("../routes/products");
    const result = await syncProductsFromAPIs();
    return `🔄 <b>تمت المزامنة بنجاح</b>\n\n` +
      `📦 منتجات مستوردة/محدّثة: <b>${result?.imported ?? 0}</b>\n` +
      `❌ أخطاء: <b>${result?.errors?.length ?? 0}</b>` +
      (result?.errors?.length ? `\n\n<i>${escapeHtml(result.errors.slice(0, 3).join(" · "))}</i>` : "");
  } catch (e: any) {
    return `❌ فشلت المزامنة: ${escapeHtml(e?.message?.slice(0, 100) ?? "unknown")}`;
  }
}

async function fetchProviderBalance(): Promise<string> {
  const { fetchAllBalances } = await import("./providers");
  const balances = await fetchAllBalances().catch(() => []);
  if (balances.length === 0) return "💰 <b>رصيد المورّدين</b>\n\nتعذر الاتصال بالمورّدين.";

  const lines = balances.map(b => {
    const label = b.displayName ?? b.provider;
    if (!b.configured) return `• <b>${escapeHtml(label)}</b>: <i>غير مضبوط</i>`;
    if (b.balanceUsd !== null && b.balanceUsd !== undefined) {
      const emailLine = b.email ? ` (${escapeHtml(b.email)})` : "";
      const sypLine = b.balanceSyp != null ? ` • <i>${b.balanceSyp.toLocaleString("en-US")} SYP</i>` : "";
      return `• <b>${escapeHtml(label)}</b>: <b>$${b.balanceUsd.toFixed(2)}</b>${sypLine}${emailLine}`;
    }
    return `• <b>${escapeHtml(label)}</b>: ${escapeHtml(b.error ?? "تعذر الجلب")}`;
  });

  return `💰 <b>رصيد المورّدين</b>\n\n${lines.join("\n")}`;
}

async function renderProduct(productId: string): Promise<string> {
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!product) return `❌ لم أجد المنتج: <code>${escapeHtml(productId)}</code>`;
  return `📦 <b>${escapeHtml(product.name)}</b>\n\n` +
    `ID: <code>${escapeHtml(product.id)}</code>\n` +
    `التصنيف: <b>${escapeHtml(product.category)}</b>\n` +
    `اللعبة/المجموعة: <b>${escapeHtml(product.description ?? "-")}</b>\n` +
    `المورّد: <b>${escapeHtml(product.provider)}</b>\n` +
    `السعر: <b>${Number(product.priceUsd ?? 0).toFixed(6)} USD</b>\n` +
    `الهامش: <b>${escapeHtml(product.profitMargin)}%</b>\n` +
    `الحالة: <b>${product.status === "active" ? "فعال" : "موقوف"}</b>\n\n` +
    `تعديل السعر: <code>/price ${escapeHtml(product.id)} 1.25</code>\n` +
    `تفعيل/إيقاف: <code>/toggle ${escapeHtml(product.id)}</code>`;
}

async function renderProductsSearch(term = ""): Promise<string> {
  const q = term.trim();
  const condition = q
    ? or(ilike(productsTable.name, `%${q}%`), ilike(productsTable.nameAr, `%${q}%`), ilike(productsTable.description, `%${q}%`), ilike(productsTable.id, `%${q}%`))
    : undefined;
  const rows = condition
    ? await db.select().from(productsTable).where(condition).orderBy(productsTable.category, productsTable.name).limit(12)
    : await db.select().from(productsTable).orderBy(productsTable.category, productsTable.name).limit(12);

  if (rows.length === 0) return `📦 لم أجد منتجات مطابقة لـ <b>${escapeHtml(q)}</b>`;
  return `📦 <b>${q ? `نتائج البحث: ${escapeHtml(q)}` : "أول المنتجات"}</b>\n\n` + rows.map(p =>
    `${p.status === "active" ? "✅" : "🚫"} <b>${escapeHtml(p.name)}</b>\n` +
    `   <code>${escapeHtml(p.id)}</code> — ${Number(p.priceUsd ?? 0).toFixed(4)} USD`
  ).join("\n\n") + `\n\nاستخدم: <code>/product PRODUCT_ID</code>`;
}

async function setProductPrice(productId: string, priceRaw: string): Promise<string> {
  const price = Number(priceRaw);
  if (!Number.isFinite(price) || price < 0) return "❌ السعر غير صالح. مثال: /price product_id 1.25";
  const [product] = await db.update(productsTable).set({ priceUsd: price.toFixed(6), updatedAt: new Date() }).where(eq(productsTable.id, productId)).returning();
  if (!product) return `❌ لم أجد المنتج: <code>${escapeHtml(productId)}</code>`;
  return `✅ تم تعديل السعر\n\n<b>${escapeHtml(product.name)}</b>\nالسعر الجديد: <b>${price.toFixed(6)} USD</b>`;
}

async function toggleProduct(productId: string): Promise<string> {
  const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!existing) return `❌ لم أجد المنتج: <code>${escapeHtml(productId)}</code>`;
  const nextStatus = existing.status === "active" ? "inactive" : "active";
  const [product] = await db.update(productsTable).set({ status: nextStatus, updatedAt: new Date() }).where(eq(productsTable.id, productId)).returning();
  return `${nextStatus === "active" ? "✅ تم تفعيل المنتج" : "🚫 تم إيقاف المنتج"}\n\n<b>${escapeHtml(product.name)}</b>`;
}

async function renderRecentUsers(): Promise<string> {
  const users = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.role, "user"))
    .orderBy(desc(usersTable.createdAt))
    .limit(10);
  if (users.length === 0) return "👥 لا يوجد مستخدمون بعد.";
  return (
    `👥 <b>آخر المستخدمين</b>\n\n` +
    users
      .map(
        (u) =>
          `👤 <b>${escapeHtml(u.username)}</b>\n` +
          `   📧 <code>${escapeHtml(u.email)}</code>\n` +
          `   💵 الرصيد: <b>${Number(u.balance ?? 0).toFixed(2)} USD</b>\n` +
          `   📅 ${new Date(u.createdAt).toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus" })}`
      )
      .join("\n\n")
  );
}

async function renderUserByEmail(email: string): Promise<string> {
  if (!email) return "❌ استخدم: /user EMAIL";
  const [u] = await db
    .select()
    .from(usersTable)
    .where(ilike(usersTable.email, `%${email}%`));
  if (!u) return `❌ لم أجد مستخدماً بالبريد: <code>${escapeHtml(email)}</code>`;

  const [ordersRes] = await db
    .select({ count: count(), total: sum(ordersTable.totalPrice) })
    .from(ordersTable)
    .where(eq(ordersTable.userId, u.id));

  const adminUrl = getAdminUrl();
  return (
    `👤 <b>معلومات المستخدم</b>\n\n` +
    `الاسم: <b>${escapeHtml(u.username)}</b>\n` +
    `البريد: <code>${escapeHtml(u.email)}</code>\n` +
    `الدور: <b>${u.role === "admin" ? "مدير 🛡️" : "مستخدم"}</b>\n` +
    `الرصيد: <b>${Number(u.balance ?? 0).toFixed(2)} USD</b>\n` +
    `مستوى VIP: <b>${u.vipLevel ?? 0}</b>\n` +
    `الطلبات: <b>${ordersRes?.count ?? 0}</b> (إجمالي: ${Number(ordersRes?.total ?? 0).toFixed(2)} USD)\n` +
    `تاريخ الانضمام: ${new Date(u.createdAt).toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus" })}\n\n` +
    `🔗 <a href="${adminUrl}/admin/users">إدارة المستخدمين</a>`
  );
}

async function renderOrderById(orderId: string): Promise<string> {
  const r = await renderOrderByIdEx(orderId);
  return r.text;
}

async function renderOrderByIdEx(orderId: string): Promise<{ text: string; status?: string; fullId?: string }> {
  if (!orderId) return { text: "❌ استخدم: /order ORDER_ID" };
  const [order] = await db
    .select()
    .from(ordersTable)
    .where(ilike(ordersTable.id, `${orderId}%`));
  if (!order) return { text: `❌ لم أجد طلباً بالرقم: <code>${escapeHtml(orderId)}</code>` };
  const statusIcon = order.status === "completed" ? "✅" : order.status === "failed" ? "❌" : "⏳";
  const adminUrl = getAdminUrl();
  const text =
    `🧾 <b>تفاصيل الطلب</b>\n\n` +
    `${statusIcon} الحالة: <b>${escapeHtml(order.status)}</b>\n` +
    `📦 المنتج: <b>${escapeHtml(order.productName)}</b>\n` +
    `🆔 رقم الطلب: <code>${escapeHtml(order.id)}</code>\n` +
    `💰 السعر: <b>${Number(order.totalPrice ?? 0).toFixed(2)} ${escapeHtml(order.currency)}</b>\n` +
    `🔢 الكمية: <b>x${order.qty}</b>\n` +
    (order.playerId ? `🎮 Player ID: <code>${escapeHtml(String(order.playerId))}</code>\n` : "") +
    `📅 التاريخ: ${new Date(order.createdAt).toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}\n\n` +
    `🔗 <a href="${adminUrl}/admin/orders">لوحة الطلبات</a>`;
  return { text, status: order.status, fullId: order.id };
}

async function renderTodayStats(): Promise<string> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [todayRev] = await db
    .select({ total: sum(ordersTable.totalPrice), cnt: count() })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, today)));
  const [todayAll] = await db
    .select({ cnt: count() })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, today));
  const [todayFailed] = await db
    .select({ cnt: count() })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, today)));
  const [todayUsers] = await db
    .select({ cnt: count() })
    .from(usersTable)
    .where(gte(usersTable.createdAt, today));
  const [pendingPay] = await db
    .select({ cnt: count() })
    .from(paymentsTable)
    .where(eq(paymentsTable.status, "pending"));

  const dateStr = new Date().toLocaleDateString("ar-SY", {
    timeZone: "Asia/Damascus",
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    `📈 <b>تقرير اليوم — Elite Store</b>\n` +
    `📅 ${dateStr}\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 <b>الإيراد اليوم:</b> $${Number(todayRev?.total ?? 0).toFixed(2)}\n` +
    `🛒 <b>إجمالي الطلبات:</b> ${todayAll?.cnt ?? 0}\n` +
    `✅ <b>مكتملة:</b> ${todayRev?.cnt ?? 0}\n` +
    `❌ <b>فاشلة:</b> ${todayFailed?.cnt ?? 0}\n` +
    `🆕 <b>مستخدمون جدد:</b> ${todayUsers?.cnt ?? 0}\n` +
    `⏳ <b>إيداعات بانتظار المراجعة:</b> ${pendingPay?.cnt ?? 0}\n` +
    `━━━━━━━━━━━━━━━━━━━━`
  );
}

async function priceSync(factorRaw: string): Promise<string> {
  const factor = Number(factorRaw);
  if (!Number.isFinite(factor) || factor <= 0 || factor > 10) {
    return "❌ معامل غير صالح. مثال: <code>/pricesync 1.05</code> = +5%، <code>/pricesync 0.9</code> = -10%.\nالنطاق المسموح: 0.1 — 10.";
  }
  const result = await db
    .update(productsTable)
    .set({ priceUsd: sql`ROUND(${productsTable.priceUsd}::numeric * ${factor}, 6)`, updatedAt: new Date() })
    .where(eq(productsTable.status, "active"))
    .returning({ id: productsTable.id });
  const pct = ((factor - 1) * 100).toFixed(2);
  const sign = factor >= 1 ? "+" : "";
  return (
    `✅ <b>تم تحديث أسعار ${result.length} منتج فعّال</b>\n\n` +
    `📈 المعامل المطبّق: <b>×${factor}</b> (${sign}${pct}%)\n` +
    `⏱ ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}\n\n` +
    `💡 للتراجع، طبّق المعكوس: <code>/pricesync ${(1 / factor).toFixed(4)}</code>`
  );
}

function buildChartUrl(labels: string[], data: number[], title: string): string {
  const config = {
    type: "bar",
    data: {
      labels,
      datasets: [{ label: title, data, backgroundColor: "rgba(34,197,94,0.7)", borderColor: "rgba(34,197,94,1)", borderWidth: 1 }],
    },
    options: {
      title: { display: true, text: title, fontSize: 16, fontColor: "#fff" },
      legend: { display: false },
      scales: {
        yAxes: [{ ticks: { fontColor: "#fff", beginAtZero: true }, gridLines: { color: "rgba(255,255,255,0.1)" } }],
        xAxes: [{ ticks: { fontColor: "#fff" }, gridLines: { color: "rgba(255,255,255,0.1)" } }],
      },
    },
  };
  const json = encodeURIComponent(JSON.stringify(config));
  return `https://quickchart.io/chart?bkg=%23111827&w=700&h=380&c=${json}`;
}

async function renderRangeReport(period: "today" | "week" | "month"): Promise<{ caption: string; chartUrl: string | null }> {
  const days = period === "today" ? 1 : period === "week" ? 7 : 30;
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - (days - 1));

  const [rev] = await db
    .select({ total: sum(ordersTable.totalPrice), cnt: count() })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, start)));
  const [allOrders] = await db
    .select({ cnt: count() })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, start));
  const [failed] = await db
    .select({ cnt: count() })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, start)));
  const [newUsers] = await db
    .select({ cnt: count() })
    .from(usersTable)
    .where(gte(usersTable.createdAt, start));

  // Daily breakdown for chart
  const breakdown = await db.execute(sql`
    SELECT DATE(created_at AT TIME ZONE 'Asia/Damascus') AS day,
           COALESCE(SUM(total_price), 0)::float AS revenue
    FROM orders
    WHERE status = 'completed' AND created_at >= ${start}
    GROUP BY day ORDER BY day ASC
  `);

  const labels: string[] = [];
  const dataPoints: number[] = [];
  const map = new Map<string, number>();
  for (const row of (breakdown as any).rows ?? []) {
    const d = new Date(row.day);
    const key = d.toISOString().slice(0, 10);
    map.set(key, Number(row.revenue ?? 0));
  }
  for (let i = 0; i < days; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const key = d.toISOString().slice(0, 10);
    labels.push(d.toLocaleDateString("ar-SY", { month: "short", day: "numeric", timeZone: "Asia/Damascus" }));
    dataPoints.push(map.get(key) ?? 0);
  }

  const periodLabel = period === "today" ? "اليوم" : period === "week" ? "آخر 7 أيام" : "آخر 30 يوم";
  const totalRev = Number(rev?.total ?? 0);
  const avg = days > 0 ? (totalRev / days).toFixed(2) : "0.00";

  const caption =
    `📈 <b>تقرير ${escapeHtml(periodLabel)} — Elite Store</b>\n` +
    `📅 ${start.toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus" })} → ${new Date().toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus" })}\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 <b>إجمالي الإيراد:</b> $${totalRev.toFixed(2)}\n` +
    `📊 <b>المتوسط اليومي:</b> $${avg}\n` +
    `🛒 <b>إجمالي الطلبات:</b> ${allOrders?.cnt ?? 0}\n` +
    `✅ <b>مكتملة:</b> ${rev?.cnt ?? 0}\n` +
    `❌ <b>فاشلة:</b> ${failed?.cnt ?? 0}\n` +
    `🆕 <b>مستخدمون جدد:</b> ${newUsers?.cnt ?? 0}\n` +
    `━━━━━━━━━━━━━━━━━━━━`;

  const chartUrl = days > 1 ? buildChartUrl(labels, dataPoints, `الإيراد اليومي بالـ USD — ${periodLabel}`) : null;
  return { caption, chartUrl };
}

async function setDefaultMarkup(markupRaw: string): Promise<string> {
  const markup = Number(markupRaw);
  if (!Number.isFinite(markup) || markup < 0 || markup > 500) return "❌ الهامش غير صالح. مثال: /markup 12";
  await setSetting("default_profit_margin", markup.toFixed(2));
  await db.update(productsTable).set({ profitMargin: markup.toFixed(2), updatedAt: new Date() }).where(sql`${productsTable.provider} <> 'manual'`);
  return `✅ تم تعديل هامش الربح العام إلى <b>${markup.toFixed(2)}%</b> وتطبيقه على منتجات المورّدين.`;
}

// Map persistent reply-keyboard text labels to commands
const REPLY_LABEL_MAP: Record<string, string> = {
  "📊 الإحصائيات": "/stats",
  "🛒 الطلبات": "/orders",
  "📦 المنتجات": "/products",
  "👥 المستخدمون": "/users",
  "📈 التقارير": "__MENU__:reports",
  "⚙️ الإعدادات": "__MENU__:settings",
};

function welcomeMessage(): string {
  const url = getAdminUrl();
  return `🛡️ <b>مرحباً بك في Elite Store Admin</b>\n\n` +
    `استخدم الأزرار بالأسفل للتنقل السريع، أو القائمة الذكية أدناه للوصول الكامل.\n\n` +
    `🏠 <a href="${url}/admin">فتح لوحة التحكم</a>`;
}

async function handleAdminCommand(text: string): Promise<string> {
  // Persistent reply-keyboard mapping
  if (REPLY_LABEL_MAP[text]) text = REPLY_LABEL_MAP[text];

  // Inline /order_<id8> shortcut from order lists
  const orderShortcut = text.match(/^\/order_([a-f0-9]+)/i);
  if (orderShortcut) return renderOrderById(orderShortcut[1]);

  const [commandRaw, ...args] = text.trim().split(/\s+/);
  const command = commandRaw.toLowerCase();

  if (["/start", "/admin", "/help", "/menu"].includes(command)) return "__WELCOME__";
  if (command === "__menu__:reports") return "__MENU__:reports";
  if (command === "__menu__:settings") return "__MENU__:settings";
  if (command === "/stats") return renderStats();
  if (command === "/today") return renderTodayStats();
  if (command === "/orders") return "__ORDERS_PAGE__:0";
  if (command === "/order") return args[0] ? renderOrderById(args[0]) : "❌ استخدم: /order ORDER_ID";
  if (command === "/balance") return fetchProviderBalance();
  if (command === "/users") return renderRecentUsers();
  if (command === "/user") return args[0] ? renderUserByEmail(args.join(" ")) : "❌ استخدم: /user EMAIL";
  if (command === "/products") return renderProductsSearch(args.join(" "));
  if (command === "/find") return renderProductsSearch(args.join(" "));
  if (command === "/product") return args[0] ? renderProduct(args[0]) : "❌ استخدم: /product PRODUCT_ID";
  if (command === "/price") return args[0] && args[1] ? setProductPrice(args[0], args[1]) : "❌ استخدم: /price PRODUCT_ID 1.25";
  if (command === "/toggle") return args[0] ? toggleProduct(args[0]) : "❌ استخدم: /toggle PRODUCT_ID";
  if (command === "/markup") return args[0] ? setDefaultMarkup(args[0]) : "❌ استخدم: /markup 12";
  if (command === "/pricesync") return args[0] ? priceSync(args[0]) : "❌ استخدم: /pricesync 1.05 (يضرب كل الأسعار بـ 5%)";
  if (command === "/sync") return triggerSyncNow();
  if (command === "/stuck") return renderStuckOrders();
  if (command === "/status") return renderSystemStatus();
  if (command === "/pause") return setOrdersPaused(true);
  if (command === "/resume") return setOrdersPaused(false);
  if (command === "/health") return renderSystemStatus();
  if (command === "/report") {
    const period = (args[0] ?? "today").toLowerCase();
    if (period === "week" || period === "month" || period === "today") {
      return `__REPORT__:${period}`;
    }
    return "❌ استخدم: /report today | /report week | /report month";
  }

  return `❓ لم أفهم الأمر.\n\nاضغط /help لرؤية القائمة الرئيسية.`;
}

async function sendReport(chatId: string, period: "today" | "week" | "month"): Promise<void> {
  const { caption, chartUrl } = await renderRangeReport(period);
  if (chartUrl) {
    const ok = await sendPhoto(chatId, chartUrl, caption, reportsMenu());
    if (!ok) await sendMessage(chatId, caption, reportsMenu());
  } else {
    await sendMessage(chatId, caption, reportsMenu());
  }
}

async function routeCallback(data: string, chatId: string, messageId: number | undefined): Promise<void> {
  // Payment actions: approve / reject deposit
  if (data.startsWith("pay_approve:") || data.startsWith("pay_reject:")) {
    const action = data.startsWith("pay_approve:") ? "approve" : "reject";
    const id = parseInt(data.split(":")[1] ?? "", 10);
    const result = await handlePaymentAction(id, action);
    await sendMessage(chatId, result, [
      [{ text: "💳 الإيداعات", url: `${getAdminUrl()}/admin/payments` }, backButton()],
    ]);
    return;
  }

  // View user profile from notification
  if (data.startsWith("user_view:")) {
    const userId = parseInt(data.split(":")[1] ?? "", 10);
    const text = await renderUserCard(userId);
    await sendMessage(chatId, text, [
      [{ text: "👥 إدارة المستخدمين", url: `${getAdminUrl()}/admin/users` }, backButton()],
    ]);
    return;
  }

  // System status / stuck / pause / resume from inline buttons
  if (data === "sys:status") {
    const text = await renderSystemStatus();
    if (messageId) await editMessage(chatId, messageId, text, adminKeyboard());
    else await sendMessage(chatId, text, adminKeyboard());
    return;
  }
  if (data === "sys:stuck") {
    const text = await renderStuckOrders();
    if (messageId) await editMessage(chatId, messageId, text, adminKeyboard());
    else await sendMessage(chatId, text, adminKeyboard());
    return;
  }
  if (data === "sys:pause") {
    const text = await setOrdersPaused(true);
    await sendMessage(chatId, text, adminKeyboard());
    return;
  }
  if (data === "sys:resume") {
    const text = await setOrdersPaused(false);
    await sendMessage(chatId, text, adminKeyboard());
    return;
  }

  // Order actions: approve / reject / retry
  if (data.startsWith("order:") || data.startsWith("approve_order:") || data.startsWith("reject_order:")) {
    let action: "approve" | "reject" | "retry" = "approve";
    let orderId = "";
    if (data.startsWith("approve_order:")) { action = "approve"; orderId = data.split(":")[1] ?? ""; }
    else if (data.startsWith("reject_order:")) { action = "reject"; orderId = data.split(":")[1] ?? ""; }
    else {
      const [, act, id] = data.split(":");
      action = (act as any) ?? "approve";
      orderId = id ?? "";
    }
    const actualAction = action === "retry" ? "approve" : action;
    const result = await handleOrderAction(orderId, actualAction);
    await sendMessage(chatId, result, [
      [{ text: "🛒 قائمة الطلبات", callback_data: "menu:orders" }, backButton()],
    ]);
    return;
  }

  // Markup adjustments
  if (data.startsWith("markup:")) {
    const delta = parseFloat(data.split(":")[1]);
    if (Number.isFinite(delta)) {
      const r = await adjustMarkup(delta);
      const updated = settingsMenu(r.markup);
      if (messageId) await editMessage(chatId, messageId, r.text, updated);
      else await sendMessage(chatId, r.text, updated);
    }
    return;
  }

  // Sync now
  if (data === "sync:now") {
    if (messageId) await editMessage(chatId, messageId, "🔄 جاري مزامنة المنتجات... قد يستغرق ذلك دقيقة.", []);
    const result = await triggerSyncNow();
    await sendMessage(chatId, result, adminKeyboard());
    return;
  }

  // Reports
  if (data.startsWith("report:")) {
    const period = data.split(":")[1] as "today" | "week" | "month";
    await sendReport(chatId, period);
    return;
  }

  // Orders pagination + filters
  if (data.startsWith("orders:page:")) {
    const page = parseInt(data.split(":")[2], 10) || 0;
    const r = await renderOrdersPage(page);
    if (messageId) await editMessage(chatId, messageId, r.text, r.keyboard);
    else await sendMessage(chatId, r.text, r.keyboard);
    return;
  }
  if (data === "orders:pending" || data === "orders:failed" || data === "orders:completed") {
    const status = data.split(":")[1] as "pending" | "failed" | "completed";
    const text = await renderOrdersByStatus(status);
    const kb: InlineKeyboard = [[{ text: "🔙 قائمة الطلبات", callback_data: "menu:orders" }]];
    if (messageId) await editMessage(chatId, messageId, text, kb);
    else await sendMessage(chatId, text, kb);
    return;
  }

  // Users pagination
  if (data.startsWith("users:page:")) {
    const text = await renderRecentUsers();
    const kb: InlineKeyboard = [[backButton()]];
    if (messageId) await editMessage(chatId, messageId, text, kb);
    else await sendMessage(chatId, text, kb);
    return;
  }

  // Products list
  if (data === "products:list") {
    const text = await renderProductsSearch();
    const kb: InlineKeyboard = [[{ text: "🔙 قائمة المنتجات", callback_data: "menu:products" }]];
    if (messageId) await editMessage(chatId, messageId, text, kb);
    else await sendMessage(chatId, text, kb);
    return;
  }

  // Menu navigation
  if (data === "menu:main") {
    const text = `🏠 <b>القائمة الرئيسية</b>\n\nاختر القسم:`;
    if (messageId) await editMessage(chatId, messageId, text, adminKeyboard());
    else await sendMessage(chatId, text, adminKeyboard());
    return;
  }
  if (data === "menu:reports") {
    const text = `📈 <b>التقارير</b>\n\nاختر الفترة الزمنية:`;
    if (messageId) await editMessage(chatId, messageId, text, reportsMenu());
    else await sendMessage(chatId, text, reportsMenu());
    return;
  }
  if (data === "menu:orders") {
    const text = `🛒 <b>الطلبات</b>\n\nاختر طريقة العرض:`;
    if (messageId) await editMessage(chatId, messageId, text, ordersMenu());
    else await sendMessage(chatId, text, ordersMenu());
    return;
  }
  if (data === "menu:products") {
    const text = `📦 <b>المنتجات</b>\n\nاختر الإجراء:`;
    if (messageId) await editMessage(chatId, messageId, text, productsMenu());
    else await sendMessage(chatId, text, productsMenu());
    return;
  }
  if (data === "menu:users") {
    const text = `👥 <b>المستخدمون</b>\n\nاختر الإجراء:`;
    if (messageId) await editMessage(chatId, messageId, text, usersMenu());
    else await sendMessage(chatId, text, usersMenu());
    return;
  }
  if (data === "menu:settings") {
    const markup = await getSetting("default_profit_margin", "10");
    const text = `⚙️ <b>الإعدادات السريعة</b>\n\nعدّل هامش الربح أو شغّل المزامنة:`;
    if (messageId) await editMessage(chatId, messageId, text, settingsMenu(markup));
    else await sendMessage(chatId, text, settingsMenu(markup));
    return;
  }
  if (data === "menu:stats" || data === "stats") {
    const text = await renderStats();
    if (messageId) await editMessage(chatId, messageId, text, adminKeyboard());
    else await sendMessage(chatId, text, adminKeyboard());
    return;
  }

  // Legacy / quick callbacks
  if (data === "balance") {
    const text = await fetchProviderBalance();
    const kb: InlineKeyboard = [[{ text: "🔄 تحديث", callback_data: "balance" }, backButton()]];
    if (messageId) await editMessage(chatId, messageId, text, kb);
    else await sendMessage(chatId, text, kb);
    return;
  }
  if (data === "orders") {
    const r = await renderOrdersPage(0);
    if (messageId) await editMessage(chatId, messageId, r.text, r.keyboard);
    else await sendMessage(chatId, r.text, r.keyboard);
    return;
  }
  if (data === "today") {
    const text = await renderTodayStats();
    if (messageId) await editMessage(chatId, messageId, text, reportsMenu());
    else await sendMessage(chatId, text, reportsMenu());
    return;
  }
  if (data === "users") {
    const text = await renderRecentUsers();
    const kb: InlineKeyboard = [[backButton()]];
    if (messageId) await editMessage(chatId, messageId, text, kb);
    else await sendMessage(chatId, text, kb);
    return;
  }
  if (data === "products") {
    const text = await renderProductsSearch();
    const kb: InlineKeyboard = [[{ text: "🔙 قائمة المنتجات", callback_data: "menu:products" }]];
    if (messageId) await editMessage(chatId, messageId, text, kb);
    else await sendMessage(chatId, text, kb);
    return;
  }

  // No-op (e.g. info-only buttons)
  if (data === "noop") return;
}

export async function handleTelegramUpdate(update: TelegramUpdate): Promise<void> {
  const chatId = parseChatId(update);
  if (!isAdminChat(chatId)) {
    if (chatId) await sendMessage(chatId, "هذه اللوحة مخصصة لمدير Elite Store فقط.");
    return;
  }

  if (update.callback_query) {
    const data = update.callback_query.data ?? "";
    await answerCallbackQuery(update.callback_query.id);
    const messageId = update.callback_query.message?.message_id;
    if (chatId) await routeCallback(data, chatId, messageId);
    return;
  }

  const text = update.message?.text?.trim();
  if (!text || !chatId) return;
  const response = await handleAdminCommand(text);

  // /start /help /menu — welcome with persistent reply keyboard
  if (response === "__WELCOME__") {
    await sendMessage(chatId, welcomeMessage(), undefined, PERSISTENT_KEYBOARD);
    await sendMessage(chatId, "🏠 <b>القائمة الرئيسية</b>\n\nاختر القسم:", adminKeyboard());
    return;
  }

  // Submenu shortcuts (from persistent keyboard)
  if (response === "__MENU__:reports") {
    await sendMessage(chatId, "📈 <b>التقارير</b>\n\nاختر الفترة الزمنية:", reportsMenu());
    return;
  }
  if (response === "__MENU__:settings") {
    const markup = await getSetting("default_profit_margin", "10");
    await sendMessage(chatId, "⚙️ <b>الإعدادات السريعة</b>", settingsMenu(markup));
    return;
  }

  // Orders page shortcut
  if (response.startsWith("__ORDERS_PAGE__:")) {
    const page = parseInt(response.split(":")[1], 10) || 0;
    const r = await renderOrdersPage(page);
    await sendMessage(chatId, r.text, r.keyboard);
    return;
  }

  // /report — chart photo
  if (response.startsWith("__REPORT__:")) {
    const period = response.split(":")[1] as "today" | "week" | "month";
    await sendReport(chatId, period);
    return;
  }

  // If user sent /order_xxxx — show with action buttons
  const orderShortcut = text.match(/^\/order_([a-f0-9]+)/i) || (text.match(/^\/order\s+(\S+)/i));
  if (orderShortcut) {
    const r = await renderOrderByIdEx(orderShortcut[1]);
    if (r.fullId && r.status) {
      await sendMessage(chatId, r.text, orderActionKeyboard(r.fullId, r.status));
      return;
    }
    await sendMessage(chatId, r.text, [[backButton()]]);
    return;
  }

  await sendMessage(chatId, response, adminKeyboard());
}

async function handleOrderAction(orderId: string, action: "approve" | "reject"): Promise<string> {
  if (!orderId) return "❌ معرّف الطلب مفقود.";
  try {
    // Dynamic import avoids the circular dep (order-actions imports this file).
    const { approveOrderById, rejectOrderById } = await import("./order-actions");
    const result = action === "approve"
      ? await approveOrderById(orderId, { username: "telegram-admin" })
      : await rejectOrderById(orderId, "Rejected from Telegram", { username: "telegram-admin" });
    if (!result.ok) return `⚠️ ${escapeHtml(result.reason)}`;
    if (action === "approve") {
      return result.status === "completed"
        ? `✅ تم اعتماد الطلب <code>${escapeHtml(orderId.slice(0, 8))}</code> وتنفيذه بنجاح.`
        : `⚠️ تم اعتماد الطلب لكن فشل التنفيذ من المورّد، وتم استرجاع الرصيد.`;
    }
    return `🚫 تم رفض الطلب <code>${escapeHtml(orderId.slice(0, 8))}</code> واسترجاع الرصيد.`;
  } catch (e: any) {
    return `⚠️ خطأ: ${escapeHtml(e?.message?.slice(0, 100) ?? "unknown")}`;
  }
}

// ─── New alert exports ────────────────────────────────────────────────────────

export async function notifyHighValueOrder(params: {
  username: string;
  productName: string;
  price: number;
  orderId: string;
  currency?: string;
}): Promise<void> {
  const cur = params.currency ?? "USD";
  const msg =
    `🚨 <b>طلب بقيمة مرتفعة — يحتاج موافقة</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `📦 المنتج: <b>${escapeHtml(params.productName)}</b>\n` +
    `💰 المبلغ: <b>${params.price.toFixed(2)} ${escapeHtml(cur)}</b>\n` +
    `🆔 رقم الطلب: <code>${escapeHtml(params.orderId)}</code>\n` +
    `⏱ ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;
  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "✅ اعتماد فوري", callback_data: `approve_order:${params.orderId}` },
      { text: "🚫 رفض واسترجاع", callback_data: `reject_order:${params.orderId}` },
    ],
    [{ text: "📋 فتح في اللوحة", url: `${getAdminUrl()}/admin/orders` }],
  ]);
}

export async function notifyFraudAttempt(params: {
  ip: string;
  count: number;
  emails: string[];
  newUsername: string;
  newEmail: string;
}): Promise<void> {
  const msg =
    `🚨 <b>محاولة احتيال محتملة</b>\n\n` +
    `📡 IP: <code>${escapeHtml(params.ip)}</code>\n` +
    `🔢 عدد الحسابات من نفس الـ IP: <b>${params.count}</b>\n` +
    `🆕 آخر تسجيل: <b>${escapeHtml(params.newUsername)}</b> — <code>${escapeHtml(params.newEmail)}</code>\n\n` +
    `📧 <b>الحسابات السابقة:</b>\n${params.emails.slice(0, 8).map(e => `• <code>${escapeHtml(e)}</code>`).join("\n")}` +
    (params.emails.length > 8 ? `\n<i>...وأخرى</i>` : "");
  await sendMessage(getAdminChatId(), msg, [
    [{ text: "👥 إدارة المستخدمين", url: `${getAdminUrl()}/admin/users` }],
  ]);
}

export async function notifyLowProviderBalance(params: {
  provider: string;
  balance: number;
  threshold: number;
}): Promise<void> {
  const msg =
    `🚨 <b>رصيد المورّد قارب على النفاد</b>\n\n` +
    `🏢 المورّد: <b>${escapeHtml(params.provider)}</b>\n` +
    `💰 الرصيد الحالي: <b>${params.balance.toFixed(4)} USD</b>\n` +
    `⚠️ حد التنبيه: <b>${params.threshold.toFixed(2)} USD</b>\n\n` +
    `يُنصح بالشحن قبل تعطّل الطلبات.`;
  await sendMessage(getAdminChatId(), msg, [
    [{ text: "💰 فحص الأرصدة", callback_data: "balance" }],
    [{ text: "⚙️ الإعدادات", url: `${getAdminUrl()}/admin/settings` }],
  ]);
}

export async function notifyLowStock(params: {
  productName: string;
  productId: string;
  remaining: number;
}): Promise<void> {
  const msg =
    `🚨 <b>منتج قارب على النفاد</b>\n\n` +
    `📦 المنتج: <b>${escapeHtml(params.productName)}</b>\n` +
    `🆔 <code>${escapeHtml(params.productId)}</code>\n` +
    `📉 المتبقي: <b>${params.remaining}</b>\n\n` +
    `استخدم <code>/product ${escapeHtml(params.productId)}</code> للتفاصيل.`;
  await sendMessage(getAdminChatId(), msg, [
    [{ text: "📦 المنتجات", url: `${getAdminUrl()}/admin/products` }],
  ]);
}

function resolveWebhookUrl(): string {
  // 1. Explicit webhook URL always wins
  if (process.env.TELEGRAM_WEBHOOK_URL?.trim()) {
    return process.env.TELEGRAM_WEBHOOK_URL.trim();
  }
  // 2. REPLIT_DOMAINS is auto-set and always matches the current environment (dev or prod)
  const replitDomains = process.env.REPLIT_DOMAINS?.trim();
  if (replitDomains) {
    const primaryDomain = replitDomains.split(",")[0].trim();
    if (primaryDomain) return `https://${primaryDomain}/api/telegram/webhook`;
  }
  // 3. Manual SITE_URL as last fallback
  if (process.env.SITE_URL?.trim()) {
    return `${process.env.SITE_URL.trim().replace(/\/$/, "")}/api/telegram/webhook`;
  }
  return "";
}

export async function configureTelegramWebhook(retryCount = 0): Promise<void> {
  if (!getBotToken()) {
    console.warn("[Telegram] setWebhook skipped: no BOT_TOKEN");
    return;
  }

  // Skip webhook setup in dev unless explicitly opted-in, so dev restarts
  // don't hijack the production webhook URL.
  const isDeployment =
    process.env.REPLIT_DEPLOYMENT === "1" ||
    process.env.NODE_ENV === "production";
  const allowDevWebhook = process.env.TELEGRAM_DEV_WEBHOOK === "1" ||
    !!process.env.TELEGRAM_WEBHOOK_URL?.trim();
  if (!isDeployment && !allowDevWebhook) {
    console.info("[Telegram] setWebhook skipped in dev (set TELEGRAM_DEV_WEBHOOK=1 to override)");
    return;
  }

  const webhookUrl = resolveWebhookUrl();

  if (!webhookUrl) {
    console.info("[Telegram] setWebhook skipped: no SITE_URL or REPLIT_DOMAINS set");
    return;
  }

  try {
    const result = await telegramRequest("setWebhook", {
      url: webhookUrl,
      allowed_updates: ["message", "callback_query"],
      drop_pending_updates: true,
    });
    if (result?.ok) {
      console.info("[Telegram] ✅ Webhook set successfully:", webhookUrl);
    } else {
      // Retry up to 3 times with increasing delays (10s, 30s, 60s)
      if (retryCount < 3) {
        const delay = [10000, 30000, 60000][retryCount];
        console.warn(`[Telegram] Webhook registration failed — retrying in ${delay / 1000}s (attempt ${retryCount + 1}/3)`);
        setTimeout(() => configureTelegramWebhook(retryCount + 1), delay);
      } else {
        console.warn("[Telegram] ⚠️ Webhook registration failed after 3 attempts:", JSON.stringify(result), "| URL:", webhookUrl);
      }
    }
  } catch (err: any) {
    if (retryCount < 3) {
      const delay = [10000, 30000, 60000][retryCount];
      console.warn(`[Telegram] Network error — retrying in ${delay / 1000}s:`, (err as any)?.message?.slice(0, 80));
      setTimeout(() => configureTelegramWebhook(retryCount + 1), delay);
    } else {
      console.error("[Telegram] ❌ setWebhook failed after 3 retries:", err?.message ?? err);
    }
  }
}

export async function deleteTelegramWebhook(): Promise<any> {
  if (!getBotToken()) return { ok: false, error: "No bot token" };
  return telegramRequest("deleteWebhook", { drop_pending_updates: true });
}

export async function getTelegramWebhookInfo(): Promise<any> {
  if (!getBotToken()) return { ok: false, error: "No bot token" };
  return telegramRequest("getWebhookInfo", {});
}

export async function sendTestMessage(): Promise<boolean> {
  if (!getBotToken() || !getAdminChatId()) return false;
  try {
    await sendMessage(getAdminChatId(), `✅ <b>Elite Store Bot</b>\n\nالبوت يعمل بشكل صحيح ✔️\n<i>وقت الاختبار: ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}</i>`);
    return true;
  } catch {
    return false;
  }
}

export async function notifyNewOrder(params: {
  username: string;
  productName: string;
  price: number;
  orderId: string;
  currency?: string;
}): Promise<void> {
  const cur = params.currency ?? "USD";
  const msg =
    `🛒 <b>طلب جديد</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `📦 المنتج: <b>${escapeHtml(params.productName)}</b>\n` +
    `💰 السعر: <b>${params.price.toFixed(2)} ${escapeHtml(cur)}</b>\n` +
    `🆔 رقم الطلب: <code>${escapeHtml(params.orderId)}</code>\n` +
    `⏱ الوقت: ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;

  const adminUrl = getAdminUrl();
  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "🧾 آخر الطلبات", callback_data: "orders" },
      { text: "📊 الإحصائيات", callback_data: "stats" },
    ],
    [
      { text: "📋 لوحة الطلبات", url: `${adminUrl}/admin/orders` },
      { text: "📊 لوحة التحكم", url: `${adminUrl}/admin` },
    ],
  ]);
}

export async function notifyOrderSuccess(params: {
  username: string;
  productName: string;
  orderId: string;
}): Promise<void> {
  const msg =
    `✅ <b>تم تنفيذ الطلب بنجاح</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `📦 المنتج: <b>${escapeHtml(params.productName)}</b>\n` +
    `🆔 رقم الطلب: <code>${escapeHtml(params.orderId)}</code>`;

  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "🧾 آخر الطلبات", callback_data: "orders" },
      { text: "📊 الإحصائيات", callback_data: "stats" },
    ],
  ]);
}

export async function notifyOrderFailed(params: {
  username: string;
  productName: string;
  orderId: string;
  error?: string;
}): Promise<void> {
  const msg =
    `❌ <b>فشل الطلب — تم استرجاع الرصيد تلقائياً</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `📦 المنتج: <b>${escapeHtml(params.productName)}</b>\n` +
    `🆔 رقم الطلب: <code>${escapeHtml(params.orderId)}</code>` +
    (params.error ? `\n⚠️ السبب: <i>${escapeHtml(params.error.slice(0, 120))}</i>` : "");

  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "🧾 آخر الطلبات", callback_data: "orders" },
      { text: "📊 الإحصائيات", callback_data: "stats" },
    ],
  ]);
}

export async function notifyNewUser(params: {
  username: string;
  email: string;
}): Promise<void> {
  const msg =
    `🆕 <b>مستخدم جديد انضم إلى المتجر</b>\n\n` +
    `👤 الاسم: <b>${escapeHtml(params.username)}</b>\n` +
    `📧 البريد: <code>${escapeHtml(params.email)}</code>\n` +
    `📅 التاريخ: ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;

  const adminUrl = getAdminUrl();
  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "👥 إدارة المستخدمين", url: `${adminUrl}/admin/users` },
      { text: "📊 لوحة التحكم", url: `${adminUrl}/admin` },
    ],
  ]);
}

export async function notifyDeposit(params: {
  paymentId?: number;
  userId?: number;
  username: string;
  amount: number;
  currency: string;
  method: string;
  transactionRef: string;
  screenshotUrl?: string | null;
}): Promise<void> {
  const msg =
    `💳 <b>طلب إيداع رصيد جديد</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `💵 المبلغ: <b>${params.amount} ${escapeHtml(params.currency)}</b>\n` +
    `🏦 الطريقة: <b>${escapeHtml(params.method)}</b>\n` +
    `🔢 رقم العملية: <code>${escapeHtml(params.transactionRef)}</code>\n` +
    `⏱ الوقت: ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;

  const adminUrl = getAdminUrl();
  const keyboard: InlineKeyboard = [];
  if (params.paymentId) {
    keyboard.push([
      { text: "✅ Approve Deposit", callback_data: `pay_approve:${params.paymentId}` },
      { text: "❌ Reject Deposit", callback_data: `pay_reject:${params.paymentId}` },
    ]);
  }
  if (params.userId) {
    keyboard.push([{ text: "👁 View User Profile", callback_data: `user_view:${params.userId}` }]);
  }
  keyboard.push([{ text: "📋 مراجعة الإيداعات", url: `${adminUrl}/admin/payments` }]);

  // Build absolute URL for the screenshot (Telegram requires absolute HTTPS).
  let absoluteScreenshot: string | null = null;
  if (params.screenshotUrl) {
    if (/^https?:\/\//i.test(params.screenshotUrl)) {
      absoluteScreenshot = params.screenshotUrl;
    } else {
      const base = getAdminUrl().replace(/\/$/, "");
      absoluteScreenshot = `${base}${params.screenshotUrl.startsWith("/") ? "" : "/"}${params.screenshotUrl}`;
    }
  }

  if (absoluteScreenshot) {
    const photoOk = await sendPhoto(getAdminChatId(), absoluteScreenshot, msg, keyboard);
    if (photoOk) return;
    // Fallback: include the URL inline so admin can still open it
    await sendMessage(
      getAdminChatId(),
      `${msg}\n\n🖼 <a href="${escapeHtml(absoluteScreenshot)}">صورة الإيصال</a>`,
      keyboard,
    );
    return;
  }

  await sendMessage(getAdminChatId(), msg, keyboard);
}

// ─── Daily Report ─────────────────────────────────────────────────────────────
export async function sendDailyReport(): Promise<void> {
  if (!getAdminChatId()) return;
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [totalRevResult] = await db.select({ total: sum(ordersTable.totalPrice) }).from(ordersTable).where(eq(ordersTable.status, "completed"));
    const [todayRevResult] = await db.select({ total: sum(ordersTable.totalPrice) }).from(ordersTable).where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, today)));
    const [totalOrdersResult] = await db.select({ c: count() }).from(ordersTable);
    const [todayOrdersResult] = await db.select({ c: count() }).from(ordersTable).where(gte(ordersTable.createdAt, today));
    const [totalUsersResult] = await db.select({ c: count() }).from(usersTable).where(eq(usersTable.role, "user"));
    const [pendingPayResult] = await db.select({ c: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending"));

    const totalRev = parseFloat(totalRevResult?.total ?? "0").toFixed(2);
    const todayRev = parseFloat(todayRevResult?.total ?? "0").toFixed(2);
    const totalOrders = totalOrdersResult?.c ?? 0;
    const todayOrders = todayOrdersResult?.c ?? 0;
    const totalUsers = totalUsersResult?.c ?? 0;
    const pendingPay = pendingPayResult?.c ?? 0;
    const dateStr = new Date().toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus", weekday: "long", year: "numeric", month: "long", day: "numeric" });

    const msg =
      `📊 <b>التقرير اليومي - Elite Store</b>\n` +
      `📅 ${dateStr}\n\n` +
      `💰 <b>الإيرادات اليوم:</b> $${todayRev}\n` +
      `📈 <b>الإيرادات الإجمالية:</b> $${totalRev}\n\n` +
      `🛒 <b>الطلبات اليوم:</b> ${todayOrders}\n` +
      `📦 <b>إجمالي الطلبات:</b> ${totalOrders}\n\n` +
      `👥 <b>إجمالي المستخدمين:</b> ${totalUsers}\n` +
      `⏳ <b>إيداعات بانتظار المراجعة:</b> ${pendingPay}\n\n` +
      `🔗 <a href="${getAdminUrl()}/admin">لوحة التحكم</a>`;

    const adminUrl = getAdminUrl();
    await sendMessage(getAdminChatId(), msg, [
      [{ text: "📊 لوحة التحكم", url: `${adminUrl}/admin` }, { text: "💳 الإيداعات", url: `${adminUrl}/admin/payments` }],
      [{ text: "📦 الطلبات", url: `${adminUrl}/admin/orders` }, { text: "👥 المستخدمون", url: `${adminUrl}/admin/users` }],
    ]);
  } catch (e: any) {
    console.warn("[Telegram] Daily report failed:", e?.message);
  }
}

// ─── Weekly Report ────────────────────────────────────────────────────────────
export async function sendWeeklyReport(): Promise<void> {
  const adminChat = getAdminChatId();
  if (!adminChat) return;
  try {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [weekRev] = await db.select({ total: sum(ordersTable.totalPrice) })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, weekAgo)));
    const [weekOrders] = await db.select({ c: count() })
      .from(ordersTable).where(gte(ordersTable.createdAt, weekAgo));
    const [weekCompleted] = await db.select({ c: count() })
      .from(ordersTable).where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, weekAgo)));
    const [weekFailed] = await db.select({ c: count() })
      .from(ordersTable).where(and(eq(ordersTable.status, "failed"), gte(ordersTable.createdAt, weekAgo)));
    const [weekUsers] = await db.select({ c: count() })
      .from(usersTable).where(and(eq(usersTable.role, "user"), gte(usersTable.createdAt, weekAgo)));
    const [pendingPay] = await db.select({ c: count() })
      .from(paymentsTable).where(eq(paymentsTable.status, "pending"));

    // Top 5 products by order count this week
    const topProducts = await db.select({
      name: ordersTable.productName,
      qty: count(),
      revenue: sum(ordersTable.totalPrice),
    })
      .from(ordersTable)
      .where(and(eq(ordersTable.status, "completed"), gte(ordersTable.createdAt, weekAgo)))
      .groupBy(ordersTable.productName)
      .orderBy(desc(count()))
      .limit(5);

    // Recent provider errors (last 7d)
    const [providerErrCount] = await db.select({ c: count() })
      .from(providerErrorsTable).where(gte(providerErrorsTable.createdAt, weekAgo));

    // Inactive products count (potential low-stock warning)
    const [inactiveProducts] = await db.select({ c: count() })
      .from(productsTable).where(eq(productsTable.status, "inactive"));

    // Provider balance (single-provider system; low-balance alert < $10)
    const providerBal = await fetchBalance().catch(() => null);

    const totalRev = parseFloat(weekRev?.total ?? "0").toFixed(2);
    const successRate = (weekOrders?.c ?? 0) > 0
      ? Math.round(((weekCompleted?.c ?? 0) * 100) / (weekOrders?.c ?? 1))
      : 0;

    let topLines = "—";
    if (topProducts.length > 0) {
      topLines = topProducts.map((p, i) =>
        `${i + 1}. ${escapeHtml(p.name)} — <b>${p.qty}</b> طلب • $${parseFloat(p.revenue ?? "0").toFixed(2)}`
      ).join("\n");
    }

    const alerts: string[] = [];
    if ((pendingPay?.c ?? 0) > 0) alerts.push(`💳 <b>${pendingPay?.c}</b> إيداع بانتظار المراجعة`);
    if ((providerErrCount?.c ?? 0) > 0) alerts.push(`⚠️ <b>${providerErrCount?.c}</b> خطأ من المزودين هذا الأسبوع`);
    if ((weekFailed?.c ?? 0) > 0) alerts.push(`❌ <b>${weekFailed?.c}</b> طلب فاشل هذا الأسبوع`);
    if ((inactiveProducts?.c ?? 0) > 50) alerts.push(`📦 <b>${inactiveProducts?.c}</b> منتج غير نشط (راجع المخزون)`);
    if (providerBal?.configured && providerBal.balanceUsd != null && providerBal.balanceUsd < 10) {
      const lbl = providerBal.displayName ?? providerBal.provider;
      alerts.push(`💵 رصيد ${escapeHtml(lbl)} منخفض: <b>$${providerBal.balanceUsd.toFixed(2)}</b>`);
    }

    const dateStr = `${weekAgo.toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus", day: "numeric", month: "short" })} → ${now.toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus", day: "numeric", month: "short" })}`;

    const msg =
      `📅 <b>التقرير الأسبوعي - Elite Store</b>\n` +
      `🗓 ${dateStr}\n\n` +
      `💰 <b>إيرادات الأسبوع:</b> $${totalRev}\n` +
      `🛒 <b>إجمالي الطلبات:</b> ${weekOrders?.c ?? 0}\n` +
      `✅ <b>منجز:</b> ${weekCompleted?.c ?? 0}  •  ❌ <b>فاشل:</b> ${weekFailed?.c ?? 0}\n` +
      `📈 <b>نسبة النجاح:</b> ${successRate}%\n` +
      `👥 <b>مستخدمون جدد:</b> ${weekUsers?.c ?? 0}\n\n` +
      `🏆 <b>أعلى المبيعات:</b>\n${topLines}\n\n` +
      (alerts.length > 0 ? `🚨 <b>تنبيهات تتطلب انتباهك:</b>\n• ${alerts.join("\n• ")}\n\n` : `✨ <b>لا توجد تنبيهات عاجلة</b>\n\n`) +
      `🔗 <a href="${getAdminUrl()}/admin">لوحة التحكم</a>`;

    const adminUrl = getAdminUrl();
    await sendMessage(adminChat, msg, [
      [{ text: "📊 لوحة التحكم", url: `${adminUrl}/admin` }, { text: "📦 الطلبات", url: `${adminUrl}/admin/orders` }],
      [{ text: "💳 الإيداعات", url: `${adminUrl}/admin/payments` }, { text: "⚠️ أخطاء المزودين", url: `${adminUrl}/admin/provider-errors` }],
    ]);
  } catch (e: any) {
    console.warn("[Telegram] Weekly report failed:", e?.message);
  }
}

export async function notifyVipChange(params: {
  username: string;
  publicCode?: string | null;
  oldLevel: number;
  newLevel: number;
  locked: boolean;
  adminUsername: string;
}): Promise<void> {
  const arrow = params.newLevel > params.oldLevel ? "⬆️ ترقية" : params.newLevel < params.oldLevel ? "⬇️ تخفيض" : "🔄 تحديث";
  const msg =
    `👑 <b>${arrow} مستوى VIP من قبل الإدارة</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    (params.publicCode ? `🆔 الكود: <code>${escapeHtml(params.publicCode)}</code>\n` : "") +
    `📊 المستوى: <b>VIP ${params.oldLevel}</b> → <b>VIP ${params.newLevel}</b>\n` +
    `🔒 مقفل يدوياً: ${params.locked ? "نعم" : "لا (تلقائي)"}\n` +
    `🛡 المنفّذ: <b>${escapeHtml(params.adminUsername)}</b>\n` +
    `⏱ ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;

  await sendMessage(getAdminChatId(), msg, [
    [{ text: "👥 المستخدمون", url: `${getAdminUrl()}/admin/users` }],
  ]);
}

export async function notifyBalanceChange(params: {
  username: string;
  publicCode?: string | null;
  operation: "add" | "subtract" | "set";
  amount: number;
  newBalance: number;
  reason?: string;
  adminUsername: string;
}): Promise<void> {
  const opLabel = params.operation === "add" ? "➕ إضافة" : params.operation === "subtract" ? "➖ خصم" : "🔧 تحديد";
  const msg =
    `💰 <b>${opLabel} رصيد من قبل الإدارة</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    (params.publicCode ? `🆔 الكود: <code>${escapeHtml(params.publicCode)}</code>\n` : "") +
    `💵 المبلغ: <b>${params.amount.toFixed(2)} USD</b>\n` +
    `💼 الرصيد الجديد: <b>${params.newBalance.toFixed(2)} USD</b>\n` +
    (params.reason ? `📝 السبب: <i>${escapeHtml(params.reason)}</i>\n` : "") +
    `🛡 المنفّذ: <b>${escapeHtml(params.adminUsername)}</b>\n` +
    `⏱ ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;

  await sendMessage(getAdminChatId(), msg, [
    [{ text: "👥 المستخدمون", url: `${getAdminUrl()}/admin/users` }],
  ]);
}

export async function notifyLoyaltyRedeem(params: {
  username: string;
  points: number;
  usdAdded: number;
}): Promise<void> {
  const msg =
    `🎁 <b>استبدال نقاط ولاء</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `⭐ النقاط المستبدلة: <b>${params.points}</b>\n` +
    `💵 الرصيد المضاف: <b>${params.usdAdded.toFixed(2)} USD</b>`;

  await sendMessage(getAdminChatId(), msg).catch(() => {});
}

export async function notifyDepositApproved(params: {
  username: string;
  amountUsd: number;
}): Promise<void> {
  const msg =
    `✅ <b>تم قبول الإيداع وإضافته للرصيد</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `💵 المبلغ المضاف: <b>${params.amountUsd.toFixed(2)} USD</b>`;

  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "📊 الإحصائيات", callback_data: "stats" },
      { text: "👥 المستخدمون", url: `${getAdminUrl()}/admin/users` },
    ],
  ]);
}

// ─── New notifications: API outage / login fail / stuck order ─────────────────

export async function notifyAdminLoginFailed(params: {
  username: string;
  ip: string;
  userAgent?: string;
  attempts?: number;
}): Promise<void> {
  const msg =
    `🚨 <b>محاولة دخول فاشلة لحساب أدمن</b>\n\n` +
    `👤 الحساب: <b>${escapeHtml(params.username)}</b>\n` +
    `📡 IP: <code>${escapeHtml(params.ip)}</code>\n` +
    (params.userAgent ? `🖥 المتصفح: <code>${escapeHtml(params.userAgent.slice(0, 80))}</code>\n` : "") +
    (params.attempts ? `🔁 عدد المحاولات الأخيرة: <b>${params.attempts}</b>\n` : "") +
    `⏱ ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;
  await sendMessage(getAdminChatId(), msg, [
    [{ text: "👥 المستخدمون", url: `${getAdminUrl()}/admin/users` }],
  ]);
}

export async function notifyApiOutage(params: {
  provider: string;
  operation: string;
  error: string;
}): Promise<void> {
  const msg =
    `🛑 <b>انقطاع في API المورّد</b>\n\n` +
    `🏢 المورّد: <b>${escapeHtml(params.provider)}</b>\n` +
    `🔧 العملية: <code>${escapeHtml(params.operation)}</code>\n` +
    `⚠️ الخطأ: <i>${escapeHtml(params.error.slice(0, 200))}</i>\n\n` +
    `سيقوم النظام بإعادة المحاولة تلقائياً. الرجاء التحقق من حالة المورّد.`;
  await sendMessage(getAdminChatId(), msg, [
    [{ text: "⚙️ الإعدادات", url: `${getAdminUrl()}/admin/settings` }],
    [{ text: "📜 سجل أخطاء المورّد", url: `${getAdminUrl()}/admin/provider-errors` }],
  ]);
}

export async function notifyStuckOrder(params: {
  orderId: string;
  productName: string;
  username: string;
  minutes: number;
}): Promise<void> {
  const msg =
    `⏰ <b>طلب عالق منذ ${params.minutes} دقيقة</b>\n\n` +
    `👤 المستخدم: <b>${escapeHtml(params.username)}</b>\n` +
    `📦 المنتج: <b>${escapeHtml(params.productName)}</b>\n` +
    `🆔 رقم الطلب: <code>${escapeHtml(params.orderId)}</code>\n\n` +
    `يحتاج مراجعة يدوية أو إعادة محاولة.`;
  await sendMessage(getAdminChatId(), msg, [
    [
      { text: "✅ تنفيذ الطلب", callback_data: `approve_order:${params.orderId}` },
      { text: "🚫 رفض واسترجاع", callback_data: `reject_order:${params.orderId}` },
    ],
    [{ text: "📋 لوحة الطلبات", url: `${getAdminUrl()}/admin/orders` }],
  ]);
}

// ─── Payment approve/reject from Telegram ─────────────────────────────────────
async function handlePaymentAction(paymentId: number, action: "approve" | "reject"): Promise<string> {
  if (!Number.isFinite(paymentId)) return "❌ معرّف الإيداع غير صالح.";
  try {
    const { approvePaymentById, rejectPaymentById } = await import("./payment-actions");
    const r = action === "approve"
      ? await approvePaymentById(paymentId, { username: "telegram-admin" })
      : await rejectPaymentById(paymentId, "Rejected from Telegram", { username: "telegram-admin" });
    if (!r.ok) return `⚠️ ${escapeHtml(r.reason)}`;
    if (action === "approve") {
      return `✅ تمت الموافقة على إيداع <b>${escapeHtml(r.username ?? "")}</b> بقيمة <b>${r.amount} ${escapeHtml(r.currency)}</b> وأُضيف للمحفظة.`;
    }
    return `🚫 تم رفض إيداع <b>${escapeHtml(r.username ?? "")}</b>.`;
  } catch (e: any) {
    return `⚠️ خطأ: ${escapeHtml(e?.message?.slice(0, 100) ?? "unknown")}`;
  }
}

async function renderUserCard(userId: number): Promise<string> {
  const [u] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!u) return "❌ المستخدم غير موجود.";
  const balance = parseFloat(u.balance ?? "0");
  return `👤 <b>${escapeHtml(u.username)}</b>\n` +
    `📧 <code>${escapeHtml(u.email)}</code>\n` +
    `🆔 <code>${escapeHtml(u.publicCode ?? String(u.id))}</code>\n` +
    `💰 الرصيد: <b>$${balance.toFixed(2)}</b>\n` +
    `🛡 الدور: <b>${escapeHtml(u.role)}</b>\n` +
    `${u.isSuspended ? "🚫 موقوف" : "✅ نشط"}\n` +
    `📅 تاريخ التسجيل: ${new Date(u.createdAt).toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`;
}

// ─── /stuck — pending orders > 10 min ─────────────────────────────────────────
async function renderStuckOrders(): Promise<string> {
  const cutoff = new Date(Date.now() - 10 * 60 * 1000);
  const rows = await db
    .select({
      id: ordersTable.id,
      productName: ordersTable.productName,
      createdAt: ordersTable.createdAt,
      totalPrice: ordersTable.totalPrice,
      userId: ordersTable.userId,
    })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "processing"), sql`${ordersTable.createdAt} < ${cutoff}`))
    .orderBy(desc(ordersTable.createdAt))
    .limit(15);

  if (rows.length === 0) return "✅ <b>لا يوجد طلبات عالقة</b>\n\nكل الطلبات ضمن النطاق الطبيعي (أقل من 10 دقائق).";

  let text = `⏰ <b>الطلبات العالقة (${rows.length})</b>\n\n`;
  for (const o of rows) {
    const mins = Math.round((Date.now() - new Date(o.createdAt).getTime()) / 60000);
    text += `• <code>${escapeHtml(o.id.slice(0, 8))}</code> · ${escapeHtml(o.productName ?? "?")} · منذ ${mins}د\n`;
  }
  return text;
}

// ─── /status — overall system health ──────────────────────────────────────────
async function renderSystemStatus(): Promise<string> {
  const lines: string[] = [`🩺 <b>حالة النظام</b>\n`];

  // Bot health
  const bh = getBotHealth();
  lines.push(`🤖 البوت: ${bh.healthy ? "🟢 متصل" : "🔴 منقطع"}`);
  lines.push(`📨 المرسَلة: ${bh.totalSent} | الفاشلة: ${bh.totalFailed} | الطابور: ${bh.queueSize}`);

  // Provider
  try {
    const { fetchBalance, getProviderConfig } = await import("./providers");
    const cfg = await getProviderConfig();
    lines.push(`\n🏢 المورّد: <b>${escapeHtml(cfg.displayName)}</b>`);
    lines.push(`🔌 الحالة: ${cfg.enabled ? "🟢 مفعّل" : "🔴 معطّل"}`);
    if (cfg.configured) {
      const b = await fetchBalance();
      if (b.balanceSyp != null) {
        lines.push(`💰 الرصيد: <b>${b.balanceSyp.toLocaleString("en-US")} ل.س</b>`);
      }
    }
  } catch (e: any) {
    lines.push(`🏢 المورّد: ⚠️ خطأ — ${escapeHtml(e?.message?.slice(0, 60) ?? "")}`);
  }

  // Orders pause state
  const paused = (await getSetting("orders_paused", "false")) === "true";
  lines.push(`\n🛒 استقبال الطلبات: ${paused ? "⏸ متوقّف" : "▶️ يعمل"}`);

  // Stuck orders count
  const cutoff = new Date(Date.now() - 10 * 60 * 1000);
  const [stuck] = await db.select({ c: count() }).from(ordersTable)
    .where(and(eq(ordersTable.status, "processing"), sql`${ordersTable.createdAt} < ${cutoff}`));
  lines.push(`⏰ طلبات عالقة (>10د): <b>${stuck?.c ?? 0}</b>`);

  // Pending payments
  const [pendingPay] = await db.select({ c: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending"));
  lines.push(`💳 إيداعات بانتظار المراجعة: <b>${pendingPay?.c ?? 0}</b>`);

  // DB OK if we got here
  lines.push(`\n💾 قاعدة البيانات: 🟢 تعمل`);
  lines.push(`⏱ ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`);

  return lines.join("\n");
}

// ─── /pause /resume — orders intake control ───────────────────────────────────
async function setOrdersPaused(paused: boolean): Promise<string> {
  await setSetting("orders_paused", paused ? "true" : "false");
  return paused
    ? "⏸ <b>تم إيقاف استقبال الطلبات.</b>\n\nلن يستطيع المستخدمون إنشاء طلبات جديدة حتى تعيد التشغيل بـ /resume."
    : "▶️ <b>تم استئناف استقبال الطلبات.</b>\n\nالموقع يستقبل طلبات جديدة الآن.";
}
