import { db, seasonalDiscountsTable, homeBannersTable } from "@workspace/db";
import { and, eq, lte, gte, sql } from "drizzle-orm";
import { logger } from "./logger";

const CHECK_INTERVAL_MS = 30 * 60 * 1000; // every 30 min
let started = false;

async function syncBanners(): Promise<void> {
  const now = new Date();

  // 1) Activate / banner-create for live discounts
  const live = await db.select().from(seasonalDiscountsTable)
    .where(and(eq(seasonalDiscountsTable.isActive, true), lte(seasonalDiscountsTable.startsAt, now), gte(seasonalDiscountsTable.endsAt, now)));

  for (const d of live) {
    if (!d.autoBanner) continue;
    const slug = `seasonal-${d.id}`;
    const exists = await db.select({ id: homeBannersTable.id }).from(homeBannersTable).where(eq(homeBannersTable.title, slug)).limit(1);
    if (exists.length === 0) {
      await db.insert(homeBannersTable).values({
        title: slug,
        titleAr: `${d.emoji ?? "🎉"} ${d.nameAr}`,
        subtitleAr: `خصم ${d.discountPercent}% — لفترة محدودة`,
        ctaTextAr: "تسوّق الآن",
        ctaHref: d.category ? `/games?category=${d.category}` : (d.productId ? `/product/${d.productId}` : "/products"),
        bgGradient: `linear-gradient(135deg, ${d.bannerColor ?? "#f59e0b"}, #1a1a2e)`,
        textColor: "#ffffff",
        isActive: true,
        sortOrder: 1,
      } as any).onConflictDoNothing?.() ?? null;
      logger.info({ id: d.id, name: d.nameAr }, "Seasonal discount banner created");
    }
  }

  // 2) Remove banners for expired/inactive discounts
  const expired = await db.select().from(seasonalDiscountsTable)
    .where(sql`(${seasonalDiscountsTable.isActive} = false OR ${seasonalDiscountsTable.endsAt} < ${now})`);

  for (const d of expired) {
    const slug = `seasonal-${d.id}`;
    await db.delete(homeBannersTable).where(eq(homeBannersTable.title, slug));
  }
}

async function runOnce(): Promise<void> {
  try {
    await syncBanners();
  } catch (err) {
    logger.warn({ err }, "Seasonal scheduler iteration failed");
  }
}

export function startSeasonalScheduler(): void {
  if (started) return;
  started = true;
  logger.info({ intervalMs: CHECK_INTERVAL_MS }, "Seasonal discounts scheduler started");
  runOnce();
  setInterval(runOnce, CHECK_INTERVAL_MS);
}

// Helper used by checkout to apply discount for a given category/product
export async function getActiveSeasonalDiscount(productId: string, category: string | null): Promise<number> {
  try {
    const now = new Date();
    const rows = await db.select({ discountPercent: seasonalDiscountsTable.discountPercent, productId: seasonalDiscountsTable.productId, category: seasonalDiscountsTable.category })
      .from(seasonalDiscountsTable)
      .where(and(eq(seasonalDiscountsTable.isActive, true), lte(seasonalDiscountsTable.startsAt, now), gte(seasonalDiscountsTable.endsAt, now)));

    let best = 0;
    for (const r of rows) {
      const matches = (r.productId && r.productId === productId) || (r.category && r.category === category) || (!r.productId && !r.category);
      if (matches) {
        const pct = Number(r.discountPercent ?? 0);
        if (pct > best) best = pct;
      }
    }
    return best;
  } catch {
    return 0;
  }
}
