import { db, ordersTable, usersTable } from "@workspace/db";
import { and, eq, lt, isNull } from "drizzle-orm";
import { logger } from "./logger";
import { notifyStuckOrder } from "./telegram";

const STUCK_THRESHOLD_MS = 10 * 60 * 1000;
const CHECK_INTERVAL_MS = 2 * 60 * 1000;

const alreadyAlerted = new Set<string>();

export async function runStuckCheck(): Promise<void> {
  try {
    const cutoff = new Date(Date.now() - STUCK_THRESHOLD_MS);
    const stuck = await db
      .select({
        id: ordersTable.id,
        productName: ordersTable.productName,
        userId: ordersTable.userId,
        createdAt: ordersTable.createdAt,
        totalPrice: ordersTable.totalPrice,
      })
      .from(ordersTable)
      .where(and(
        eq(ordersTable.status, "processing"),
        lt(ordersTable.createdAt, cutoff),
      ))
      .limit(20);

    for (const o of stuck) {
      if (alreadyAlerted.has(o.id)) continue;
      alreadyAlerted.add(o.id);
      const [u] = await db.select({ username: usersTable.username }).from(usersTable).where(eq(usersTable.id, o.userId));
      const minutes = Math.round((Date.now() - new Date(o.createdAt).getTime()) / 60000);
      notifyStuckOrder({
        orderId: o.id,
        productName: o.productName ?? "?",
        username: u?.username ?? String(o.userId),
        minutes,
      }).catch(() => {});
    }

    if (alreadyAlerted.size > 500) {
      const arr = Array.from(alreadyAlerted).slice(-300);
      alreadyAlerted.clear();
      arr.forEach(id => alreadyAlerted.add(id));
    }
  } catch (e: any) {
    logger.warn({ err: e?.message }, "Stuck order check failed");
  }
}

export function startStuckMonitor(): void {
  setTimeout(() => {
    runStuckCheck();
    setInterval(() => { runStuckCheck(); }, CHECK_INTERVAL_MS);
  }, 30_000);
  logger.info(`Stuck order monitor scheduled (every ${CHECK_INTERVAL_MS / 1000}s, threshold ${STUCK_THRESHOLD_MS / 60000}min)`);
}
