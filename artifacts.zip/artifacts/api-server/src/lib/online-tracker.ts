// In-memory tracker for "online now" — counts unique IPs/sessions seen in last 5 minutes.
const ACTIVE_WINDOW_MS = 5 * 60 * 1000;
const seen = new Map<string, number>();

export function trackVisitor(key: string): void {
  if (!key) return;
  seen.set(key, Date.now());
}

export function getOnlineCount(): number {
  const cutoff = Date.now() - ACTIVE_WINDOW_MS;
  let live = 0;
  for (const [k, ts] of seen) {
    if (ts < cutoff) seen.delete(k);
    else live++;
  }
  // Floor of 3 so the bar always shows life
  return Math.max(live, 3);
}
