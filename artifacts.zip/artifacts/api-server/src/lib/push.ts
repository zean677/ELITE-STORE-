import webpush from "web-push";
import { db, settingsTable, pushSubscriptionsTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";
import { logger } from "./logger";

let initialized = false;
let publicKey = "";
let privateKey = "";

async function loadOrGenerateKeys(): Promise<void> {
  const rows = await db.select().from(settingsTable).where(inArray(settingsTable.key, ["vapid_public_key", "vapid_private_key", "vapid_subject"]));
  const map = new Map(rows.map((r) => [r.key, r.value as string]));
  publicKey = map.get("vapid_public_key") || process.env.VAPID_PUBLIC_KEY || "";
  privateKey = map.get("vapid_private_key") || process.env.VAPID_PRIVATE_KEY || "";
  let subject = map.get("vapid_subject") || process.env.VAPID_SUBJECT || "mailto:admin@elitestore.local";
  if (!publicKey || !privateKey) {
    const k = webpush.generateVAPIDKeys();
    publicKey = k.publicKey;
    privateKey = k.privateKey;
    await db.insert(settingsTable).values({ key: "vapid_public_key", value: publicKey }).onConflictDoUpdate({ target: settingsTable.key, set: { value: publicKey } });
    await db.insert(settingsTable).values({ key: "vapid_private_key", value: privateKey }).onConflictDoUpdate({ target: settingsTable.key, set: { value: privateKey } });
    await db.insert(settingsTable).values({ key: "vapid_subject", value: subject }).onConflictDoUpdate({ target: settingsTable.key, set: { value: subject } });
    logger.info("Generated new VAPID keys for push notifications");
  }
  webpush.setVapidDetails(subject, publicKey, privateKey);
}

export async function initPush(): Promise<void> {
  if (initialized) return;
  try {
    await loadOrGenerateKeys();
    initialized = true;
  } catch (err) {
    logger.warn({ err }, "Push init failed");
  }
}

export function getPublicKey(): string { return publicKey; }
export function isPushReady(): boolean { return initialized && !!publicKey && !!privateKey; }

export interface PushPayload {
  title: string;
  body: string;
  url?: string;
  tag?: string;
}

export async function sendPushToUser(userId: number, payload: PushPayload): Promise<{ ok: number; failed: number }> {
  if (!isPushReady()) await initPush();
  if (!isPushReady()) return { ok: 0, failed: 0 };
  const subs = await db.select().from(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.userId, userId));
  let ok = 0, failed = 0;
  const dead: number[] = [];
  for (const s of subs) {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
      );
      ok++;
    } catch (err: any) {
      failed++;
      const code = err?.statusCode || 0;
      if (code === 404 || code === 410) dead.push(s.id);
      else logger.warn({ err: err?.message, code, userId }, "Push send failed");
    }
  }
  if (dead.length > 0) {
    try { await db.delete(pushSubscriptionsTable).where(inArray(pushSubscriptionsTable.id, dead)); } catch {}
  }
  return { ok, failed };
}

export async function sendPushToAll(payload: PushPayload): Promise<{ ok: number; failed: number; total: number }> {
  if (!isPushReady()) await initPush();
  if (!isPushReady()) return { ok: 0, failed: 0, total: 0 };
  const subs = await db.select().from(pushSubscriptionsTable);
  let ok = 0, failed = 0;
  const dead: number[] = [];
  for (const s of subs) {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
      );
      ok++;
    } catch (err: any) {
      failed++;
      const code = err?.statusCode || 0;
      if (code === 404 || code === 410) dead.push(s.id);
    }
  }
  if (dead.length > 0) {
    try { await db.delete(pushSubscriptionsTable).where(inArray(pushSubscriptionsTable.id, dead)); } catch {}
  }
  return { ok, failed, total: subs.length };
}
