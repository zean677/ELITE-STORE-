import { db, scheduledNotificationsTable, notificationsTable, usersTable } from "@workspace/db";
import { and, eq, lte, isNull, ne } from "drizzle-orm";
import { logger } from "./logger";

async function processDueNotifications(): Promise<void> {
  const now = new Date();
  const due = await db.select().from(scheduledNotificationsTable).where(and(
    eq(scheduledNotificationsTable.status, "scheduled"),
    isNull(scheduledNotificationsTable.sentAt),
    ne(scheduledNotificationsTable.cancelled, "yes"),
    lte(scheduledNotificationsTable.sendAt, now),
  ));

  for (const job of due) {
    const [claimed] = await db.update(scheduledNotificationsTable)
      .set({ status: "processing", processingAt: new Date(), errorMessage: null })
      .where(and(
        eq(scheduledNotificationsTable.id, job.id),
        eq(scheduledNotificationsTable.status, "scheduled"),
        isNull(scheduledNotificationsTable.sentAt),
        ne(scheduledNotificationsTable.cancelled, "yes"),
      ))
      .returning({ id: scheduledNotificationsTable.id });
    if (!claimed) continue;

    try {
      if (job.targetUserId) {
        const [recipient] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.id, job.targetUserId));
        if (!recipient) throw new Error(`Target user ${job.targetUserId} not found`);
        await db.insert(notificationsTable).values({
          userId: job.targetUserId, type: job.type, title: job.title, message: job.message, isRead: false,
        });
      } else {
        const allUsers = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.role, "user"));
        if (allUsers.length > 0) {
          await db.insert(notificationsTable).values(
            allUsers.map(u => ({ userId: u.id, type: job.type, title: job.title, message: job.message, isRead: false }))
          );
        }
      }
      await db.update(scheduledNotificationsTable)
        .set({ status: "sent", sentAt: new Date(), errorMessage: null })
        .where(and(eq(scheduledNotificationsTable.id, job.id), eq(scheduledNotificationsTable.status, "processing")));
      logger.info({ id: job.id, target: job.targetUserId ?? "all" }, "Scheduled notification sent");
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      await db.update(scheduledNotificationsTable)
        .set({ status: "failed", errorMessage: errorMessage.slice(0, 1000) })
        .where(and(eq(scheduledNotificationsTable.id, job.id), eq(scheduledNotificationsTable.status, "processing")))
        .catch(() => {});
      logger.error({ err, id: job.id }, "Failed to send scheduled notification");
    }
  }
}

export function startScheduledNotifications(): void {
  const ONE_MIN = 60 * 1000;
  setInterval(() => { processDueNotifications().catch(() => {}); }, ONE_MIN);
  logger.info("Scheduled notifications worker started");
}
