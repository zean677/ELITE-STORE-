import { db, paymentsTable, usersTable, walletTransactionsTable, notificationsTable, settingsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { emitPaymentApproved } from "./ws";
import { logger } from "./logger";

export type PaymentActionResult =
  | { ok: true; status: "approved" | "rejected"; username?: string; amount: number; currency: string }
  | { ok: false; reason: string };

async function getRate(key: string, def: string): Promise<number> {
  const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  const v = parseFloat(row?.value ?? def);
  return Number.isFinite(v) ? v : parseFloat(def);
}

export async function approvePaymentById(
  paymentId: number,
  actor: { id?: number; username: string } = { username: "telegram-bot" },
): Promise<PaymentActionResult> {
  const [existing] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, paymentId));
  if (!existing) return { ok: false, reason: "Payment not found" };
  if (existing.status !== "pending") return { ok: false, reason: `Payment already ${existing.status}` };

  const [payment] = await db
    .update(paymentsTable)
    .set({ status: "approved", adminNote: `Approved by ${actor.username}` })
    .where(and(eq(paymentsTable.id, paymentId), eq(paymentsTable.status, "pending")))
    .returning();
  if (!payment) return { ok: false, reason: "Payment was just modified by someone else" };

  const amountRaw = parseFloat(payment.amount ?? "0");
  const sypRate = await getRate("syp_rate", "13000");
  const eurRate = await getRate("eur_rate", "0.92");
  const usd = payment.currency === "SYP" ? amountRaw / sypRate
    : payment.currency === "EUR" ? amountRaw / eurRate
    : amountRaw;

  await db.update(usersTable)
    .set({ balance: sql`${usersTable.balance} + ${usd.toString()}` })
    .where(eq(usersTable.id, payment.userId));

  await db.insert(walletTransactionsTable).values({
    userId: payment.userId,
    type: "deposit",
    amount: usd.toString(),
    currency: "USD",
    description: `إيداع عبر ${payment.method} (${payment.currency} ${payment.amount})`,
  });

  await db.insert(notificationsTable).values({
    userId: payment.userId,
    type: "payment_approved",
    title: "✅ تمت الموافقة على الدفعة",
    message: `تمت الموافقة على إيداعك بقيمة ${payment.currency} ${parseFloat(payment.amount ?? "0").toLocaleString()} وإضافته لمحفظتك. (≈ $${usd.toFixed(2)})`,
    isRead: false,
  });

  const [u] = await db.select({ username: usersTable.username }).from(usersTable).where(eq(usersTable.id, payment.userId));
  const username = u?.username ?? String(payment.userId);

  emitPaymentApproved({
    id: payment.id,
    username,
    amount: usd,
    currency: "USD",
  });

  logger.info({ paymentId, actor: actor.username, usd }, "Payment approved");
  return { ok: true, status: "approved", username, amount: amountRaw, currency: payment.currency ?? "USD" };
}

export async function rejectPaymentById(
  paymentId: number,
  reason: string | undefined,
  actor: { id?: number; username: string } = { username: "telegram-bot" },
): Promise<PaymentActionResult> {
  const [existing] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, paymentId));
  if (!existing) return { ok: false, reason: "Payment not found" };
  if (existing.status !== "pending") return { ok: false, reason: `Payment already ${existing.status}` };

  const note = reason ? `Rejected by ${actor.username}: ${reason}` : `Rejected by ${actor.username}`;
  const [payment] = await db
    .update(paymentsTable)
    .set({ status: "rejected", adminNote: note })
    .where(and(eq(paymentsTable.id, paymentId), eq(paymentsTable.status, "pending")))
    .returning();
  if (!payment) return { ok: false, reason: "Payment was just modified by someone else" };

  await db.insert(notificationsTable).values({
    userId: payment.userId,
    type: "payment_approved",
    title: "🚫 تم رفض الإيداع",
    message: reason
      ? `تم رفض إيداعك بقيمة ${payment.currency} ${parseFloat(payment.amount ?? "0").toLocaleString()}. السبب: ${reason}`
      : `تم رفض إيداعك بقيمة ${payment.currency} ${parseFloat(payment.amount ?? "0").toLocaleString()}.`,
    isRead: false,
  });

  const [u] = await db.select({ username: usersTable.username }).from(usersTable).where(eq(usersTable.id, payment.userId));
  logger.info({ paymentId, actor: actor.username, reason }, "Payment rejected");
  return { ok: true, status: "rejected", username: u?.username, amount: parseFloat(payment.amount ?? "0"), currency: payment.currency ?? "USD" };
}
