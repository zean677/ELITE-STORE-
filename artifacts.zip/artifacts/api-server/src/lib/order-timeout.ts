import { db, ordersTable, productsTable, usersTable, notificationsTable, walletTransactionsTable, settingsTable } from "@workspace/db";
import { and, eq, sql, lt } from "drizzle-orm";
import { logger } from "./logger";
import { notifyOrderFailed } from "./telegram";
import { emitOrderUpdate } from "./ws";

// Auto-cancel orders that have been "processing" longer than the configured
// timeout. Refunds the user's wallet and notifies the buyer + admin.
//
// Configurable via the `order_timeout_minutes` setting (default 30 minutes).
// Runs every 5 minutes.

const CHECK_INTERVAL_MS = 5 * 60 * 1000;
let started = false;

async function getTimeoutMinutes(): Promise<number> {
  try {
    const [row] = await db.select().from(settingsTable).where(eq(settingsTable.key, "order_timeout_minutes"));
    const v = parseInt(row?.value ?? "30", 10);
    return Number.isFinite(v) && v > 0 ? v : 30;
  } catch {
    return 30;
  }
}

async function sweepTimeouts(): Promise<void> {
  const mins = await getTimeoutMinutes();
  const cutoff = new Date(Date.now() - mins * 60 * 1000);

  const stuck = await db
    .select({
      id: ordersTable.id,
      userId: ordersTable.userId,
      productId: ordersTable.productId,
      productName: ordersTable.productName,
      qty: ordersTable.qty,
      totalPrice: ordersTable.totalPrice,
    })
    .from(ordersTable)
    .where(and(eq(ordersTable.status, "processing"), lt(ordersTable.createdAt, cutoff)))
    .limit(50);

  if (stuck.length === 0) return;

  for (const order of stuck) {
    try {
      // Atomically flip to "failed" so we never refund twice
      const [updated] = await db
        .update(ordersTable)
        .set({
          status: "failed",
          lastDispatchError: `Auto-cancelled after ${mins}min timeout`,
          updatedAt: new Date(),
        })
        .where(and(eq(ordersTable.id, order.id), eq(ordersTable.status, "processing")))
        .returning();
      if (!updated) continue;

      const refundUsd = parseFloat(order.totalPrice ?? "0");
      if (refundUsd > 0) {
        await db
          .update(usersTable)
          .set({ balance: sql`${usersTable.balance} + ${refundUsd.toString()}` })
          .where(eq(usersTable.id, order.userId));
        await db.insert(walletTransactionsTable).values({
          userId: order.userId,
          type: "refund",
          amount: refundUsd.toString(),
          currency: "USD",
          description: `Auto-refund: order timed out after ${mins}min — ${order.productName} x${order.qty}`,
        });
      }

      await db.insert(notificationsTable).values({
        userId: order.userId,
        type: "order_failed",
        title: "⏰ تم إلغاء طلبك بسبب التأخير — تم إرجاع الرصيد",
        message: `طلبك لـ ${order.productName} استغرق وقتاً أطول من المعتاد ولم ينفّذه المورّد. تم إرجاع المبلغ تلقائياً إلى محفظتك.`,
        isRead: false,
      });

      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, order.userId));
      if (user) {
        notifyOrderFailed({
          username: user.username,
          productName: order.productName ?? "",
          orderId: order.id,
          error: `Auto-cancelled after ${mins}min timeout`,
        }).catch(() => {});
        emitOrderUpdate(order.id, "failed", order.productName ?? "", user.username, refundUsd);
      }

      logger.info({ orderId: order.id, refundUsd, mins }, "Order auto-cancelled by timeout sweeper");
    } catch (e) {
      logger.warn({ err: e, orderId: order.id }, "Failed to auto-cancel timed-out order");
    }
  }
}

export function startOrderTimeoutSweeper(): void {
  if (started) return;
  started = true;
  logger.info({ intervalMs: CHECK_INTERVAL_MS }, "Order timeout sweeper started (5min cadence)");
  setInterval(() => {
    sweepTimeouts().catch(err => logger.warn({ err }, "Timeout sweeper iteration failed"));
  }, CHECK_INTERVAL_MS);
}
