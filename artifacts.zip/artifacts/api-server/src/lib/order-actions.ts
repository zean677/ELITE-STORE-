import { db, ordersTable, productsTable, usersTable, notificationsTable, walletTransactionsTable, settingsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { dispatchToProvider } from "../routes/orders";
import { applyCompletedOrderSpend } from "./vip";
import { notifyOrderSuccess, notifyOrderFailed, notifyLowStock } from "./telegram";
import { emitOrderUpdate } from "./ws";
import { logAdminAction } from "../routes/admin";
import { logger } from "./logger";

const MAX_RETRIES = 2;        // total of 3 attempts (initial + 2 retries)
const RETRY_DELAY_MS = 5 * 60 * 1000; // 5 minutes between retries

// A transient error is one we should retry: network failures, timeouts, 5xx.
// 4xx (bad request, not found, unauthorized) are NOT transient — they need admin attention.
function isTransientError(errorMsg: string | undefined): boolean {
  if (!errorMsg) return true; // unknown error → assume transient
  const lower = errorMsg.toLowerCase();
  // Match "Provider returned 5xx" or generic network errors
  if (/provider returned 4\d\d/i.test(errorMsg)) return false;
  if (/provider returned (5\d\d|unknown)/i.test(errorMsg)) return true;
  if (lower.includes("timeout") || lower.includes("network") || lower.includes("fetch failed") || lower.includes("econnrefused") || lower.includes("aborted")) return true;
  return true; // default to transient (safer for user — admin can manually reject if needed)
}

export type OrderActionResult =
  | { ok: true; status: "completed" | "failed" | "retry_scheduled"; productName: string; username?: string }
  | { ok: false; reason: string };

export async function approveOrderById(
  orderId: string,
  actor: { id?: number; username: string } = { username: "telegram-bot" },
  options: { deliveryMessage?: string } = {},
): Promise<OrderActionResult> {
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
  if (!order) return { ok: false, reason: "Order not found" };
  if (order.status !== "processing" && order.status !== "pending") {
    return { ok: false, reason: `Order already ${order.status}` };
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, order.productId));
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, order.userId));
  const priceUsd = product ? parseFloat(product.priceUsd ?? "0") * order.qty : parseFloat(order.totalPrice ?? "0");
  const provider = product?.provider ?? "manual";
  const deliveryMessage = options.deliveryMessage?.trim() || undefined;

  // For manual products with a delivery message, skip provider dispatch — admin is delivering by hand.
  let dispatch: { success: boolean; providerOrderId?: string; error?: string } = { success: true };
  if (!deliveryMessage && product && provider !== "manual") {
    // ── Profit Margin Enforcer ──
    // Refuse to dispatch if our selling price is below the upstream cost.
    // The admin can override per-product by setting `enforce_profit_margin=false`.
    try {
      const [enforceRow] = await db.select().from(settingsTable)
        .where(eq(settingsTable.key, "enforce_profit_margin"));
      const enforce = (enforceRow?.value ?? "true").toLowerCase() !== "false";
      const sellUsd = parseFloat(product.priceUsd ?? "0");
      const costUsd = parseFloat(product.unitPriceUsd ?? "0");
      if (enforce && costUsd > 0 && sellUsd > 0 && sellUsd < costUsd) {
        // Auto-deactivate the product so further orders can't be placed
        await db.update(productsTable)
          .set({ status: "inactive", updatedAt: new Date() })
          .where(eq(productsTable.id, product.id));
        const errMsg = `Profit margin negative: sell $${sellUsd.toFixed(4)} < cost $${costUsd.toFixed(4)}`;
        logger.warn({ orderId, productId: product.id, sellUsd, costUsd }, "Profit Margin Enforcer blocked dispatch — product auto-deactivated");
        // Try import dynamically to avoid potential circular import in some build orders
        try {
          const { notifyApiOutage } = await import("./telegram");
          notifyApiOutage({
            provider,
            operation: "profit_margin_enforcer",
            error: `Product ${product.name} disabled: ${errMsg}`,
          }).catch(() => {});
        } catch { /* ignore */ }
        dispatch = { success: false, error: errMsg };
      } else {
        dispatch = await dispatchToProvider(order, product);
      }
    } catch (e) {
      // If the margin check itself fails, fall through to dispatch (don't block customer)
      dispatch = await dispatchToProvider(order, product);
    }
  }

  if (dispatch.success) {
    await db.update(ordersTable)
      .set({
        status: "completed",
        providerOrderId: dispatch.providerOrderId ?? order.providerOrderId,
        deliveredCode: deliveryMessage ?? order.deliveredCode ?? null,
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(ordersTable.id, orderId));
    await applyCompletedOrderSpend(order.userId, priceUsd, orderId);
    await db.insert(notificationsTable).values({
      userId: order.userId,
      type: "order_completed",
      title: "✅ تم تنفيذ طلبك",
      message: deliveryMessage
        ? `تم تنفيذ طلبك لـ ${order.productName} (x${order.qty}).\n\n📩 رسالة من الإدارة:\n${deliveryMessage}`
        : `تم تنفيذ طلبك لـ ${order.productName} (x${order.qty}) بنجاح.`,
      isRead: false,
    });

    // Decrement stock and check low-stock alert
    if (product && product.stockQty !== null && product.stockQty !== undefined) {
      const newStock = Math.max(0, product.stockQty - order.qty);
      await db.update(productsTable).set({ stockQty: newStock, updatedAt: new Date() }).where(eq(productsTable.id, product.id));
      const threshold = product.lowStockThreshold ?? 5;
      if (newStock <= threshold) {
        notifyLowStock({ productName: product.name, productId: product.id, remaining: newStock }).catch(() => {});
      }
    }

    if (user) {
      notifyOrderSuccess({ username: user.username, productName: order.productName ?? "", orderId }).catch(() => {});
      emitOrderUpdate(orderId, "completed", order.productName ?? "", user.username, priceUsd);
    }
    if (actor.id) {
      logAdminAction({ adminId: actor.id, adminUsername: actor.username, action: "approve", entity: "order", entityId: orderId }).catch(() => {});
    }
    return { ok: true, status: "completed", productName: order.productName ?? "", username: user?.username };
  }

  // Provider failed → decide: schedule retry OR mark failed + refund
  const currentRetries = order.retryCount ?? 0;
  const transient = isTransientError(dispatch.error);

  if (transient && currentRetries < MAX_RETRIES) {
    // Schedule an automatic retry — keep the order in 'processing', don't refund yet
    const nextRetryAt = new Date(Date.now() + RETRY_DELAY_MS);
    await db.update(ordersTable).set({
      status: "processing",
      retryCount: currentRetries + 1,
      nextRetryAt,
      lastDispatchError: (dispatch.error ?? "Unknown").slice(0, 500),
      updatedAt: new Date(),
    }).where(eq(ordersTable.id, orderId));

    await db.insert(notificationsTable).values({
      userId: order.userId,
      type: "order_processing",
      title: "⏳ تأخّر بسيط في تنفيذ طلبك",
      message: `الموقع يعيد محاولة تنفيذ طلبك لـ ${order.productName} تلقائياً خلال 5 دقائق. لا داعي لأي إجراء.`,
      isRead: false,
    });
    if (user) {
      emitOrderUpdate(orderId, "processing", order.productName ?? "", user.username, priceUsd);
    }
    logger.info({ orderId, retryAttempt: currentRetries + 1, nextRetryAt, error: dispatch.error }, "Order dispatch failed — scheduled for retry");
    return { ok: true, status: "retry_scheduled", productName: order.productName ?? "", username: user?.username };
  }

  // Permanent failure (4xx error OR exhausted retries) → mark failed and refund
  await db.update(ordersTable).set({
    status: "failed",
    nextRetryAt: null,
    lastDispatchError: (dispatch.error ?? "Unknown").slice(0, 500),
    updatedAt: new Date(),
  }).where(eq(ordersTable.id, orderId));
  await db.update(usersTable).set({ balance: sql`${usersTable.balance} + ${priceUsd.toString()}` }).where(eq(usersTable.id, order.userId));
  await db.insert(walletTransactionsTable).values({
    userId: order.userId,
    type: "refund",
    amount: priceUsd.toString(),
    currency: "USD",
    description: `Refund: provider dispatch failed for ${order.productName} x${order.qty}${currentRetries > 0 ? ` (after ${currentRetries + 1} attempts)` : ""}`,
  });
  await db.insert(notificationsTable).values({
    userId: order.userId,
    type: "order_failed",
    title: "❌ فشل تنفيذ الطلب — تم إرجاع الرصيد",
    message: `فشل تنفيذ طلبك لـ ${order.productName}${currentRetries > 0 ? ` بعد عدة محاولات` : ""}. تم إرجاع المبلغ تلقائياً إلى محفظتك.`,
    isRead: false,
  });
  if (user) {
    notifyOrderFailed({ username: user.username, productName: order.productName ?? "", orderId, error: dispatch.error }).catch(() => {});
    emitOrderUpdate(orderId, "failed", order.productName ?? "", user.username, priceUsd);
  }
  return { ok: true, status: "failed", productName: order.productName ?? "", username: user?.username };
}

export async function rejectOrderById(
  orderId: string,
  reason: string | undefined,
  actor: { id?: number; username: string } = { username: "telegram-bot" },
): Promise<OrderActionResult> {
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
  if (!order) return { ok: false, reason: "Order not found" };
  if (order.status !== "processing" && order.status !== "pending") {
    return { ok: false, reason: `Order already ${order.status}` };
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, order.productId));
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, order.userId));
  const refundUsd = product ? parseFloat(product.priceUsd ?? "0") * order.qty : parseFloat(order.totalPrice ?? "0");

  await db.update(ordersTable).set({ status: "failed", updatedAt: new Date() }).where(eq(ordersTable.id, orderId));
  await db.update(usersTable).set({ balance: sql`${usersTable.balance} + ${refundUsd.toString()}` }).where(eq(usersTable.id, order.userId));
  await db.insert(walletTransactionsTable).values({
    userId: order.userId,
    type: "refund",
    amount: refundUsd.toString(),
    currency: "USD",
    description: reason ? `Refund (rejected): ${order.productName} — ${reason}` : `Refund (rejected): ${order.productName} x${order.qty}`,
  });
  await db.insert(notificationsTable).values({
    userId: order.userId,
    type: "order_failed",
    title: "❌ تم رفض طلبك — تم إرجاع الرصيد",
    message: reason
      ? `تم رفض طلبك لـ ${order.productName}. السبب: ${reason}. تم إرجاع المبلغ إلى محفظتك.`
      : `تم رفض طلبك لـ ${order.productName} وتم إرجاع المبلغ إلى محفظتك.`,
    isRead: false,
  });
  if (user) {
    notifyOrderFailed({ username: user.username, productName: order.productName ?? "", orderId, error: reason ?? "Rejected" }).catch(() => {});
    emitOrderUpdate(orderId, "failed", order.productName ?? "", user.username, refundUsd);
  }
  if (actor.id) {
    logAdminAction({ adminId: actor.id, adminUsername: actor.username, action: "reject", entity: "order", entityId: orderId, details: reason ? { reason } : undefined }).catch(() => {});
  }
  return { ok: true, status: "failed", productName: order.productName ?? "", username: user?.username };
}
