import { db, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { fetchBalance, getSypRate } from "./providers";
import { notifyLowProviderBalance } from "./telegram";
import { logger } from "./logger";

const lastAlertedAt = new Map<string, number>();
const ALERT_COOLDOWN_MS = 6 * 60 * 60 * 1000; // 6 hours between repeat alerts

async function getSypThreshold(): Promise<number> {
  const [automationRow] = await db.select().from(settingsTable).where(eq(settingsTable.key, "low_balance_threshold_syp"));
  const [row] = automationRow
    ? [automationRow]
    : await db.select().from(settingsTable).where(eq(settingsTable.key, "provider_balance_threshold_syp"));
  const v = parseFloat(row?.value ?? "100000");
  return Number.isFinite(v) && v > 0 ? v : 100000;
}

export async function runBalanceCheck(): Promise<void> {
  try {
    const thresholdSyp = await getSypThreshold();
    const sypRate = await getSypRate();
    const b = await fetchBalance();
    if (!b.configured || b.balanceSyp == null) return;
    if (b.balanceSyp <= thresholdSyp) {
      const now = Date.now();
      const last = lastAlertedAt.get(b.provider) ?? 0;
      if (now - last < ALERT_COOLDOWN_MS) return;
      lastAlertedAt.set(b.provider, now);
      const balanceUsd = sypRate > 0 ? b.balanceSyp / sypRate : 0;
      const thresholdUsd = sypRate > 0 ? thresholdSyp / sypRate : 0;
      notifyLowProviderBalance({
        provider: b.provider,
        balance: balanceUsd,
        threshold: thresholdUsd,
      }).catch(() => {});
      logger.warn({ provider: b.provider, balanceSyp: b.balanceSyp, thresholdSyp }, "Low provider balance alert sent");
    }
  } catch (e: any) {
    logger.warn({ err: e?.message }, "Balance check failed");
  }
}

export function startBalanceMonitor(): void {
  const ONE_HOUR = 60 * 60 * 1000;
  // First check after 5 minutes (allow startup to settle), then hourly.
  setTimeout(() => {
    runBalanceCheck();
    setInterval(() => { runBalanceCheck(); }, ONE_HOUR);
  }, 5 * 60 * 1000);
  logger.info("Provider balance monitor scheduled (hourly, SYP threshold)");
}
