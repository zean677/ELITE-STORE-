import { db, ordersTable, productsTable, usersTable, notificationsTable, walletTransactionsTable } from "@workspace/db";
import { and, eq, isNotNull, inArray, sql, gte } from "drizzle-orm";
import { logger } from "./logger";
import { checkOrdersBatch, type ProviderName } from "./providers";
import { notifyOrderSuccess, notifyOrderFailed } from "./telegram";
import { applyCompletedOrderSpend } from "./vip";
import { emitOrderUpdate } from "./ws";

// Status check every 30 seconds (was 60s). Batch lookups for efficiency.
const POLL_INTERVAL_MS = 30_000;
const STALE_AFTER_MS = 24 * 60 * 60 * 1000; // stop polling orders older than 24h
const MAX_BATCH = 50;

let pollerStarted = false;

async function pollOnce(): Promise<void> {
  // Find recent processing orders that have already been dispatched (have providerOrderId)
  const since = new Date(Date.now() - STALE_AFTER_MS);
  const candidates = await db
    .select({
      id: ordersTable.id,
      productId: ordersTable.productId,
      productName: ordersTable.productName,
      qty: ordersTable.qty,
      userId: ordersTable.userId,
      providerOrderId: ordersTable.providerOrderId,
      totalPrice: ordersTable.totalPrice,
      currency: ordersTable.currency,
    })
    .from(ordersTable)
    .where(and(
      eq(ordersTable.status, "processing"),
      isNotNull(ordersTable.providerOrderId),
      gte(ordersTable.createdAt, since),
    ))
    .limit(MAX_BATCH);

  if (candidates.length === 0) return;

  // Map productId -> product so we can determine provider per order
  const productIds = Array.from(new Set(candidates.map(c => c.productId)));
  const products = productIds.length > 0
    ? await db.select().from(productsTable).where(inArray(productsTable.id, productIds))
    : [];
  const productMap = new Map(products.map(p => [p.id, p]));

  // Group orders by provider so we can batch-check each provider in one HTTP call
  const byProvider = new Map<ProviderName, typeof candidates>();
  for (const order of candidates) {
    const product = productMap.get(order.productId);
    const provider = (product?.provider ?? "manual") as ProviderName | "manual";
    if (provider === "manual") continue;
    if (!order.providerOrderId) continue;
    if (!byProvider.has(provider)) byProvider.set(provider, []);
    byProvider.get(provider)!.push(order);
  }

  // Resolve each provider in a single batched /check call
  const remoteByOrderId = new Map<string, { status: string; deliveredCode?: string | null }>();
  for (const [provider, orders] of byProvider) {
    const ids = orders.map(o => o.providerOrderId!).filter(Boolean);
    const results = await checkOrdersBatch(provider, ids, false);
    for (const o of orders) {
      const r = results[o.providerOrderId!];
      if (r) remoteByOrderId.set(o.id, { status: r.status, deliveredCode: r.deliveredCode ?? null });
    }
  }

  for (const order of candidates) {
    const product = productMap.get(order.productId);
    const provider = (product?.provider ?? "manual") as ProviderName | "manual";
    if (provider === "manual") continue;
    if (!order.providerOrderId) continue;

    const remoteEntry = remoteByOrderId.get(order.id);
    if (!remoteEntry) continue;
    const remote = { status: remoteEntry.status, deliveredCode: remoteEntry.deliveredCode };
    if (remote.status === "processing" || remote.status === "unknown") continue;

    if (remote.status === "completed") {
      const [updated] = await db.update(ordersTable)
        .set({
          status: "completed",
          deliveredCode: remote.deliveredCode ?? null,
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(and(eq(ordersTable.id, order.id), eq(ordersTable.status, "processing")))
        .returning();
      if (!updated) continue;

      const priceUsd = product ? parseFloat(product.priceUsd ?? "0") * order.qty : parseFloat(order.totalPrice ?? "0");
      await applyCompletedOrderSpend(order.userId, priceUsd, order.id).catch(() => {});

      await db.insert(notificationsTable).values({
        userId: order.userId,
        type: "order_completed",
        title: "✅ تم تنفيذ طلبك",
        message: remote.deliveredCode
          ? `تم تنفيذ طلبك لـ ${order.productName} (x${order.qty}). الكود: ${String(remote.deliveredCode).slice(0, 200)}`
          : `تم تنفيذ طلبك لـ ${order.productName} (x${order.qty}) بنجاح من قبل المورّد.`,
        isRead: false,
      });

      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, order.userId));
      if (user) {
        notifyOrderSuccess({ username: user.username, productName: order.productName ?? "", orderId: order.id }).catch(() => {});
        emitOrderUpdate(order.id, "completed", order.productName ?? "", user.username, priceUsd);
      }

      logger.info({ orderId: order.id, provider }, "Order auto-completed by poller");
      continue;
    }

    if (remote.status === "failed") {
      const [updated] = await db.update(ordersTable)
        .set({ status: "failed", updatedAt: new Date() })
        .where(and(eq(ordersTable.id, order.id), eq(ordersTable.status, "processing")))
        .returning();
      if (!updated) continue;

      const refundUsd = product ? parseFloat(product.priceUsd ?? "0") * order.qty : parseFloat(order.totalPrice ?? "0");
      if (refundUsd > 0) {
        await db.update(usersTable)
          .set({ balance: sql`${usersTable.balance} + ${refundUsd.toString()}` })
          .where(eq(usersTable.id, order.userId));

        await db.insert(walletTransactionsTable).values({
          userId: order.userId,
          type: "refund",
          amount: refundUsd.toString(),
          currency: "USD",
          description: `Refund (provider rejected): ${order.productName} x${order.qty}`,
        });
      }

      await db.insert(notificationsTable).values({
        userId: order.userId,
        type: "order_failed",
        title: "❌ فشل تنفيذ الطلب — تم إرجاع الرصيد",
        message: `رفض المورّد طلبك لـ ${order.productName}. تم إرجاع المبلغ تلقائياً إلى محفظتك.`,
        isRead: false,
      });

      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, order.userId));
      if (user) {
        notifyOrderFailed({ username: user.username, productName: order.productName ?? "", orderId: order.id, error: "Provider rejected the order" }).catch(() => {});
        emitOrderUpdate(order.id, "failed", order.productName ?? "", user.username, refundUsd);
      }

      logger.info({ orderId: order.id, provider }, "Order auto-failed + refunded by poller");
    }
  }
}

export function startOrderPoller(): void {
  if (pollerStarted) return;
  pollerStarted = true;
  logger.info({ intervalMs: POLL_INTERVAL_MS }, "Order status poller started");
  setInterval(() => {
    pollOnce().catch(err => logger.warn({ err }, "Order poller iteration failed"));
  }, POLL_INTERVAL_MS);
}
