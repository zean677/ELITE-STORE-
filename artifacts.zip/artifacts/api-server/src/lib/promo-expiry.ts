import { db, promoCodesTable } from "@workspace/db";
import { and, eq, lte, isNotNull } from "drizzle-orm";
import { logger } from "./logger";

const CHECK_INTERVAL_MS = 60 * 60 * 1000; // hourly
let started = false;

async function runOnce(): Promise<void> {
  const now = new Date();
  const expired = await db
    .update(promoCodesTable)
    .set({ isActive: false })
    .where(and(
      eq(promoCodesTable.isActive, true),
      isNotNull(promoCodesTable.expiresAt),
      lte(promoCodesTable.expiresAt, now),
    ))
    .returning({ id: promoCodesTable.id, code: promoCodesTable.code });

  if (expired.length > 0) {
    logger.info({ count: expired.length, codes: expired.map(e => e.code) }, "Auto-expired promo codes");
  }
}

export function startPromoExpiryJob(): void {
  if (started) return;
  started = true;
  logger.info({ intervalMs: CHECK_INTERVAL_MS }, "Promo code expiry job started");
  // run immediately on startup, then hourly
  runOnce().catch(err => logger.warn({ err }, "Promo expiry first run failed"));
  setInterval(() => {
    runOnce().catch(err => logger.warn({ err }, "Promo expiry iteration failed"));
  }, CHECK_INTERVAL_MS);
}
