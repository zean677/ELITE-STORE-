import { spawn } from "child_process";
import { mkdir, readdir, stat, unlink } from "fs/promises";
import { createWriteStream } from "fs";
import { createGzip } from "zlib";
import path from "path";
import { logger } from "./logger";

const BACKUP_DIR = process.env.BACKUP_DIR || path.resolve(process.cwd(), "backups");
const KEEP_DAYS = Number(process.env.BACKUP_KEEP_DAYS || 14);
const ONE_DAY_MS = 24 * 60 * 60 * 1000;

async function notifyTelegram(text: string): Promise<void> {
  const token = (process.env.TELEGRAM_BOT_TOKEN || "").trim();
  const chatId = (process.env.TELEGRAM_ADMIN_CHAT_ID || "").trim();
  if (!token || !chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
      signal: AbortSignal.timeout(8000),
    });
  } catch { /* swallow */ }
}

async function pruneOldBackups(): Promise<number> {
  let removed = 0;
  const cutoff = Date.now() - KEEP_DAYS * ONE_DAY_MS;
  const files = await readdir(BACKUP_DIR).catch(() => [] as string[]);
  for (const file of files) {
    if (!file.startsWith("elite-store-") || !file.endsWith(".sql.gz")) continue;
    const full = path.join(BACKUP_DIR, file);
    const st = await stat(full).catch(() => null);
    if (st && st.mtimeMs < cutoff) {
      await unlink(full).catch(() => {});
      removed += 1;
    }
  }
  return removed;
}

function humanSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

export async function runBackup(): Promise<{ ok: boolean; file?: string; size?: number; error?: string }> {
  const databaseUrl = (process.env.DATABASE_URL || "").trim();
  if (!databaseUrl) return { ok: false, error: "DATABASE_URL not set" };

  await mkdir(BACKUP_DIR, { recursive: true });

  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const file = path.join(BACKUP_DIR, `elite-store-${ts}.sql.gz`);

  return new Promise((resolve) => {
    const proc = spawn("pg_dump", [databaseUrl, "--no-owner", "--no-acl", "--format=plain"], {
      stdio: ["ignore", "pipe", "pipe"],
    });

    const gz = createGzip({ level: 9 });
    const out = createWriteStream(file);
    let stderr = "";

    proc.stderr.on("data", (chunk) => { stderr += chunk.toString().slice(0, 2000); });
    proc.stdout.pipe(gz).pipe(out);

    out.on("finish", async () => {
      const st = await stat(file).catch(() => null);
      const size = st?.size ?? 0;
      if (proc.exitCode !== 0 && proc.exitCode !== null) {
        await unlink(file).catch(() => {});
        resolve({ ok: false, error: stderr.slice(0, 500) || `pg_dump exited ${proc.exitCode}` });
        return;
      }
      resolve({ ok: true, file, size });
    });

    proc.on("error", (err) => resolve({ ok: false, error: err.message }));
    out.on("error", (err) => resolve({ ok: false, error: err.message }));
  });
}

export async function runBackupAndNotify(): Promise<void> {
  const start = Date.now();
  const result = await runBackup();
  const duration = ((Date.now() - start) / 1000).toFixed(1);

  if (!result.ok) {
    logger.error({ err: result.error }, "Database backup failed");
    await notifyTelegram(`❌ <b>فشل النسخ الاحتياطي للقاعدة</b>\n\n<code>${(result.error ?? "").slice(0, 300)}</code>`);
    return;
  }

  const removed = await pruneOldBackups().catch(() => 0);
  const fileName = result.file ? path.basename(result.file) : "";
  logger.info({ file: fileName, sizeBytes: result.size, removed, durationSec: duration }, "Database backup complete");

  await notifyTelegram(
    `✅ <b>نسخة احتياطية يومية</b>\n\n` +
    `📦 الملف: <code>${fileName}</code>\n` +
    `📏 الحجم: <b>${humanSize(result.size ?? 0)}</b>\n` +
    `⏱ المدة: <b>${duration}s</b>\n` +
    (removed > 0 ? `🗑 تم حذف <b>${removed}</b> نسخة قديمة (أكثر من ${KEEP_DAYS} يوم)\n` : "") +
    `🕐 ${new Date().toLocaleString("ar-SY", { timeZone: "Asia/Damascus" })}`
  );
}

// Schedule daily backup at 03:00 Damascus time
export function startBackupScheduler(): void {
  if (process.env.BACKUP_DISABLED === "1") {
    logger.info("Backup scheduler disabled via BACKUP_DISABLED=1");
    return;
  }

  const computeMsUntil = (): number => {
    const now = new Date();
    const damascus = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Damascus" }));
    const next = new Date(damascus);
    next.setHours(3, 0, 0, 0);
    if (damascus >= next) next.setDate(next.getDate() + 1);
    return next.getTime() - damascus.getTime();
  };

  const schedule = () => {
    const ms = computeMsUntil();
    setTimeout(async () => {
      await runBackupAndNotify().catch((err) => logger.error({ err }, "Backup task crashed"));
      schedule();
    }, ms);
  };

  schedule();
  logger.info({ keepDays: KEEP_DAYS, dir: BACKUP_DIR }, "Daily database backup scheduled (03:00 Damascus time)");
}
