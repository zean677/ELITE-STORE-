import { db, ordersTable, settingsTable } from "@workspace/db";
import { and, eq, isNull, isNotNull, lte } from "drizzle-orm";
import { logger } from "./logger";
import { approveOrderById } from "./order-actions";

const RETRY_INTERVAL_MS = 60_000; // check every minute
const MAX_BATCH = 10;

let started = false;

async function processOnce(): Promise<void> {
  const [setting] = await db.select({ value: settingsTable.value })
    .from(settingsTable)
    .where(eq(settingsTable.key, "auto_retry_failed_orders"));
  if (setting?.value === "false") return;

  const now = new Date();
  // Find orders due for retry: still processing, no providerOrderId yet (initial dispatch failed),
  // and the scheduled retry time has arrived.
  const due = await db
    .select({ id: ordersTable.id, retryCount: ordersTable.retryCount })
    .from(ordersTable)
    .where(and(
      eq(ordersTable.status, "processing"),
      isNull(ordersTable.providerOrderId),
      isNotNull(ordersTable.nextRetryAt),
      lte(ordersTable.nextRetryAt, now),
    ))
    .limit(MAX_BATCH);

  if (due.length === 0) return;

  logger.info({ count: due.length }, "Retry scheduler: re-dispatching failed orders");

  for (const o of due) {
    try {
      // Clear nextRetryAt before re-dispatching so it isn't picked up again concurrently
      await db.update(ordersTable)
        .set({ nextRetryAt: null, updatedAt: new Date() })
        .where(eq(ordersTable.id, o.id));

      const result = await approveOrderById(o.id, { username: "retry-scheduler" });
      logger.info({ orderId: o.id, attempt: (o.retryCount ?? 0), result: result.ok ? (result as any).status : result.reason }, "Retry attempt result");
    } catch (err) {
      logger.warn({ err, orderId: o.id }, "Retry scheduler: failed to re-dispatch order");
    }
  }
}

export function startRetryScheduler(): void {
  if (started) return;
  started = true;
  logger.info({ intervalMs: RETRY_INTERVAL_MS }, "Order retry scheduler started");
  setInterval(() => {
    processOnce().catch(err => logger.warn({ err }, "Retry scheduler iteration failed"));
  }, RETRY_INTERVAL_MS);
}
