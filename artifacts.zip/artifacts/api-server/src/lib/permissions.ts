import { Response, NextFunction } from "express";
import { requireAuth, AuthRequest } from "./auth";
import { hasPermission, PERMISSIONS, type PermissionKey } from "./admin-permissions";

export { PERMISSIONS, type PermissionKey } from "./admin-permissions";

// Allow either full admin OR staff with the required permission.
export function requirePermission(perm: PermissionKey) {
  return async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
    await requireAuth(req, res, async () => {
      if (req.user?.role === "admin") return next();
      if (req.user?.role === "staff" && hasPermission(req.user.permissions ?? [], perm)) return next();
      res.status(403).json({ error: "Forbidden", message: "Missing permission: " + perm });
    });
  };
}

// Permission gate that allows admin OR staff (any permission). Useful for read-only
// pages where the staff list is filtered by the route itself.
export async function requireStaffOrAdmin(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  await requireAuth(req, res, async () => {
    if (req.user?.role === "admin" || req.user?.role === "staff") return next();
    res.status(403).json({ error: "Forbidden" });
  });
}
