import jwt from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { db, usersTable, userSessionsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { hasPermission, permissionForAdminRoute } from "./admin-permissions";

const JWT_SECRET = process.env.SESSION_SECRET ?? "";
const SESSION_DAYS = 7;

if (!JWT_SECRET) {
  throw new Error("SESSION_SECRET must be configured in every environment");
}

export function getRequestIp(req: Request): string {
  const xff = (req.headers["x-forwarded-for"] as string | undefined) ?? "";
  return (xff.split(",")[0].trim() || req.socket.remoteAddress || "").slice(0, 64);
}

export async function signSessionToken(
  userId: number,
  role: string,
  meta: { ip?: string; userAgent?: string } = {},
): Promise<string> {
  const jti = uuidv4();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(userSessionsTable).values({
    id: jti,
    userId,
    ip: meta.ip ?? null,
    userAgent: (meta.userAgent ?? "").slice(0, 300) || null,
    expiresAt,
  });
  return jwt.sign({ userId, role, jti }, JWT_SECRET, { expiresIn: `${SESSION_DAYS}d` });
}

// Legacy helper kept for backward compatibility (no jti tracking).
export function signToken(userId: number, role: string): string {
  return jwt.sign({ userId, role }, JWT_SECRET, { expiresIn: `${SESSION_DAYS}d` });
}

export function verifyToken(token: string): { userId: number; role: string; jti?: string } | null {
  try {
    return jwt.verify(token, JWT_SECRET) as { userId: number; role: string; jti?: string };
  } catch {
    return null;
  }
}

export interface AuthRequest extends Request {
  user?: { id: number; role: string; username: string; permissions: string[]; jti?: string };
}

export async function requireAuth(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized", message: "No token provided" });
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ error: "Unauthorized", message: "Invalid token" });
    return;
  }

  const [authRow] = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      role: usersTable.role,
      permissions: usersTable.permissions,
      isSuspended: usersTable.isSuspended,
      sessionId: userSessionsTable.id,
      sessionRevoked: userSessionsTable.revoked,
      sessionExpiresAt: userSessionsTable.expiresAt,
      sessionLastSeenAt: userSessionsTable.lastSeenAt,
      sessionIp: userSessionsTable.ip,
    })
    .from(usersTable)
    .leftJoin(
      userSessionsTable,
      and(
        eq(userSessionsTable.id, payload.jti ?? ""),
        eq(userSessionsTable.userId, usersTable.id),
      ),
    )
    .where(eq(usersTable.id, payload.userId));
  if (!authRow || authRow.isSuspended) {
    res.status(401).json({ error: "Unauthorized", message: "User not found or suspended" });
    return;
  }

  // New-format tokens must match an active, unexpired session record.
  if (payload.jti) {
    if (
      !authRow.sessionId ||
      authRow.sessionRevoked ||
      !authRow.sessionExpiresAt ||
      authRow.sessionExpiresAt <= new Date()
    ) {
      res.status(401).json({ error: "Session revoked", message: "This session has been signed out" });
      return;
    }
    // Avoid a write on every API request; update activity at most once a minute.
    if (!authRow.sessionLastSeenAt || Date.now() - authRow.sessionLastSeenAt.getTime() >= 60_000) {
      db.update(userSessionsTable)
        .set({ lastSeenAt: new Date(), ip: getRequestIp(req) || authRow.sessionIp })
        .where(eq(userSessionsTable.id, payload.jti))
        .catch(() => {});
    }
  }

  req.user = {
    id: authRow.id,
    role: authRow.role,
    username: authRow.username ?? "",
    permissions: authRow.permissions ?? [],
    jti: payload.jti,
  };
  next();
}

export async function requireAdmin(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  await requireAuth(req, res, async () => {
    if (req.user?.role === "admin") {
      next();
      return;
    }
    const permission = permissionForAdminRoute(req.method, req.originalUrl);
    if (req.user?.role === "staff" && permission && hasPermission(req.user.permissions, permission)) {
      next();
      return;
    }
    res.status(403).json({
      error: "Forbidden",
      message: permission ? `Missing permission: ${permission}` : "Administrator access required",
    });
  });
}
