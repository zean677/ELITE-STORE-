export const PERMISSIONS = [
  "orders.view",
  "orders.write",
  "payments.view",
  "payments.approve",
  "payments.manage",
  "users.view",
  "users.write",
  "products.view",
  "products.write",
  "notifications.view",
  "notifications.write",
  "settings.write",
  "analytics.view",
  "support.manage",
  "loyalty.manage",
  "offers.manage",
  "store.manage",
  "media.manage",
  "system.monitor",
] as const;

export type PermissionKey = typeof PERMISSIONS[number];

const IMPLIED_PERMISSIONS: Partial<Record<PermissionKey, PermissionKey[]>> = {
  "orders.view": ["orders.write"],
  "payments.view": ["payments.approve", "payments.manage"],
  "users.view": ["users.write"],
  "products.view": ["products.write"],
  "notifications.view": ["notifications.write"],
};

export function hasPermission(permissions: string[], required: PermissionKey): boolean {
  return permissions.includes(required) ||
    (IMPLIED_PERMISSIONS[required] ?? []).some((granted) => permissions.includes(granted));
}

function isWithin(path: string, prefix: string): boolean {
  return path === prefix || path.startsWith(`${prefix}/`);
}

/**
 * Returns the staff permission needed for a protected admin endpoint.
 * Undefined deliberately means "administrator only"; unmapped endpoints never
 * become accessible to staff by default.
 */
export function permissionForAdminRoute(method: string, rawUrl: string): PermissionKey | undefined {
  const urlPath = rawUrl.split("?")[0] ?? "";
  const adminStart = urlPath.indexOf("/admin/");
  if (adminStart < 0) return undefined;
  const path = urlPath.slice(adminStart).replace(/\/+$/, "") || "/admin";
  const verb = method.toUpperCase();
  const readOnly = verb === "GET" || verb === "HEAD";

  // Role assignment and staff administration are always administrator-only.
  if (
    path === "/admin/staff" ||
    path === "/admin/permissions/list" ||
    /^\/admin\/users\/[^/]+\/permissions$/.test(path)
  ) return undefined;

  if (/^\/admin\/products\/[^/]+\/test-order$/.test(path) || path === "/admin/products/clear-all") {
    return undefined;
  }

  if (isWithin(path, "/admin/orders") || path === "/admin/order-queue" || path === "/admin/dashboard/urgent") {
    return readOnly ? "orders.view" : "orders.write";
  }
  if (path === "/admin/dashboard" || path === "/admin/revenue-chart" ||
      isWithin(path, "/admin/analytics") || isWithin(path, "/admin/financial") ||
      path === "/admin/profit-daily" || /^\/admin\/products\/[^/]+\/analytics$/.test(path)) {
    return "analytics.view";
  }
  if (isWithin(path, "/admin/payments") || path === "/admin/export/payments") {
    if (path === "/admin/export/payments" || readOnly) return "payments.view";
    return path === "/admin/payments" ? "payments.view" : "payments.approve";
  }
  if (path === "/admin/users" || path === "/admin/export/users") return "users.view";
  if (/^\/admin\/users\/[^/]+\/(vip|balance|suspend|notes)$/.test(path)) return "users.write";

  if (path === "/admin/export/products" || path === "/admin/reports/dead-products") return "products.view";
  if (isWithin(path, "/admin/products") || isWithin(path, "/admin/categories")) {
    return readOnly ? "products.view" : "products.write";
  }
  if (isWithin(path, "/admin/images") || isWithin(path, "/admin/upload")) return "media.manage";

  if (isWithin(path, "/admin/notifications") || isWithin(path, "/admin/push") ||
      isWithin(path, "/admin/scheduled-notifications") || path === "/admin/message-templates") {
    return readOnly ? "notifications.view" : "notifications.write";
  }
  if (isWithin(path, "/admin/support")) return "support.manage";
  if (isWithin(path, "/admin/loyalty") || /^\/admin\/users\/[^/]+\/loyalty$/.test(path)) return "loyalty.manage";
  if (isWithin(path, "/admin/bundles") || isWithin(path, "/admin/group-buys") ||
      isWithin(path, "/admin/gift-cards") || isWithin(path, "/admin/promo-codes")) return "offers.manage";
  if (isWithin(path, "/admin/banners")) return "store.manage";
  if (isWithin(path, "/admin/store-appearance") || isWithin(path, "/admin/home-sections") ||
      isWithin(path, "/admin/automation")) return "settings.write";
  if (path === "/admin/monitoring/full" || path === "/admin/system") return "system.monitor";

  // Unknown or sensitive admin endpoints stay administrator-only.
  return undefined;
}