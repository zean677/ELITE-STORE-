import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import fs from "fs";
import router from "./routes";
import { logger } from "./lib/logger";
import { UPLOADS_DIR } from "./routes/upload";

const app: Express = express();

// ─── Security Headers (helmet-lite) ──────────────────────────────────────────
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
  res.removeHeader("X-Powered-By");
  next();
});

// ─── CORS ─────────────────────────────────────────────────────────────────────
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ?? "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, cb) => {
      // Allow requests with no origin (mobile apps, curl, etc.)
      if (!origin) return cb(null, true);
      // In dev, allow all
      if (process.env.NODE_ENV !== "production") return cb(null, true);
      // In prod, only configured origins
      if (ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin)) {
        return cb(null, true);
      }
      cb(new Error("CORS: origin not allowed"));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    maxAge: 86400, // 24h preflight cache
  }),
);

// ─── Rate Limiting (in-memory, with auto-cleanup to prevent memory leak) ─────
const requestBuckets = new Map<string, { count: number; resetAt: number }>();

// Clean up expired buckets every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of requestBuckets) {
    if (bucket.resetAt <= now) requestBuckets.delete(key);
  }
}, 5 * 60 * 1000);

// Tighter limits for auth endpoints (per IP, per minute)
const RATE_LIMITS: Record<string, number> = {
  "/api/auth/login":           5,   // 5 attempts/min — brute-force protection
  "/api/auth/register":        3,   // 3 registrations/min — anti-spam
  "/api/auth/forgot-password": 3,   // 3 reset requests/min
  "/api/auth/change-password": 5,
  "/api/orders":               30,
  "/api/payments":             10,
};

app.use((req: Request, res: Response, next: NextFunction) => {
  const now = Date.now();
  const basePath = req.path.split("?")[0];
  const key = `${req.ip}:${basePath}`;
  const current = requestBuckets.get(key);
  const bucket = current && current.resetAt > now
    ? current
    : { count: 0, resetAt: now + 60_000 };
  bucket.count += 1;
  requestBuckets.set(key, bucket);

  const limit = RATE_LIMITS[basePath] ?? 150;
  if (bucket.count > limit) {
    const retryAfter = Math.ceil((bucket.resetAt - now) / 1000);
    res.setHeader("Retry-After", String(retryAfter));
    res.status(429).json({
      error: "Too many requests",
      message: "Please slow down and try again shortly",
      retryAfter,
    });
    return;
  }
  next();
});

// ─── HTTP Logging ─────────────────────────────────────────────────────────────
app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
  }),
);

// ─── Body Parser (2mb limit — prevents large payload attacks) ─────────────────
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));

// ─── SEO: dynamic sitemap.xml + robots.txt (must be before static middleware) ─
import sitemapRouter from "./routes/sitemap";
app.use("/", sitemapRouter);

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use("/api", router);

// ─── Uploaded Screenshots — served as static files ────────────────────────────
app.use("/api/uploads", express.static(UPLOADS_DIR, { maxAge: "30d" }));

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ status: "ok", ts: new Date().toISOString() });
});

// ─── Static Files (production — serve compiled React frontend) ─────────────────
const FRONTEND_DIST = path.resolve(
  __dirname,
  process.env.FRONTEND_DIST_PATH ?? "../../elite-store/dist/public",
);
const frontendExists = fs.existsSync(path.join(FRONTEND_DIST, "index.html"));

if (frontendExists) {
  app.use(express.static(FRONTEND_DIST, {
    maxAge: "1y",
    etag: true,
    // Don't cache index.html — always fresh for PWA updates
    setHeaders(res, filePath) {
      if (path.basename(filePath) === "index.html") {
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      }
    },
  }));
  // SPA fallback — serve index.html for all non-API routes (Express 5 compatible)
  app.use((_req: Request, res: Response) => {
    res.sendFile(path.join(FRONTEND_DIST, "index.html"));
  });
  logger.info({ path: FRONTEND_DIST }, "Serving frontend static files");
} else {
  // ─── 404 Handler (API-only mode) ──────────────────────────────────────────
  app.use((_req: Request, res: Response) => {
    res.status(404).json({ error: "Not found" });
  });
}

// ─── Global Error Handler ─────────────────────────────────────────────────────
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  // Don't leak internal details to client in production
  const isDev = process.env.NODE_ENV !== "production";
  const status = err?.status ?? err?.statusCode ?? 500;
  logger.error({ err, status }, "Unhandled error");
  res.status(status).json({
    error: status === 500 ? "Internal server error" : (err?.message ?? "Error"),
    ...(isDev && status === 500 ? { detail: String(err?.message) } : {}),
  });
});

export default app;
