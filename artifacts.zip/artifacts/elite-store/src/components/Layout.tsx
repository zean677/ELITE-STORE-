import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { canAccessAdminPage } from '@/lib/admin-route-access';
import { useLanguage } from '@/i18n';
import { useGetNotifications } from '@workspace/api-client-react';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { CurrencySwitcher } from '@/components/CurrencySwitcher';
import { Logo } from '@/components/Logo';
import { AdminLiveBell } from '@/components/AdminLiveBell';
import { VipUpgradeBar } from '@/components/VipUpgradeBar';
import { getVipFromData } from '@/components/VipBadge';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home, ShoppingBag, Package, Wallet, Bell, User, Settings,
  ChevronDown, Menu, X, Shield, BarChart2, Users, CreditCard, Crown,
  LogOut, Layers, ChevronRight, MessageCircle, Users2, Coins, Tag, Heart, History, Star, BarChart3, Send, Activity, AlertTriangle,
  DollarSign, Zap, Palette
} from 'lucide-react';
import { useCurrency } from '@/hooks/use-currency';

// Contact links — Telegram, WhatsApp chat, WhatsApp group
export const TELEGRAM_SUPPORT_LINK = 'https://t.me/+963931670388';
export const WHATSAPP_GROUP_LINK = 'https://chat.whatsapp.com/DmATlEZYLFgHbWuo4HOVay';
export const WHATSAPP_PHONE = '963992718483'; // 0992 718 483 in international format
export const WHATSAPP_CHAT_LINK = `https://wa.me/${WHATSAPP_PHONE}`;

function FloatingSupport() {
  const { lang } = useLanguage();
  const [open, setOpen] = useState(false);

  // Order requested: WhatsApp group first, then WhatsApp number, then Telegram
  const options = [
    {
      href: WHATSAPP_GROUP_LINK,
      label: lang === 'ar' ? 'غروب الموقع' : 'Site Group',
      bg: 'linear-gradient(135deg, #25D366, #128C7E)',
      icon: <Users2 size={20} />,
    },
    {
      href: WHATSAPP_CHAT_LINK,
      label: lang === 'ar' ? 'تواصل مع الدعم' : 'Contact Support',
      bg: 'linear-gradient(135deg, #25D366, #1DA851)',
      icon: <MessageCircle size={20} />,
    },
    {
      href: TELEGRAM_SUPPORT_LINK,
      label: lang === 'ar' ? 'تيليغرام' : 'Telegram',
      bg: 'linear-gradient(135deg, #2AABEE, #1E96D0)',
      icon: <Send size={20} className="-rotate-12" />,
    },
  ];

  return (
    <div className="fixed bottom-20 left-3 sm:bottom-6 sm:left-5 z-50 flex flex-col items-start gap-2">
      <AnimatePresence>
        {open && options.map((o, i) => (
          <motion.a
            key={o.href}
            href={o.href}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 10, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.8 }}
            transition={{ delay: i * 0.04 }}
            aria-label={o.label}
            title={o.label}
            className="flex items-center gap-2 pr-3 pl-2 py-2 rounded-2xl text-white text-xs font-bold shadow-xl shadow-black/40 hover:scale-105 active:scale-95 transition-transform"
            style={{ background: o.bg }}
          >
            <span className="w-8 h-8 rounded-xl flex items-center justify-center bg-white/15">{o.icon}</span>
            <span className="whitespace-nowrap">{o.label}</span>
          </motion.a>
        ))}
      </AnimatePresence>
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        aria-label={lang === 'ar' ? 'تواصل معنا' : 'Contact us'}
        title={lang === 'ar' ? 'تواصل معنا' : 'Contact us'}
        className="w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-black/40 transition-all hover:scale-110 active:scale-95"
        style={{
          background: open
            ? 'linear-gradient(135deg, #ef4444, #b91c1c)'
            : 'linear-gradient(135deg, #25D366, #128C7E)',
          boxShadow: '0 8px 24px rgba(37,211,102,0.45)',
        }}
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </div>
  );
}

interface LayoutProps {
  children: React.ReactNode;
}

export function PublicLayout({ children }: LayoutProps) {
  const { user, logout } = useAuth();
  const { t, dir, lang } = useLanguage();
  const { formatPrice } = useCurrency();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const { data: notifications } = useGetNotifications({ query: { enabled: !!user, staleTime: 3 * 60 * 1000, gcTime: 10 * 60 * 1000 } as any });
  const unreadCount = (notifications || []).filter(n => !n.isRead).length;
  const [location] = useLocation();
  const userBalanceDisplay = user ? formatPrice(parseFloat(user.balance?.toString() ?? '0')) : '';

  useEffect(() => {
    if (mobileMenuOpen) {
      const scrollY = window.scrollY;
      document.body.dataset.scrollY = String(scrollY);
      document.body.style.overflow = 'hidden';
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
      document.body.style.left = '0';
      document.body.style.right = '0';
    } else {
      const scrollY = parseInt(document.body.dataset.scrollY || '0', 10);
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      document.body.style.left = '';
      document.body.style.right = '';
      delete document.body.dataset.scrollY;
      window.scrollTo(0, scrollY);
    }
    return () => {
      const scrollY = parseInt(document.body.dataset.scrollY || '0', 10);
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      document.body.style.left = '';
      document.body.style.right = '';
      delete document.body.dataset.scrollY;
      if (scrollY) window.scrollTo(0, scrollY);
    };
  }, [mobileMenuOpen]);

  return (
    <div className="min-h-screen bg-background text-foreground" dir={dir}>

      {/* Announcement ticker bar */}
      <div className="ticker-wrap w-full overflow-hidden py-1.5" style={{ background: 'linear-gradient(90deg, #6C5CE7, #00CEC9, #6C5CE7)', backgroundSize: '200% 100%' }} title="مرّر الفأرة لإيقاف الشريط">
        <div className="flex items-center">
          <div className="ticker-text flex items-center gap-8 text-white text-xs font-bold px-4">
            {['⚡ خدمة سريعة 24/7', '🔒 دفع آمن ومضمون', '💎 أفضل الأسعار في سوريا', '✅ تسليم فوري بعد التحقق', '🎮 شحن جميع الألعاب', '📱 خدمات سوشيال ميديا', '💳 شحن رصيد سيريتل وشام كاش', '🌐 elite-store.com'].map((item, i) => (
              <span key={i} className="flex items-center gap-2 whitespace-nowrap">{item} <span className="opacity-50">•</span></span>
            ))}
          </div>
        </div>
      </div>

      {/* VIP upgrade nudge — shows for logged-in users below max VIP */}
      <VipUpgradeBar />

      <header className="sticky top-0 z-50 border-b border-border backdrop-blur-xl" style={{ background: 'rgba(15,23,42,0.92)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-[auto_1fr_auto] items-center h-14 gap-1.5">
            <Link href="/" className="flex items-center gap-1.5 group hover:opacity-90 transition-opacity shrink-0">
              {/* Compact logo on mobile so all action icons fit comfortably */}
              <span className="sm:hidden"><Logo size={32} withText={true} /></span>
              <span className="hidden sm:inline-flex"><Logo size={40} withText={true} /></span>
            </Link>

            <div />

            <div className="flex items-center gap-0.5 sm:gap-2 justify-end">
              {/* Currency switcher: visible on all sizes — customers need to pick USD/SYP/EUR */}
              <CurrencySwitcher />
              {/* Language switcher: only on tablets+ (also available in side menu) */}
              <div className="hidden sm:flex">
                <LanguageSwitcher />
              </div>

              {user ? (
                <>
                  {/* Wallet Balance — compact on mobile */}
                  <Link href="/wallet" className="flex items-center gap-1 px-1.5 sm:px-2.5 py-1 sm:py-1.5 rounded-lg sm:rounded-xl border border-green-500/30 bg-green-500/10 hover:bg-green-500/15 transition-colors max-w-[90px] sm:max-w-none">
                    <Coins size={11} className="text-green-400 shrink-0" />
                    <span className="text-[10px] sm:text-xs font-bold text-green-400 truncate">{userBalanceDisplay}</span>
                  </Link>
                  <Link href="/notifications" className="relative p-1.5 sm:p-2 rounded-lg hover:bg-card transition-colors shrink-0">
                    <Bell size={16} className="text-muted-foreground" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 min-w-[14px] h-[14px] px-0.5 bg-destructive text-white text-[9px] font-bold rounded-full flex items-center justify-center">{unreadCount > 9 ? '9+' : unreadCount}</span>
                    )}
                  </Link>
                  <div className="relative shrink-0">
                    <button onClick={() => setUserMenuOpen(!userMenuOpen)} className="flex items-center gap-1.5 p-1 sm:p-2 rounded-lg hover:bg-card transition-colors">
                      <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                        <span className="text-primary text-xs font-bold">{user.username[0].toUpperCase()}</span>
                      </div>
                      <div className="hidden sm:flex items-center gap-1.5">
                        <span className="text-sm font-medium">{user.username}</span>
                        {(() => { const v = getVipFromData(user); return v.level > 0 ? (
                          <span className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-black text-slate-900 bg-gradient-to-r ${v.tier?.from ?? 'from-amber-500'} ${v.tier?.to ?? 'to-yellow-300'}`}>
                            <Crown size={8} fill="currentColor" />VIP{v.level}
                          </span>
                        ) : null; })()}
                      </div>
                      <ChevronDown size={14} className="hidden sm:block text-muted-foreground" />
                    </button>
                    <AnimatePresence>
                      {userMenuOpen && (
                        <motion.div initial={{ opacity: 0, y: -8, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: 0.95 }} transition={{ duration: 0.15 }} className={`absolute ${dir === 'rtl' ? 'left-0' : 'right-0'} top-full mt-2 w-52 bg-card border border-border rounded-xl shadow-xl overflow-hidden z-50`}>
                          <div className="p-3 border-b border-border">
                            <p className="text-sm font-semibold">{user.username}</p>
                            <p className="text-xs text-muted-foreground">{user.email}</p>
                          </div>
                          <div className="p-2">
                            <Link href="/dashboard" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-background transition-colors">
                              <Home size={14} />{t('dashboard')}
                            </Link>
                            <Link href="/profile" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-background transition-colors">
                              <User size={14} />{lang === 'ar' ? 'الملف الشخصي' : 'Profile'}
                            </Link>
                            <Link href="/wallet" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-background transition-colors">
                              <Wallet size={14} />{t('wallet')}
                            </Link>
                            <Link href="/orders" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-background transition-colors">
                              <Package size={14} />{t('orders')}
                            </Link>
                            <Link href="/rewards" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-amber-500/10 transition-colors">
                              <Star size={14} className="text-amber-400" fill="currentColor" />{lang === 'ar' ? 'نقاطي والمكافآت' : 'Rewards'}
                            </Link>
                            <Link href="/support" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-background transition-colors">
                              <MessageCircle size={14} />{lang === 'ar' ? 'الدعم' : 'Support'}
                            </Link>
                            {user.role === 'admin' && (
                              <Link href="/admin" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-background transition-colors text-primary">
                                <Shield size={14} />{t('admin')}
                              </Link>
                            )}
                            <button onClick={() => { logout(); setUserMenuOpen(false); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-lg hover:bg-destructive/10 text-destructive transition-colors mt-1">
                              <LogOut size={14} />{t('logout')}
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                  <Link href="/login" className="text-[11px] sm:text-sm font-medium px-2 sm:px-3 py-1.5 rounded-lg text-muted-foreground hover:text-foreground transition-colors whitespace-nowrap">{t('login')}</Link>
                  <Link href="/register" className="text-[11px] sm:text-sm font-medium px-2 sm:px-3 py-1.5 rounded-lg bg-primary text-white hover:bg-primary/90 transition-colors shadow-lg shadow-primary/30 whitespace-nowrap">{t('register')}</Link>
                </div>
              )}

              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-1.5 rounded-lg hover:bg-card transition-colors shrink-0" aria-label="menu">
                {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>
        </div>
      </header>
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[110] md:hidden"
            style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(4px)' }}
            onClick={() => setMobileMenuOpen(false)}
          >
            <motion.div
              initial={{ x: dir === 'rtl' ? '100%' : '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: dir === 'rtl' ? '100%' : '-100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 32 }}
              className={`absolute top-0 ${dir === 'rtl' ? 'right-0' : 'left-0'} bottom-0 w-72 overflow-y-auto flex flex-col`}
              style={{ background: 'linear-gradient(180deg, #0d1627 0%, #0a1122 100%)', borderLeft: dir === 'rtl' ? 'none' : '1px solid rgba(108,92,231,0.2)', borderRight: dir === 'rtl' ? '1px solid rgba(108,92,231,0.2)' : 'none', boxShadow: dir === 'rtl' ? '-20px 0 60px rgba(0,0,0,0.7)' : '20px 0 60px rgba(0,0,0,0.7)' }}
              onClick={e => e.stopPropagation()}
            >
              {/* ── Header ── */}
              <div className="flex items-center justify-between p-5" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                <Logo size={32} withText={true} />
                <button onClick={() => setMobileMenuOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors">
                  <X size={16} className="text-muted-foreground" />
                </button>
              </div>

              {/* ── User / Auth ── */}
              {user ? (
                <div className="p-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <div className="flex items-center gap-3 p-3 rounded-2xl" style={{ background: 'rgba(108,92,231,0.12)', border: '1px solid rgba(108,92,231,0.2)' }}>
                    <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                      <span className="text-primary font-black text-base">{user.username[0].toUpperCase()}</span>
                    </div>
                    <div className="min-w-0 flex-1" dir="rtl">
                      <p className="font-bold text-sm truncate">{user.username}</p>
                      <div className="flex items-center gap-1 mt-0.5">
                        <Coins size={11} className="text-green-400" />
                        <span className="text-green-400 text-xs font-bold">{userBalanceDisplay}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 space-y-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }} dir="rtl">
                  <Link href="/login" onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-90"
                    style={{ background: 'rgba(108,92,231,0.15)', border: '1px solid rgba(108,92,231,0.3)', color: '#a29bfe' }}>
                    {t('login')}
                  </Link>
                  <Link href="/register" onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90"
                    style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)', boxShadow: '0 4px 15px rgba(108,92,231,0.3)' }}>
                    {t('register')}
                  </Link>
                </div>
              )}

              {/* ── Navigation ── */}
              <div className="p-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }} dir="rtl">
                <p className="text-[10px] font-bold uppercase tracking-widest mb-3 px-1" style={{ color: 'rgba(255,255,255,0.3)' }}>{lang === 'ar' ? 'التنقل' : 'Navigation'}</p>
                <div className="space-y-0.5">
                  {[
                    { href: '/', label: lang === 'ar' ? 'الرئيسية' : 'Home', icon: '🏠' },
                    { href: '/games?category=mobile_games', label: lang === 'ar' ? 'الألعاب والتطبيقات' : 'Games & Apps', icon: '🛍️' },
                    { href: '/bundles', label: lang === 'ar' ? 'الحزم والعروض' : 'Bundles & Offers', icon: '🎁' },
                    { href: '/support', label: lang === 'ar' ? 'الدعم الفني' : 'Support', icon: '💬' },
                    { href: '/terms', label: lang === 'ar' ? 'الشروط والأحكام' : 'Terms', icon: '📜' },
                  ].map(item => (
                    <Link key={item.href} href={item.href} onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/5 text-muted-foreground hover:text-foreground">
                      <span className="text-base w-6 text-center">{item.icon}</span>
                      {item.label}
                    </Link>
                  ))}
                  {user && <>
                    <Link href="/orders" onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/5 text-muted-foreground hover:text-foreground">
                      <span className="text-base w-6 text-center">📦</span>{lang === 'ar' ? 'طلباتي' : 'My Orders'}
                    </Link>
                    <Link href="/wallet" onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/5 text-muted-foreground hover:text-foreground">
                      <span className="text-base w-6 text-center">💳</span>{lang === 'ar' ? 'المحفظة والإيداع' : 'Wallet'}
                    </Link>
                  </>}
                </div>
              </div>

              {/* ── Categories ── */}
              <div className="p-4 flex-1" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }} dir="rtl">
                <p className="text-[10px] font-bold uppercase tracking-widest mb-3 px-1" style={{ color: 'rgba(255,255,255,0.3)' }}>{lang === 'ar' ? 'الأقسام' : 'Categories'}</p>
                <div className="space-y-2">
                  {[
                    { id: 'mobile_games', nameAr: 'ألعاب الهاتف', icon: '🎮', color: '#8b5cf6', bg: 'rgba(139,92,246,0.1)', border: 'rgba(139,92,246,0.25)' },
                    { id: 'pc_games',     nameAr: 'ألعاب الكمبيوتر', icon: '🖥️', color: '#3b82f6', bg: 'rgba(59,130,246,0.1)', border: 'rgba(59,130,246,0.25)' },
                    { id: 'services',     nameAr: 'الخدمات الرقمية', icon: '⚡', color: '#10b981', bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.25)' },
                    { id: 'gift_cards',   nameAr: 'بطاقات الهدايا',  icon: '🎁', color: '#f59e0b', bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.25)' },
                    { id: 'general',      nameAr: 'خدمات متنوعة',    icon: '🛒', color: '#f43f5e', bg: 'rgba(244,63,94,0.1)',  border: 'rgba(244,63,94,0.25)'  },
                  ].map(cat => (
                    <Link
                      key={cat.id}
                      href={`/games?category=${cat.id}`}
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 p-3 rounded-2xl transition-all hover:brightness-125 active:scale-[0.98]"
                      style={{ background: cat.bg, border: `1px solid ${cat.border}` }}
                    >
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: `${cat.color}22` }}>
                        {cat.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-sm text-white">{cat.nameAr}</p>
                        <p className="text-xs mt-0.5" style={{ color: cat.color }}>{lang === 'ar' ? 'اضغط للتصفح' : 'Tap to browse'}</p>
                      </div>
                      <ChevronRight size={14} className="rotate-180 shrink-0" style={{ color: cat.color }} />
                    </Link>
                  ))}
                </div>
              </div>

              {/* ── Social + Logout ── */}
              <div className="p-4 space-y-3" dir="rtl">
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { href: WHATSAPP_GROUP_LINK,               label: 'غروب واتساب',  color: '#25D366', icon: '👥' },
                    { href: WHATSAPP_CHAT_LINK,                label: 'واتساب',        color: '#25D366', icon: '💬' },
                    { href: TELEGRAM_SUPPORT_LINK,             label: 'دعم تيليغرام', color: '#2aabee', icon: '✈️' },
                    { href: 'https://t.me/elitestore_sy',      label: 'قناتنا',       color: '#1E96D0', icon: '📢' },
                  ].map((s, i) => (
                    <a key={i} href={s.href} target="_blank" rel="noopener noreferrer"
                      className="flex-1 flex flex-col items-center gap-1 py-2 rounded-xl text-[10px] font-bold transition-all hover:scale-105 active:scale-95"
                      style={{ background: `${s.color}15`, border: `1px solid ${s.color}30`, color: s.color }}>
                      <span className="text-base">{s.icon}</span>
                      {s.label}
                    </a>
                  ))}
                </div>
                {user && (
                  <button onClick={() => { logout(); setMobileMenuOpen(false); }}
                    className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-90 flex items-center justify-center gap-2"
                    style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)', color: '#ef4444' }}>
                    <LogOut size={14} />
                    {t('logout')}
                  </button>
                )}
                <p className="text-[10px] text-center" style={{ color: 'rgba(255,255,255,0.2)' }}>© {new Date().getFullYear()} Elite Store — جميع الحقوق محفوظة</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <main className="pb-24 lg:pb-0">{children}</main>

      {/* Footer (enhanced) */}
      <footer className="mt-16 pt-10 pb-4 px-4" style={{ background: 'linear-gradient(0deg, #080d1a, #0F172A)', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div className="max-w-7xl mx-auto">
          {/* 4-column grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">

            {/* About */}
            <div className="col-span-2 md:col-span-1 flex flex-col gap-3">
              <Logo size={32} withText={true} />
              <p className="text-xs text-gray-400 leading-relaxed" dir="rtl">منصة سورية لشحن الألعاب والخدمات الرقمية. تسليم فوري، أسعار تنافسية، ودعم 24/7.</p>
              <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                نحن متواجدون الآن
              </div>
            </div>

            {/* Quick links */}
            <div className="flex flex-col gap-2">
              <h4 className="text-white font-black text-sm mb-2">{lang === 'ar' ? 'روابط سريعة' : 'Quick Links'}</h4>
              <Link href="/" className="text-xs text-gray-400 hover:text-white transition-colors">{lang === 'ar' ? 'الرئيسية' : 'Home'}</Link>
              <Link href="/games?category=mobile_games" className="text-xs text-gray-400 hover:text-white transition-colors">{lang === 'ar' ? 'الألعاب' : 'Games'}</Link>
              <Link href="/support" className="text-xs text-gray-400 hover:text-white transition-colors">{lang === 'ar' ? 'الدعم الفني' : 'Support'}</Link>
              <Link href="/faq" className="text-xs text-gray-400 hover:text-white transition-colors">{lang === 'ar' ? 'الأسئلة الشائعة' : 'FAQ'}</Link>
              <Link href="/terms" className="text-xs text-gray-400 hover:text-white transition-colors">{lang === 'ar' ? 'الشروط والأحكام' : 'Terms'}</Link>
              <Link href="/terms#refund" className="text-xs text-gray-400 hover:text-white transition-colors">{lang === 'ar' ? 'سياسة الاسترجاع' : 'Refund Policy'}</Link>
            </div>

            {/* Payment methods */}
            <div className="flex flex-col gap-2">
              <h4 className="text-white font-black text-sm mb-2">{lang === 'ar' ? 'طرق الدفع المقبولة' : 'Payment Methods'}</h4>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { name: 'شام كاش', color: '#0EA5E9', icon: '💳' },
                  { name: 'سيريتل كاش', color: '#A01C26', icon: '📱' },
                  { name: 'MTN كاش', color: '#FFCC00', icon: '📲' },
                  { name: 'USDT', color: '#26A17B', icon: '₮' },
                  { name: 'تحويل بنكي', color: '#6366F1', icon: '🏦' },
                  { name: 'كاش يدوي', color: '#10B981', icon: '💵' },
                ].map((p, i) => (
                  <div key={i} className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-[10px] font-bold"
                    style={{ background: `${p.color}15`, border: `1px solid ${p.color}33`, color: p.color }}>
                    <span>{p.icon}</span>
                    <span className="truncate">{p.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Contact + Hours */}
            <div className="flex flex-col gap-3">
              <h4 className="text-white font-black text-sm mb-1">{lang === 'ar' ? 'تواصل معنا' : 'Contact Us'}</h4>
              <div className="flex flex-col gap-2">
                {[
                  { href: TELEGRAM_SUPPORT_LINK, label: 'دعم تيليغرام', color: '#2aabee', icon: '✈️' },
                  { href: 'https://t.me/elitestore_sy', label: 'قناتنا', color: '#1E96D0', icon: '📢' },
                  { href: 'https://www.facebook.com/elitestore.sy', label: 'فيسبوك', color: '#1877F2', icon: '📘' },
                  { href: 'https://www.instagram.com/elitestore.sy', label: 'إنستغرام', color: '#E4405F', icon: '📸' },
                ].map((s, i) => (
                  <a key={i} href={s.href} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 text-xs px-3 py-2 rounded-xl font-bold transition-all hover:scale-[1.03] active:scale-95"
                    style={{ background: `${s.color}15`, border: `1px solid ${s.color}33`, color: s.color }}>
                    <span>{s.icon}</span>
                    <span>{s.label}</span>
                  </a>
                ))}
              </div>
              <div className="mt-2 px-3 py-2 rounded-xl text-[11px] text-gray-300" style={{ background: 'rgba(108,92,231,0.1)', border: '1px solid rgba(108,92,231,0.25)' }}>
                <div className="flex items-center gap-1.5 font-bold text-white mb-1">
                  <span>🕐</span><span>ساعات العمل</span>
                </div>
                <div className="text-gray-400">يومياً: 09:00 صباحاً — 02:00 صباحاً</div>
                <div className="text-emerald-400 mt-0.5">دعم تلقائي 24/7</div>
              </div>
            </div>
          </div>

          {/* Trust badges row */}
          <div className="flex flex-wrap items-center justify-center gap-3 py-4 border-t border-white/5">
            <span className="flex items-center gap-1.5 text-[11px] text-gray-400 px-3 py-1.5 rounded-full" style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)' }}>
              <span>🔒</span><span>اتصال آمن SSL</span>
            </span>
            <span className="flex items-center gap-1.5 text-[11px] text-gray-400 px-3 py-1.5 rounded-full" style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.2)' }}>
              <span>✅</span><span>ضمان استرجاع الرصيد</span>
            </span>
            <span className="flex items-center gap-1.5 text-[11px] text-gray-400 px-3 py-1.5 rounded-full" style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)' }}>
              <span>⚡</span><span>تسليم فوري</span>
            </span>
            <span className="flex items-center gap-1.5 text-[11px] text-gray-400 px-3 py-1.5 rounded-full" style={{ background: 'rgba(168,85,247,0.08)', border: '1px solid rgba(168,85,247,0.2)' }}>
              <span>💎</span><span>أسعار تنافسية</span>
            </span>
          </div>

          {/* Bottom */}
          <div className="border-t border-white/5 pt-4 text-center">
            <p className="text-xs text-gray-600">© {new Date().getFullYear()} Elite Store — جميع الحقوق محفوظة | متجر الألعاب والخدمات الرقمية في سوريا</p>
          </div>
        </div>
      </footer>

      <FloatingSupport />
    </div>
  );
}

export function DashboardLayout({ children }: LayoutProps) {
  const { user, logout } = useAuth();
  const { t, dir, lang } = useLanguage();
  const { formatPrice } = useCurrency();
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { data: notifications } = useGetNotifications({ query: { enabled: !!user, staleTime: 3 * 60 * 1000, gcTime: 10 * 60 * 1000 } as any });
  const unreadCount = (notifications || []).filter((n: any) => !n.isRead).length;

  useEffect(() => {
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    if (sidebarOpen) {
      document.body.style.overflow = 'hidden';
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    } else {
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
    };
  }, [sidebarOpen]);

  const navItems = [
    { href: '/dashboard', icon: Home, label: t('dashboard') },
    { href: '/products', icon: ShoppingBag, label: t('products') },
    { href: '/orders', icon: Package, label: t('orders') },
    { href: '/wallet', icon: Wallet, label: t('wallet') },
    { href: '/deposit', icon: CreditCard, label: t('deposit') },
    { href: '/notifications', icon: Bell, label: t('notifications') },
    { href: '/wishlist', icon: Heart, label: lang === 'ar' ? 'المفضلة' : 'Wishlist' },
    { href: '/profile', icon: User, label: lang === 'ar' ? 'الملف الشخصي' : 'Profile' },
    { href: '/support', icon: MessageCircle, label: lang === 'ar' ? 'الدعم' : 'Support' },
  ];

  const adminNavItems = [
    { href: '/admin', icon: BarChart2, label: 'الإحصائيات' },
    { href: '/admin/orders', icon: Package, label: 'جميع الطلبات' },
    { href: '/admin/payments', icon: CreditCard, label: 'المدفوعات' },
    { href: '/admin/users', icon: Users, label: 'المستخدمون' },
    { href: '/admin/products', icon: Layers, label: 'المنتجات' },
    { href: '/admin/categories', icon: ChevronRight, label: 'إدارة الفئات' },
    { href: '/admin/category-mapping', icon: ChevronRight, label: 'ربط فئات المزود' },
    { href: '/admin/notifications', icon: Bell, label: 'إشعارات العملاء' },
    { href: '/admin/payment-methods', icon: CreditCard, label: 'طرق الدفع' },
    { href: '/admin/promo-codes', icon: Tag, label: 'أكواد الخصم' },
    { href: '/admin/loyalty', icon: Star, label: 'نقاط الولاء' },
    { href: '/admin/analytics', icon: BarChart3, label: 'التحليلات المتقدمة' },
    { href: '/admin/top-selling', icon: Star, label: 'الأكثر مبيعاً' },
    { href: '/admin/dead-products', icon: AlertTriangle, label: 'المنتجات الميتة' },
    { href: '/admin/featured-tabs', icon: Star, label: 'الكروت المميزة والتبويبات' },
    { href: '/admin/control', icon: AlertTriangle, label: 'مركز التحكم السريع' },
    { href: '/admin/staff', icon: Shield, label: 'الموظفون والصلاحيات' },
    { href: '/admin/scheduled', icon: Bell, label: 'إشعارات مجدولة' },
    { href: '/admin/smart-pricing', icon: Star, label: 'تسعير ذكي' },
    { href: '/admin/card-builder', icon: Layers, label: '🃏 تصميم كروت المنتجات' },
    { href: '/admin/image-tools', icon: Settings, label: '🖼️ أدوات الصور' },
    { href: '/admin/activity-log', icon: History, label: 'سجل النشاط' },
    { href: '/admin/monitoring', icon: Activity, label: '🔭 مركز المراقبة' },
    { href: '/admin/financial', icon: DollarSign, label: '💰 التحكم المالي' },
    { href: '/admin/security', icon: Shield, label: '🔒 مركز الأمان' },
    { href: '/admin/automation', icon: Zap, label: '🤖 مركز الأتمتة' },
    { href: '/admin/store-editor', icon: Palette, label: '🎨 محرر المتجر' },
    { href: '/admin/system', icon: Activity, label: 'حالة النظام' },
    { href: '/admin/provider-errors', icon: AlertTriangle, label: 'أخطاء المزوّدين' },
    { href: '/admin/settings', icon: Settings, label: 'الإعدادات' },
  ];

  const isAdmin = user?.role === 'admin';
  const visibleAdminNavItems = isAdmin
    ? adminNavItems
    : adminNavItems.filter(item => canAccessAdminPage(item.href, user?.permissions ?? []));

  const balanceDisplay = user ? formatPrice(parseFloat(user.balance?.toString() ?? '0')) : '';

  return (
    <div className="min-h-screen bg-background text-foreground flex" dir={dir}>
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSidebarOpen(false)} className="fixed inset-0 bg-black/50 z-40 lg:hidden" />
        )}
      </AnimatePresence>

      <aside className={`fixed inset-y-0 ${dir === 'rtl' ? 'right-0' : 'left-0'} w-64 bg-card border-${dir === 'rtl' ? 'l' : 'r'} border-border z-50 flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : dir === 'rtl' ? 'translate-x-full lg:translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-5 border-b border-border">
          <Link href="/" className="flex items-center gap-2 group hover:opacity-90 transition-opacity">
            <Logo size={30} withText={true} />
          </Link>
        </div>

        {user && (
          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center">
                <span className="text-primary text-sm font-bold">{user.username[0].toUpperCase()}</span>
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">{user.username}</p>
                <p className="text-xs text-secondary font-medium">{balanceDisplay}</p>
              </div>
            </div>
          </div>
        )}

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map(item => {
            const Icon = item.icon;
            const active = location === item.href;
            return (
              <Link key={item.href} href={item.href} onClick={() => setSidebarOpen(false)} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${active ? 'bg-primary/15 text-primary border border-primary/20' : 'text-muted-foreground hover:bg-background hover:text-foreground'}`}>
                <Icon size={16} />
                {item.label}
                {active && <ChevronRight size={14} className={`${dir === 'rtl' ? 'mr-auto rotate-180' : 'ml-auto'} text-primary`} />}
              </Link>
            );
          })}

          {(isAdmin || visibleAdminNavItems.length > 0) && (
            <>
              <div className="pt-3 pb-1 px-3">
                <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Admin</span>
              </div>
              {visibleAdminNavItems.map(item => {
                const Icon = item.icon;
                const active = location === item.href;
                return (
                  <Link key={item.href} href={item.href} onClick={() => setSidebarOpen(false)} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${active ? 'bg-primary/15 text-primary border border-primary/20' : 'text-muted-foreground hover:bg-background hover:text-foreground'}`}>
                    <Icon size={16} />
                    {item.label}
                  </Link>
                );
              })}
            </>
          )}
        </nav>

        <div className="p-3 border-t border-border space-y-1">
          <div className="flex items-center gap-2 px-3 py-2">
            <LanguageSwitcher />
            <CurrencySwitcher />
          </div>
          <button onClick={logout} className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all">
            <LogOut size={16} />
            {t('logout')}
          </button>
        </div>
      </aside>

      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen pb-20 lg:pb-0 min-w-0 overflow-x-hidden w-full">
        {/* Mobile Header */}
        <header className="sticky top-0 z-30 border-b border-border/60 bg-background/97 backdrop-blur-xl lg:hidden" style={{ backdropFilter: 'blur(20px)' }}>
          <div className="flex items-center justify-between h-14 px-2 gap-1.5" dir="rtl">
            {/* Right side: Logo */}
            <Link href="/" className="flex items-center shrink-0 min-w-0">
              <Logo size={20} withText={true} />
            </Link>

            {/* Left side: controls */}
            <div className="flex items-center gap-1 mr-auto shrink-0">
              {/* Balance */}
              {user && (
                <Link href="/deposit"
                  className="flex items-center gap-1 px-2 py-1 rounded-lg border border-primary/30 bg-primary/10 hover:bg-primary/20 transition-colors shrink-0"
                >
                  <span className="text-[11px] font-bold text-white whitespace-nowrap">{balanceDisplay}</span>
                  <span className="text-primary text-xs font-bold">+</span>
                </Link>
              )}

              {/* Admin Live Bell (admins only, real-time) */}
              {isAdmin && <AdminLiveBell />}

              {/* Bell */}
              <Link href="/notifications" className="relative p-1.5 rounded-lg hover:bg-card transition-colors shrink-0">
                <Bell size={17} className="text-muted-foreground" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-destructive text-white text-[8px] font-bold rounded-full flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>

              {/* User Badge */}
              {user && (
                <Link href="/profile" className="shrink-0">
                  <div className="w-7 h-7 rounded-full flex items-center justify-center shadow-lg relative"
                    style={{
                      background: 'radial-gradient(circle at 30% 30%, #4f87ff, #1a3fa0)',
                      boxShadow: '0 0 0 2px rgba(59,130,246,0.4), 0 3px 10px rgba(30,58,138,0.5)',
                    }}>
                    <span className="text-white text-[11px] font-black">{user.username[0].toUpperCase()}</span>
                    <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-background"
                      style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)' }} />
                  </div>
                </Link>
              )}

              {/* Hamburger */}
              <button onClick={() => setSidebarOpen(true)} className="p-1.5 rounded-lg hover:bg-card transition-colors shrink-0">
                <Menu size={19} />
              </button>
            </div>
          </div>
        </header>

        {/* Desktop Header */}
        <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-xl hidden lg:block">
          <div className="flex items-center justify-between h-14 px-4">
            <div className="flex-1" />
            {user && (
              <div className="flex items-center gap-3">
                <Link href="/deposit" className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-green-500/40 bg-green-500/10 hover:bg-green-500/20 transition-colors">
                  <span className="text-green-400 text-xs font-bold">+</span>
                  <span className="text-xs font-bold text-white">{balanceDisplay}</span>
                </Link>
                {isAdmin && <AdminLiveBell />}
                <Link href="/notifications" className="relative p-2 rounded-lg hover:bg-card transition-colors">
                  <Bell size={18} className="text-muted-foreground" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-white text-[10px] font-bold rounded-full flex items-center justify-center">{unreadCount > 9 ? '9+' : unreadCount}</span>
                  )}
                </Link>
              </div>
            )}
          </div>
        </header>

        <main className="flex-1 p-2 sm:p-4 lg:p-6 min-w-0 overflow-x-hidden">{children}</main>
      </div>

      <FloatingSupport />
    </div>
  );
}
