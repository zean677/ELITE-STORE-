import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Wifi, WifiOff, Trash2, Check, Loader2, Volume2, VolumeX, MonitorUp, MonitorOff } from 'lucide-react';
import { Link } from 'wouter';
import {
  useAdminWs,
  isAdminSoundEnabled, setAdminSoundEnabled,
  isAdminDesktopEnabled, setAdminDesktopEnabled,
  ensureNotificationPermission,
} from '@/hooks/use-admin-ws';

export function AdminLiveBell() {
  const { items, unread, status, markAllRead, clear } = useAdminWs();
  const [open, setOpen] = useState(false);
  const [soundOn, setSoundOn] = useState<boolean>(() => isAdminSoundEnabled());
  const [desktopOn, setDesktopOn] = useState<boolean>(() => isAdminDesktopEnabled());
  const [permission, setPermission] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'denied'
  );
  const ref = useRef<HTMLDivElement | null>(null);

  function toggleSound() {
    const next = !soundOn;
    setSoundOn(next);
    setAdminSoundEnabled(next);
  }
  async function toggleDesktop() {
    const next = !desktopOn;
    setDesktopOn(next);
    setAdminDesktopEnabled(next);
    if (next) {
      const p = await ensureNotificationPermission();
      setPermission(p);
    }
  }

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (!ref.current) return;
      if (!ref.current.contains(e.target as Node)) setOpen(false);
    }
    if (open) document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [open]);

  const dotColor =
    status === 'connected'
      ? 'bg-emerald-400'
      : status === 'connecting'
      ? 'bg-amber-400'
      : 'bg-rose-400';

  return (
    <div className="relative" ref={ref} dir="rtl">
      <button
        onClick={() => {
          setOpen(v => !v);
          if (!open && unread > 0) setTimeout(() => markAllRead(), 400);
        }}
        className="relative p-2 rounded-xl hover:bg-card transition-colors group"
        title={`إشعارات الإدارة • ${status === 'connected' ? 'مباشر' : status === 'connecting' ? 'يتصل...' : 'منقطع'}`}
        aria-label="Admin notifications"
      >
        <Bell size={18} className="text-muted-foreground group-hover:text-foreground transition-colors" />
        <span className={`absolute top-1 right-1 w-2 h-2 rounded-full ${dotColor} ring-2 ring-background`} />
        {unread > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -left-1 min-w-[18px] h-[18px] px-1 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-lg shadow-primary/40"
          >
            {unread > 99 ? '99+' : unread}
          </motion.span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="fixed sm:absolute top-16 sm:top-auto inset-x-3 sm:inset-x-auto sm:right-0 sm:left-auto sm:mt-2 sm:w-[340px] sm:max-w-[calc(100vw-1.5rem)] bg-card border border-border rounded-2xl shadow-2xl z-50 overflow-hidden"
          >
            <div className="p-3 border-b border-border flex items-center justify-between gap-2 bg-gradient-to-l from-primary/10 to-transparent">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center">
                  <Bell size={14} className="text-primary" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold leading-tight">الإشعارات المباشرة</h3>
                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground mt-0.5">
                    {status === 'connected' ? (
                      <><Wifi size={10} className="text-emerald-400" /><span className="text-emerald-400 font-semibold">مباشر</span></>
                    ) : status === 'connecting' ? (
                      <><Loader2 size={10} className="text-amber-400 animate-spin" /><span className="text-amber-400">يتصل...</span></>
                    ) : (
                      <><WifiOff size={10} className="text-rose-400" /><span className="text-rose-400">منقطع</span></>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={toggleSound}
                  className={`p-1.5 rounded-lg transition-colors ${soundOn ? 'text-emerald-400 hover:bg-emerald-500/10' : 'text-muted-foreground hover:bg-muted'}`}
                  title={soundOn ? 'إيقاف الصوت' : 'تفعيل الصوت'}
                >
                  {soundOn ? <Volume2 size={13} /> : <VolumeX size={13} />}
                </button>
                <button
                  onClick={toggleDesktop}
                  className={`p-1.5 rounded-lg transition-colors ${desktopOn && permission === 'granted' ? 'text-emerald-400 hover:bg-emerald-500/10' : 'text-muted-foreground hover:bg-muted'}`}
                  title={
                    permission === 'denied'
                      ? 'الإشعارات محظورة من المتصفح'
                      : desktopOn
                      ? 'إيقاف إشعار سطح المكتب'
                      : 'تفعيل إشعار سطح المكتب'
                  }
                >
                  {desktopOn && permission === 'granted' ? <MonitorUp size={13} /> : <MonitorOff size={13} />}
                </button>
                {items.length > 0 && (
                  <button
                    onClick={clear}
                    className="text-[10px] text-muted-foreground hover:text-rose-400 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-rose-500/10 transition-colors"
                    title="مسح الكل"
                  >
                    <Trash2 size={11} />
                    مسح
                  </button>
                )}
              </div>
            </div>

            <div className="max-h-[420px] overflow-y-auto">
              {items.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-muted/50 border border-border flex items-center justify-center mx-auto mb-2">
                    <Bell size={18} className="text-muted-foreground/40" />
                  </div>
                  <p className="text-xs text-muted-foreground">لا يوجد إشعارات بعد</p>
                  <p className="text-[10px] text-muted-foreground/70 mt-1">
                    سيظهر هنا أي طلب أو إيداع جديد فوراً
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {items.map(item => (
                    <ItemRow key={item.id} item={item} onClick={() => setOpen(false)} />
                  ))}
                </div>
              )}
            </div>

            {items.length > 0 && (
              <div className="p-2 border-t border-border bg-background/50">
                <button
                  onClick={() => { markAllRead(); }}
                  className="w-full text-[11px] text-muted-foreground hover:text-primary py-1.5 rounded-lg hover:bg-primary/10 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Check size={12} />
                  تحديد الكل كمقروء
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ItemRow({ item, onClick }: { item: ReturnType<typeof useAdminWs>['items'][number]; onClick: () => void }) {
  const minutesAgo = Math.max(0, Math.floor((Date.now() - item.ts) / 60000));
  const timeText =
    minutesAgo < 1 ? 'الآن' : minutesAgo < 60 ? `قبل ${minutesAgo} د` : `قبل ${Math.floor(minutesAgo / 60)} س`;

  const accent =
    item.type === 'new_order' ? 'border-r-primary' :
    item.type === 'order_completed' ? 'border-r-emerald-500' :
    item.type === 'order_failed' ? 'border-r-rose-500' :
    item.type === 'new_payment' ? 'border-r-amber-500' :
    item.type === 'payment_approved' ? 'border-r-emerald-500' :
    item.type === 'new_user' ? 'border-r-sky-500' : 'border-r-border';

  const inner = (
    <div className={`p-3 hover:bg-muted/30 transition-colors border-r-2 ${accent} ${!item.read ? 'bg-primary/[0.04]' : ''}`}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-bold leading-tight">{item.title}</p>
        <span className="text-[10px] text-muted-foreground whitespace-nowrap shrink-0">{timeText}</span>
      </div>
      <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed line-clamp-2">{item.body}</p>
    </div>
  );

  if (item.href) {
    return (
      <Link href={item.href} onClick={onClick}>
        <div className="cursor-pointer">{inner}</div>
      </Link>
    );
  }
  return inner;
}
