import React from 'react';

const logoFull = `${import.meta.env.BASE_URL}logo-full-v2.webp?v=1`;
const logoIcon = `${import.meta.env.BASE_URL}logo-icon.webp?v=2`;

interface LogoProps {
  size?: number;
  withText?: boolean;
  className?: string;
}

const FULL_W = 1024;
const FULL_H = 215;
const FULL_RATIO = FULL_W / FULL_H;

export function Logo({ size = 36, withText = false, className = '' }: LogoProps) {
  if (withText) {
    const height = Math.round(size * 1.6);
    const width = Math.round(height * FULL_RATIO);
    return (
      <img
        src={logoFull}
        alt="Elite Store"
        width={width}
        height={height}
        loading="eager"
        decoding="async"
        fetchPriority="high"
        className={`inline-block align-middle select-none ${className}`}
        style={{
          height,
          width: 'auto',
          maxWidth: '100%',
          objectFit: 'contain',
          direction: 'ltr',
        }}
      />
    );
  }

  return (
    <img
      src={logoIcon}
      alt="Elite Store"
      width={size}
      height={size}
      loading="eager"
      decoding="async"
      fetchPriority="high"
      className={`inline-block align-middle select-none ${className}`}
      style={{
        width: size,
        height: size,
        display: 'block',
        borderRadius: Math.round(size * 0.22),
        filter: 'drop-shadow(0 2px 8px rgba(124, 92, 255, 0.4))',
      }}
    />
  );
}
