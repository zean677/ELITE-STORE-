import React from 'react';
import { Crown, Sparkles } from 'lucide-react';

export const VIP_TIERS = [
  { level: 1, thresholdUsd: 100, discountPercent: 1, from: 'from-amber-500', to: 'to-yellow-300', ring: 'border-yellow-300/50' },
  { level: 2, thresholdUsd: 300, discountPercent: 2, from: 'from-sky-400', to: 'to-cyan-200', ring: 'border-cyan-200/50' },
  { level: 3, thresholdUsd: 700, discountPercent: 4, from: 'from-fuchsia-500', to: 'to-pink-300', ring: 'border-pink-300/50' },
  { level: 4, thresholdUsd: 1500, discountPercent: 7, from: 'from-violet-500', to: 'to-yellow-200', ring: 'border-yellow-200/60' },
];

export function getVipFromData(source: any) {
  const vip = source?.vip;
  const level = Number(vip?.level ?? source?.vipLevel ?? 0);
  const totalSpentUsd = Number(vip?.totalSpentUsd ?? source?.totalSpentUsd ?? 0);
  const discountPercent = Number(vip?.discountPercent ?? source?.vipDiscountPercent ?? 0);
  const nextThresholdUsd = vip?.nextThresholdUsd ?? VIP_TIERS.find(t => totalSpentUsd < t.thresholdUsd)?.thresholdUsd ?? null;
  const remainingToNextUsd = vip?.remainingToNextUsd ?? (nextThresholdUsd ? Math.max(0, nextThresholdUsd - totalSpentUsd) : 0);
  const progressToNext = vip?.progressToNext ?? (nextThresholdUsd ? Math.max(0, Math.min(100, (totalSpentUsd / nextThresholdUsd) * 100)) : 100);
  const tier = VIP_TIERS.find(t => t.level === level);
  return { level, totalSpentUsd, discountPercent, nextThresholdUsd, remainingToNextUsd, progressToNext, tier };
}

export function VipBadge({ source, compact = false }: { source: any; compact?: boolean }) {
  const vip = getVipFromData(source);
  const tier = vip.tier ?? VIP_TIERS[0];
  const label = vip.level > 0 ? `VIP ${vip.level}` : 'VIP';

  return (
    <div className={`inline-flex items-center gap-2 rounded-full border ${tier.ring} bg-gradient-to-r ${tier.from} ${tier.to} px-3 py-1.5 text-slate-950 shadow-lg shadow-yellow-500/10`}>
      <Crown size={compact ? 13 : 15} className="fill-current" />
      <span className={`${compact ? 'text-[11px]' : 'text-xs'} font-black tracking-wide`}>{label}</span>
      {vip.discountPercent > 0 && <span className="rounded-full bg-black/15 px-2 py-0.5 text-[10px] font-black">-{vip.discountPercent}%</span>}
    </div>
  );
}

export function VipProgressCard({ source, sypRate = 13000, eurRate = 0.92 }: { source: any; sypRate?: number; eurRate?: number }) {
  const vip = getVipFromData(source);
  const nextUsd = vip.nextThresholdUsd;

  return (
    <div className="relative overflow-hidden rounded-3xl border border-yellow-300/20 bg-[radial-gradient(circle_at_top_right,rgba(250,204,21,0.22),transparent_35%),linear-gradient(135deg,rgba(124,58,237,0.22),rgba(15,23,42,0.92))] p-5">
      <div className="absolute -left-10 -top-10 h-28 w-28 rounded-full bg-yellow-300/10 blur-2xl" />
      <div className="relative flex items-start justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.22em] text-yellow-200">
            <Sparkles size={14} />
            Elite VIP
          </p>
          <h3 className="mt-2 text-2xl font-black text-white">{vip.level > 0 ? `VIP ${vip.level}` : 'ابدأ رحلتك إلى VIP 1'}</h3>
          <p className="mt-1 text-sm text-white/70">إجمالي إنفاقك: ${vip.totalSpentUsd.toFixed(2)}</p>
        </div>
        <VipBadge source={source} />
      </div>

      <div className="relative mt-5">
        <div className="mb-2 flex justify-between text-xs text-white/70">
          <span>{nextUsd ? `المتبقي للترقية: $${vip.remainingToNextUsd.toFixed(2)}` : 'وصلت لأعلى مستوى'}</span>
          <span>{Math.round(vip.progressToNext)}%</span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full bg-gradient-to-r from-yellow-300 to-amber-500" style={{ width: `${vip.progressToNext}%` }} />
        </div>
      </div>

      <div className="relative mt-4 grid grid-cols-3 gap-2 text-center text-[11px] text-white/70">
        <div className="rounded-xl bg-white/10 p-2">
          <p className="font-bold text-white">USD</p>
          <p>{nextUsd ? `$${nextUsd.toFixed(0)}` : 'MAX'}</p>
        </div>
        <div className="rounded-xl bg-white/10 p-2">
          <p className="font-bold text-white">SYP</p>
          <p>{nextUsd ? `${Math.round(nextUsd * sypRate).toLocaleString('en-US')} ل.س` : 'MAX'}</p>
        </div>
        <div className="rounded-xl bg-white/10 p-2">
          <p className="font-bold text-white">EUR</p>
          <p>{nextUsd ? `€${(nextUsd * eurRate).toFixed(0)}` : 'MAX'}</p>
        </div>
      </div>
    </div>
  );
}