import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { Crown, X, ArrowLeft, Sparkles, Trophy } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useCurrency } from '@/hooks/use-currency';
import { useLanguage } from '@/i18n';
import { useToast } from '@/hooks/use-toast';

export const VIP_BAR_DISMISS_KEY = 'vip_upgrade_bar_dismissed';

interface VipInfo {
  level: number;
  discountPercent: number;
  totalSpentUsd: number;
  nextThresholdUsd: number | null;
  remainingToNextUsd: number;
  progressToNext: number;
  tiers?: Array<{ level: number; thresholdUsd: number; discountPercent: number }>;
}

export function VipUpgradeBar() {
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const { lang } = useLanguage();
  const { toast } = useToast();
  const [dismissed, setDismissed] = useState(false);
  const prevLevelRef = useRef<number | null>(null);

  // Read permanent dismiss preference; listen for restore event
  useEffect(() => {
    try {
      const raw = localStorage.getItem(VIP_BAR_DISMISS_KEY);
      if (raw === 'permanent') setDismissed(true);
    } catch {}

    const handleStorage = (e: StorageEvent) => {
      if (e.key === VIP_BAR_DISMISS_KEY && e.newValue === null) setDismissed(false);
    };
    window.addEventListener('storage', handleStorage);
    // Also listen for in-page restore (same tab)
    const handleRestore = () => setDismissed(false);
    window.addEventListener('vip-bar-restore', handleRestore);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('vip-bar-restore', handleRestore);
    };
  }, []);

  const vip: VipInfo | undefined = (user as any)?.vip;
  const currentLevel = vip?.level ?? 0;

  // Detect VIP level upgrade — show toast immediately
  useEffect(() => {
    if (prevLevelRef.current === null) {
      prevLevelRef.current = currentLevel;
      return;
    }
    if (currentLevel > prevLevelRef.current && currentLevel > 0) {
      const tierColors: Record<number, string> = { 1: '🥉', 2: '🥈', 3: '🥇', 4: '👑' };
      const emoji = tierColors[currentLevel] ?? '⭐';
      toast({
        title: `${emoji} ترقية VIP! أصبحت VIP ${currentLevel}`,
        description: `تهانينا! حصلت على خصم ${vip?.discountPercent ?? 0}% على جميع طلباتك`,
        duration: 8000,
      });
      prevLevelRef.current = currentLevel;
    } else {
      prevLevelRef.current = currentLevel;
    }
  }, [currentLevel]);

  if (!user || dismissed) return null;
  if (!vip) return null;

  const isMaxLevel = vip.nextThresholdUsd === null || vip.nextThresholdUsd === undefined;
  const nextTier = vip.tiers?.find(t => t.thresholdUsd === vip.nextThresholdUsd);
  const nextLevel = nextTier?.level ?? vip.level + 1;
  const nextDiscount = nextTier?.discountPercent ?? (vip.discountPercent + 1);
  const remaining = vip.remainingToNextUsd ?? 0;
  const progress = Math.max(0, Math.min(100, vip.progressToNext ?? 0));
  const isNew = vip.level === 0;

  const handleDismiss = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try { localStorage.setItem(VIP_BAR_DISMISS_KEY, 'permanent'); } catch {}
    setDismissed(true);
  };

  // ── MAX LEVEL banner ──────────────────────────────────────────────────────
  if (isMaxLevel && vip.level >= 4) {
    return (
      <div
        className="relative w-full overflow-hidden"
        style={{
          background: 'linear-gradient(90deg, rgba(124,58,237,0.22), rgba(250,204,21,0.22), rgba(124,58,237,0.22))',
          borderBottom: '1px solid rgba(250,204,21,0.35)',
        }}
      >
        <div className="absolute inset-0 opacity-25 pointer-events-none"
          style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.18), transparent)', animation: 'shine-slide 3s ease-in-out infinite' }} />
        <Link href="/profile" className="block relative">
          <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #7c3aed, #facc15)', boxShadow: '0 0 18px rgba(250,204,21,0.5)' }}>
              <Trophy size={18} className="text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-xs sm:text-sm font-bold text-foreground">
                {lang === 'ar'
                  ? <>{lang === 'ar' ? 'أنت في أعلى مستوى VIP ' : 'You\'ve reached the highest VIP level '}<span className="text-yellow-300 font-black">🎉</span> مبروك <span className="text-yellow-300 font-black">VIP {vip.level}</span> — خصمك الدائم <span className="text-emerald-400 font-black">{vip.discountPercent}%</span></>
                  : <>You've reached <span className="text-yellow-300 font-black">VIP {vip.level} — Max Level 🎉</span> You enjoy <span className="text-emerald-400 font-black">{vip.discountPercent}%</span> off every order!</>
                }
              </span>
            </div>
            <button onClick={handleDismiss}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
              aria-label="dismiss">
              <X size={14} />
            </button>
          </div>
        </Link>
      </div>
    );
  }

  // ── Normal progress banner ────────────────────────────────────────────────
  return (
    <div
      className="relative w-full overflow-hidden"
      style={{
        background: isNew
          ? 'linear-gradient(90deg, rgba(108,92,231,0.18), rgba(245,158,11,0.18), rgba(108,92,231,0.18))'
          : 'linear-gradient(90deg, rgba(245,158,11,0.18), rgba(234,179,8,0.18), rgba(245,158,11,0.18))',
        borderBottom: '1px solid rgba(245,158,11,0.25)',
      }}
    >
      <div className="absolute inset-0 opacity-30 pointer-events-none"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent)', animation: 'shine-slide 4s ease-in-out infinite' }} />

      <Link href="/profile" className="block relative">
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #f59e0b, #eab308)', boxShadow: '0 0 16px rgba(245,158,11,0.4)' }}>
            <Crown size={18} className="text-white" fill="currentColor" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs sm:text-sm font-bold text-foreground">
                {isNew ? (
                  lang === 'ar'
                    ? <>اشترِ بـ <span className="text-amber-400 font-black">{formatPrice(remaining)}</span> فقط لتصبح <span className="text-amber-400 font-black">VIP {nextLevel}</span> وتوفّر <span className="text-emerald-400 font-black">{nextDiscount}%</span> على كل طلب 🎉</>
                    : <>Spend <span className="text-amber-400 font-black">{formatPrice(remaining)}</span> more to unlock <span className="text-amber-400 font-black">VIP {nextLevel}</span> and save <span className="text-emerald-400 font-black">{nextDiscount}%</span>!</>
                ) : (
                  lang === 'ar'
                    ? <>أنت <span className="text-amber-400 font-black">VIP {vip.level}</span> ({vip.discountPercent}%). اشترِ بـ <span className="text-amber-400 font-black">{formatPrice(remaining)}</span> لترتقي إلى <span className="text-amber-400 font-black">VIP {nextLevel}</span> = <span className="text-emerald-400 font-black">{nextDiscount}%</span> خصم! ⬆️</>
                    : <>You're <span className="text-amber-400 font-black">VIP {vip.level}</span> ({vip.discountPercent}%). Spend <span className="text-amber-400 font-black">{formatPrice(remaining)}</span> more for <span className="text-amber-400 font-black">VIP {nextLevel}</span> = <span className="text-emerald-400 font-black">{nextDiscount}%</span>! ⬆️</>
                )}
              </span>
            </div>
            {/* Animated progress bar */}
            <div className="mt-1.5 h-1.5 w-full bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full relative overflow-hidden transition-all duration-700 ease-out"
                style={{
                  width: `${progress}%`,
                  background: 'linear-gradient(90deg, #f59e0b, #eab308, #facc15)',
                  boxShadow: '0 0 8px rgba(245,158,11,0.6)',
                }}
              >
                <div className="absolute inset-0 opacity-60"
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)', animation: 'shine-slide 2s ease-in-out infinite' }} />
              </div>
            </div>
            <div className="mt-0.5 flex justify-between text-[10px] text-white/40">
              <span>${vip.totalSpentUsd?.toFixed(0) ?? '0'}</span>
              <span className="font-bold text-amber-400/70">{Math.round(progress)}%</span>
              <span>${vip.nextThresholdUsd?.toFixed(0) ?? '?'}</span>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1 text-amber-400 font-black text-xs flex-shrink-0">
            <Sparkles size={12} />
            <span>{lang === 'ar' ? 'تفاصيل' : 'Details'}</span>
            <ArrowLeft size={12} />
          </div>

          <button onClick={handleDismiss}
            className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            title={lang === 'ar' ? 'إخفاء' : 'Hide'}
            aria-label="dismiss">
            <X size={14} />
          </button>
        </div>
      </Link>
    </div>
  );
}
