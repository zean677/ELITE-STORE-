import React from 'react';
import { RefreshCw, AlertTriangle } from 'lucide-react';

interface State { hasError: boolean; error?: Error }

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6" dir="rtl">
        <div className="max-w-md w-full text-center space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-destructive/15 border border-destructive/20 flex items-center justify-center mx-auto">
            <AlertTriangle size={28} className="text-destructive" />
          </div>
          <div>
            <h1 className="text-xl font-black mb-2">حدث خطأ غير متوقع</h1>
            <p className="text-sm text-muted-foreground">
              يرجى تحديث الصفحة. إذا استمر الخطأ، تواصل مع الدعم.
            </p>
          </div>
          <button
            onClick={() => window.location.reload()}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-white font-semibold rounded-xl hover:bg-primary/90 transition-colors"
          >
            <RefreshCw size={16} />
            تحديث الصفحة
          </button>
          {import.meta.env.DEV && this.state.error && (
            <pre className="text-left text-xs bg-card border border-border rounded-xl p-4 overflow-auto max-h-40 text-destructive">
              {this.state.error.message}
            </pre>
          )}
        </div>
      </div>
    );
  }
}
