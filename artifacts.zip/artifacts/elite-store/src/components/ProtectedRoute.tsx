import React from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { canAccessAdminPage } from '@/lib/admin-route-access';

interface ProtectedRouteProps {
  children: React.ReactNode;
  adminOnly?: boolean;
}

export function ProtectedRoute({ children, adminOnly = false }: ProtectedRouteProps) {
  const { user, token, loading } = useAuth();
  const [location, navigate] = useLocation();
  const hasAdminAccess = !!user && (
    user.role === 'admin' || canAccessAdminPage(location, user.permissions ?? [])
  );

  React.useEffect(() => {
    if (loading) return;
    // Only kick out if there's NO token at all — if a token exists but /me
    // hasn't returned (transient error / slow network), give it a chance.
    if (!token) {
      navigate('/login');
    } else if (adminOnly && user && !hasAdminAccess) {
      navigate('/dashboard');
    }
  }, [user, token, loading, adminOnly, hasAdminAccess, navigate]);

  if (loading || (token && !user)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 mx-auto rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <p className="text-muted-foreground text-sm">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;
  if (adminOnly && !hasAdminAccess) return null;

  return <>{children}</>;
}
