import React, { useState, useEffect } from 'react';
import { bustUrl } from '@/lib/image-utils';

interface Props {
  src?: string | null;
  alt?: string;
  className?: string;
  skeletonClassName?: string;
  fallback?: React.ReactNode;
  imgStyle?: React.CSSProperties;
  loading?: 'lazy' | 'eager';
  onError?: () => void;
  version?: string;
}

/**
 * Drops a skeleton pulse placeholder while the image loads, then fades in.
 * Appends ?v=<cache-token> to local upload URLs automatically.
 */
export function ImageWithSkeleton({
  src,
  alt = '',
  className = '',
  skeletonClassName = '',
  fallback,
  imgStyle,
  loading = 'lazy',
  onError,
  version,
}: Props) {
  const [loaded, setLoaded] = useState(false);
  const [errored, setErrored] = useState(false);
  const busted = bustUrl(src, version);

  // Reset state when URL changes so skeleton re-appears for the new image
  useEffect(() => {
    setLoaded(false);
    setErrored(false);
  }, [busted]);

  if (!busted || errored) {
    return <>{fallback ?? null}</>;
  }

  return (
    <div className={`relative overflow-hidden ${skeletonClassName}`} style={{ display: 'contents' }}>
      {!loaded && (
        <div
          className={`absolute inset-0 animate-pulse bg-white/5 rounded-inherit ${skeletonClassName}`}
          style={{ borderRadius: 'inherit' }}
        />
      )}
      <img
        src={busted}
        alt={alt}
        loading={loading}
        decoding="async"
        className={`${className} transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        style={imgStyle}
        onLoad={() => setLoaded(true)}
        onError={() => { setErrored(true); onError?.(); }}
      />
    </div>
  );
}

export default ImageWithSkeleton;
