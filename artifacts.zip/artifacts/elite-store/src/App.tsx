import { lazy, Suspense } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/i18n";
import { CurrencyProvider } from "@/hooks/use-currency";
import { AuthProvider } from "@/hooks/use-auth";
import { CartProvider } from "@/hooks/use-cart";
import { AnnouncementBanner } from "@/components/AnnouncementBanner";
import { BottomNavigation } from "@/components/BottomNavigation";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import NotFound from "@/pages/not-found";

const Home = lazy(() => import("@/pages/Home"));
const Login = lazy(() => import("@/pages/Login"));
const Register = lazy(() => import("@/pages/Register"));
const Products = lazy(() => import("@/pages/Products"));
const GamesList = lazy(() => import("@/pages/GamesList"));
const ProductDetail = lazy(() => import("@/pages/ProductDetail"));
const Dashboard = lazy(() => import("@/pages/Dashboard"));
const WalletPage = lazy(() => import("@/pages/WalletPage"));
const Deposit = lazy(() => import("@/pages/Deposit"));
const Orders = lazy(() => import("@/pages/Orders"));
const OrderResult = lazy(() => import("@/pages/OrderResult"));
const OrderDetail = lazy(() => import("@/pages/OrderDetail"));
const Notifications = lazy(() => import("@/pages/Notifications"));
const Profile = lazy(() => import("@/pages/Profile"));
const Support = lazy(() => import("@/pages/Support"));
const Terms = lazy(() => import("@/pages/Terms"));
const Security = lazy(() => import("@/pages/Security"));
const AdminDashboard = lazy(() => import("@/pages/admin/AdminDashboard"));
const AdminOrders = lazy(() => import("@/pages/admin/AdminOrders"));
const AdminPayments = lazy(() => import("@/pages/admin/AdminPayments"));
const AdminUsers = lazy(() => import("@/pages/admin/AdminUsers"));
const AdminProducts = lazy(() => import("@/pages/admin/AdminProducts"));
const AdminSettings = lazy(() => import("@/pages/admin/AdminSettings"));
const AdminCategories = lazy(() => import("@/pages/admin/AdminCategories"));
const AdminCategoryMapping = lazy(() => import("@/pages/admin/AdminCategoryMapping"));
const AdminNotifications = lazy(() => import("@/pages/admin/AdminNotifications"));
const AdminPromoCodes = lazy(() => import("@/pages/admin/AdminPromoCodes"));
const AdminPaymentMethods = lazy(() => import("@/pages/admin/AdminPaymentMethods"));
const AdminActivityLog = lazy(() => import("@/pages/admin/AdminActivityLog"));
const AdminBanners = lazy(() => import("@/pages/admin/AdminBanners"));
const AdminLoyalty = lazy(() => import("@/pages/admin/AdminLoyalty"));
const LoyaltyRewards = lazy(() => import("@/pages/LoyaltyRewards"));
const PriceAlerts = lazy(() => import("@/pages/PriceAlerts"));
const AdminAnalytics = lazy(() => import("@/pages/admin/AdminAnalytics"));
const AdminSystem = lazy(() => import("@/pages/admin/AdminSystem"));
const AdminMonitoring = lazy(() => import("@/pages/admin/AdminMonitoring"));
const AdminProviderErrors = lazy(() => import("@/pages/admin/AdminProviderErrors"));
const AdminTopSelling = lazy(() => import("@/pages/admin/AdminTopSelling"));
const AdminDeadProducts = lazy(() => import("@/pages/admin/AdminDeadProducts"));
const AdminFeaturedTabs = lazy(() => import("@/pages/admin/AdminFeaturedTabs"));
const AdminControlCenter = lazy(() => import("@/pages/admin/AdminControlCenter"));
const AdminStaff = lazy(() => import("@/pages/admin/AdminStaff"));
const AdminScheduled = lazy(() => import("@/pages/admin/AdminScheduled"));
const AdminProductHistory = lazy(() => import("@/pages/admin/AdminProductHistory"));
const AdminSmartPricing = lazy(() => import("@/pages/admin/AdminSmartPricing"));
const LoginHistory = lazy(() => import("@/pages/LoginHistory"));
const Wishlist = lazy(() => import("@/pages/Wishlist"));
const VipLeaderboard = lazy(() => import("@/pages/VipLeaderboard"));
const Cart = lazy(() => import("@/pages/Cart"));
const FAQ = lazy(() => import("@/pages/FAQ"));
const Bundles = lazy(() => import("@/pages/Bundles"));
const BundleDetail = lazy(() => import("@/pages/BundleDetail"));
const AdminBundles = lazy(() => import("@/pages/admin/AdminBundles"));
const AdminBackups = lazy(() => import("@/pages/admin/AdminBackups"));
const AdminCardBuilder = lazy(() => import("@/pages/admin/AdminCardBuilder"));
const AdminCategoryCardBuilder = lazy(() => import("@/pages/admin/AdminCategoryCardBuilder"));
const StatusPage = lazy(() => import("@/pages/StatusPage"));
const AdminOrderQueue = lazy(() => import("@/pages/admin/AdminOrderQueue"));
const SupportTickets = lazy(() => import("@/pages/SupportTickets"));
const AdminSupport = lazy(() => import("@/pages/admin/AdminSupport"));
const AdminImageTools = lazy(() => import("@/pages/admin/AdminImageTools"));
const AdminFinancial = lazy(() => import("@/pages/admin/AdminFinancial"));
const AdminSecurity = lazy(() => import("@/pages/admin/AdminSecurity"));
const AdminAutomation = lazy(() => import("@/pages/admin/AdminAutomation"));
const AdminStoreEditor = lazy(() => import("@/pages/admin/AdminStoreEditor"));
const UserStats = lazy(() => import("@/pages/UserStats"));
const GiftCards = lazy(() => import("@/pages/GiftCards"));
const GroupBuy = lazy(() => import("@/pages/GroupBuy"));
const AdminIntelligence = lazy(() => import("@/pages/admin/AdminIntelligence"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
      staleTime: 30_000,
    },
  },
});

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
    </div>
  );
}

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/products" component={Products} />
        <Route path="/games" component={GamesList} />
        <Route path="/products/:id" component={ProductDetail} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/wallet" component={WalletPage} />
        <Route path="/deposit" component={Deposit} />
        <Route path="/orders" component={Orders} />
        <Route path="/orders/:id/success" component={OrderResult} />
        <Route path="/orders/:id/failed" component={OrderResult} />
        <Route path="/orders/:id" component={OrderDetail} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/profile" component={Profile} />
        <Route path="/support" component={Support} />
        <Route path="/terms" component={Terms} />
        <Route path="/privacy" component={Terms} />
        <Route path="/security" component={Security} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/orders" component={AdminOrders} />
        <Route path="/admin/payments" component={AdminPayments} />
        <Route path="/admin/users" component={AdminUsers} />
        <Route path="/admin/products" component={AdminProducts} />
        <Route path="/admin/settings" component={AdminSettings} />
        <Route path="/admin/categories" component={AdminCategories} />
        <Route path="/admin/category-mapping" component={AdminCategoryMapping} />
        <Route path="/admin/notifications" component={AdminNotifications} />
        <Route path="/admin/promo-codes" component={AdminPromoCodes} />
        <Route path="/admin/payment-methods" component={AdminPaymentMethods} />
        <Route path="/admin/activity-log" component={AdminActivityLog} />
        <Route path="/admin/banners" component={AdminBanners} />
        <Route path="/admin/loyalty" component={AdminLoyalty} />
        <Route path="/admin/analytics" component={AdminAnalytics} />
        <Route path="/admin/system" component={AdminSystem} />
        <Route path="/admin/monitoring" component={AdminMonitoring} />
        <Route path="/admin/provider-errors" component={AdminProviderErrors} />
        <Route path="/admin/top-selling" component={AdminTopSelling} />
        <Route path="/admin/dead-products" component={AdminDeadProducts} />
        <Route path="/admin/bundles" component={AdminBundles} />
        <Route path="/admin/backups" component={AdminBackups} />
        <Route path="/bundles" component={Bundles} />
        <Route path="/bundles/:id" component={BundleDetail} />
        <Route path="/admin/featured-tabs" component={AdminFeaturedTabs} />
        <Route path="/admin/control" component={AdminControlCenter} />
        <Route path="/admin/staff" component={AdminStaff} />
        <Route path="/admin/scheduled" component={AdminScheduled} />
        <Route path="/admin/smart-pricing" component={AdminSmartPricing} />
        <Route path="/admin/card-builder" component={AdminCardBuilder} />
        <Route path="/admin/category-card-builder" component={AdminCategoryCardBuilder} />
        <Route path="/status" component={StatusPage} />
        <Route path="/admin/order-queue" component={AdminOrderQueue} />
        <Route path="/support/tickets" component={SupportTickets} />
        <Route path="/admin/support" component={AdminSupport} />
        <Route path="/admin/image-tools" component={AdminImageTools} />
        <Route path="/admin/financial" component={AdminFinancial} />
        <Route path="/admin/security" component={AdminSecurity} />
        <Route path="/admin/automation" component={AdminAutomation} />
        <Route path="/admin/store-editor" component={AdminStoreEditor} />
        <Route path="/admin/products/:id/history" component={AdminProductHistory} />
        <Route path="/login-history" component={LoginHistory} />
        <Route path="/stats" component={UserStats} />
        <Route path="/gift-cards" component={GiftCards} />
        <Route path="/group-buys" component={GroupBuy} />
        <Route path="/admin/intelligence" component={AdminIntelligence} />
        <Route path="/rewards" component={LoyaltyRewards} />
        <Route path="/price-alerts" component={PriceAlerts} />
        <Route path="/wishlist" component={Wishlist} />
        <Route path="/vip-leaderboard" component={VipLeaderboard} />
        <Route path="/cart" component={Cart} />
        <Route path="/faq" component={FAQ} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <CurrencyProvider>
          <AuthProvider>
            <CartProvider>
              <TooltipProvider>
                <WouterRouter base={import.meta.env.BASE_URL?.replace(/\/$/, "") || ""}>
                  <AnnouncementBanner />
                  <Router />
                  <BottomNavigation />
                  <PWAInstallPrompt />
                </WouterRouter>
                <Toaster />
              </TooltipProvider>
            </CartProvider>
          </AuthProvider>
        </CurrencyProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
