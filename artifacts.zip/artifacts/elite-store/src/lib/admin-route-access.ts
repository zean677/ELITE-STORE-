type PermissionGroups = readonly string[];

const ADMIN_PAGE_PERMISSIONS: Array<{ pattern: RegExp; permissions: PermissionGroups }> = [
  { pattern: /^\/admin$/, permissions: ["analytics.view"] },
  { pattern: /^\/admin\/(orders|order-queue)(?:\/|$)/, permissions: ["orders.view", "orders.write"] },
  { pattern: /^\/admin\/payments(?:\/|$)/, permissions: ["payments.view", "payments.approve", "payments.manage"] },
  { pattern: /^\/admin\/users(?:\/|$)/, permissions: ["users.view", "users.write"] },
  { pattern: /^\/admin\/products\/[^/]+\/history$/, permissions: ["products.view", "products.write"] },
  { pattern: /^\/admin\/(products|categories|category-mapping|featured-tabs|dead-products|smart-pricing)(?:\/|$)/, permissions: ["products.view", "products.write"] },
  { pattern: /^\/admin\/(notifications|scheduled)(?:\/|$)/, permissions: ["notifications.view", "notifications.write"] },
  { pattern: /^\/admin\/(promo-codes|bundles)(?:\/|$)/, permissions: ["offers.manage"] },
  { pattern: /^\/admin\/loyalty(?:\/|$)/, permissions: ["loyalty.manage"] },
  { pattern: /^\/admin\/analytics(?:\/|$)/, permissions: ["analytics.view"] },
  { pattern: /^\/admin\/(top-selling|financial|intelligence)(?:\/|$)/, permissions: ["analytics.view"] },
  { pattern: /^\/admin\/(monitoring|system)(?:\/|$)/, permissions: ["system.monitor"] },
  { pattern: /^\/admin\/support(?:\/|$)/, permissions: ["support.manage"] },
  { pattern: /^\/admin\/store-editor(?:\/|$)/, permissions: ["settings.write"] },
  { pattern: /^\/admin\/banners(?:\/|$)/, permissions: ["store.manage"] },
  { pattern: /^\/admin\/image-tools(?:\/|$)/, permissions: ["media.manage"] },
];

const IMPLIED_PERMISSIONS: Record<string, string[]> = {
  "orders.view": ["orders.write"],
  "payments.view": ["payments.approve", "payments.manage"],
  "users.view": ["users.write"],
  "products.view": ["products.write"],
  "notifications.view": ["notifications.write"],
};

export function canAccessAdminPage(path: string, userPermissions: string[] = []): boolean {
  const normalizedPath = path.split("?")[0].replace(/\/+$/, "") || "/";
  const rule = ADMIN_PAGE_PERMISSIONS.find(({ pattern }) => pattern.test(normalizedPath));
  if (!rule) return false;

  const permissions = new Set(userPermissions);
  return rule.permissions.some((required) =>
    permissions.has(required) || (IMPLIED_PERMISSIONS[required] ?? []).some((granted) => permissions.has(granted)),
  );
}