const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

const headers = (json = false) => {
  const h: Record<string, string> = { Authorization: `Bearer ${localStorage.getItem('elite_token') || ''}` };
  if (json) h['Content-Type'] = 'application/json';
  return h;
};

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = window.atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; ++i) out[i] = raw.charCodeAt(i);
  return out;
}

export function isPushSupported(): boolean {
  return typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
}

export async function getCurrentSubscription(): Promise<PushSubscription | null> {
  if (!isPushSupported()) return null;
  const reg = await navigator.serviceWorker.ready;
  return await reg.pushManager.getSubscription();
}

export async function subscribePush(): Promise<{ ok: boolean; reason?: string }> {
  if (!isPushSupported()) return { ok: false, reason: 'الجهاز ما يدعم الإشعارات' };
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') return { ok: false, reason: 'لازم تسمح بالإشعارات من إعدادات المتصفح' };

  const keyRes = await fetch(`${BASE}/api/push/public-key`).then((r) => r.json());
  if (!keyRes?.key) return { ok: false, reason: 'مفتاح الخادم غير متوفر' };

  const reg = await navigator.serviceWorker.ready;
  let sub = await reg.pushManager.getSubscription();
  if (!sub) {
    sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(keyRes.key) as BufferSource,
    });
  }
  const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
  const r = await fetch(`${BASE}/api/push/subscribe`, {
    method: 'POST',
    headers: headers(true),
    body: JSON.stringify({ endpoint: json.endpoint, keys: json.keys }),
  });
  if (!r.ok) return { ok: false, reason: 'فشل التسجيل في الخادم' };
  return { ok: true };
}

export async function unsubscribePush(): Promise<boolean> {
  const sub = await getCurrentSubscription();
  if (!sub) return true;
  try {
    await fetch(`${BASE}/api/push/unsubscribe`, {
      method: 'POST',
      headers: headers(true),
      body: JSON.stringify({ endpoint: sub.endpoint }),
    });
  } catch {}
  await sub.unsubscribe();
  return true;
}

export async function sendTestPush(): Promise<boolean> {
  try {
    const r = await fetch(`${BASE}/api/push/test`, { method: 'POST', headers: headers() });
    const j = await r.json();
    return (j?.ok ?? 0) > 0;
  } catch { return false; }
}
