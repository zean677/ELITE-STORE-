// ─── Image Cache Busting & URL Utilities ─────────────────────────────────────
//
// Images uploaded through the admin panel live at /api/uploads/…
// After an admin edits a product/category image, we append ?v=<epoch> so the
// browser fetches the new file instead of serving the stale cached version.

const CACHE_KEY = "elite_img_version";

/** Read the current global image-cache token (persists in localStorage). */
export function getImageVersion(): string {
  try {
    return localStorage.getItem(CACHE_KEY) ?? "1";
  } catch {
    return "1";
  }
}

/** Bump the cache token — call this after any admin image save. */
export function bumpImageVersion(): string {
  const v = String(Date.now());
  try {
    localStorage.setItem(CACHE_KEY, v);
  } catch {}
  // Also broadcast to other tabs so they reload without a manual refresh.
  try {
    window.dispatchEvent(new StorageEvent("storage", { key: CACHE_KEY, newValue: v }));
  } catch {}
  return v;
}

/** Append ?v=<token> to any uploaded image URL (local /api/uploads/ paths only). */
export function bustUrl(url: string | null | undefined, version?: string): string {
  if (!url) return "";
  // Only bust local uploads, not external CDN/favicons/etc.
  if (!url.includes("/api/uploads/") && !url.includes("/uploads/")) return url;
  const v = version ?? getImageVersion();
  const sep = url.includes("?") ? "&" : "?";
  return `${url}${sep}v=${v}`;
}
