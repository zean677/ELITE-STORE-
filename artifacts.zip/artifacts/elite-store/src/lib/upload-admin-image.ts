const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

type UploadScope = 'media' | 'loyalty';

function authHeaders(): Record<string, string> {
  const token = localStorage.getItem('elite_token');
  return {
    Authorization: `Bearer ${token ?? ''}`,
    'Content-Type': 'application/json',
  };
}

async function readJson(response: Response): Promise<any> {
  return response.json().catch(() => ({}));
}

export async function uploadAdminImage(file: File, scope: UploadScope = 'media'): Promise<string> {
  if (!ALLOWED_TYPES.has(file.type)) {
    throw new Error('اختر صورة بصيغة JPEG أو PNG أو WebP أو GIF');
  }
  if (file.size <= 0 || file.size > MAX_IMAGE_BYTES) {
    throw new Error('يجب ألا يتجاوز حجم الصورة 5 ميغابايت');
  }

  const routes = scope === 'loyalty'
    ? {
        request: `${BASE}/api/admin/loyalty/rewards/image-upload-url`,
        confirm: `${BASE}/api/admin/loyalty/rewards/image-upload-confirm`,
      }
    : {
        request: `${BASE}/api/admin/upload/storage-url`,
        confirm: `${BASE}/api/admin/upload/storage-confirm`,
      };

  const ticketResponse = await fetch(routes.request, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
  });
  const ticket = await readJson(ticketResponse);
  if (!ticketResponse.ok || !ticket.uploadURL || !ticket.objectPath) {
    throw new Error(ticket.error || 'تعذر بدء رفع الصورة');
  }

  // The signed URL is a one-time capability; do not send the app's bearer token to it.
  const uploadResponse = await fetch(ticket.uploadURL, {
    method: 'PUT',
    headers: { 'Content-Type': file.type },
    body: file,
  });
  if (!uploadResponse.ok) {
    throw new Error(`فشل رفع الصورة إلى التخزين (${uploadResponse.status})`);
  }

  const confirmResponse = await fetch(routes.confirm, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify({ objectPath: ticket.objectPath }),
  });
  const confirmation = await readJson(confirmResponse);
  if (!confirmResponse.ok || typeof confirmation.url !== 'string') {
    throw new Error(confirmation.error || 'تعذر التحقق من الصورة');
  }
  return confirmation.url;
}