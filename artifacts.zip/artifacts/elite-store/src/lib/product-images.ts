// Smart product image resolver
// Priority: direct high-res game image → server-side logo proxy → brand color badge

export interface BrandInfo {
  color: string;
  label: string;
  logoUrl: string | null;
}

// ─── Package variant detector (UC, Cash, Membership, Pass, Bundle...) ────────
export interface PackageVariant {
  key: string;
  label: string;
  shortLabel: string;
  color: string;
  icon: string;
}

const PACKAGE_VARIANTS: Array<PackageVariant & { patterns: RegExp[] }> = [
  { key: 'uc', label: 'شدات UC', shortLabel: 'UC', color: '#F5A623', icon: '💰',
    patterns: [/\buc\b/i, /شد(ا|ّا)ت/, /\bشدة\b/] },
  { key: 'diamonds', label: 'ألماس / جواهر', shortLabel: '💎', color: '#06B6D4', icon: '💎',
    patterns: [/diamond/i, /\bdm\b/i, /ألماس/, /الماس/, /جواهر/, /gem/i] },
  { key: 'cash', label: 'كاش / رصيد', shortLabel: 'CASH', color: '#10B981', icon: '💵',
    patterns: [/\bcash\b/i, /كاش/, /رصيد/, /balance/i, /credit/i] },
  { key: 'gold', label: 'ذهب / Gold', shortLabel: 'GOLD', color: '#FBBF24', icon: '🪙',
    patterns: [/\bgold\b/i, /ذهب/, /coins?/i, /كوينز/] },
  { key: 'membership', label: 'عضوية', shortLabel: 'VIP', color: '#A855F7', icon: '👑',
    patterns: [/member/i, /عضوي/, /\bvip\b/i, /subscri/i, /اشتراك/, /اعضاء/, /royal/i] },
  { key: 'pass', label: 'باس / Pass', shortLabel: 'PASS', color: '#EC4899', icon: '🎫',
    patterns: [/\bpass\b/i, /\bباس\b/, /battle pass/i, /season pass/i, /موسم/] },
  { key: 'bundle', label: 'حزمة / Bundle', shortLabel: 'PACK', color: '#8B5CF6', icon: '📦',
    patterns: [/bundle/i, /\bpack(age)?\b/i, /حزم(ة|ه)/, /مجموعة/, /combo/i] },
  { key: 'topup', label: 'شحن مباشر', shortLabel: 'TOP', color: '#3B82F6', icon: '⚡',
    patterns: [/top.?up/i, /recharge/i, /شحن/, /\btopup\b/i] },
  { key: 'card', label: 'بطاقة', shortLabel: 'CARD', color: '#0EA5E9', icon: '💳',
    patterns: [/card/i, /بطاقة/, /code/i, /كود/, /اكواد/] },
  { key: 'account', label: 'حساب', shortLabel: 'ACC', color: '#6366F1', icon: '👤',
    patterns: [/account/i, /حساب/, /آيدي/, /id\b/i] },
];

/** Detects what variant of in-game currency/item this product represents */
export function getPackageVariant(name: string, description?: string): PackageVariant | null {
  const text = `${name ?? ''} ${description ?? ''}`;
  for (const v of PACKAGE_VARIANTS) {
    if (v.patterns.some(p => p.test(text))) {
      // strip 'patterns' field
      return { key: v.key, label: v.label, shortLabel: v.shortLabel, color: v.color, icon: v.icon };
    }
  }
  return null;
}

/** Build proxy URL — served via our API server to avoid CORS/CDN restrictions */
function proxy(base: string, domain: string): string {
  const prefix = base.replace(/\/$/, '');
  return `${prefix}/api/logo?domain=${domain}`;
}

const STEAM = (id: number) => `https://cdn.akamai.steamstatic.com/steam/apps/${id}/capsule_616x353.jpg`;
const GP = (id: string) => `https://play-lh.googleusercontent.com/${id}=s360-rw`;

// ─── Direct high-quality game images ─────────────────────────────────────────
const GAME_IMAGE_DIRECT: Record<string, string> = {
  // Mobile Games
  "PUBG Mobile":                   "https://cdn.akamai.steamstatic.com/steam/apps/578080/capsule_616x353.jpg",
  "Garena Free Fire":              GP("WWcssQ1skJkzTtW6Un5pAHEYlkRBNB7G-LUFl0MFmWRlYpfL3_PJyPa8kPSKaJp-dA"),
  "فري فاير":                      GP("WWcssQ1skJkzTtW6Un5pAHEYlkRBNB7G-LUFl0MFmWRlYpfL3_PJyPa8kPSKaJp-dA"),
  "فري فاير عالمي":                GP("WWcssQ1skJkzTtW6Un5pAHEYlkRBNB7G-LUFl0MFmWRlYpfL3_PJyPa8kPSKaJp-dA"),
  "Mobile Legends: Bang Bang":     GP("T74PN2BoMcVGaZJpjFZtBLMMTqlO8ksMnPJnUFT9-7b-0ym_uH02Td1YuHkiA1j3_Q"),
  "Genshin Impact":                GP("So4-or9fmDTVE2A_8vz5wLfVLkMWHMBGKL8ECMuChIKWTTMjOJmMpU0P_GTkuTQyXIo"),
  "Honkai: Star Rail":             GP("S6VXPPA8LxPxdHGOsHN_tBrVK1RJlW6bDqXEpizWVyc0JFBRuLNO6PB_kNJb28KXW1I"),
  "Honkai : Star Rail":            GP("S6VXPPA8LxPxdHGOsHN_tBrVK1RJlW6bDqXEpizWVyc0JFBRuLNO6PB_kNJb28KXW1I"),
  "Zenless Zone Zero":             GP("bfkwVl7O2A-jjlvXFX-IqXnj1bsz2XUiJ8YOXZ0OfqUHj8TE6Uc6jWyTCQE-o8vPUo"),
  "Clash of Clans":                GP("LBB3v3YMr4SVMsM1tXNKDzOl9XhAr4Eig2IuvkXxEKqfHJ5uGcgI0bQi4oqNKJXXH1Wb"),
  "Clash of clans":                GP("LBB3v3YMr4SVMsM1tXNKDzOl9XhAr4Eig2IuvkXxEKqfHJ5uGcgI0bQi4oqNKJXXH1Wb"),
  "Clash Royale":                  GP("K-MNjDiSfNbMQfDuq8DaBoNsO5G4hpQVGXYx3yp-B1mDVpDJnunFlP7rOELCkSNA4x0"),
  "Clash royal":                   GP("K-MNjDiSfNbMQfDuq8DaBoNsO5G4hpQVGXYx3yp-B1mDVpDJnunFlP7rOELCkSNA4x0"),
  "Brawl Stars":                   GP("f5bN-mgyI0OPJZ5jd0nNELHnqmT9v4zFiU3g5nCWoWBjsUZbCtnIJh9H2xC0oUxgVgs"),
  "Brawel Star اكواد":             GP("f5bN-mgyI0OPJZ5jd0nNELHnqmT9v4zFiU3g5nCWoWBjsUZbCtnIJh9H2xC0oUxgVgs"),
  "Brawel star آيدي":              GP("f5bN-mgyI0OPJZ5jd0nNELHnqmT9v4zFiU3g5nCWoWBjsUZbCtnIJh9H2xC0oUxgVgs"),
  "Call of Duty: Mobile":          GP("a8TFLG-TvKEtOpfMGfRLzptzFsHITqnCHCWBbvs0X2lHPlG3GCdFVOIlkHxBFXwPuE"),
  "Roblox":                        STEAM(1526456),
  "ROBLOX":                        STEAM(1526456),
  "Fortnite":                      "https://cdn2.unrealengine.com/Fortnite%2FFortnite_PC_GameBanner-1920x1080-b7a546f2e8ad7e5bdd04e5f9bdf4f3ded5e83be6.jpg",
  "Valorant":                      "https://www.riotgames.com/darkroom/1440/d0807e131a84b2b16b9f69cec84df0ac:9f74b52a7f94debbe1a16adae14e32e8/valorant-702.jpg",
  "Valorant Turkey":               "https://www.riotgames.com/darkroom/1440/d0807e131a84b2b16b9f69cec84df0ac:9f74b52a7f94debbe1a16adae14e32e8/valorant-702.jpg",
  "Valorant USA":                  "https://www.riotgames.com/darkroom/1440/d0807e131a84b2b16b9f69cec84df0ac:9f74b52a7f94debbe1a16adae14e32e8/valorant-702.jpg",
  "Wild Rift":                     GP("FfTy_Jy7yD1gFpHOb4hhEcAfhvIXbhN5YQuvBbvxlN-9EhcMRJHUMj59J7DBLW-RdSH"),
  "Honor of Kings":                GP("zSRQxHn08rJCBf-FGYvimfv6H82MFQeqMPbVqWUoNFAv6Nt18PXWJ-LmRrCUqjp17Y"),
  "Honor Of Kings":                GP("zSRQxHn08rJCBf-FGYvimfv6H82MFQeqMPbVqWUoNFAv6Nt18PXWJ-LmRrCUqjp17Y"),
  "Rise of Kingdoms":              GP("JrXRYfCVU6DqQ3mCLfm5X9SkBwbFl4PqkBqHIuuAIL6Q0zQb0X6gVN7GvZTWD5fLGHk"),
  "State of Survival":             GP("SN8TUlBBPGHc0m1sAlNZtdS3RJhBH7F7pBqvBqBCpW6DYpG4QX3JGvkKLpj9gGHVRR8"),
  "State Of Survival":             GP("SN8TUlBBPGHc0m1sAlNZtdS3RJhBH7F7pBqvBqBCpW6DYpG4QX3JGvkKLpj9gGHVRR8"),
  "Last War: Survival":            GP("HKrRMqmfmwPsW9lGmFJfHkLjAJBllxIi6V6Z3p1wXK5NbHRf7hXPT1GFW3E5yV6Lfg"),
  "Last War":                      GP("HKrRMqmfmwPsW9lGmFJfHkLjAJBllxIi6V6Z3p1wXK5NbHRf7hXPT1GFW3E5yV6Lfg"),
  "Whiteout Survival":             GP("6HFpwFf68VCJHzFflSUq5JIJ5LoIxSwVEbJJicMQGOJ4b8kGNwQk8E2MuMjMuqVSmw"),
  "Coin Master":                   GP("FNTihLJDa4UNYB01n5RxbHAUK4SJb8W6UvJnxDrmPQKg6I1p5_nz0QGQF0pJkmb0g"),
  "Royal Match":                   GP("Xc0HM6LiaqI7-dWMFkDYrspvH2g7ygJB-N2OC0JJSXB97K5WiTI0W3tJ-i5FGu0dHg"),
  "Merge Mansion":                 GP("PqJcnCiTI2_OM4bUMfvRZdDMp0o1nMGj5dW-P2OFUzMvXFQQbwHzFTlH4LNkrU0WtLc"),
  "Magic Chess: Go Go":            GP("eFDUkrslYxGMbCWqUVvM0gT2f2B1rKbgVHGZvOXSNKUr-K_kXO1J5N3LJUujnBEF5g"),
  "Wuthering Waves":               GP("gELhFe5V6P_Y-YGgJDJt5B7P-pVGl4-FYLtXFzBKqQB1lbGT5fcVnZ_Gm1p7mRnXqA"),
  "Stumble Guys":                  GP("P9M5FBK0g9cLDJC1XMzx-X-2CU-gFwkU2QGbpIXZn6o-GMQ9jYJGSfD1F-R7FQLG4w"),
  "AFK Journey":                   GP("Qxn7Z9XhDKxR4e0d8ZCvx0cRLqe2w6TZ5DZgfLH9KpWe5pvJY2f9m0c7s0NbF0xJ"),
  "Honkai Impact 3rd":             GP("5gOJfI8ePaL6v9GNXBpzKhJJP3W1G7q9T1h0pJoRU4GwBQGIB7-rlMqXYDCn7VHPWQ"),
  "Solo Leveling: ARISE":          GP("a8TFLG-TvKEtOpfMGfRLzptzFsHITqnCHCWBbvs0X2lHPlG3GCdFVOIlkHxBFXwPuE"),
  "Arena of Valor":                GP("9cdc4k9LCJjxN5nFQjrh3YW7CtJsB6Z1GzHgJ9TxpBaI8EHfK3jH6Bi5DDJF2VRmAeE"),
  "Eggy Party":                    GP("3G8GYD2aSQ_-JCMWR_AMb0NqM7-a0S-oPQMEe9l2HJ_-9BL5Xe0GhJNBz0d6r6P88Q"),

  // PC Games
  "Steam":                         "https://store.akamai.steamstatic.com/public/shared/images/header/logo_steam_steam.png",
  "Steam USA":                     "https://store.akamai.steamstatic.com/public/shared/images/header/logo_steam_steam.png",
  "Steam Turkey":                  "https://store.akamai.steamstatic.com/public/shared/images/header/logo_steam_steam.png",
  "Counter-Strike 2":              STEAM(730),
  "Dota 2":                        STEAM(570),
  "Overwatch 2":                   STEAM(2357570),
  "OverWatch 2":                   STEAM(2357570),
  "World of Warcraft":             "https://bnetcmsus-a.akamaihd.net/cms/blog_header/1IYTACQD8JE91551898275874.jpg",
  "Epic Games":                    "https://cdn2.unrealengine.com/epic-games-store-webinar-social-1200x630-dd83c75a3c90.jpg",
  "League of Legends":             STEAM(1826370),
  "Minecraft":                     STEAM(1672970),
  "Marvel Rivals":                 STEAM(2767030),
  "Rainbow Six Mobile":            "https://staticctf.ubisoft.com/J3yJr34U2pZ2Ieem48Dwy9uqj5PNUQTn/2o7BhJiWdWJgmgx0oDr6LL/4be4a0ef84c5f58e8f8ad5cf6e9a9b3f/r6m_keyart_1920x1080.jpg",
  "Delta Force GLOBAL":            "https://cdn.akamai.steamstatic.com/steam/apps/2507690/capsule_616x353.jpg",

  // Streaming & Services
  "Netflix":                       "https://assets.nflxext.com/ffe/siteui/common/icons/nficon2023.png",
  "Netflix USA":                   "https://assets.nflxext.com/ffe/siteui/common/icons/nficon2023.png",
  "Spotify":                       "https://storage.googleapis.com/pr-newsroom-wp/1/2018/11/Spotify_Logo_RGB_Green.png",
  "YouTube Premium":               "https://lh3.googleusercontent.com/z6Sl4j9zQ84oUgFuXcltm6yhMbpPaKe3dHBBSVBgOKOePxrfJkMELaH2VkW4yKqPBg=w360",
  "Disney+":                       "https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/FCA60E3B2C5E0C2466D4D3A0FBEB9C8ED4E3EEE83E7B8FE6FBA80D4DCED9988/scale?width=400",
  "ChatGPT":                       "https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/ChatGPT_logo.svg/512px-ChatGPT_logo.svg.png",
  "Canva":                         "https://static.canva.com/web/images/8439b51bb7a19f6e65ce1064bc37c197.png",
  "Canva pro":                     "https://static.canva.com/web/images/8439b51bb7a19f6e65ce1064bc37c197.png",
  "Microsoft 365":                 "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE4DKFm?ver=0362",
  "Telegram Premium":              "https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Telegram_logo.svg/512px-Telegram_logo.svg.png",
  "Snapchat Plus":                 "https://upload.wikimedia.org/wikipedia/en/thumb/a/ad/Snapchat_logo.svg/512px-Snapchat_logo.svg.png",

  // Gift Cards
  "Google Play":                   "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Google_Play_Logo_%282016%29.svg/1200px-Google_Play_Logo_%282016%29.svg.png",
  "Google Play USA":               "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Google_Play_Logo_%282016%29.svg/1200px-Google_Play_Logo_%282016%29.svg.png",
  "App Store":                     "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/App_Store_%28iOS%29.svg/512px-App_Store_%28iOS%29.svg.png",
  "iTunes":                        "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/App_Store_%28iOS%29.svg/512px-App_Store_%28iOS%29.svg.png",
  "iTunes USA":                    "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/App_Store_%28iOS%29.svg/512px-App_Store_%28iOS%29.svg.png",
  "iTunes turkeya":                "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/App_Store_%28iOS%29.svg/512px-App_Store_%28iOS%29.svg.png",
  "PlayStation Store":             "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/PlayStation_logo_and_wordmark.svg/1024px-PlayStation_logo_and_wordmark.svg.png",
  "PlayStation Saudi":             "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/PlayStation_logo_and_wordmark.svg/1024px-PlayStation_logo_and_wordmark.svg.png",
  "PlayStation USA":               "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/PlayStation_logo_and_wordmark.svg/1024px-PlayStation_logo_and_wordmark.svg.png",
  "Xbox":                          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Xbox_one_logo.svg/512px-Xbox_one_logo.svg.png",
  "XBOX USA":                      "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Xbox_one_logo.svg/512px-Xbox_one_logo.svg.png",
  "Nintendo":                      "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Nintendo.svg/1024px-Nintendo.svg.png",
  "Nintendo Card":                 "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Nintendo.svg/1024px-Nintendo.svg.png",
  "Amazon":                        "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/1200px-Amazon_logo.svg.png",
  "Amazon Card":                   "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/1200px-Amazon_logo.svg.png",
  "Razer Gold":                    "https://assets.razerzone.com/eeimages/gold/razer-gold-logo-og.png",
  "Blizzard Card":                 "https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/Blizzard_Entertainment_Logo_2015.svg/1200px-Blizzard_Entertainment_Logo_2015.svg.png",
  "GameStop Card":                 "https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/GameStop_Stores.jpg/320px-GameStop_Stores.jpg",
};

// ─── Comprehensive game name → domain mapping ─────────────────────────────────
const GAME_DOMAIN_MAP: Record<string, { color: string; label: string; domain: string }> = {
  // Arabic game variants
  "التطبيقات":                 { color: '#0EA5E9', label: 'APPs', domain: 'apple.com' },
  "فئات جاهزة":               { color: '#F59E0B', label: 'GC',   domain: 'amazon.com' },
  "فري فاير اندونيسيا":       { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير سنغافورة":        { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير تايوان":          { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير البرازيل":        { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير عالمي":           { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير":                 { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير أمريكا اللاتينية": { color: '#F97316', label: 'FF',  domain: 'ff.garena.com' },
  "فري فاير أوروبا":          { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير اكواد":           { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير باكستان":         { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير بنغلادش":         { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير فيتنام":          { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "فري فاير روبوت":           { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "شدات":                     { color: '#F5A623', label: 'UC',   domain: 'pubg.com' },
  "ببجي روبوت":               { color: '#F5A623', label: 'PG',   domain: 'pubg.com' },
  "ببجي يدوي":                { color: '#F5A623', label: 'PG',   domain: 'pubg.com' },
  "عضويات ببجي":              { color: '#F5A623', label: 'PG',   domain: 'pubg.com' },
  "عضويات فري فاير":          { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' },
  "ألماس":                    { color: '#818CF8', label: '💎',   domain: 'mobilelegends.net' },
  "خدمات MTN":                { color: '#FFCC00', label: 'MTN',  domain: 'mtn.com' },
  "خدمات سيريتل":             { color: '#A01C26', label: 'SY',   domain: 'syriatel.com.sy' },
  "خدمات شام كاش":            { color: '#0EA5E9', label: 'SC',   domain: 'syriatel.com.sy' },
  "خدمات عامة":               { color: '#6B7280', label: '⚡',   domain: 'google.com' },
  "ليرات ترك تلكوم":          { color: '#0070BB', label: 'TK',   domain: 'turkcell.com.tr' },
  "ليرات تروكسل":             { color: '#FFA500', label: 'TR',   domain: 'turkcell.com.tr' },
  "ليرات فودافون":             { color: '#E60000', label: 'VF',   domain: 'vodafone.com' },
  "الذكاء الاصطناعي":         { color: '#10A37F', label: 'AI',   domain: 'openai.com' },
  "العملات الرقمية":          { color: '#F3BA2F', label: '₿',    domain: 'binance.com' },
  "الرصيد والاتصالات":        { color: '#22C55E', label: '📱',   domain: 'syriatel.com.sy' },
  "حسابات جاهزة":             { color: '#8B5CF6', label: '👤',   domain: 'google.com' },
  "Yalla Ludo الماس":         { color: '#F59E0B', label: 'YL',   domain: 'yalla.com' },
  "Yalla Ludo ذهب":           { color: '#F59E0B', label: 'YL',   domain: 'yalla.com' },

  // Popular mobile games
  "8BALL POOL":                { color: '#1A7F3C', label: '8B',  domain: 'miniclip.com' },
  "8BALL POOL شدات":           { color: '#1A7F3C', label: '8B',  domain: 'miniclip.com' },
  "8BALL POOL كوينز":          { color: '#1A7F3C', label: '8B',  domain: 'miniclip.com' },
  "AFK Journey":               { color: '#5B21B6', label: 'AFK', domain: 'farlight.com' },
  "AceCraft":                  { color: '#0891B2', label: 'AC',  domain: 'garena.com' },
  "Age Of Empires Mobile":     { color: '#92400E', label: 'AoE', domain: 'ageofempires.com' },
  "Age of Magic":              { color: '#D946EF', label: 'AoM', domain: 'ageofmagic.net' },
  "Arena Breakout":            { color: '#374151', label: 'AB',  domain: 'tencent.com' },
  "Arena Breakout: Infinite":  { color: '#1F2937', label: 'ABI', domain: 'tencent.com' },
  "Arena of Valor":            { color: '#DC2626', label: 'AoV', domain: 'garena.com' },
  "Arknights: Endfield":       { color: '#1D4ED8', label: 'ARK', domain: 'arknights.com' },
  "Asphalt 9: Legends":        { color: '#EF4444', label: 'A9',  domain: 'gameloft.com' },
  "Black Clover M":            { color: '#111827', label: 'BCM', domain: 'bandainamco.com' },
  "Bleach: Soul Resonance":    { color: '#3B82F6', label: 'BSR', domain: 'bandainamco.com' },
  "Blockman Go":               { color: '#F59E0B', label: 'BMG', domain: 'blockmango.com' },
  "Blood Strike GLOBAL":       { color: '#DC2626', label: 'BS',  domain: 'netease.com' },
  "Blood Strike MENA":         { color: '#B91C1C', label: 'BS',  domain: 'netease.com' },
  "Cats: Crash Arena Turbo Stars": { color: '#FBBF24', label: 'CATS', domain: 'betadwarf.com' },
  "City Of Crime Gang War":    { color: '#6B7280', label: 'CoC', domain: 'playcitycrime.com' },
  "CrossFire Mobile":          { color: '#1D4ED8', label: 'CF',  domain: 'crossfiremobile.com' },
  "Crossout Mobile":           { color: '#F97316', label: 'XO',  domain: 'gaijin.net' },
  "Crystal of Atlan":          { color: '#06B6D4', label: 'CoA', domain: 'crystalofatlan.com' },
  "DC Dark Legion":            { color: '#1E3A5F', label: 'DC',  domain: 'dc.com' },
  "Deadly Dudes":              { color: '#7C3AED', label: 'DD',  domain: 'deadlydudes.io' },
  "Delta Force GLOBAL":        { color: '#374151', label: 'DF',  domain: 'deltaforcegame.com' },
  "Destiny Rising":            { color: '#4338CA', label: 'DR',  domain: 'bungie.net' },
  "Devil May Cry: Peak of Combat": { color: '#DC2626', label: 'DMC', domain: 'capcom.com' },
  "Dragon Nest M Classic":     { color: '#7C3AED', label: 'DN',  domain: 'eyedentitygames.com' },
  "Dragonheir : Silent Gods":  { color: '#B45309', label: 'DH',  domain: 'dragonheir.com' },
  "Duet Night Abyss":          { color: '#6366F1', label: 'DNA', domain: 'duetnightabyss.com' },
  "EVE Echoes":                { color: '#06B6D4', label: 'EVE', domain: 'eveechoes.com' },
  "Echocalypse: Scarlet Covenant": { color: '#EF4444', label: 'EC', domain: 'echocalypse.com' },
  "Eggy Party":                { color: '#F472B6', label: 'EGP', domain: 'netease.com' },
  "Etheria: Restart":          { color: '#06B6D4', label: 'ETH', domain: 'etheria.game' },
  "FRAG Pro Shooter":          { color: '#EF4444', label: 'FRG', domain: 'fragpro.com' },
  "Farlight 84":               { color: '#6366F1', label: 'FL',  domain: 'farlight.com' },
  "Football Rising Star":      { color: '#16A34A', label: 'FRS', domain: 'futuroapp.com' },
  "Garena Free Fire":          { color: '#F97316', label: 'FF',  domain: 'ff.garena.com' },
  "Garena Undawn":             { color: '#16A34A', label: 'UDW', domain: 'garena.com' },
  "Guns Of Glory":             { color: '#92400E', label: 'GoG', domain: 'funplus.com' },
  "HAIKYU!! FLY HIGH":         { color: '#F97316', label: 'HFH', domain: 'bandainamcoent.com' },
  "Harry Potter: Magic Awakened": { color: '#7C2D12', label: 'HP', domain: 'netease.com' },
  "Heartopia":                 { color: '#EC4899', label: 'HT',  domain: 'heartopia.game' },
  "Heaven Burns Red":          { color: '#EF4444', label: 'HBR', domain: 'hbr.jp' },
  "Hero Clash":                { color: '#F59E0B', label: 'HC',  domain: 'supercell.com' },
  "Hero Wars":                 { color: '#7C3AED', label: 'HW',  domain: 'nexters.com' },
  "Honkai : Star Rail":        { color: '#818CF8', label: 'HSR', domain: 'hoyoverse.com' },
  "Honkai Impact 3rd":         { color: '#3B82F6', label: 'HI3', domain: 'hoyoverse.com' },
  "Identity V":                { color: '#374151', label: 'IDV', domain: 'netease.com' },
  "King of Avalon":            { color: '#B45309', label: 'KoA', domain: 'funplus.com' },
  "Knives Out":                { color: '#374151', label: 'KO',  domain: 'netease.com' },
  "Last War":                  { color: '#1F2937', label: 'LW',  domain: 'lastwar.fun' },
  "Last War: Survival":        { color: '#1F2937', label: 'LW',  domain: 'lastwar.fun' },
  "Legend of Neverland":       { color: '#8B5CF6', label: 'LoN', domain: 'legendofneverland.net' },
  "Legend of the Phoenix":     { color: '#C89B3C', label: 'LoP', domain: 'yoozoo.com' },
  "Life After":                { color: '#374151', label: 'LA',  domain: 'netease.com' },
  "Lords Mobile":              { color: '#7C3AED', label: 'LM',  domain: 'igg.com' },
  "Ludo World":                { color: '#F59E0B', label: 'LW',  domain: 'ludo-world.com' },
  "Ludo club":                 { color: '#3B82F6', label: 'LC',  domain: 'ludobeats.com' },
  "MWT : Tank Battles":        { color: '#374151', label: 'MWT', domain: 'mwt.zone' },
  "Magic Chess: Go Go":        { color: '#7C3AED', label: 'MC',  domain: 'moonton.com' },
  "MapleStory M":              { color: '#3B82F6', label: 'MS',  domain: 'nexon.com' },
  "Marvel Duel":               { color: '#DC2626', label: 'MD',  domain: 'marvel.com' },
  "Marvel Rivals":             { color: '#DC2626', label: 'MR',  domain: 'marvelrivals.com' },
  "Mecha BREAK":               { color: '#06B6D4', label: 'MB',  domain: 'mechabreak.com' },
  "Merge Kingdom":             { color: '#F59E0B', label: 'MK',  domain: 'mergekingdom.game' },
  "Minecraft":                 { color: '#84CC16', label: 'MC',  domain: 'minecraft.net' },
  "Mobile Legends ASIA":       { color: '#DC2626', label: 'ML',  domain: 'mobilelegends.net' },
  "Mobile Legends GLOBAL":     { color: '#DC2626', label: 'ML',  domain: 'mobilelegends.net' },
  "Mobile Legends TURKEY":     { color: '#DC2626', label: 'ML',  domain: 'mobilelegends.net' },
  "Mobile Legends: Adventure": { color: '#8B5CF6', label: 'MLA', domain: 'moonton.com' },
  "Mobile Legends: Bang Bang": { color: '#DC2626', label: 'MLBB', domain: 'mobilelegends.net' },
  "Mobile Royale":             { color: '#7C3AED', label: 'MR',  domain: 'i-tw.com' },
  "Modern Strike Online":      { color: '#374151', label: 'MSO', domain: 'extreme-developers.com' },
  "Modern Warships":           { color: '#1D4ED8', label: 'MW',  domain: 'modernwarships.com' },
  "Moonlight Blade M":         { color: '#A78BFA', label: 'MBM', domain: 'tencent.com' },
  "OSN PLUS":                  { color: '#DC2626', label: 'OSN', domain: 'osn.com' },
  "Once Human":                { color: '#64748B', label: 'OH',  domain: 'oncehuman.game' },
  "Onmyoji Arena":             { color: '#7C3AED', label: 'OA',  domain: 'netease.com' },
  "Overmortal Idle":           { color: '#9333EA', label: 'OVR', domain: 'overmortal.com' },
  "Oxide: Survival Island":    { color: '#92400E', label: 'OXD', domain: 'warzone.com' },
  "Piggy Go":                  { color: '#EC4899', label: 'PG',  domain: 'piggygoapp.com' },
  "Pixel Gun 3D":              { color: '#10B981', label: 'PG3', domain: 'pixel-gun.com' },
  "Project Entropy":           { color: '#6366F1', label: 'PE',  domain: 'projecrentropy.com' },
  "Pure Sniper":               { color: '#374151', label: 'PS',  domain: 'playpuresniper.com' },
  "Puzzles & Survival":        { color: '#F59E0B', label: 'P&S', domain: '37games.com' },
  "ROBLOX":                    { color: '#EF4444', label: 'RBX', domain: 'roblox.com' },
  "Ragnarok Origin":           { color: '#DC2626', label: 'RO',  domain: 'gravity.co.kr' },
  "Ragnarok X: Next Generation": { color: '#B91C1C', label: 'RX', domain: 'gravity.co.kr' },
  "Rainbow Six Mobile":        { color: '#1D4ED8', label: 'R6',  domain: 'ubisoft.com' },
  "Revenge of Sultans":        { color: '#92400E', label: 'RoS', domain: 'onemt.com' },
  "Rise Of The Kings":         { color: '#B45309', label: 'RoK', domain: 'rivergame.com' },
  "Rise of Kingdoms":          { color: '#92400E', label: 'RoK', domain: 'rok.lilithgames.com' },
  "Roblox":                    { color: '#EF4444', label: 'RBX', domain: 'roblox.com' },
  "Royal Match":               { color: '#3B82F6', label: 'RM',  domain: 'dream-games.com' },
  "Sea of Conquest":           { color: '#0EA5E9', label: 'SoC', domain: 'funplus.com' },
  "Silver and Blood":          { color: '#6B7280', label: 'SaB', domain: 'silverandblood.com' },
  "Snowbreak: Containment Zone": { color: '#06B6D4', label: 'SNW', domain: 'snowbreak.com' },
  "Solo Leveling: ARISE":      { color: '#6366F1', label: 'SLA', domain: 'netmarble.com' },
  "Star Resonance":            { color: '#818CF8', label: 'SR',  domain: 'starresonance.com' },
  "State Of Survival":         { color: '#EF4444', label: 'SoS', domain: 'stateofsurvival.com' },
  "State of Survival":         { color: '#EF4444', label: 'SoS', domain: 'stateofsurvival.com' },
  "Stormshot: Isle of Adventure": { color: '#F59E0B', label: 'SS', domain: 'centplay.com' },
  "Stumble Guys":              { color: '#A855F7', label: 'SG',  domain: 'stumbleguys.com' },
  "Super SUS":                 { color: '#6366F1', label: 'SUS', domain: 'playsuper.us' },
  "Sword of Justice":          { color: '#7C3AED', label: 'SoJ', domain: 'gtarcade.com' },
  "Tarisland":                 { color: '#F59E0B', label: 'TRL', domain: 'tarisland.com' },
  "The Walking Dead":          { color: '#374151', label: 'TWD', domain: 'skybound.com' },
  "Tiles Survive!":            { color: '#10B981', label: 'TS',  domain: 'tilssurvive.com' },
  "Undawn Global":             { color: '#16A34A', label: 'UDN', domain: 'garena.com' },
  "War Robots":                { color: '#374151', label: 'WR',  domain: 'my.com' },
  "Watcher Of Realms":         { color: '#7C3AED', label: 'WoR', domain: 'watcherofrealms.com' },
  "Wild Rift":                 { color: '#2563EB', label: 'WR',  domain: 'wildrift.leagueoflegends.com' },
  "Wuthering Waves":           { color: '#0EA5E9', label: 'WW',  domain: 'kurogames.com' },
  "ZEPETO":                    { color: '#818CF8', label: 'ZEP', domain: 'zepeto.me' },
  "Zenless Zone Zero":         { color: '#F59E0B', label: 'ZZZ', domain: 'hoyoverse.com' },
  "Coin Master":               { color: '#F97316', label: 'CM',  domain: 'coinmaster.com' },
  "Merge Mansion":             { color: '#F59E0B', label: 'MM',  domain: 'metacore.com' },

  // PC Games
  "Steam":                     { color: '#1B2838', label: 'STM', domain: 'steampowered.com' },
  "Steam USA":                 { color: '#1B2838', label: 'STM', domain: 'steampowered.com' },
  "Steam Turkey":              { color: '#1B2838', label: 'STM', domain: 'steampowered.com' },
  "Epic Games":                { color: '#313131', label: 'EGS', domain: 'epicgames.com' },
  "Dota 2":                    { color: '#C23C2A', label: 'D2',  domain: 'dota2.com' },
  "Counter-Strike 2":          { color: '#F39C12', label: 'CS2', domain: 'counter-strike.net' },
  "Overwatch 2":               { color: '#F5A623', label: 'OW2', domain: 'playoverwatch.com' },
  "OverWatch 2":               { color: '#F5A623', label: 'OW2', domain: 'playoverwatch.com' },
  "World of Warcraft":         { color: '#2E6DB4', label: 'WoW', domain: 'battle.net' },
  "League of Legends":         { color: '#C89B3C', label: 'LoL', domain: 'leagueoflegends.com' },
  "PUBG Mobile":               { color: '#F5A623', label: 'PBG', domain: 'pubg.com' },
  "Genshin Impact":            { color: '#06B6D4', label: 'GI',  domain: 'hoyoverse.com' },
  "Honkai: Star Rail":         { color: '#818CF8', label: 'HSR', domain: 'hoyoverse.com' },
  "Brawl Stars":               { color: '#FBBF24', label: 'BS',  domain: 'supercell.com' },
  "Clash of Clans":            { color: '#10B981', label: 'CoC', domain: 'supercell.com' },
  "Clash Royale":              { color: '#8B5CF6', label: 'CR',  domain: 'supercell.com' },
  "Call of Duty: Mobile":      { color: '#374151', label: 'CoDM', domain: 'callofduty.com' },
  "Fortnite":                  { color: '#06B6D4', label: 'FN',  domain: 'fortnite.com' },
  "Valorant":                  { color: '#FF4655', label: 'VAL', domain: 'playvalorant.com' },
  "Valorant Turkey":           { color: '#FF4655', label: 'VAL', domain: 'playvalorant.com' },
  "Valorant USA":              { color: '#FF4655', label: 'VAL', domain: 'playvalorant.com' },
  "Apex Legends Mobile":       { color: '#E74C3C', label: 'APX', domain: 'ea.com' },
  "Honor of Kings":            { color: '#9333EA', label: 'HoK', domain: 'honorofkings.com' },
  "Undawn":                    { color: '#16A34A', label: 'UDN', domain: 'garena.com' },

  // Streaming / Subscriptions
  "Netflix":                   { color: '#E50914', label: 'NF',  domain: 'netflix.com' },
  "Netflix USA":               { color: '#E50914', label: 'NF',  domain: 'netflix.com' },
  "Spotify":                   { color: '#1DB954', label: 'SP',  domain: 'spotify.com' },
  "YouTube Premium":           { color: '#FF0000', label: 'YT',  domain: 'youtube.com' },
  "Disney+":                   { color: '#113CCF', label: 'D+',  domain: 'disneyplus.com' },
  "Amazon Prime Video":        { color: '#00A8E0', label: 'PV',  domain: 'primevideo.com' },
  "Apple Music":               { color: '#FC3C44', label: 'AM',  domain: 'apple.com' },
  "Apple TV":                  { color: '#000000', label: 'ATV', domain: 'apple.com' },
  "Twitch":                    { color: '#9146FF', label: 'TW',  domain: 'twitch.tv' },
  "Crunchyroll":               { color: '#F47521', label: 'CR',  domain: 'crunchyroll.com' },
  "Shahid":                    { color: '#E50914', label: 'شاهد', domain: 'shahid.net' },
  "WeTV":                      { color: '#1DB954', label: 'WTV', domain: 'wetv.vip' },
  "Deezer":                    { color: '#A238FF', label: 'DZ',  domain: 'deezer.com' },
  "Canva pro":                 { color: '#00C4CC', label: 'CV',  domain: 'canva.com' },
  "Canva":                     { color: '#00C4CC', label: 'CV',  domain: 'canva.com' },
  "ChatGPT":                   { color: '#10A37F', label: 'GPT', domain: 'openai.com' },
  "ChatGPT - Go":              { color: '#10A37F', label: 'GPT', domain: 'openai.com' },
  "Gemini Pro":                { color: '#4285F4', label: 'GEM', domain: 'google.com' },
  "CapCut":                    { color: '#000000', label: 'CC',  domain: 'capcut.com' },
  "PicsArt":                   { color: '#3B82F6', label: 'PA',  domain: 'picsart.com' },
  "Snapchat Plus":             { color: '#FFFC00', label: 'SC',  domain: 'snapchat.com' },
  "Telegram Premium":          { color: '#2AABEE', label: 'TG',  domain: 'telegram.org' },
  "Flaticon":                  { color: '#FF5733', label: 'FI',  domain: 'flaticon.com' },
  "Microsoft 365":             { color: '#00A4EF', label: 'M365', domain: 'microsoft.com' },
  "Midjourney":                { color: '#000000', label: 'MJ',  domain: 'midjourney.com' },
  "Adobe":                     { color: '#FF0000', label: 'AD',  domain: 'adobe.com' },
  "invideo":                   { color: '#7C3AED', label: 'IV',  domain: 'invideo.io' },

  // VPN Services
  "Adguard VPN":               { color: '#67B346', label: 'AG',  domain: 'adguard.com' },
  "Browsec VPN":               { color: '#3B82F6', label: 'BV',  domain: 'browsec.com' },
  "Cyber Ghost VPN":           { color: '#FBBF24', label: 'CG',  domain: 'cyberghostvpn.com' },
  "Express VPN":               { color: '#DA3940', label: 'EX',  domain: 'expressvpn.com' },
  "Hotspot Shield":            { color: '#1D4ED8', label: 'HS',  domain: 'hotspotshield.com' },
  "IPVanish VPN":              { color: '#0EA5E9', label: 'IP',  domain: 'ipvanish.com' },
  "LagoFast VPN":              { color: '#7C3AED', label: 'LF',  domain: 'lagofast.com' },
  "Nord VPN":                  { color: '#4687FF', label: 'NV',  domain: 'nordvpn.com' },
  "Norton VPN":                { color: '#FBBF24', label: 'NR',  domain: 'norton.com' },
  "Open VPN":                  { color: '#EA580C', label: 'OV',  domain: 'openvpn.net' },
  "PIA VPN":                   { color: '#3B82F6', label: 'PIA', domain: 'privateinternetaccess.com' },
  "Planet VPN":                { color: '#1D4ED8', label: 'PL',  domain: 'vpnlab.tech' },
  "Proton VPN":                { color: '#6D4AFF', label: 'PV',  domain: 'protonvpn.com' },
  "Pure VPN":                  { color: '#EF4444', label: 'PV',  domain: 'purevpn.com' },
  "SurfShark VPN":             { color: '#1DBBA1', label: 'SS',  domain: 'surfshark.com' },
  "TunnelBear VPN":            { color: '#F5A623', label: 'TB',  domain: 'tunnelbear.com' },
  "Windscribe Traffic VPN":    { color: '#06B6D4', label: 'WS',  domain: 'windscribe.com' },
  "Zoog VPN":                  { color: '#3B82F6', label: 'ZG',  domain: 'zoogvpn.com' },

  // Gift Cards / Payment
  "Google Play":               { color: '#01875F', label: 'GP',  domain: 'play.google.com' },
  "Google Play USA":           { color: '#01875F', label: 'GP',  domain: 'play.google.com' },
  "iTunes":                    { color: '#0071E3', label: 'iOS', domain: 'apple.com' },
  "iTunes USA":                { color: '#0071E3', label: 'iOS', domain: 'apple.com' },
  "iTunes turkeya":            { color: '#0071E3', label: 'iOS', domain: 'apple.com' },
  "App Store":                 { color: '#0071E3', label: 'iOS', domain: 'apple.com' },
  "PlayStation Store":         { color: '#003087', label: 'PS',  domain: 'playstation.com' },
  "PlayStation Saudi":         { color: '#003087', label: 'PS',  domain: 'playstation.com' },
  "PlayStation USA":           { color: '#003087', label: 'PS',  domain: 'playstation.com' },
  "Xbox":                      { color: '#107C10', label: 'XBX', domain: 'xbox.com' },
  "XBOX USA":                  { color: '#107C10', label: 'XBX', domain: 'xbox.com' },
  "Nintendo":                  { color: '#E60012', label: 'ND',  domain: 'nintendo.com' },
  "Nintendo Card":             { color: '#E60012', label: 'ND',  domain: 'nintendo.com' },
  "Amazon":                    { color: '#FF9900', label: 'AMZ', domain: 'amazon.com' },
  "Amazon Card":               { color: '#FF9900', label: 'AMZ', domain: 'amazon.com' },
  "Razer Gold":                { color: '#44D62C', label: 'RZR', domain: 'razer.com' },
  "GameStop Card":             { color: '#E60012', label: 'GS',  domain: 'gamestop.com' },
  "Visa":                      { color: '#1A1F71', label: 'VISA', domain: 'visa.com' },
};

// ─── Regex BRAND_MAP ──────────────────────────────────────────────────────────
const BRAND_MAP: [RegExp, { color: string; label: string; domain: string | null }][] = [
  [/pubg|battleground|ببجي|شدات/i,        { color: '#F5A623', label: 'PG',   domain: 'pubg.com' }],
  [/free.?fire|freefire|فري فاير/i,       { color: '#F97316', label: 'FF',   domain: 'ff.garena.com' }],
  [/mobile.?legend|mlbb/i,                { color: '#3B82F6', label: 'ML',   domain: 'mobilelegends.net' }],
  [/clash.?of.?clans/i,                   { color: '#10B981', label: 'CoC',  domain: 'supercell.com' }],
  [/clash.?royale/i,                       { color: '#8B5CF6', label: 'CR',   domain: 'supercell.com' }],
  [/brawl.?star|brawel/i,                  { color: '#FBBF24', label: 'BS',   domain: 'supercell.com' }],
  [/genshin/i,                             { color: '#06B6D4', label: 'GI',   domain: 'hoyoverse.com' }],
  [/honkai.*star.?rail/i,                  { color: '#818CF8', label: 'HSR',  domain: 'hoyoverse.com' }],
  [/honkai.?impact/i,                      { color: '#3B82F6', label: 'HI3',  domain: 'hoyoverse.com' }],
  [/zenless.?zone/i,                       { color: '#F59E0B', label: 'ZZZ',  domain: 'hoyoverse.com' }],
  [/wuthering.?waves/i,                    { color: '#0EA5E9', label: 'WW',   domain: 'kurogames.com' }],
  [/roblox/i,                              { color: '#EF4444', label: 'RBX',  domain: 'roblox.com' }],
  [/minecraft/i,                           { color: '#84CC16', label: 'MC',   domain: 'minecraft.net' }],
  [/fortnite/i,                            { color: '#06B6D4', label: 'FN',   domain: 'fortnite.com' }],
  [/call.?of.?duty|cod\b/i,               { color: '#374151', label: 'CoD',  domain: 'callofduty.com' }],
  [/valorant/i,                            { color: '#FF4655', label: 'VAL',  domain: 'playvalorant.com' }],
  [/wild.?rift/i,                          { color: '#2563EB', label: 'WR',   domain: 'wildrift.leagueoflegends.com' }],
  [/league.?of.?legend|\blol\b/i,         { color: '#C89B3C', label: 'LoL',  domain: 'leagueoflegends.com' }],
  [/solo.?leveling/i,                      { color: '#6366F1', label: 'SLA',  domain: 'netmarble.com' }],
  [/honor.?of.?king/i,                    { color: '#9333EA', label: 'HoK',  domain: 'honorofkings.com' }],
  [/arena.?of.?valor|aov\b/i,             { color: '#DC2626', label: 'AoV',  domain: 'garena.com' }],
  [/stumble.?guys/i,                       { color: '#A855F7', label: 'SG',   domain: 'stumbleguys.com' }],
  [/8.?ball.?pool/i,                       { color: '#1A7F3C', label: '8B',   domain: 'miniclip.com' }],
  [/lords.?mobile/i,                       { color: '#7C3AED', label: 'LM',   domain: 'igg.com' }],
  [/last.?war/i,                           { color: '#1F2937', label: 'LW',   domain: 'lastwar.fun' }],
  [/whiteout.?survival/i,                  { color: '#60A5FA', label: 'WS',   domain: 'whiteout-survival.com' }],
  [/netflix/i,                             { color: '#E50914', label: 'NF',   domain: 'netflix.com' }],
  [/spotify/i,                             { color: '#1DB954', label: 'SP',   domain: 'spotify.com' }],
  [/youtube.*premium/i,                    { color: '#FF0000', label: 'YT',   domain: 'youtube.com' }],
  [/disney/i,                              { color: '#113CCF', label: 'D+',   domain: 'disneyplus.com' }],
  [/amazon.?prime|prime.?video/i,          { color: '#00A8E0', label: 'PV',   domain: 'primevideo.com' }],
  [/apple.?music/i,                        { color: '#FC3C44', label: 'AM',   domain: 'apple.com' }],
  [/apple.?tv/i,                           { color: '#000000', label: 'ATV',  domain: 'apple.com' }],
  [/twitch/i,                              { color: '#9146FF', label: 'TW',   domain: 'twitch.tv' }],
  [/crunchyroll/i,                         { color: '#F47521', label: 'CR',   domain: 'crunchyroll.com' }],
  [/shahid/i,                              { color: '#E50914', label: 'شاهد', domain: 'shahid.net' }],
  [/wetv|we.tv/i,                          { color: '#1DB954', label: 'WTV',  domain: 'wetv.vip' }],
  [/deezer/i,                              { color: '#A238FF', label: 'DZ',   domain: 'deezer.com' }],
  [/telegram/i,                            { color: '#2AABEE', label: 'TG',   domain: 'telegram.org' }],
  [/snapchat/i,                            { color: '#FFFC00', label: 'SC',   domain: 'snapchat.com' }],
  [/chatgpt|openai|gpt.?plus/i,            { color: '#10A37F', label: 'GPT',  domain: 'openai.com' }],
  [/gemini/i,                              { color: '#4285F4', label: 'GEM',  domain: 'google.com' }],
  [/canva/i,                               { color: '#00C4CC', label: 'CV',   domain: 'canva.com' }],
  [/capcut/i,                              { color: '#000000', label: 'CC',   domain: 'capcut.com' }],
  [/picsart/i,                             { color: '#3B82F6', label: 'PA',   domain: 'picsart.com' }],
  [/adobe/i,                               { color: '#FF0000', label: 'AD',   domain: 'adobe.com' }],
  [/microsoft|copilot|ms.?365/i,           { color: '#00A4EF', label: 'MS',   domain: 'microsoft.com' }],
  [/google.?play/i,                        { color: '#01875F', label: 'GP',   domain: 'play.google.com' }],
  [/app.?store|itunes/i,                   { color: '#0071E3', label: 'iOS',  domain: 'apple.com' }],
  [/playstation|psn/i,                     { color: '#003087', label: 'PS',   domain: 'playstation.com' }],
  [/\bxbox\b|game.?pass/i,                { color: '#107C10', label: 'XBX',  domain: 'xbox.com' }],
  [/nintendo/i,                            { color: '#E60012', label: 'ND',   domain: 'nintendo.com' }],
  [/amazon\b/i,                            { color: '#FF9900', label: 'AMZ',  domain: 'amazon.com' }],
  [/steam/i,                               { color: '#1B2838', label: 'STM',  domain: 'steampowered.com' }],
  [/epic.?game/i,                          { color: '#313131', label: 'EGS',  domain: 'epicgames.com' }],
  [/razer/i,                               { color: '#44D62C', label: 'RZR',  domain: 'razer.com' }],
  [/garena/i,                              { color: '#FF5F00', label: 'GR',   domain: 'garena.com' }],
  [/blizzard/i,                            { color: '#00AEFF', label: 'BLZ',  domain: 'blizzard.com' }],
  [/nord.?vpn/i,                           { color: '#4687FF', label: 'NV',   domain: 'nordvpn.com' }],
  [/express.?vpn/i,                        { color: '#DA3940', label: 'EX',   domain: 'expressvpn.com' }],
  [/surfshark/i,                           { color: '#1DBBA1', label: 'SS',   domain: 'surfshark.com' }],
  [/proton.?vpn/i,                         { color: '#6D4AFF', label: 'PV',   domain: 'protonvpn.com' }],
  [/cyberghost/i,                          { color: '#FBBF24', label: 'CG',   domain: 'cyberghostvpn.com' }],
  [/vpn|virtual.?private/i,                { color: '#6B7280', label: 'VPN',  domain: 'openvpn.net' }],
  [/syriatel|سيريتل/i,                     { color: '#A01C26', label: 'SY',   domain: null }],
  [/mtn|MTN/i,                             { color: '#FFCC00', label: 'MTN',  domain: 'mtn.com' }],
  [/binance/i,                             { color: '#F3BA2F', label: 'BNB',  domain: 'binance.com' }],
  [/usdt|tether/i,                         { color: '#26A17B', label: '₮',    domain: 'tether.to' }],
  [/visa/i,                                { color: '#1A1F71', label: 'VISA', domain: 'visa.com' }],
  [/yalla.?ludo/i,                         { color: '#F59E0B', label: 'YL',   domain: 'yalla.com' }],
  [/marvel/i,                              { color: '#DC2626', label: 'MR',   domain: 'marvel.com' }],
  [/overwatch/i,                           { color: '#F5A623', label: 'OW2',  domain: 'playoverwatch.com' }],
  [/invideo/i,                             { color: '#7C3AED', label: 'IV',   domain: 'invideo.io' }],
];

const CATEGORY_DEFAULTS: Record<string, BrandInfo> = {
  mobile_games: { color: '#7C3AED', label: '🎮', logoUrl: null },
  pc_games:     { color: '#1D4ED8', label: '🖥',  logoUrl: null },
  gift_cards:   { color: '#F59E0B', label: '🎁',  logoUrl: null },
  services:     { color: '#0EA5E9', label: '⚡',  logoUrl: null },
  general:      { color: '#6B7280', label: '📦',  logoUrl: null },
};

export function getBrandInfo(
  description: string,
  name: string,
  category?: string | null,
  apiBase?: string
): BrandInfo {
  const makeLogoUrl = (domain: string | null) => {
    if (!domain) return null;
    if (apiBase) return proxy(apiBase, domain);
    return `https://logo.clearbit.com/${domain}?size=256`;
  };

  const desc = (description ?? '').trim();
  const nm = (name ?? '').trim();

  // 1. Exact description match
  if (desc) {
    const exact = GAME_DOMAIN_MAP[desc];
    if (exact) {
      const directImg = apiBase ? null : GAME_IMAGE_DIRECT[desc] ?? null;
      return { color: exact.color, label: exact.label, logoUrl: directImg ?? makeLogoUrl(exact.domain) };
    }
  }

  // 2. Regex on description
  for (const [regex, info] of BRAND_MAP) {
    if (regex.test(desc)) {
      const directImg = apiBase ? null : GAME_IMAGE_DIRECT[desc] ?? null;
      return { color: info.color, label: info.label, logoUrl: directImg ?? makeLogoUrl(info.domain) };
    }
  }

  // 3. Regex on name
  for (const [regex, info] of BRAND_MAP) {
    if (regex.test(nm)) {
      return { color: info.color, label: info.label, logoUrl: makeLogoUrl(info.domain) };
    }
  }

  // 4. Category default
  return CATEGORY_DEFAULTS[category ?? 'general'] ?? CATEGORY_DEFAULTS['general'];
}

export function getProductImage(
  description: string,
  name: string,
  category?: string | null,
  existingImage?: string | null,
  apiBase?: string
): string | null {
  if (existingImage) return existingImage;
  if (!apiBase && description && GAME_IMAGE_DIRECT[description]) return GAME_IMAGE_DIRECT[description];
  const brand = getBrandInfo(description, name, category, apiBase);
  return brand.logoUrl;
}
