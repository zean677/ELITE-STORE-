import React from 'react';
import { Link } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useLanguage } from '@/i18n';
import { useCurrency } from '@/hooks/use-currency';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Heart, HeartOff, Zap, ShoppingBag, Trash2 } from 'lucide-react';
import { getBrandInfo, getProductImage } from '@/lib/product-images';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function apiRequest(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

function WishlistProductCard({ item, onRemove }: { item: any; onRemove: (id: string) => void }) {
  const { formatPrice } = useCurrency();
  const { lang } = useLanguage();
  const brand = getBrandInfo(item.description ?? '', item.name ?? '', item.category, BASE);
  const imgSrc = getProductImage(item.description ?? '', item.name ?? '', item.category, item.image, BASE);
  const [imgOk, setImgOk] = React.useState(true);
  const name = lang === 'ar' && item.nameAr ? item.nameAr : item.name;
  const isAvailable = item.status === 'active';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="group relative bg-card border border-border rounded-2xl overflow-hidden"
      style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.3)' }}
    >
      <div className="relative h-28 flex items-center justify-center overflow-hidden" style={{ background: `linear-gradient(135deg, ${brand.color}30, ${brand.color}10)` }}>
        {imgSrc && imgOk ? (
          <img src={imgSrc} alt={name} loading="lazy" className="h-20 w-auto max-w-full object-contain px-2 z-10" onError={() => setImgOk(false)} />
        ) : (
          <div className="z-10 absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl shadow-lg" style={{ background: `linear-gradient(135deg, ${brand.color}cc, ${brand.color}66)`, color: '#fff' }}>
              {brand.label.length > 3 ? brand.label.slice(0, 2) : brand.label}
            </div>
          </div>
        )}
        {!isAvailable && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="text-white/70 text-xs font-bold">{lang === 'ar' ? 'غير متاح' : 'Unavailable'}</span>
          </div>
        )}
        <button
          onClick={() => onRemove(item.productId)}
          className="absolute top-2 right-2 w-7 h-7 rounded-full bg-red-500/20 hover:bg-red-500/40 flex items-center justify-center transition-colors z-10 border border-red-500/30"
          title={lang === 'ar' ? 'إزالة من المفضلة' : 'Remove from wishlist'}
        >
          <Trash2 size={12} className="text-red-400" />
        </button>
      </div>
      <div className="p-3">
        <h3 className="font-semibold text-sm leading-tight line-clamp-2 min-h-[2.5rem]">{name}</h3>
        <div className="flex items-center justify-between mt-3">
          <span className="font-black text-sm" style={{ color: brand.color }}>
            {parseFloat(item.priceUsd ?? '0') === 0
              ? <span className="text-muted-foreground text-xs">{lang === 'ar' ? 'يُحدَّد عند الطلب' : 'Custom'}</span>
              : formatPrice(item.priceUsd)}
          </span>
          {isAvailable && (
            <Link
              href={`/products/${item.productId}`}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-white transition-all hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #6C5CE7, #8b7eff)', boxShadow: '0 4px 12px rgba(108,92,231,0.40)' }}
            >
              <Zap size={10} />{lang === 'ar' ? 'شحن' : 'Buy'}
            </Link>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default function Wishlist() {
  const { lang } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ['wishlist'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/wishlist');
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
  });

  const removeMutation = useMutation({
    mutationFn: async (productId: string) => {
      const res = await apiRequest('DELETE', `/api/wishlist/${productId}`);
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wishlist'] });
      toast({ title: lang === 'ar' ? 'تمت الإزالة' : 'Removed', description: lang === 'ar' ? 'تمت إزالة المنتج من المفضلة' : 'Removed from wishlist' });
    },
  });

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-6" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
            <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/30 flex items-center justify-center">
              <Heart size={20} className="text-red-400" fill="currentColor" />
            </div>
            <div>
              <h1 className="font-black text-2xl text-white">{lang === 'ar' ? 'المفضلة' : 'Wishlist'}</h1>
              <p className="text-sm text-muted-foreground">{items.length} {lang === 'ar' ? 'منتج محفوظ' : 'saved products'}</p>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-card border border-border rounded-2xl overflow-hidden animate-pulse">
                  <div className="h-28 bg-muted" />
                  <div className="p-3 space-y-2"><div className="h-3.5 bg-muted rounded w-4/5" /><div className="h-3 bg-muted rounded w-2/5" /></div>
                </div>
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 text-center">
              <HeartOff size={48} className="text-muted-foreground/40 mb-4" />
              <h2 className="text-xl font-bold text-white/70 mb-2">{lang === 'ar' ? 'المفضلة فارغة' : 'Wishlist is empty'}</h2>
              <p className="text-muted-foreground text-sm mb-6">{lang === 'ar' ? 'أضف منتجات لتجدها هنا لاحقاً' : 'Save products to find them here later'}</p>
              <Link href="/games" className="flex items-center gap-2 px-5 py-2.5 bg-primary/20 border border-primary/40 text-primary rounded-xl font-semibold text-sm hover:bg-primary/30 transition-colors">
                <ShoppingBag size={16} />{lang === 'ar' ? 'تصفح الألعاب' : 'Browse Games'}
              </Link>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {items.map((item: any) => (
                  <WishlistProductCard key={item.productId} item={item} onRemove={(id) => removeMutation.mutate(id)} />
                ))}
              </div>
            </AnimatePresence>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
