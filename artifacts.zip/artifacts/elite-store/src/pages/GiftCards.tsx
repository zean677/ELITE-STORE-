import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useAuth } from '@/hooks/use-auth';
import { useCurrency } from '@/hooks/use-currency';
import { useToast } from '@/hooks/use-toast';
import { Gift, Copy, CheckCircle, Sparkles, Plus, QrCode, Tag, Clock, Loader2, Send, Lock, X } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authFetch(path: string, opts?: RequestInit) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...((opts?.headers) ?? {}) },
  });
}

const AMOUNTS = [5, 10, 25, 50, 100];

function GiftCardVisual({ card, onCopy }: { card: any; onCopy: (code: string) => void }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(card.code).catch(() => {});
    setCopied(true);
    onCopy(card.code);
    setTimeout(() => setCopied(false), 2000);
  };

  const isActive = card.status === 'active';
  const shareLink = `${window.location.origin}${BASE}/gift/${card.code}`;

  return (
    <div className={`relative rounded-2xl overflow-hidden border ${isActive ? 'border-violet-500/30 bg-gradient-to-br from-violet-600/15 via-purple-700/10 to-pink-600/10' : 'border-white/10 bg-white/3 opacity-60'}`}>
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-violet-500/10 blur-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-20 h-20 rounded-full bg-pink-500/10 blur-xl pointer-events-none" />

      <div className="relative p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center">
              <Gift size={16} className="text-white" />
            </div>
            <div>
              <p className="text-white font-black text-lg">${parseFloat(card.amountUsd).toFixed(0)}</p>
              <p className="text-[10px] text-gray-400">بطاقة هدية</p>
            </div>
          </div>
          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${isActive ? 'bg-emerald-500/20 text-emerald-400' : card.status === 'redeemed' ? 'bg-gray-500/20 text-gray-400' : 'bg-red-500/20 text-red-400'}`}>
            {isActive ? '✅ نشطة' : card.status === 'redeemed' ? '✔ مُستخدمة' : '❌ منتهية'}
          </span>
        </div>

        {card.messageAr && (
          <p className="text-gray-300 text-xs italic mb-3 border-r-2 border-violet-500/40 pr-2">{card.messageAr}</p>
        )}

        {/* Code display */}
        <div className="bg-black/30 rounded-xl px-3 py-2 flex items-center justify-between mb-3 font-mono">
          <span className="text-white text-sm tracking-widest font-bold">{card.code}</span>
          {isActive && (
            <button onClick={copy} className="text-gray-400 hover:text-white transition-colors">
              {copied ? <CheckCircle size={16} className="text-emerald-400" /> : <Copy size={16} />}
            </button>
          )}
        </div>

        {isActive && (
          <div className="flex gap-2">
            <button
              onClick={copy}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-violet-600/20 border border-violet-500/30 text-violet-300 text-xs font-bold hover:bg-violet-600/30 transition-colors"
            >
              <Copy size={13} /> نسخ الكود
            </button>
            <button
              onClick={() => { navigator.share?.({ url: shareLink, title: 'بطاقة هدية' }).catch(() => { navigator.clipboard.writeText(shareLink); }); }}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-pink-600/20 border border-pink-500/30 text-pink-300 text-xs font-bold hover:bg-pink-600/30 transition-colors"
            >
              <Send size={13} /> مشاركة
            </button>
          </div>
        )}

        <p className="text-gray-600 text-[9px] mt-2 text-center">
          {card.expiresAt ? `تنتهي: ${new Date(card.expiresAt).toLocaleDateString('ar-SY')}` : ''}
        </p>
      </div>
    </div>
  );
}

export default function GiftCards() {
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const { toast } = useToast();
  const qc = useQueryClient();

  const [showBuy, setShowBuy] = useState(false);
  const [showRedeem, setShowRedeem] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState(10);
  const [msgAr, setMsgAr] = useState('');
  const [redeemCode, setRedeemCode] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['my-gift-cards'],
    queryFn: async () => { const r = await authFetch('/api/gift-cards'); return r.json(); },
    staleTime: 30_000,
  });

  const cards: any[] = data?.cards ?? [];

  const buyMutation = useMutation({
    mutationFn: async () => {
      const r = await authFetch('/api/gift-cards', { method: 'POST', body: JSON.stringify({ amountUsd: selectedAmount, messageAr: msgAr || undefined }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? 'فشل');
      return d;
    },
    onSuccess: () => {
      toast({ title: '✅ تم شراء البطاقة', description: 'يمكنك الآن مشاركة الكود مع أي شخص' });
      qc.invalidateQueries({ queryKey: ['my-gift-cards'] });
      qc.invalidateQueries({ queryKey: ['wallet'] });
      setShowBuy(false);
      setMsgAr('');
    },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  const redeemMutation = useMutation({
    mutationFn: async () => {
      const r = await authFetch('/api/gift-cards/redeem', { method: 'POST', body: JSON.stringify({ code: redeemCode }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? 'فشل');
      return d;
    },
    onSuccess: (d: any) => {
      toast({ title: '🎁 تم الاستلام!', description: `أُضيف ${formatPrice(d.amountUsd)} لمحفظتك` });
      qc.invalidateQueries({ queryKey: ['wallet'] });
      setShowRedeem(false);
      setRedeemCode('');
    },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="p-4 max-w-lg mx-auto pb-24" dir="rtl">
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div>
              <h1 className="text-white text-xl font-black flex items-center gap-2">
                <Gift size={20} className="text-violet-400" /> بطاقات الهدايا
              </h1>
              <p className="text-gray-400 text-xs mt-0.5">أرسل هدية لأي شخص بكل سهولة</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowRedeem(true)} className="px-3 py-2 rounded-xl bg-white/10 text-white text-xs font-bold hover:bg-white/15 transition-colors flex items-center gap-1">
                <Tag size={13} /> استخدام كود
              </button>
              <button onClick={() => setShowBuy(true)} className="px-3 py-2 rounded-xl bg-violet-600 text-white text-xs font-bold hover:bg-violet-500 transition-colors flex items-center gap-1">
                <Plus size={13} /> شراء
              </button>
            </div>
          </div>

          {/* Buy modal */}
          {showBuy && (
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end justify-center p-4">
              <div className="bg-[#0f0f1a] border border-white/10 rounded-3xl p-5 w-full max-w-md" dir="rtl">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-white font-black">شراء بطاقة هدية</h2>
                  <button onClick={() => setShowBuy(false)}><X size={20} className="text-gray-400" /></button>
                </div>

                <p className="text-gray-400 text-xs mb-3">اختر القيمة</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {AMOUNTS.map(a => (
                    <button key={a} onClick={() => setSelectedAmount(a)}
                      className={`px-4 py-2 rounded-xl font-bold text-sm border transition-all ${selectedAmount === a ? 'bg-violet-600 border-violet-500 text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:border-violet-500/50'}`}>
                      ${a}
                    </button>
                  ))}
                </div>

                <p className="text-gray-400 text-xs mb-2">رسالة للمستلم (اختياري)</p>
                <textarea
                  value={msgAr}
                  onChange={e => setMsgAr(e.target.value)}
                  placeholder="مثال: عيد ميلاد سعيد! 🎂"
                  maxLength={200}
                  rows={2}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder-gray-600 resize-none focus:outline-none focus:border-violet-500/50 mb-4"
                />

                <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 mb-4">
                  <Lock size={14} className="text-amber-400 shrink-0" />
                  <p className="text-amber-200/80 text-xs">سيُخصم ${selectedAmount} من محفظتك عند الشراء</p>
                </div>

                <button
                  onClick={() => buyMutation.mutate()}
                  disabled={buyMutation.isPending}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-violet-600 to-pink-600 text-white font-black text-sm hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {buyMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                  شراء بطاقة ${selectedAmount}
                </button>
              </div>
            </div>
          )}

          {/* Redeem modal */}
          {showRedeem && (
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-[#0f0f1a] border border-white/10 rounded-3xl p-5 w-full max-w-sm" dir="rtl">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-white font-black">استخدام بطاقة هدية</h2>
                  <button onClick={() => setShowRedeem(false)}><X size={20} className="text-gray-400" /></button>
                </div>
                <p className="text-gray-400 text-xs mb-3">أدخل كود البطاقة</p>
                <input
                  value={redeemCode}
                  onChange={e => setRedeemCode(e.target.value.toUpperCase())}
                  placeholder="XXXX-XXXX-XXXX-XXXX"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-3 text-white text-sm font-mono tracking-widest text-center placeholder-gray-600 focus:outline-none focus:border-violet-500/50 mb-4"
                  maxLength={19}
                />
                <button
                  onClick={() => redeemMutation.mutate()}
                  disabled={redeemMutation.isPending || redeemCode.replace(/-/g, '').length < 16}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-sm hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {redeemMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Gift size={16} />}
                  استخدام البطاقة
                </button>
              </div>
            </div>
          )}

          {/* Cards list */}
          {isLoading ? (
            <div className="flex justify-center py-16"><div className="w-7 h-7 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" /></div>
          ) : cards.length === 0 ? (
            <div className="text-center py-16">
              <Gift size={40} className="text-gray-700 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">ليس لديك بطاقات هدايا بعد</p>
              <button onClick={() => setShowBuy(true)} className="mt-4 px-5 py-2.5 rounded-xl bg-violet-600 text-white text-sm font-bold hover:bg-violet-500 transition-colors">اشترِ أول بطاقة</button>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {cards.map(c => <GiftCardVisual key={c.id} card={c} onCopy={() => toast({ title: 'تم نسخ الكود ✅' })} />)}
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
