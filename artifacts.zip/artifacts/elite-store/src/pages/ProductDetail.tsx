import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link, useRoute, useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { useGetProduct, useCreateOrder, useGetWallet } from '@workspace/api-client-react';
import { PublicLayout } from '@/components/Layout';
import { useCurrency } from '@/hooks/use-currency';
import { useLanguage } from '@/i18n';
import { useAuth } from '@/hooks/use-auth';
import { AlertCircle, BadgeCheck, Bell, Bookmark, BookmarkCheck, CheckCircle, ChevronLeft, Clock, Gift, Headphones, Heart, HeartOff, Image as ImageIcon, Loader2, Lock, Minus, PackageCheck, Plus, ShieldCheck, ShoppingBag, ShoppingCart, Sparkles, Star, Tag, X, Zap } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';
import { useToast } from '@/hooks/use-toast';
import { getProductImage, getBrandInfo } from '@/lib/product-images';
import { VipBadge, getVipFromData } from '@/components/VipBadge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

// ─── Price History Chart ──────────────────────────────────────────────────────
const BASE_PD = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function PriceHistoryChart({ productId, formatPrice, lang }: { productId: string; formatPrice: any; lang: string }) {
  const { data } = useQuery({
    queryKey: ['price-history', productId],
    queryFn: async () => {
      const r = await fetch(`${BASE_PD}/api/products/${productId}/price-history`);
      return r.json();
    },
    staleTime: 5 * 60_000,
  });
  const points: { date: string; price: number }[] = data?.history ?? [];
  if (points.length < 2) return null;

  const chartData = points.map(p => ({
    name: new Date(p.date).toLocaleDateString(lang === 'ar' ? 'ar-SY' : 'en', { month: 'short', day: 'numeric' }),
    price: p.price,
  }));
  const minPrice = Math.min(...points.map(p => p.price));
  const maxPrice = Math.max(...points.map(p => p.price));
  const dropped = points.length > 1 && points[points.length - 1].price < points[0].price;

  return (
    <div className="mt-8 rounded-2xl border border-blue-500/20 bg-blue-500/5 p-4" dir="rtl">
      <div className="flex items-center justify-between mb-3">
        <p className="text-white font-bold text-sm">{lang === 'ar' ? '📉 تاريخ الأسعار' : 'Price History'}</p>
        <div className="flex gap-3 text-[10px] text-gray-400">
          <span>أدنى: <span className="text-emerald-400 font-bold">{formatPrice(minPrice)}</span></span>
          <span>أعلى: <span className="text-red-400 font-bold">{formatPrice(maxPrice)}</span></span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={100}>
        <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
          <defs>
            <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={dropped ? '#10b981' : '#3b82f6'} stopOpacity={0.3} />
              <stop offset="95%" stopColor={dropped ? '#10b981' : '#3b82f6'} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 8 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
          <YAxis tick={{ fill: '#6b7280', fontSize: 8 }} axisLine={false} tickLine={false} domain={['auto', 'auto']} />
          <Tooltip
            contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: 8, fontSize: 11 }}
            formatter={(v: any) => [formatPrice(v), lang === 'ar' ? 'السعر' : 'Price']}
          />
          <Area type="monotone" dataKey="price" stroke={dropped ? '#10b981' : '#3b82f6'} fill="url(#priceGrad)" strokeWidth={2} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
      {dropped && <p className="text-emerald-400 text-[10px] text-center mt-1">✅ السعر انخفض مؤخراً</p>}
    </div>
  );
}

// ─── Reviews Component ────────────────────────────────────────────────────────
function StarsRow({ value, onChange, size = 20 }: { value: number; onChange?: (v: number) => void; size?: number }) {
  const [hover, setHover] = React.useState(0);
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          size={size}
          className={`transition-colors cursor-pointer ${i <= (hover || value) ? 'text-amber-400 fill-amber-400' : 'text-gray-600'}`}
          onClick={() => onChange?.(i)}
          onMouseEnter={() => onChange && setHover(i)}
          onMouseLeave={() => onChange && setHover(0)}
        />
      ))}
    </div>
  );
}

function ReviewsSection({ productId, user, lang, formatPrice: _fp }: { productId: string; user: any; lang: string; formatPrice: any }) {
  const BASE2 = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
  const { toast: showToast } = useToast();
  const qc = useQueryClient();
  const [myRating, setMyRating] = React.useState(0);
  const [myComment, setMyComment] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);
  const [showForm, setShowForm] = React.useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['reviews', productId],
    queryFn: async () => {
      const res = await fetch(`${BASE2}/api/reviews/${productId}`);
      return res.json();
    },
    staleTime: 30_000,
  });

  const reviews: any[] = data?.reviews ?? [];
  const avgRating: string | null = data?.avgRating ?? null;
  const totalReviews: number = data?.totalReviews ?? 0;

  const handleSubmit = async () => {
    if (!myRating) return;
    setSubmitting(true);
    try {
      const token = localStorage.getItem('elite_token');
      const res = await fetch(`${BASE2}/api/reviews/${productId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ rating: myRating, comment: myComment.trim() || undefined }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed'); }
      showToast({ title: lang === 'ar' ? '✅ تم إرسال تقييمك' : '✅ Review submitted' });
      qc.invalidateQueries({ queryKey: ['reviews', productId] });
      setShowForm(false);
      setMyRating(0);
      setMyComment('');
    } catch (e: any) {
      showToast({ title: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="mt-12" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-heading text-xl font-bold">{lang === 'ar' ? 'التقييمات والمراجعات' : 'Reviews'}</h2>
          {avgRating && (
            <div className="flex items-center gap-2 mt-1">
              <StarsRow value={Math.round(parseFloat(avgRating))} size={16} />
              <span className="text-sm font-bold text-amber-400">{avgRating}</span>
              <span className="text-xs text-muted-foreground">({totalReviews} {lang === 'ar' ? 'تقييم' : 'reviews'})</span>
            </div>
          )}
        </div>
        {user && !showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 rounded-xl text-sm font-semibold border border-primary/40 text-primary hover:bg-primary/10 transition-colors"
          >
            {lang === 'ar' ? '✏️ أضف تقييمك' : '✏️ Write a review'}
          </button>
        )}
      </div>

      {showForm && (
        <div className="bg-card border border-primary/20 rounded-2xl p-5 mb-6">
          <h3 className="text-sm font-bold mb-3">{lang === 'ar' ? 'تقييمك' : 'Your review'}</h3>
          <div className="mb-3">
            <StarsRow value={myRating} onChange={setMyRating} size={28} />
          </div>
          <textarea
            value={myComment}
            onChange={e => setMyComment(e.target.value)}
            rows={3}
            placeholder={lang === 'ar' ? 'أضف تعليقك (اختياري)...' : 'Add a comment (optional)...'}
            className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm resize-none focus:outline-none focus:border-primary/50"
          />
          <div className="flex gap-2 mt-3">
            <button onClick={handleSubmit} disabled={!myRating || submitting} className="flex items-center gap-2 px-5 py-2 bg-primary text-white rounded-xl text-sm font-bold disabled:opacity-50 hover:bg-primary/90 transition-colors">
              {submitting ? <Loader2 size={14} className="animate-spin" /> : null}
              {lang === 'ar' ? 'إرسال' : 'Submit'}
            </button>
            <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-xl text-sm border border-border text-muted-foreground hover:text-foreground transition-colors">
              {lang === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2].map(i => <div key={i} className="h-20 bg-card rounded-2xl animate-pulse" />)}
        </div>
      ) : reviews.length === 0 ? (
        <div className="py-12 text-center bg-card border border-border rounded-2xl">
          <Star size={32} className="mx-auto text-muted-foreground/20 mb-3" />
          <p className="text-muted-foreground text-sm">{lang === 'ar' ? 'لا توجد تقييمات بعد. كن أول من يقيّم!' : 'No reviews yet. Be the first!'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {reviews.map((r: any) => (
            <div key={r.id} className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                    {(r.username ?? '?').slice(0, 1).toUpperCase()}
                  </div>
                  <span className="text-sm font-semibold">{r.username ?? 'مجهول'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <StarsRow value={r.rating} size={13} />
                  <span className="text-[10px] text-muted-foreground">{new Date(r.createdAt).toLocaleDateString('en-GB')}</span>
                </div>
              </div>
              {r.comment && <p className="text-sm text-muted-foreground">{r.comment}</p>}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function authFetch(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  const base = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
  return fetch(`${base}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function getSavedId(productId: string): string {
  try { return (JSON.parse(localStorage.getItem('elite_saved_ids') ?? '{}'))[productId] ?? ''; } catch { return ''; }
}

function persistId(productId: string, uid: string) {
  try {
    const all = JSON.parse(localStorage.getItem('elite_saved_ids') ?? '{}');
    all[productId] = uid;
    localStorage.setItem('elite_saved_ids', JSON.stringify(all));
  } catch {}
}

function normalizeField(field: string) {
  const f = field.toLowerCase();
  if (f.includes('email') || f.includes('mail')) return { key: 'email', labelAr: 'البريد / الحساب', labelEn: 'Email / Account', placeholderAr: 'أدخل البريد أو الحساب', placeholderEn: 'Enter account email', type: 'email' };
  if (f.includes('zone')) return { key: 'zoneId', labelAr: 'Zone ID', labelEn: 'Zone ID', placeholderAr: 'أدخل Zone ID', placeholderEn: 'Enter Zone ID', type: 'text' };
  if (f.includes('server')) return { key: 'server', labelAr: 'السيرفر', labelEn: 'Server', placeholderAr: 'أدخل السيرفر', placeholderEn: 'Enter server', type: 'text' };
  return { key: 'playerId', labelAr: 'معرّف اللاعب', labelEn: 'Player ID', placeholderAr: 'أدخل معرّف اللاعب', placeholderEn: 'Enter Player ID', type: 'text' };
}

export default function ProductDetail() {
  const [, params] = useRoute('/products/:id');
  const id = params?.id ?? '';
  const { data: productRaw, isLoading, isError, refetch } = useGetProduct(id, { query: { enabled: !!id, retry: 1 } as any });
  const product: any = productRaw;
  const { formatPrice, currency } = useCurrency();
  const { t, lang } = useLanguage();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const createOrder = useCreateOrder();
  const cart = useCart();

  const handleAddToCart = () => {
    const missing = requiredFields.find((field: any) => field.required !== false && !formValues[field.key]?.trim());
    if (missing) {
      toast({ title: 'بيانات ناقصة', description: `يرجى إدخال ${lang === 'ar' ? missing.labelAr : missing.labelEn} قبل إضافة المنتج للسلة`, variant: 'destructive' });
      return;
    }
    if (showGift && giftEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(giftEmail)) {
      toast({ title: lang === 'ar' ? 'بريد إلكتروني غير صالح' : 'Invalid email', variant: 'destructive' });
      return;
    }
    cart.addItem({
      productId: id,
      name: product?.name || '',
      nameAr: (product as any)?.nameAr,
      image: product?.image || undefined,
      description: product?.description || undefined,
      category: (product as any)?.categoryId || undefined,
      priceUsd: String(product?.priceUsd || '0'),
      qty,
      playerId: composePlayerId() || undefined,
      formValues: { ...formValues },
      giftEmail: showGift && giftEmail ? giftEmail : undefined,
      promoCodeId: promoApplied?.id != null ? String(promoApplied.id) : undefined,
      promoCode: promoApplied?.code,
    });
    toast({ title: '🛒 تمّت الإضافة للسلة', description: `${product?.name} × ${qty}` });
  };
  const { data: wallet } = useGetWallet({ query: { enabled: !!user } as any });

  const [qty, setQty] = useState(1);
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [galleryIndex, setGalleryIndex] = useState(0);
  const [idSaved, setIdSaved] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState<{ id: number; discountUsd: number; code: string } | null>(null);
  const [promoLoading, setPromoLoading] = useState(false);
  const [showGift, setShowGift] = useState(false);
  const [giftEmail, setGiftEmail] = useState('');
  const [showPriceAlert, setShowPriceAlert] = useState(false);
  const [priceAlertTarget, setPriceAlertTarget] = useState('');
  const priceAlertMutation = useMutation({
    mutationFn: async () => {
      const res = await authFetch('POST', '/api/price-alerts', {
        productId: id,
        targetPriceUsd: parseFloat(priceAlertTarget),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'فشل');
      return data;
    },
    onSuccess: () => {
      toast({ title: lang === 'ar' ? '🔔 تم تفعيل التنبيه!' : '🔔 Alert created!', description: lang === 'ar' ? 'سنخبرك فور وصول السعر للهدف' : "We'll notify you when price drops" });
      setShowPriceAlert(false);
      setPriceAlertTarget('');
    },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });
  const queryClient = useQueryClient();

  const name = product ? (lang === 'ar' && product.nameAr ? product.nameAr : product.name) : 'Elite Store';
  const requiredFields = useMemo(() => {
    const custom = (product as any)?.customFields;
    if (Array.isArray(custom) && custom.length > 0) {
      const seen = new Set<string>();
      return custom
        .filter((f: any) => f && f.key && !seen.has(f.key) && seen.add(f.key))
        .map((f: any) => ({
          key: f.key,
          labelAr: f.labelAr || f.key,
          labelEn: f.labelEn || f.labelAr || f.key,
          placeholderAr: f.placeholder || '',
          placeholderEn: f.placeholder || '',
          type: f.type || 'text',
          required: f.required !== false,
          options: Array.isArray(f.options) ? f.options : undefined,
        }));
    }
    const fields = product?.requiredFields?.length ? product.requiredFields : ['playerId'];
    const seen = new Set<string>();
    return fields.map(normalizeField).map((f: any) => ({ ...f, required: true })).filter((field: any) => {
      if (seen.has(field.key)) return false;
      seen.add(field.key);
      return true;
    });
  }, [product?.requiredFields, (product as any)?.customFields]);
  const minQty = product?.qtyMin ? Number(product.qtyMin) : 1;
  const maxQty = product?.qtyMax ? Number(product.qtyMax) : 999999;
  const brandInfo = useMemo(() => {
    if (!product) return null;
    return getBrandInfo(product.description ?? '', product.name ?? '', product.category, BASE);
  }, [product?.description, product?.name, product?.category]);

  const images = useMemo(() => {
    if (!product) return [];
    const resolved = getProductImage(product.description ?? '', product.name ?? '', product.category, product.image, BASE);
    return [resolved].filter(Boolean) as string[];
  }, [product?.description, product?.name, product?.category, product?.image]);
  const relatedProducts = product?.relatedProducts ?? [];

  useEffect(() => {
    if (id) {
      const saved = getSavedId(id);
      if (saved) {
        setFormValues(values => ({ ...values, playerId: saved }));
        setIdSaved(true);
      }
    }
  }, [id]);

  useEffect(() => {
    if (!product) return;
    document.title = `${name} | Elite Store`;
    const description = product.description || 'اشحن الألعاب والبطاقات والخدمات الرقمية بسرعة وأمان من Elite Store';
    let meta = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    meta.content = description;
    let og = document.querySelector('meta[property="og:title"]') as HTMLMetaElement | null;
    if (!og) {
      og = document.createElement('meta');
      og.setAttribute('property', 'og:title');
      document.head.appendChild(og);
    }
    og.content = `${name} | Elite Store`;
  }, [product, name]);

  useEffect(() => {
    if (product && qty < minQty) setQty(minQty);
  }, [product, minQty, qty]);

  // Wishlist check
  const { data: wishlistData } = useQuery({
    queryKey: ['wishlist-check', id],
    enabled: !!user && !!id,
    queryFn: async () => {
      const res = await authFetch('GET', '/api/wishlist');
      if (!res.ok) return [];
      return res.json();
    },
    staleTime: 60_000,
  });
  const isWishlisted = useMemo(() => (wishlistData ?? []).some((w: any) => w.productId === id), [wishlistData, id]);

  const wishlistMutation = useMutation({
    mutationFn: async () => {
      if (!user) { navigate('/login'); return; }
      if (isWishlisted) {
        await authFetch('DELETE', `/api/wishlist/${id}`);
      } else {
        await authFetch('POST', '/api/wishlist', { productId: id });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wishlist-check', id] });
      queryClient.invalidateQueries({ queryKey: ['wishlist'] });
      toast({ title: isWishlisted ? (lang === 'ar' ? 'أُزيل من المفضلة' : 'Removed from wishlist') : (lang === 'ar' ? 'أُضيف للمفضلة' : 'Added to wishlist') });
    },
  });

  const vip = getVipFromData(wallet ?? user);
  const totalBeforeVip = Number(product?.priceUsd ?? 0) * qty;
  const vipDiscount = totalBeforeVip * (vip.discountPercent / 100);
  const totalAfterVip = Math.max(0, totalBeforeVip - vipDiscount);
  const promoDiscount = promoApplied ? Math.min(promoApplied.discountUsd, totalAfterVip) : 0;
  const total = Math.max(0, totalAfterVip - promoDiscount);

  // Promo code validation
  const applyPromo = useCallback(async () => {
    if (!promoCode.trim()) return;
    setPromoLoading(true);
    try {
      const res = await authFetch('POST', '/api/promo/validate', { code: promoCode.trim(), orderAmountUsd: total });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Invalid');
      setPromoApplied({ id: data.promoId, discountUsd: data.discountUsd, code: promoCode.trim().toUpperCase() });
      toast({ title: lang === 'ar' ? `تم تطبيق الكوبون ✓` : 'Promo applied ✓', description: `${lang === 'ar' ? 'خصم' : 'Discount'}: -${formatPrice(data.discountUsd)}` });
    } catch (e: any) {
      toast({ title: lang === 'ar' ? 'كوبون غير صالح' : 'Invalid promo', description: e.message, variant: 'destructive' });
    } finally {
      setPromoLoading(false);
    }
  }, [promoCode, total]);

  const updateField = (key: string, value: string) => {
    setFormValues(values => ({ ...values, [key]: value }));
    if (key === 'playerId') setIdSaved(false);
  };

  const handleSaveId = () => {
    const playerId = formValues.playerId?.trim();
    if (!playerId) return;
    persistId(id, playerId);
    setIdSaved(true);
    toast({ title: 'تم حفظ المعرّف', description: 'سيُملأ تلقائياً في المرة القادمة' });
  };

  const composePlayerId = () => {
    const main = formValues.playerId || formValues.email || '';
    const extras = Object.entries(formValues)
      .filter(([key, value]) => value.trim() && key !== 'playerId' && key !== 'email')
      .map(([key, value]) => `${key}:${value.trim()}`);
    return [main.trim(), ...extras].filter(Boolean).join(' | ');
  };

  const handleBuy = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    const missing2 = requiredFields.find((field: any) => field.required !== false && !formValues[field.key]?.trim());
    if (missing2) {
      toast({ title: 'بيانات ناقصة', description: `يرجى إدخال ${lang === 'ar' ? missing2.labelAr : missing2.labelEn}`, variant: 'destructive' });
      return;
    }

    if (showGift && giftEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(giftEmail)) {
      toast({ title: lang === 'ar' ? 'بريد إلكتروني غير صالح' : 'Invalid email', variant: 'destructive' });
      return;
    }

    try {
      const order: any = await createOrder.mutateAsync({
        data: {
          productId: id,
          qty,
          playerId: composePlayerId() || undefined,
          currency: currency as any,
          ...(promoApplied ? { promoCodeId: promoApplied.id } : {}),
          ...(showGift && giftEmail ? { giftToEmail: giftEmail } : {}),
        } as any,
      });
      toast({ title: 'تم إنشاء الطلب', description: showGift && giftEmail ? `تم إرسال الهدية إلى ${giftEmail}` : 'تم خصم الرصيد وإرسال الطلب للمزود' });
      navigate(`/orders/${order.id}/success`);
    } catch (err: any) {
      const serverMsg = err?.data?.message ?? err?.response?.data?.message ?? err?.message ?? '';
      const isInsufficientBalance = serverMsg.toLowerCase().includes('insufficient') || serverMsg.toLowerCase().includes('balance');
      const msg = isInsufficientBalance ? 'رصيدك غير كافٍ. يرجى شحن المحفظة أولاً.' : serverMsg || 'حدث خطأ أثناء تقديم الطلب';
      toast({ title: 'فشل الطلب', description: msg, variant: 'destructive' });
      if (isInsufficientBalance) {
        navigate('/wallet');
      }
      // Stay on product page so user can retry — no navigate to invalid order ID
    }
  };

  if (isLoading) {
    return (
      <PublicLayout>
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-2 gap-8 animate-pulse">
            <div className="h-96 rounded-3xl bg-card border border-border" />
            <div className="space-y-4">
              <div className="h-8 bg-card rounded-xl w-3/4" />
              <div className="h-20 bg-card rounded-2xl" />
              <div className="h-16 bg-card rounded-2xl" />
              <div className="h-44 bg-card rounded-2xl" />
            </div>
          </div>
        </div>
      </PublicLayout>
    );
  }

  if (isError || !product) {
    return (
      <PublicLayout>
        <div className="max-w-xl mx-auto px-4 py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-destructive/10 border border-destructive/20 flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="text-destructive" />
          </div>
          <h1 className="font-heading text-2xl font-bold mb-2">تعذر تحميل المنتج</h1>
          <p className="text-muted-foreground text-sm mb-5">المنتج غير موجود أو توقف مؤقتاً.</p>
          <button onClick={() => refetch()} className="px-5 py-2.5 bg-primary text-white rounded-xl font-semibold">إعادة المحاولة</button>
        </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-8 min-w-0 overflow-x-hidden" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
        <button onClick={() => navigate('/products')} className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm mb-3 sm:mb-6 transition-colors">
          <ChevronLeft size={16} className={lang === 'ar' ? 'rotate-180' : ''} />
          {lang === 'ar' ? 'العودة للمنتجات' : 'Back to Products'}
        </button>

        <div className="grid lg:grid-cols-[1.05fr_.95fr] gap-4 sm:gap-8 min-w-0">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="space-y-3 sm:space-y-4 lg:order-1 min-w-0">
            <div className="relative min-h-[200px] sm:min-h-[380px] rounded-3xl overflow-hidden border border-white/10 bg-[radial-gradient(circle_at_top,#6C5CE733,transparent_45%),linear-gradient(145deg,#111827,#0f172a)] flex items-center justify-center">
              {images.length > 0 ? (
                <img
                  src={images[galleryIndex]}
                  alt={name}
                  loading="lazy"
                  className="max-h-64 max-w-[80%] object-contain drop-shadow-2xl"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fb = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fb) fb.style.display = 'flex';
                  }}
                />
              ) : null}
              {/* Brand placeholder — shown when no image or image fails to load */}
              <div
                className="flex-col items-center justify-center gap-4"
                style={{ display: images.length > 0 ? 'none' : 'flex' }}
              >
                {(() => {
                  const color = brandInfo?.color ?? '#6c5ce7';
                  const label = brandInfo?.label ?? name.split(' ').slice(0, 2).map((w: string) => w[0]?.toUpperCase() ?? '').join('');
                  return (
                    <>
                      <div
                        className="w-40 h-40 rounded-3xl flex items-center justify-center relative overflow-hidden"
                        style={{
                          background: `radial-gradient(circle at 30% 30%, ${color}55, ${color}18)`,
                          border: `2px solid ${color}40`,
                          boxShadow: `0 0 80px ${color}28`,
                        }}
                      >
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(255,255,255,0.06),transparent_60%)]" />
                        <span className="z-10 text-3xl font-black tracking-widest" style={{ color: 'white', textShadow: `0 0 20px ${color}` }}>{label}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {product.provider === 'manual' ? 'Elite Store'
                          : product.provider === 'megagame' ? 'Mega Game'
                          : product.provider === 'ahminix' ? 'Ahminix'
                          : 'Elite Store'}
                      </p>
                    </>
                  );
                })()}
              </div>
              <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-1.5 bg-success/15 text-success border border-success/25 rounded-full text-xs font-bold">
                <CheckCircle size={13} />
                {product.status === 'active' ? 'متوفر الآن' : 'متوقف'}
              </div>
            </div>

            {images.length > 1 && (
              <div className="grid grid-cols-4 gap-2 sm:gap-3">
                {images.map((img, index) => (
                  <button key={index} onClick={() => setGalleryIndex(index)} className={`h-14 sm:h-20 rounded-xl sm:rounded-2xl border flex items-center justify-center bg-card ${galleryIndex === index ? 'border-primary' : 'border-border'}`}>
                    <img src={img} alt={name} loading="lazy" className="h-10 sm:h-12 object-contain" />
                  </button>
                ))}
              </div>
            )}

          </motion.div>

          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }} className="space-y-4 sm:space-y-5 lg:order-2 min-w-0">
            {/* Title block — badges + title in clean vertical stack */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                {product.description && (
                  <span
                    className="inline-flex items-center gap-1.5 px-3 py-1 text-[11px] sm:text-xs font-bold rounded-full border"
                    style={{
                      background: `${brandInfo?.color ?? '#6c5ce7'}1f`,
                      color: brandInfo?.color ?? '#6c5ce7',
                      borderColor: `${brandInfo?.color ?? '#6c5ce7'}55`,
                    }}
                  >
                    <span>🎮</span> {product.description}
                  </span>
                )}
                <span className="inline-flex items-center px-3 py-1 bg-white/[0.04] text-muted-foreground text-[11px] sm:text-xs font-medium rounded-full border border-white/10">
                  {product.category === 'mobile_games' ? 'ألعاب الهاتف' : product.category === 'pc_games' ? 'ألعاب الكمبيوتر' : product.category === 'gift_cards' ? 'بطاقات هدية' : product.category === 'services' ? 'خدمات' : 'عام'}
                </span>
              </div>
              <h1 className="font-heading text-2xl sm:text-3xl md:text-4xl font-black leading-tight break-words tracking-tight">{name}</h1>
            </div>

            {/* Price card — clean balanced layout */}
            <div className="relative overflow-hidden rounded-3xl p-5 border border-primary/25 bg-gradient-to-br from-primary/15 via-primary/8 to-transparent">
              <div className="absolute -top-12 -left-10 w-40 h-40 rounded-full bg-primary/20 blur-3xl pointer-events-none" />
              <div className="relative flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm text-muted-foreground mb-1.5 font-medium">
                    {product.productType === 'amount' ? 'السعر الابتدائي' : 'السعر'}
                  </p>
                  <p className="text-3xl sm:text-4xl font-black text-primary leading-none tracking-tight">
                    {formatPrice(product.priceUsd)}
                  </p>
                  {product.productType === 'amount' && product.unitPriceUsd && (
                    <p className="text-[11px] text-muted-foreground mt-2">
                      سعر الوحدة: ${Number(product.unitPriceUsd).toFixed(4)}
                    </p>
                  )}
                </div>
                {vip.discountPercent > 0 && (
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <VipBadge source={wallet ?? user} compact />
                    <p className="text-[11px] font-bold text-success whitespace-nowrap">
                      خصمك: {formatPrice(vipDiscount)}
                    </p>
                  </div>
                )}
              </div>
              {(() => {
                const avg = (product as any).avgDeliveryMinutes as number | null | undefined;
                const sample = (product as any).deliverySampleSize as number | undefined;
                if (avg == null || !sample) return null;
                const formatted =
                  avg < 1
                    ? (lang === 'ar' ? 'أقل من دقيقة' : 'under 1 min')
                    : avg < 60
                      ? (lang === 'ar' ? `${avg} دقيقة` : `${avg} min`)
                      : avg < 1440
                        ? (lang === 'ar' ? `${Math.round(avg / 60)} ساعة` : `${Math.round(avg / 60)} hr`)
                        : (lang === 'ar' ? `${Math.round(avg / 1440)} يوم` : `${Math.round(avg / 1440)} d`);
                const fast = avg <= 5;
                const accent = fast ? '#10b981' : avg <= 60 ? '#3b82f6' : '#f59e0b';
                return (
                  <div
                    className="mt-3 flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold"
                    style={{
                      background: `${accent}15`,
                      border: `1px solid ${accent}40`,
                      color: accent,
                    }}
                  >
                    <span className="text-base leading-none">⚡</span>
                    <span className="flex-1" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                      {lang === 'ar'
                        ? `متوسط وقت التسليم الفعلي: ${formatted}`
                        : `Average actual delivery: ${formatted}`}
                    </span>
                    <span className="text-[10px] font-medium opacity-70">
                      {lang === 'ar' ? `(آخر ${sample} طلب)` : `(last ${sample} orders)`}
                    </span>
                  </div>
                );
              })()}
            </div>

            {/* Trust feature cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5" dir="rtl">
              {[
                { Icon: ShieldCheck, color: '#10b981', title: 'حماية الرصيد', subtitle: 'استرجاع تلقائي عند فشل الطلب' },
                { Icon: Zap, color: '#22d3ee', title: 'ربط مباشر', subtitle: 'إرسال فوري إلى مزود الخدمة' },
                { Icon: Clock, color: '#f59e0b', title: 'متابعة مباشرة', subtitle: 'تتبع حالة الطلب من حسابك' },
              ].map(({ Icon, color, title, subtitle }) => (
                <div
                  key={title}
                  className="rounded-2xl p-3 flex items-center gap-3"
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: `1px solid ${color}33`,
                  }}
                >
                  <div
                    className="shrink-0 w-11 h-11 rounded-xl flex items-center justify-center"
                    style={{ background: `${color}1a`, border: `1px solid ${color}40` }}
                  >
                    <Icon style={{ color }} size={22} strokeWidth={2} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-white text-sm leading-tight">{title}</p>
                    <p className="text-[11px] text-gray-400 mt-1 leading-snug">{subtitle}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-card border border-border rounded-3xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-heading font-bold flex items-center gap-2">
                  <Sparkles size={18} className="text-primary" />
                  متطلبات الطلب
                </h2>
                <span className="text-xs text-muted-foreground">مطلوبة قبل الشراء</span>
              </div>

              {requiredFields.map((field: any) => {
                const inputType = field.type === 'phone' ? 'tel'
                  : field.type === 'number' ? 'number'
                  : field.type === 'email' ? 'email'
                  : 'text';
                const placeholder = lang === 'ar' ? field.placeholderAr : (field.placeholderEn || field.placeholderAr);
                return (
                  <div key={field.key}>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm font-medium">
                        {lang === 'ar' ? field.labelAr : (field.labelEn || field.labelAr)}
                        {field.required !== false && <span className="text-destructive"> *</span>}
                      </label>
                      {field.key === 'playerId' && (
                        <button type="button" onClick={handleSaveId} disabled={!formValues.playerId} className={`flex items-center gap-1 text-xs px-2 py-1 rounded-lg transition-colors ${idSaved && getSavedId(id) === formValues.playerId ? 'text-success bg-success/10' : 'text-muted-foreground hover:text-primary hover:bg-primary/10'} disabled:opacity-40`}>
                          {idSaved && getSavedId(id) === formValues.playerId ? <BookmarkCheck size={12} /> : <Bookmark size={12} />}
                          {idSaved && getSavedId(id) === formValues.playerId ? 'محفوظ' : 'حفظ'}
                        </button>
                      )}
                    </div>
                    {field.type === 'notes' ? (
                      <textarea value={formValues[field.key] ?? ''} onChange={e => updateField(field.key, e.target.value)} placeholder={placeholder} rows={3} className="w-full px-4 py-3 bg-background border border-border rounded-2xl text-sm focus:outline-none focus:border-primary/50 transition-colors resize-none" />
                    ) : field.type === 'dropdown' && Array.isArray(field.options) ? (
                      <select value={formValues[field.key] ?? ''} onChange={e => updateField(field.key, e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-2xl text-sm focus:outline-none focus:border-primary/50 transition-colors">
                        <option value="">{lang === 'ar' ? 'اختر...' : 'Select...'}</option>
                        {field.options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                      </select>
                    ) : (
                      <input type={inputType} value={formValues[field.key] ?? ''} onChange={e => updateField(field.key, e.target.value)} placeholder={placeholder} className="w-full px-4 py-3 bg-background border border-border rounded-2xl text-sm focus:outline-none focus:border-primary/50 transition-colors" />
                    )}
                  </div>
                );
              })}

              <div className="flex items-center gap-4">
                <span className="text-sm font-medium min-w-24">{t('quantity')}</span>
                <div className="flex items-center gap-3 bg-background border border-border rounded-2xl p-1">
                  <button onClick={() => setQty(q => Math.max(minQty, q - 1))} className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-card transition-colors"><Minus size={14} /></button>
                  <input value={qty} onChange={e => setQty(Math.max(minQty, Math.min(maxQty, Number(e.target.value) || minQty)))} className="w-14 text-center bg-transparent font-bold outline-none" />
                  <button onClick={() => setQty(q => Math.min(maxQty, q + 1))} className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-card transition-colors"><Plus size={14} /></button>
                </div>
              </div>

              {(product.qtyMin || product.qtyMax) && (
                <p className="text-xs text-muted-foreground">الكمية المسموحة: {minQty}{product.qtyMax ? ` - ${maxQty}` : '+'}</p>
              )}

              {/* Promo Code */}
              <div className="rounded-2xl border border-border bg-background/50 p-3">
                <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5"><Tag size={11} />{lang === 'ar' ? 'كوبون الخصم' : 'Promo Code'}</p>
                {promoApplied ? (
                  <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-3 py-2">
                    <span className="text-emerald-400 font-mono font-bold text-sm">{promoApplied.code} <span className="font-normal">(-{formatPrice(promoDiscount)})</span></span>
                    <button onClick={() => setPromoApplied(null)} className="text-muted-foreground hover:text-foreground transition-colors"><X size={14} /></button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      value={promoCode}
                      onChange={e => setPromoCode(e.target.value.toUpperCase())}
                      onKeyDown={e => e.key === 'Enter' && applyPromo()}
                      placeholder={lang === 'ar' ? 'أدخل الكود...' : 'Enter code...'}
                      className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm font-mono focus:outline-none focus:border-primary/50"
                    />
                    <button onClick={applyPromo} disabled={!promoCode.trim() || promoLoading} className="px-3 py-2 bg-primary/20 border border-primary/40 text-primary rounded-xl text-xs font-semibold hover:bg-primary/30 disabled:opacity-50 transition-colors">
                      {promoLoading ? <Loader2 size={13} className="animate-spin" /> : (lang === 'ar' ? 'تطبيق' : 'Apply')}
                    </button>
                  </div>
                )}
              </div>

              {/* Gift to friend */}
              <div className="rounded-2xl border border-border bg-background/50 p-3">
                <button onClick={() => setShowGift(g => !g)} className="flex items-center gap-2 text-sm font-medium w-full">
                  <Gift size={14} className={showGift ? 'text-primary' : 'text-muted-foreground'} />
                  <span>{lang === 'ar' ? 'إرسال هدية لصديق' : 'Gift to a friend'}</span>
                  <span className="mr-auto text-xs text-muted-foreground">{showGift ? '▲' : '▼'}</span>
                </button>
                {showGift && (
                  <input
                    type="email"
                    value={giftEmail}
                    onChange={e => setGiftEmail(e.target.value)}
                    placeholder={lang === 'ar' ? 'البريد الإلكتروني للصديق' : "Friend's email"}
                    className="mt-2 w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                  />
                )}
              </div>

              {/* Wishlist + Price Alert + Buy button row */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => wishlistMutation.mutate()}
                  disabled={wishlistMutation.isPending}
                  title={isWishlisted ? (lang === 'ar' ? 'إزالة من المفضلة' : 'Remove from wishlist') : (lang === 'ar' ? 'أضف للمفضلة' : 'Add to wishlist')}
                  className="w-12 h-12 flex items-center justify-center rounded-2xl border transition-all"
                  style={isWishlisted ? { background: 'rgba(239,68,68,0.12)', borderColor: 'rgba(239,68,68,0.4)' } : { background: 'transparent', borderColor: 'rgba(255,255,255,0.12)' }}
                >
                  <Heart size={18} className={isWishlisted ? 'text-red-400 fill-current' : 'text-muted-foreground'} />
                </button>
                <button
                  onClick={() => setShowPriceAlert(true)}
                  title={lang === 'ar' ? 'تنبيه سعر' : 'Price alert'}
                  className="w-12 h-12 flex items-center justify-center rounded-2xl border border-blue-500/30 bg-blue-500/5 hover:bg-blue-500/15 transition-all"
                >
                  <Bell size={18} className="text-blue-400" />
                </button>
                <div className="flex-1">
                  <div className="text-xs text-muted-foreground mb-0.5">
                    {vip.discountPercent > 0 && <span className="line-through ml-2">{formatPrice(totalBeforeVip)}</span>}
                    {promoDiscount > 0 && <span className="line-through ml-2">{formatPrice(totalAfterVip)}</span>}
                    {lang === 'ar' ? 'الإجمالي' : 'Total'}
                  </div>
                  <div className="font-black text-xl text-primary">{formatPrice(total)}</div>
                </div>
                <button
                  onClick={handleAddToCart}
                  disabled={product.status !== 'active'}
                  title={lang === 'ar' ? 'إضافة للسلة' : 'Add to cart'}
                  className="flex items-center gap-2 px-4 py-3 border-2 border-primary/50 text-primary font-bold rounded-2xl hover:bg-primary/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ShoppingCart size={18} />
                  <span className="hidden sm:inline">{lang === 'ar' ? 'للسلة' : 'Add'}</span>
                </button>
                <button onClick={handleBuy} disabled={createOrder.isPending || product.status !== 'active'} className="flex items-center gap-2 px-6 py-3 bg-primary text-white font-bold rounded-2xl hover:bg-primary/90 transition-all shadow-xl shadow-primary/30 disabled:opacity-50 disabled:cursor-not-allowed">
                  {createOrder.isPending ? <Loader2 size={18} className="animate-spin" /> : <ShoppingBag size={18} />}
                  {t('buyNow')}
                </button>
              </div>
            </div>

            {/* Premium reassurance band — replaces the duplicate trust cards */}
            <div
              className="relative overflow-hidden rounded-2xl p-5 border"
              dir="rtl"
              style={{
                background:
                  'linear-gradient(135deg, rgba(168,85,247,0.10) 0%, rgba(34,211,238,0.08) 50%, rgba(16,185,129,0.10) 100%)',
                borderColor: 'rgba(168,85,247,0.25)',
              }}
            >
              <div
                className="pointer-events-none absolute -top-12 -left-12 w-40 h-40 rounded-full blur-3xl"
                style={{ background: 'rgba(168,85,247,0.25)' }}
              />
              <div
                className="pointer-events-none absolute -bottom-12 -right-12 w-40 h-40 rounded-full blur-3xl"
                style={{ background: 'rgba(34,211,238,0.20)' }}
              />
              <div className="relative grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { Icon: BadgeCheck, color: '#a855f7', title: 'منتجات موثقة', subtitle: '100% أصلية' },
                  { Icon: Headphones, color: '#22d3ee', title: 'دعم 24/7', subtitle: 'تواصل فوري' },
                  { Icon: Lock, color: '#10b981', title: 'دفع آمن', subtitle: 'معاملات مشفّرة' },
                  { Icon: Sparkles, color: '#f59e0b', title: 'أسعار حصرية', subtitle: 'عروض مستمرة' },
                ].map(({ Icon, color, title, subtitle }) => (
                  <div key={title} className="flex flex-col items-center text-center gap-2">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center"
                      style={{
                        background: `${color}1f`,
                        border: `1px solid ${color}55`,
                        boxShadow: `0 6px 20px -8px ${color}80`,
                      }}
                    >
                      <Icon style={{ color }} size={22} strokeWidth={2.2} />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm leading-tight">{title}</p>
                      <p className="text-[11px] text-gray-400 mt-1 leading-snug">{subtitle}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* ─── Price History Chart ─────────────────────────────────────── */}
        <PriceHistoryChart productId={id} formatPrice={formatPrice} lang={lang} />

        {/* ─── Reviews Section ─────────────────────────────────────────── */}
        <ReviewsSection productId={id} user={user} lang={lang} formatPrice={formatPrice} />

        {relatedProducts.length > 0 && (
          <section className="mt-12">
            <h2 className="font-heading text-2xl font-bold mb-4">منتجات مشابهة</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {relatedProducts.map((item: any) => (
                <Link key={item.id} href={`/products/${item.id}`} className="bg-card border border-border rounded-2xl p-4 hover:border-primary/40 transition-colors">
                  <div className="h-20 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                    {item.image ? <img src={item.image} alt={item.name} loading="lazy" className="h-12 object-contain" /> : <PackageCheck className="text-primary" />}
                  </div>
                  <p className="text-sm font-bold line-clamp-2">{lang === 'ar' && item.nameAr ? item.nameAr : item.name}</p>
                  <p className="text-primary text-sm font-black mt-2">{formatPrice(item.priceUsd)}</p>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Price Alert Modal */}
      <AnimatePresence>
        {showPriceAlert && product && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => !priceAlertMutation.isPending && setShowPriceAlert(false)}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
              onClick={e => e.stopPropagation()}
              className="bg-card border border-border rounded-3xl w-full max-w-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                  <Bell size={22} className="text-white" />
                </div>
                <div>
                  <h3 className="font-heading font-bold">{lang === 'ar' ? 'تنبيه عند انخفاض السعر' : 'Price drop alert'}</h3>
                  <p className="text-xs text-muted-foreground">{lang === 'ar' ? 'سنخبرك فور وصول السعر للهدف' : "We'll notify you instantly"}</p>
                </div>
              </div>
              <div className="bg-background/50 rounded-2xl p-4 mb-4 text-center">
                <p className="text-xs text-muted-foreground">{lang === 'ar' ? 'السعر الحالي' : 'Current price'}</p>
                <p className="text-2xl font-black text-primary">${parseFloat(product.priceUsd).toFixed(2)}</p>
              </div>
              <label className="text-xs font-bold text-muted-foreground mb-2 block">
                {lang === 'ar' ? 'نبهني عندما يصل السعر إلى:' : 'Notify me when price reaches:'}
              </label>
              <div className="relative">
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <input type="number" step="0.01" value={priceAlertTarget}
                  onChange={e => setPriceAlertTarget(e.target.value)}
                  placeholder={(parseFloat(product.priceUsd) * 0.8).toFixed(2)}
                  className="w-full px-3 py-2.5 pr-7 bg-background border border-border rounded-xl text-base font-bold focus:outline-none focus:border-blue-500/50" />
              </div>
              <div className="flex gap-2 mt-4">
                {[10, 20, 30].map(pct => (
                  <button key={pct} onClick={() => setPriceAlertTarget((parseFloat(product.priceUsd) * (1 - pct / 100)).toFixed(2))}
                    className="flex-1 py-1.5 rounded-lg bg-blue-500/10 text-blue-400 text-xs font-bold hover:bg-blue-500/20">
                    -{pct}%
                  </button>
                ))}
              </div>
              <div className="flex gap-2 mt-4">
                <button disabled={priceAlertMutation.isPending} onClick={() => setShowPriceAlert(false)}
                  className="flex-1 py-2.5 rounded-xl bg-muted text-muted-foreground font-semibold text-sm">
                  {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button disabled={priceAlertMutation.isPending || !priceAlertTarget} onClick={() => priceAlertMutation.mutate()}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold text-sm disabled:opacity-50">
                  {priceAlertMutation.isPending ? <Loader2 size={14} className="inline animate-spin" /> : (lang === 'ar' ? '🔔 فعّل التنبيه' : '🔔 Set alert')}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </PublicLayout>
  );
}