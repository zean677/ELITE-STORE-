import React, { useState } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { useGetWallet, useGetWalletHistory } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useLanguage } from '@/i18n';
import { useCurrency } from '@/hooks/use-currency';
import { Wallet, ArrowDownLeft, ArrowUpRight, RefreshCw, PlusCircle, ShoppingBag, TrendingDown, TrendingUp, Crown, Mail, User as UserIcon, Copy, Check } from 'lucide-react';
import { VipBadge, VipProgressCard, getVipFromData } from '@/components/VipBadge';
import { useSettings } from '@/hooks/use-settings';
import { useAuth } from '@/hooks/use-auth';

const typeConfig: Record<string, { icon: any; color: string; sign: string }> = {
  deposit: { icon: ArrowDownLeft, color: 'text-green-400', sign: '+' },
  purchase: { icon: ArrowUpRight, color: 'text-red-400', sign: '-' },
  refund: { icon: RefreshCw, color: 'text-blue-400', sign: '+' },
};

const tabOptionsAr = ['الكل', 'المشتريات', 'المستردة'];
const tabOptionsEn = ['All', 'Purchases', 'Refunds'];

export default function WalletPage() {
  const { lang, dir } = useLanguage();
  const tabOptions = lang === 'ar' ? tabOptionsAr : tabOptionsEn;
  const { formatPrice, currency } = useCurrency();
  const { sypRate, eurRate } = useSettings();
  const { data: wallet } = useGetWallet();
  const { data: history } = useGetWalletHistory({ page: 1, limit: 100 });
  const { user } = useAuth();
  const [tab, setTab] = useState(0);
  const [copied, setCopied] = useState(false);

  const publicCode = (user as any)?.publicCode || (user ? `EL-${String(user.id).padStart(6, '0')}` : '');
  const copyId = async () => {
    if (!publicCode) return;
    try {
      await navigator.clipboard.writeText(publicCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {}
  };
  const [fromDate, setFromDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().slice(0, 10);
  });
  const [toDate, setToDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  });

  const transactions = history?.transactions ?? [];

  const totalPurchases = transactions
    .filter(tx => tx.type === 'purchase')
    .reduce((s, tx) => s + Math.abs(parseFloat(tx.amount?.toString() ?? '0')), 0);

  const totalDeposits = transactions
    .filter(tx => tx.type === 'deposit')
    .reduce((s, tx) => s + parseFloat(tx.amount?.toString() ?? '0'), 0);

  const currentBalance = parseFloat(wallet?.balance?.toString() ?? '0');
  const debitBalance = 0;
  const vip = getVipFromData(wallet);

  const stats = [
    {
      label: lang === 'ar' ? 'اجمالي مشتريات' : 'Total Purchases',
      value: formatPrice(totalPurchases),
      bg: '#ef4444',
      icon: ShoppingBag,
    },
    {
      label: lang === 'ar' ? 'رصيدك الحالي' : 'Current Balance',
      value: formatPrice(currentBalance),
      bg: '#22c55e',
      icon: Wallet,
    },
    {
      label: lang === 'ar' ? 'مستوى VIP' : 'VIP Level',
      value: vip.level > 0 ? `VIP ${vip.level}` : 'VIP 0',
      bg: '#3b82f6',
      icon: Crown,
    },
    {
      label: lang === 'ar' ? 'الوارد' : 'Total Incoming',
      value: formatPrice(totalDeposits),
      bg: '#a855f7',
      icon: TrendingUp,
    },
  ];

  const filteredTx = transactions.filter(tx => {
    if (tab === 1 && tx.type !== 'purchase') return false;
    if (tab === 2 && tx.type !== 'refund') return false;
    if (fromDate) {
      const txDate = new Date(tx.createdAt).toISOString().slice(0, 10);
      if (txDate < fromDate) return false;
    }
    if (toDate) {
      const txDate = new Date(tx.createdAt).toISOString().slice(0, 10);
      if (txDate > toDate) return false;
    }
    return true;
  });

  const totalFiltered = filteredTx.reduce((s, tx) => {
    const cfg = typeConfig[tx.type];
    if (!cfg) return s;
    const amt = parseFloat(tx.amount?.toString() ?? '0');
    return s + (tx.type === 'purchase' ? -Math.abs(amt) : Math.abs(amt));
  }, 0);

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-5 max-w-2xl mx-auto w-full min-w-0 overflow-x-hidden px-1" dir={dir}>
          <div className="flex items-center justify-between gap-3">
            <h1 className="font-heading text-2xl font-bold">{lang === 'ar' ? 'المحفظة' : 'Wallet'}</h1>
            <div className="flex items-center gap-2">
              <VipBadge source={wallet} compact />
              <Link href="/deposit" className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-semibold rounded-xl hover:bg-primary/90 transition-colors shadow-lg shadow-primary/30">
                <PlusCircle size={16} />
                {lang === 'ar' ? 'شحن رصيد' : 'Top Up'}
              </Link>
            </div>
          </div>

          {/* Profile Info Card */}
          {user && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-lg"
                  style={{ background: 'linear-gradient(135deg, #818cf8, #38bdf8, #5eead4)' }}>
                  <span className="text-white text-2xl font-black">{user.username[0]?.toUpperCase()}</span>
                </div>
                {/* Info */}
                <div className="flex-1 min-w-0 flex flex-col items-end gap-1.5 text-right">
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold truncate">{user.username}</h2>
                    <VipBadge source={wallet} compact />
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="truncate">{user.email}</span>
                    <Mail size={13} className="shrink-0" />
                  </div>
                  <button onClick={copyId} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors">
                    <UserIcon size={13} />
                    <span className="font-mono">ID: {publicCode}</span>
                    {copied ? <Check size={13} className="text-green-400" /> : <Copy size={13} />}
                  </button>
                </div>
              </div>
            </div>
          )}

          <VipProgressCard source={wallet} sypRate={sypRate} eurRate={eurRate} />

          {/* Stat Cards */}
          <div className="grid grid-cols-2 gap-3">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.07 }}
                  className="rounded-2xl p-4 flex flex-col gap-2"
                  style={{ background: stat.bg }}
                >
                  <div className="flex items-center gap-2">
                    <Icon size={16} className="text-white/80" />
                    <span className="text-white/80 text-xs font-medium">{stat.label}</span>
                  </div>
                  <p className="text-white font-black text-xl leading-none">{stat.value}</p>
                </motion.div>
              );
            })}
          </div>

          {/* Date Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 bg-card border border-border rounded-2xl p-3 sm:p-4 w-full">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <span className="text-xs text-muted-foreground shrink-0">{lang === 'ar' ? 'من' : 'From'}</span>
              <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
                className="flex-1 min-w-0 w-full bg-background border border-border rounded-xl px-2 py-1.5 text-xs focus:outline-none focus:border-primary/50" />
            </div>
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <span className="text-xs text-muted-foreground shrink-0">{lang === 'ar' ? 'إلى' : 'To'}</span>
              <input type="date" value={toDate} onChange={e => setToDate(e.target.value)}
                className="flex-1 min-w-0 w-full bg-background border border-border rounded-xl px-2 py-1.5 text-xs focus:outline-none focus:border-primary/50" />
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2">
            {tabOptions.map((tab_label, i) => (
              <button
                key={i}
                onClick={() => setTab(i)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold transition-all border ${tab === i ? 'bg-primary/15 border-primary/40 text-primary' : 'bg-card border-border text-muted-foreground'}`}
              >
                <span className={`w-5 h-5 rounded-full text-xs flex items-center justify-center font-bold ${tab === i ? 'bg-primary text-white' : 'bg-border text-muted-foreground'}`}>
                  {i === 0 ? filteredTx.length : transactions.filter(tx => i === 1 ? tx.type === 'purchase' : tx.type === 'refund').length}
                </span>
                {tab_label}
              </button>
            ))}
          </div>

          {/* Total */}
          <div className="flex justify-end">
            <div className="px-4 py-2 bg-card border border-border rounded-xl text-sm font-bold">
              {lang === 'ar' ? 'اجمالي' : 'Total'}: {formatPrice(Math.abs(totalFiltered))}
            </div>
          </div>

          {/* Transaction List */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {filteredTx.length === 0 ? (
              <div className="py-12 text-center">
                <Wallet size={32} className="mx-auto text-muted-foreground/30 mb-3" />
                <p className="text-muted-foreground text-sm">{lang === 'ar' ? 'لا توجد عمليات خلال هذه الفترة.' : 'No transactions found.'}</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filteredTx.map(tx => {
                  const cfg = typeConfig[tx.type] ?? { icon: RefreshCw, color: 'text-muted-foreground', sign: '' };
                  const Icon = cfg.icon;
                  return (
                    <motion.div key={tx.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="flex items-center justify-between p-4 hover:bg-background transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-card border border-border flex items-center justify-center">
                          <Icon size={16} className={cfg.color} />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{tx.description}</p>
                          <p className="text-xs text-muted-foreground">{new Date(tx.createdAt).toLocaleString('en-GB', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' })}</p>
                        </div>
                      </div>
                      <span className={`text-sm font-bold ${cfg.color}`}>
                        {cfg.sign}{formatPrice(Math.abs(parseFloat(tx.amount?.toString() ?? '0')))}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
