import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { useGetWallet, useGetOrders, useGetNotifications } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import { useAuth } from '@/hooks/use-auth';
import { useLanguage } from '@/i18n';
import { useCurrency } from '@/hooks/use-currency';
import { useToast } from '@/hooks/use-toast';
import { Wallet, Package, Bell, ShoppingBag, ChevronRight, TrendingUp, ChevronLeft, Sparkles, Gift, Loader2 } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

type LoyaltyData = {
  points: number;
  redeemableUsd: number;
  pointsPerUsdEarned: number;
  pointsPerUsdRedeemed: number;
  minRedeem: number;
};

function LoyaltyCard({ lang }: { lang: string }) {
  const { toast } = useToast();
  const [data, setData] = useState<LoyaltyData | null>(null);
  const [loading, setLoading] = useState(true);
  const [redeeming, setRedeeming] = useState(false);
  const [pointsToRedeem, setPointsToRedeem] = useState(0);

  const load = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/loyalty`, { headers: authHeaders() });
      if (r.ok) {
        const d = await r.json();
        setData(d);
        setPointsToRedeem(Math.min(d.points, d.minRedeem));
      }
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleRedeem = async () => {
    if (!data || pointsToRedeem < data.minRedeem) return;
    setRedeeming(true);
    try {
      const r = await fetch(`${BASE}/api/loyalty/redeem`, {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ points: pointsToRedeem }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || 'فشل الاستبدال');
      toast({ title: '✅ تم الاستبدال', description: `أضيف $${j.usdAdded.toFixed(2)} لرصيدك` });
      load();
    } catch (e: any) {
      toast({ title: 'خطأ', description: e?.message ?? '', variant: 'destructive' });
    } finally { setRedeeming(false); }
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-amber-500/10 to-orange-600/5 border border-amber-500/30 rounded-2xl p-5">
        <Loader2 size={18} className="animate-spin text-amber-400" />
      </div>
    );
  }

  if (!data) return null;
  const canRedeem = data.points >= data.minRedeem;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden bg-gradient-to-br from-amber-500/15 via-orange-500/10 to-yellow-600/5 border border-amber-500/30 rounded-2xl p-5">
      <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-amber-500/20 blur-3xl pointer-events-none" />

      <div className="flex items-center justify-between gap-3 mb-4 relative">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
            <Sparkles size={22} className="text-white" />
          </div>
          <div>
            <p className="text-amber-400 text-xs font-bold uppercase tracking-wide">
              {lang === 'ar' ? 'نقاط الولاء' : 'Loyalty Points'}
            </p>
            <p className="text-2xl font-black text-white">
              {data.points.toLocaleString()} <span className="text-sm text-amber-400/70">{lang === 'ar' ? 'نقطة' : 'pts'}</span>
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[10px] text-muted-foreground">{lang === 'ar' ? 'قيمة قابلة للاستبدال' : 'Redeemable'}</p>
          <p className="text-lg font-bold text-emerald-400">${data.redeemableUsd.toFixed(2)}</p>
        </div>
      </div>

      <div className="text-[11px] text-muted-foreground/90 mb-3 leading-relaxed">
        {lang === 'ar'
          ? `🎁 اربح ${data.pointsPerUsdEarned} نقطة لكل $1 إنفاق · ${data.pointsPerUsdRedeemed} نقطة = $1 رصيد`
          : `🎁 Earn ${data.pointsPerUsdEarned} pt per $1 spent · ${data.pointsPerUsdRedeemed} pts = $1`}
      </div>

      {canRedeem ? (
        <div className="flex items-center gap-2 relative">
          <input type="range"
            min={data.minRedeem}
            max={data.points - (data.points % data.minRedeem)}
            step={data.minRedeem}
            value={pointsToRedeem}
            onChange={e => setPointsToRedeem(Number(e.target.value))}
            className="flex-1 accent-amber-500" />
          <button onClick={handleRedeem} disabled={redeeming}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white text-xs font-bold hover:opacity-90 disabled:opacity-50 whitespace-nowrap shadow-lg shadow-amber-500/30">
            {redeeming ? <Loader2 size={12} className="animate-spin" /> : <Gift size={12} />}
            {lang === 'ar' ? `استبدال ${pointsToRedeem}` : `Redeem ${pointsToRedeem}`}
            <span className="text-amber-100/90">→ ${(pointsToRedeem / data.pointsPerUsdRedeemed).toFixed(2)}</span>
          </button>
        </div>
      ) : (
        <p className="text-[11px] text-muted-foreground text-center py-1">
          {lang === 'ar'
            ? `اجمع ${data.minRedeem - data.points} نقطة إضافية لتبدأ الاستبدال`
            : `Earn ${data.minRedeem - data.points} more points to start redeeming`}
        </p>
      )}

      <a href={`${BASE}/rewards`}
        className="mt-3 flex items-center justify-center gap-2 w-full py-2 rounded-xl bg-white/5 border border-amber-500/30 text-amber-300 text-xs font-bold hover:bg-amber-500/10 transition-colors">
        🎁 {lang === 'ar' ? 'تصفّح متجر المكافآت' : 'Browse Rewards Store'}
      </a>
    </motion.div>
  );
}

const fadeUp = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0, transition: { duration: 0.35 } } };

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string; color: string }) {
  return (
    <motion.div variants={fadeUp} className={`bg-card border border-border rounded-2xl p-5 relative overflow-hidden group hover:border-${color}/40 transition-all`}>
      <div className={`absolute inset-0 bg-gradient-to-br from-${color}/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity`} />
      <div className={`w-10 h-10 rounded-xl bg-${color}/15 border border-${color}/20 flex items-center justify-center mb-3`}>
        <Icon size={18} className={`text-${color}`} />
      </div>
      <p className="text-muted-foreground text-xs font-medium">{label}</p>
      <p className="text-2xl font-black mt-1 truncate">{value}</p>
    </motion.div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { lang, dir } = useLanguage();
  const { formatPrice } = useCurrency();
  const [, navigate] = useLocation();
  const { data: wallet } = useGetWallet();
  const { data: ordersData } = useGetOrders({ limit: 5, page: 1 });
  const { data: notifications } = useGetNotifications();

  const recentOrders = ordersData?.orders ?? [];
  const unreadNotifications = (notifications ?? []).filter(n => !n.isRead).length;
  const balance = parseFloat(wallet?.balance?.toString() ?? user?.balance?.toString() ?? '0');
  const ChevronNav = dir === 'rtl' ? ChevronLeft : ChevronRight;

  const t = {
    greeting:   lang === 'ar' ? `أهلاً, ${user?.username}` : `Hello, ${user?.username}`,
    subtitle:   lang === 'ar' ? 'مرحباً بك في لوحة التحكم' : 'Welcome back to your dashboard',
    balance:    lang === 'ar' ? 'رصيدي' : 'Balance',
    orders:     lang === 'ar' ? 'إجمالي الطلبات' : 'Total Orders',
    notifs:     lang === 'ar' ? 'الإشعارات' : 'Notifications',
    completed:  lang === 'ar' ? 'المكتملة' : 'Completed',
    recOrders:  lang === 'ar' ? 'آخر الطلبات' : 'Recent Orders',
    viewAll:    lang === 'ar' ? 'عرض الكل' : 'View All',
    noOrders:   lang === 'ar' ? 'لا يوجد طلبات بعد' : 'No orders yet',
    browse:     lang === 'ar' ? 'تصفح المنتجات' : 'Browse Products',
    actions:    lang === 'ar' ? 'إجراءات سريعة' : 'Quick Actions',
    buy:        lang === 'ar' ? 'شراء منتجات' : 'Buy Products',
    buyDesc:    lang === 'ar' ? 'تصفح المتجر' : 'Browse the store',
    deposit:    lang === 'ar' ? 'شحن رصيد' : 'Deposit Funds',
    depositDesc: lang === 'ar' ? 'اشحن محفظتك' : 'Top up your wallet',
    myOrders:   lang === 'ar' ? 'طلباتي' : 'My Orders',
    myOrdersDesc: lang === 'ar' ? 'عرض سجل الطلبات' : 'View order history',
  };

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-8" dir={dir}>
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="font-heading text-2xl font-bold">{t.greeting}</h1>
            <p className="text-muted-foreground text-sm mt-1">{t.subtitle}</p>
          </motion.div>

          <motion.div initial="initial" animate="animate" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={Wallet}    label={t.balance}   value={formatPrice(balance)}                                         color="primary" />
            <StatCard icon={Package}   label={t.orders}    value={String(ordersData?.total ?? 0)}                               color="secondary" />
            <StatCard icon={Bell}      label={t.notifs}    value={String(unreadNotifications)}                                  color="accent" />
            <StatCard icon={TrendingUp} label={t.completed} value={String(recentOrders.filter(o => o.status === 'completed').length)} color="success" />
          </motion.div>

          <LoyaltyCard lang={lang} />

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Recent Orders */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-bold">{t.recOrders}</h2>
                <Link href="/orders" className="text-primary text-sm flex items-center gap-1 hover:underline">
                  {t.viewAll} <ChevronNav size={14} />
                </Link>
              </div>
              <div className="bg-card border border-border rounded-2xl overflow-hidden">
                {recentOrders.length === 0 ? (
                  <div className="py-12 text-center">
                    <Package size={32} className="mx-auto text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground text-sm">{t.noOrders}</p>
                    <Link
                      href="/"
                      className="inline-block mt-4 px-4 py-2 bg-primary/15 text-primary text-sm font-medium rounded-xl hover:bg-primary/25 transition-colors"
                    >
                      {t.browse}
                    </Link>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {recentOrders.map(order => (
                      <div
                        key={order.id}
                        className="flex items-center justify-between p-4 hover:bg-background transition-colors cursor-pointer"
                        onClick={() => navigate(`/orders/${order.id}`)}
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">{order.productName}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            x{order.qty} · {new Date(order.createdAt).toLocaleDateString(lang === 'ar' ? 'ar-SY' : 'en-GB')}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-sm font-bold text-primary">
                            {formatPrice(parseFloat(order.totalPrice?.toString() ?? '0'))}
                          </span>
                          <StatusBadge status={order.status} size="sm" />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div>
              <h2 className="font-heading font-bold mb-4">{t.actions}</h2>
              <div className="space-y-3">
                {[
                  { href: '/',        color: 'primary',   icon: ShoppingBag, label: t.buy,     desc: t.buyDesc },
                  { href: '/deposit', color: 'secondary', icon: Wallet,      label: t.deposit, desc: t.depositDesc },
                  { href: '/orders',  color: 'accent',    icon: Package,     label: t.myOrders,desc: t.myOrdersDesc },
                ].map(item => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3 w-full bg-card border border-border rounded-xl p-4 hover:border-${item.color}/40 hover:bg-background transition-all group`}
                  >
                    <div className={`w-9 h-9 rounded-lg bg-${item.color}/15 flex items-center justify-center group-hover:bg-${item.color}/25 transition-colors shrink-0`}>
                      <item.icon size={16} className={`text-${item.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold">{item.label}</p>
                      <p className="text-xs text-muted-foreground">{item.desc}</p>
                    </div>
                    <ChevronNav size={14} className="text-muted-foreground shrink-0" />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
