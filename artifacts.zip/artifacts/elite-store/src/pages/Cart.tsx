import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { PublicLayout } from '@/components/Layout';
import { useCart, type CartItem } from '@/hooks/use-cart';
import { useCurrency } from '@/hooks/use-currency';
import { useLanguage } from '@/i18n';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useCreateOrder, useGetWallet, getGetMeQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { getProductImage, getBrandInfo } from '@/lib/product-images';
import { VipBadge, getVipFromData } from '@/components/VipBadge';
import { ShoppingBag, Trash2, Plus, Minus, ArrowLeft, Loader2, CheckCircle, AlertCircle, Sparkles, Crown } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

interface OrderResult {
  cartId: string;
  status: 'pending' | 'success' | 'failed';
  orderId?: string;
  error?: string;
}

export default function Cart() {
  const { items, count, totalUsd, removeItem, updateQty, clear } = useCart();
  const { formatPrice, currency } = useCurrency();
  const { lang } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const createOrder = useCreateOrder();
  const { data: wallet } = useGetWallet({ query: { enabled: !!user } as any });
  const vip = getVipFromData(wallet ?? user);
  const vipDiscount = totalUsd * (vip.discountPercent / 100);
  const totalAfterVip = Math.max(0, totalUsd - vipDiscount);
  const [checkoutResults, setCheckoutResults] = useState<OrderResult[] | null>(null);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const composePlayerId = (item: CartItem) => {
    const main = item.playerId || item.formValues?.playerId || item.formValues?.email || '';
    const extras = Object.entries(item.formValues || {})
      .filter(([key, value]) => value?.trim() && key !== 'playerId' && key !== 'email')
      .map(([key, value]) => `${key}:${value.trim()}`);
    return [main.trim(), ...extras].filter(Boolean).join(' | ');
  };

  const handleCheckout = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (items.length === 0) return;

    setIsCheckingOut(true);
    const results: OrderResult[] = items.map(i => ({ cartId: i.cartId, status: 'pending' }));
    setCheckoutResults([...results]);

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      try {
        const order: any = await createOrder.mutateAsync({
          data: {
            productId: item.productId,
            qty: item.qty,
            playerId: composePlayerId(item) || undefined,
            currency: currency as any,
            ...(item.promoCodeId ? { promoCodeId: item.promoCodeId } : {}),
            ...(item.giftEmail ? { giftToEmail: item.giftEmail } : {}),
          } as any,
        });
        results[i] = { cartId: item.cartId, status: 'success', orderId: order.id };
      } catch (err: any) {
        const msg = err?.data?.message ?? err?.response?.data?.message ?? err?.message ?? 'فشل الطلب';
        results[i] = { cartId: item.cartId, status: 'failed', error: msg };
      }
      setCheckoutResults([...results]);
    }

    const successful = results.filter(r => r.status === 'success');
    const failed = results.filter(r => r.status === 'failed');

    if (successful.length > 0) {
      // Remove successful items from cart
      successful.forEach(r => removeItem(r.cartId));
      // Refresh user VIP data so progress bar updates immediately
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    }

    if (failed.length === 0) {
      toast({ title: '✅ تمّ الطلب بنجاح', description: `تم تنفيذ ${successful.length} طلب${successful.length > 1 ? 'ات' : ''}` });
    } else if (successful.length === 0) {
      toast({ title: '❌ فشل الدفع', description: failed[0].error || 'تعذّر إنشاء الطلبات', variant: 'destructive' });
    } else {
      toast({ title: '⚠️ نجاح جزئي', description: `${successful.length} نجح / ${failed.length} فشل`, variant: 'destructive' });
    }

    setIsCheckingOut(false);
  };

  if (items.length === 0 && !checkoutResults) {
    return (
      <PublicLayout>
        <div className="max-w-3xl mx-auto px-4 py-16 text-center">
          <div className="w-24 h-24 rounded-3xl mx-auto mb-6 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(108,92,231,0.15), rgba(0,206,201,0.1))', border: '1px solid rgba(108,92,231,0.3)' }}>
            <ShoppingBag size={48} className="text-primary" />
          </div>
          <h1 className="text-2xl font-black mb-2">{lang === 'ar' ? 'السلة فارغة' : 'Your cart is empty'}</h1>
          <p className="text-muted-foreground mb-6">{lang === 'ar' ? 'لم تُضف أي منتج بعد. تصفّح المنتجات وأضف ما يعجبك!' : 'No items yet. Browse products and add what you like!'}</p>
          <Link href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-white font-bold rounded-2xl hover:bg-primary/90 transition-all shadow-xl shadow-primary/30">
            <ArrowLeft size={18} />
            {lang === 'ar' ? 'تصفّح المنتجات' : 'Browse Products'}
          </Link>
        </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 sm:py-8 min-w-0 overflow-x-hidden" dir="rtl">
        <div className="flex items-start justify-between gap-2 mb-4 sm:mb-6 min-w-0">
          <div className="min-w-0 flex-1">
            <h1 className="text-lg sm:text-3xl font-black flex items-center gap-2 sm:gap-3 truncate">
              <ShoppingBag className="text-primary shrink-0" size={22} />
              <span className="truncate">{lang === 'ar' ? 'سلة المشتريات' : 'Shopping Cart'}</span>
              <span className="text-[11px] sm:text-sm font-normal text-muted-foreground shrink-0">({count})</span>
            </h1>
            <p className="text-[11px] sm:text-sm text-muted-foreground mt-1 hidden sm:block">{lang === 'ar' ? 'راجع طلباتك قبل إتمام الدفع' : 'Review your items before checkout'}</p>
          </div>
          {items.length > 0 && (
            <button onClick={() => { if (confirm(lang === 'ar' ? 'تفريغ السلة بالكامل؟' : 'Clear cart?')) clear(); }}
              className="shrink-0 text-[11px] sm:text-xs text-red-400 hover:text-red-300 px-2.5 sm:px-3 py-1.5 rounded-lg border border-red-500/20 hover:bg-red-500/10 transition-colors">
              🗑️ {lang === 'ar' ? 'تفريغ' : 'Clear'}
            </button>
          )}
        </div>

        <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Items list */}
          <div className="lg:col-span-2 space-y-3">
            <AnimatePresence mode="popLayout">
              {items.map(item => {
                const result = checkoutResults?.find(r => r.cartId === item.cartId);
                const brand = getBrandInfo(item.description ?? '', item.name, item.category ?? '', BASE);
                const img = getProductImage(item.description ?? '', item.name, item.category ?? '', item.image, BASE);
                const displayName = lang === 'ar' && item.nameAr ? item.nameAr : item.name;
                const lineTotal = parseFloat(item.priceUsd || '0') * item.qty;

                return (
                  <motion.div
                    key={item.cartId}
                    layout
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20, scale: 0.95 }}
                    className="bg-card border border-border rounded-2xl p-3 sm:p-4 min-w-0"
                    style={result?.status === 'success' ? { borderColor: 'rgba(34,197,94,0.4)', background: 'rgba(34,197,94,0.05)' } : result?.status === 'failed' ? { borderColor: 'rgba(239,68,68,0.4)', background: 'rgba(239,68,68,0.05)' } : undefined}
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      {/* Image */}
                      <div className="w-14 h-14 sm:w-20 sm:h-20 rounded-xl flex-shrink-0 flex items-center justify-center overflow-hidden"
                        style={{ background: `linear-gradient(135deg, ${brand.color}30, ${brand.color}10)` }}>
                        {img ? (
                          <img src={img} alt={displayName} loading="lazy" className="h-12 sm:h-16 w-auto object-contain" />
                        ) : (
                          <span className="text-white font-black text-lg sm:text-xl" style={{ color: brand.color }}>{brand.label.slice(0, 2)}</span>
                        )}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-sm line-clamp-2">{displayName}</h3>
                        {item.description && <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">🎮 {item.description}</p>}
                        {item.playerId && <p className="text-[11px] text-primary mt-0.5 truncate">ID: {item.playerId}</p>}
                        {item.promoCode && <p className="text-[11px] text-emerald-400 mt-0.5">🎁 {item.promoCode}</p>}

                        {/* Result indicator */}
                        {result?.status === 'success' && (
                          <div className="flex items-center gap-1 text-[11px] text-emerald-400 mt-1 font-bold">
                            <CheckCircle size={12} /> تم — #{result.orderId?.slice(0,8)}
                          </div>
                        )}
                        {result?.status === 'failed' && (
                          <div className="flex items-start gap-1 text-[11px] text-red-400 mt-1 font-bold">
                            <AlertCircle size={12} className="shrink-0 mt-0.5" /> <span className="line-clamp-2">{result.error}</span>
                          </div>
                        )}
                        {result?.status === 'pending' && (
                          <div className="flex items-center gap-1 text-[11px] text-amber-400 mt-1 font-bold">
                            <Loader2 size={12} className="animate-spin" /> جاري التنفيذ...
                          </div>
                        )}
                      </div>

                      {/* Remove (top-corner on mobile) */}
                      {!result && (
                        <button onClick={() => removeItem(item.cartId)} className="shrink-0 w-8 h-8 flex items-center justify-center rounded-lg text-red-400 hover:bg-red-500/10 transition-colors" title="حذف">
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>

                    {/* Qty + Price row (full width on mobile) */}
                    {!result && (
                      <div className="flex items-center justify-between gap-2 mt-3 pt-3 border-t border-border/50">
                        <div className="flex items-center gap-1 bg-background border border-border rounded-xl p-1">
                          <button onClick={() => updateQty(item.cartId, item.qty - 1)} disabled={item.qty <= 1} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-card disabled:opacity-30 transition-colors active:scale-95">
                            <Minus size={14} />
                          </button>
                          <span className="w-10 text-center font-bold text-sm">{item.qty}</span>
                          <button onClick={() => updateQty(item.cartId, item.qty + 1)} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-card transition-colors active:scale-95">
                            <Plus size={14} />
                          </button>
                        </div>
                        <div className="text-left">
                          <p className="font-black text-primary text-base sm:text-lg whitespace-nowrap">{formatPrice(lineTotal)}</p>
                          {item.qty > 1 && <p className="text-[10px] text-muted-foreground whitespace-nowrap">{formatPrice(parseFloat(item.priceUsd || '0'))} × {item.qty}</p>}
                        </div>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {checkoutResults && items.length === 0 && (
              <div className="bg-card border border-border rounded-2xl p-8 text-center">
                <CheckCircle className="text-emerald-400 mx-auto mb-3" size={48} />
                <h3 className="font-black text-lg mb-2">{lang === 'ar' ? 'تمّت معالجة جميع الطلبات!' : 'All orders processed!'}</h3>
                <Link href="/orders" className="inline-flex items-center gap-2 mt-4 px-6 py-3 bg-primary text-white font-bold rounded-2xl hover:bg-primary/90 transition-all">
                  <ShoppingBag size={18} /> {lang === 'ar' ? 'عرض طلباتي' : 'View my orders'}
                </Link>
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-card border border-border rounded-2xl p-5 sticky top-4">
              <h2 className="font-heading text-lg font-black flex items-center gap-2 mb-4">
                <Sparkles size={18} className="text-primary" />
                {lang === 'ar' ? 'ملخّص الطلب' : 'Order Summary'}
              </h2>

              <div className="space-y-2 mb-4 pb-4 border-b border-border">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{lang === 'ar' ? 'عدد العناصر' : 'Items'}</span>
                  <span className="font-bold text-foreground">{count}</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{lang === 'ar' ? 'المجموع الفرعي' : 'Subtotal'}</span>
                  <span className="font-bold text-foreground">{formatPrice(totalUsd)}</span>
                </div>
                {user && vip.discountPercent > 0 && (
                  <div className="flex justify-between items-center text-sm pt-1">
                    <span className="flex items-center gap-1.5 text-yellow-400 font-semibold">
                      <Crown size={13} className="fill-current" />
                      {lang === 'ar' ? `خصم VIP ${vip.level} (-${vip.discountPercent}%)` : `VIP ${vip.level} discount (-${vip.discountPercent}%)`}
                    </span>
                    <span className="font-bold text-success">−{formatPrice(vipDiscount)}</span>
                  </div>
                )}
              </div>

              {user && vip.discountPercent > 0 && (
                <div
                  className="mb-3 rounded-2xl p-3 flex items-center justify-between"
                  style={{ background: 'linear-gradient(135deg, rgba(250,204,21,0.12), rgba(250,204,21,0.04))', border: '1px solid rgba(250,204,21,0.30)' }}
                >
                  <VipBadge source={wallet ?? user} compact />
                  <div className="text-left">
                    <p className="text-[10px] text-yellow-300/80 font-semibold leading-tight">
                      {lang === 'ar' ? 'سعرك الخاص' : 'Your VIP price'}
                    </p>
                    <p className="text-sm font-black text-yellow-300 leading-tight mt-0.5">
                      {formatPrice(totalAfterVip)}
                    </p>
                  </div>
                </div>
              )}

              <div className="flex justify-between items-end mb-4">
                <span className="text-sm text-muted-foreground">{lang === 'ar' ? 'الإجمالي' : 'Total'}</span>
                <div className="text-left">
                  {user && vip.discountPercent > 0 && (
                    <p className="text-xs text-muted-foreground line-through leading-none">{formatPrice(totalUsd)}</p>
                  )}
                  <span className="font-black text-2xl text-primary">{formatPrice(totalAfterVip)}</span>
                </div>
              </div>

              <button onClick={handleCheckout} disabled={isCheckingOut || items.length === 0}
                className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-primary text-white font-black rounded-2xl hover:bg-primary/90 transition-all shadow-xl shadow-primary/30 disabled:opacity-50 disabled:cursor-not-allowed">
                {isCheckingOut ? (
                  <><Loader2 size={18} className="animate-spin" /> {lang === 'ar' ? 'جاري التنفيذ...' : 'Processing...'}</>
                ) : (
                  <><ShoppingBag size={18} /> {lang === 'ar' ? `اشتر الآن (${count})` : `Checkout (${count})`}</>
                )}
              </button>

              <p className="text-[11px] text-muted-foreground text-center mt-3 leading-relaxed">
                {lang === 'ar'
                  ? 'سيتم خصم المبلغ من رصيد محفظتك. تأكّد من توفر الرصيد قبل الدفع.'
                  : 'Amount will be deducted from your wallet balance. Make sure you have sufficient funds.'}
              </p>

              <Link href="/" className="flex items-center justify-center gap-2 mt-3 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <ArrowLeft size={12} />
                {lang === 'ar' ? 'متابعة التسوّق' : 'Continue shopping'}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
