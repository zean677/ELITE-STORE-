import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useAuth } from '@/hooks/use-auth';
import { useCurrency } from '@/hooks/use-currency';
import { useLanguage } from '@/i18n';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Trophy, ShoppingBag, Wallet, Star, Calendar, TrendingUp, Gift, Crown, Zap, Heart, Award } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authFetch(path: string) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} }).then(r => r.json());
}

const VIP_LABELS = ['عادي', 'برونزي', 'فضي', 'ذهبي', 'ماسي', 'VIP+'];
const VIP_COLORS = ['#9ca3af', '#cd7f32', '#c0c0c0', '#ffd700', '#b9f2ff', '#a855f7'];
const CAT_LABELS: Record<string, string> = {
  games: 'ألعاب', topup: 'شحن', gift_card: 'بطاقات', subscription: 'اشتراكات', pubg: 'ببجي', freefire: 'فري فاير',
};

function StatCard({ icon, label, value, sub, color }: { icon: React.ReactNode; label: string; value: string | number; sub?: string; color: string }) {
  return (
    <div className={`relative rounded-2xl p-4 border ${color} overflow-hidden`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-gray-400 mb-1">{label}</p>
          <p className="text-2xl font-black text-white">{value}</p>
          {sub && <p className="text-[10px] text-gray-500 mt-0.5">{sub}</p>}
        </div>
        <div className="opacity-80">{icon}</div>
      </div>
    </div>
  );
}

export default function UserStats() {
  const { user } = useAuth();
  const { lang } = useLanguage();
  const { formatPrice } = useCurrency();

  const { data, isLoading } = useQuery({
    queryKey: ['user-stats'],
    queryFn: () => authFetch('/api/user/stats'),
    staleTime: 60_000,
  });

  const { data: ordersData } = useQuery({
    queryKey: ['user-orders-chart'],
    queryFn: () => authFetch('/api/orders?limit=100&page=1'),
    staleTime: 60_000,
  });

  if (isLoading) return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );

  const stats = data ?? {};
  const orders: any[] = ordersData?.orders ?? [];

  // Build monthly spending chart from orders
  const monthlyMap: Record<string, number> = {};
  orders.filter(o => o.status === 'delivered').forEach(o => {
    const m = new Date(o.createdAt).toLocaleString('ar', { month: 'short', year: '2-digit' });
    monthlyMap[m] = (monthlyMap[m] ?? 0) + parseFloat(o.totalUsd ?? o.total_usd ?? '0');
  });
  const chartData = Object.entries(monthlyMap).slice(-6).map(([m, v]) => ({ name: m, value: v }));

  const completionRate = stats.totalOrders > 0 ? Math.round((stats.completedOrders / stats.totalOrders) * 100) : 0;
  const sinceDate = stats.memberSince ? new Date(stats.memberSince).toLocaleDateString('ar-SY') : '—';
  const vipColor = VIP_COLORS[Math.min(stats.vipLevel ?? 0, 5)];
  const vipLabel = VIP_LABELS[Math.min(stats.vipLevel ?? 0, 5)];

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="p-4 max-w-lg mx-auto pb-24" dir="rtl">
          {/* Header */}
          <div className="mb-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-violet-500/30">
              <Trophy size={28} className="text-white" />
            </div>
            <h1 className="text-white text-xl font-black">إحصائياتك الشخصية</h1>
            <p className="text-gray-400 text-xs mt-1">مرحباً {stats.username ?? user?.username} 👋</p>
          </div>

          {/* VIP badge */}
          <div className="rounded-2xl p-4 mb-4 border border-white/10 bg-gradient-to-br from-white/5 to-transparent flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${vipColor}22`, border: `2px solid ${vipColor}55` }}>
              <Crown size={22} style={{ color: vipColor }} />
            </div>
            <div className="flex-1">
              <p className="text-white font-bold text-sm">مستوى {vipLabel}</p>
              <p className="text-gray-400 text-xs">{formatPrice(stats.vipSpent ?? 0)} إجمالي المشتريات المحسوبة</p>
            </div>
            <div className="text-left">
              <p className="text-[10px] text-gray-500">نقاط الولاء</p>
              <p className="font-black text-amber-400 text-lg">{(stats.loyaltyPoints ?? 0).toLocaleString()}</p>
            </div>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <StatCard
              icon={<ShoppingBag size={22} className="text-blue-400" />}
              label="إجمالي الطلبات"
              value={stats.totalOrders ?? 0}
              sub={`${stats.completedOrders ?? 0} مكتمل`}
              color="border-blue-500/20 bg-blue-500/5"
            />
            <StatCard
              icon={<Wallet size={22} className="text-emerald-400" />}
              label="إجمالي الإنفاق"
              value={formatPrice(stats.totalSpentUsd ?? 0)}
              sub="من الطلبات المكتملة"
              color="border-emerald-500/20 bg-emerald-500/5"
            />
            <StatCard
              icon={<Gift size={22} className="text-pink-400" />}
              label="وفّرت"
              value={formatPrice(stats.totalSavedUsd ?? 0)}
              sub="من العروض والكودات"
              color="border-pink-500/20 bg-pink-500/5"
            />
            <StatCard
              icon={<Star size={22} className="text-amber-400" />}
              label="معدل الإتمام"
              value={`${completionRate}%`}
              sub="من طلباتك مكتملة"
              color="border-amber-500/20 bg-amber-500/5"
            />
          </div>

          {/* Member since + fav category */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <div className="rounded-2xl p-3 border border-white/10 bg-white/3 text-center">
              <Calendar size={18} className="text-violet-400 mx-auto mb-1" />
              <p className="text-[10px] text-gray-400">عضو منذ</p>
              <p className="text-white font-bold text-xs">{sinceDate}</p>
            </div>
            <div className="rounded-2xl p-3 border border-white/10 bg-white/3 text-center">
              <Heart size={18} className="text-red-400 mx-auto mb-1" />
              <p className="text-[10px] text-gray-400">الفئة المفضلة</p>
              <p className="text-white font-bold text-xs">{CAT_LABELS[stats.favoriteCategory] ?? stats.favoriteCategory ?? '—'}</p>
            </div>
          </div>

          {/* Spending chart */}
          {chartData.length > 1 && (
            <div className="rounded-2xl border border-white/10 bg-white/3 p-4 mb-4">
              <p className="text-white font-bold text-sm mb-4 flex items-center gap-2">
                <TrendingUp size={16} className="text-violet-400" />
                إنفاقك الشهري
              </p>
              <ResponsiveContainer width="100%" height={120}>
                <AreaChart data={chartData} margin={{ top: 0, right: 0, left: -30, bottom: 0 }}>
                  <defs>
                    <linearGradient id="spendGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#6b7280', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: 8, fontSize: 11 }}
                    formatter={(v: any) => [formatPrice(v), 'الإنفاق']}
                  />
                  <Area type="monotone" dataKey="value" stroke="#8b5cf6" fill="url(#spendGrad)" strokeWidth={2} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Achievements */}
          <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4">
            <p className="text-white font-bold text-sm mb-3 flex items-center gap-2">
              <Award size={16} className="text-amber-400" />
              الإنجازات
            </p>
            <div className="flex flex-wrap gap-2">
              {stats.totalOrders >= 1 && <span className="px-2.5 py-1 rounded-full bg-white/10 text-white text-[10px] font-bold">🎯 أول طلب</span>}
              {stats.totalOrders >= 10 && <span className="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold">🔟 10 طلبات</span>}
              {stats.totalOrders >= 50 && <span className="px-2.5 py-1 rounded-full bg-violet-500/20 text-violet-300 text-[10px] font-bold">⚡ 50 طلب</span>}
              {stats.totalSpentUsd >= 50 && <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">💰 أنفقت $50+</span>}
              {stats.totalSpentUsd >= 200 && <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">👑 أنفقت $200+</span>}
              {stats.totalSavedUsd >= 5 && <span className="px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 text-[10px] font-bold">🎁 وفّر $5+</span>}
              {stats.loyaltyPoints >= 100 && <span className="px-2.5 py-1 rounded-full bg-yellow-500/20 text-yellow-300 text-[10px] font-bold">⭐ 100+ نقطة</span>}
              {stats.totalOrders === 0 && <span className="text-gray-500 text-xs">أكمل أول طلب لتفتح الإنجازات!</span>}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
