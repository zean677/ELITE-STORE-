import React from 'react';
import { motion } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PublicLayout } from '@/components/Layout';
import { Loader2, Smartphone, Monitor, MapPin, LogOut, ShieldOff, CheckCircle2, Trash2, History } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function api(method: string, path: string) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
}

function deviceIcon(ua: string | null) {
  const u = (ua ?? '').toLowerCase();
  if (/mobile|android|iphone|ipad/.test(u)) return Smartphone;
  return Monitor;
}

function deviceName(ua: string | null) {
  if (!ua) return 'جهاز غير معروف';
  const u = ua.toLowerCase();
  let os = 'نظام آخر';
  if (u.includes('windows')) os = 'Windows';
  else if (u.includes('android')) os = 'Android';
  else if (u.includes('iphone') || u.includes('ipad')) os = 'iOS';
  else if (u.includes('mac os')) os = 'macOS';
  else if (u.includes('linux')) os = 'Linux';
  let browser = 'متصفح';
  if (u.includes('edg/')) browser = 'Edge';
  else if (u.includes('chrome')) browser = 'Chrome';
  else if (u.includes('firefox')) browser = 'Firefox';
  else if (u.includes('safari')) browser = 'Safari';
  return `${browser} · ${os}`;
}

function formatDate(d: string | Date) {
  try {
    return new Date(d).toLocaleString('ar', { dateStyle: 'short', timeStyle: 'short' });
  } catch { return String(d); }
}

export default function LoginHistory() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const sessionsQ = useQuery<any>({
    queryKey: ['auth-sessions'],
    queryFn: async () => (await api('GET', '/api/auth/sessions')).json(),
  });
  const historyQ = useQuery<any>({
    queryKey: ['auth-login-history'],
    queryFn: async () => (await api('GET', '/api/auth/login-history')).json(),
  });

  const revokeOne = useMutation({
    mutationFn: async (id: string) => api('DELETE', `/api/auth/sessions/${id}`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['auth-sessions'] }); toast({ title: 'تم طرد الجهاز' }); },
  });
  const revokeAll = useMutation({
    mutationFn: async () => api('POST', `/api/auth/sessions/revoke-all`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['auth-sessions'] }); toast({ title: 'تم تسجيل الخروج من جميع الأجهزة الأخرى' }); },
  });

  const sessions: any[] = sessionsQ.data?.sessions ?? [];
  const attempts: any[] = historyQ.data?.attempts ?? [];

  return (
    <PublicLayout>
      <div className="container mx-auto max-w-3xl px-4 py-6 space-y-6" dir="rtl">
        <div>
          <h1 className="text-2xl font-black flex items-center gap-2">
            <History className="text-primary" /> سجل الدخول والأجهزة
          </h1>
          <p className="text-sm text-muted-foreground mt-1">شاهد من وين دخل لحسابك واطرد أي جهاز مشبوه.</p>
        </div>

        {/* Active Sessions */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold flex items-center gap-2"><Smartphone size={18} className="text-primary" /> الجلسات النشطة</h2>
            <button
              onClick={() => revokeAll.mutate()}
              disabled={revokeAll.isPending || sessions.filter((s) => !s.isCurrent && !s.revoked).length === 0}
              className="text-xs px-3 py-2 rounded-xl bg-destructive/10 text-destructive border border-destructive/30 font-bold hover:bg-destructive/20 disabled:opacity-40"
            >
              <ShieldOff size={14} className="inline ml-1" /> طرد كل الأجهزة الأخرى
            </button>
          </div>

          {sessionsQ.isLoading ? (
            <div className="flex justify-center py-6"><Loader2 className="animate-spin text-primary" /></div>
          ) : sessions.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">لا توجد جلسات.</p>
          ) : (
            <div className="space-y-2">
              {sessions.map((s) => {
                const Icon = deviceIcon(s.userAgent);
                return (
                  <div key={s.id} className={`flex items-center gap-3 p-3 rounded-xl border ${s.isCurrent ? 'border-success/40 bg-success/5' : s.revoked ? 'border-border/40 bg-background/30 opacity-60' : 'border-border bg-background/40'}`}>
                    <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                      <Icon size={18} className="text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm flex items-center gap-2">
                        {deviceName(s.userAgent)}
                        {s.isCurrent && <span className="text-[10px] font-bold text-success bg-success/10 border border-success/30 px-2 py-0.5 rounded-full">هذا الجهاز</span>}
                        {s.revoked && <span className="text-[10px] font-bold text-muted-foreground bg-muted/10 border border-border px-2 py-0.5 rounded-full">مطرود</span>}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1 flex-wrap">
                        <MapPin size={10} /> {s.ip ?? '—'} · آخر نشاط {formatDate(s.lastSeenAt)}
                      </p>
                    </div>
                    {!s.isCurrent && !s.revoked && (
                      <button
                        onClick={() => revokeOne.mutate(s.id)}
                        disabled={revokeOne.isPending}
                        className="shrink-0 text-xs px-3 py-2 rounded-xl bg-destructive/10 text-destructive border border-destructive/30 font-bold hover:bg-destructive/20 disabled:opacity-40"
                      >
                        <Trash2 size={12} className="inline" /> طرد
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>

        {/* Login Attempts */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border bg-card p-5">
          <h2 className="font-bold flex items-center gap-2 mb-4"><LogOut size={18} className="text-warning" /> آخر محاولات الدخول</h2>
          {historyQ.isLoading ? (
            <div className="flex justify-center py-6"><Loader2 className="animate-spin text-primary" /></div>
          ) : attempts.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">لا توجد محاولات سابقة.</p>
          ) : (
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {attempts.map((a) => (
                <div key={a.id} className={`flex items-center gap-3 p-3 rounded-xl border ${a.success ? 'border-success/30 bg-success/5' : 'border-destructive/30 bg-destructive/5'}`}>
                  {a.success ? <CheckCircle2 className="text-success shrink-0" size={18} /> : <ShieldOff className="text-destructive shrink-0" size={18} />}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold">{a.success ? 'دخول ناجح' : 'محاولة فاشلة'}</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{deviceName(a.userAgent)} · {a.ip}</p>
                  </div>
                  <p className="text-[11px] text-muted-foreground shrink-0">{formatDate(a.createdAt)}</p>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </PublicLayout>
  );
}
