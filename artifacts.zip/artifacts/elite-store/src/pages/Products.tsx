import React, { useState, useMemo, useEffect, useCallback, memo } from 'react';
import { Link, useSearch, useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { useGetProducts, useGetCategories } from '@workspace/api-client-react';
import { useQuery } from '@tanstack/react-query';
import { PublicLayout } from '@/components/Layout';
import { useCurrency } from '@/hooks/use-currency';
import { useLanguage } from '@/i18n';
import { useSettings } from '@/hooks/use-settings';
import { Search, ChevronRight, Zap, ArrowRight, Star } from 'lucide-react';
import { getBrandInfo, getProductImage, getPackageVariant } from '@/lib/product-images';
import { bustUrl, getImageVersion } from '@/lib/image-utils';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

const CATEGORY_STYLES: Record<string, { gradient: string; glow: string; badge: string }> = {
  mobile_games: {
    gradient: 'from-violet-600/30 via-purple-500/20 to-fuchsia-500/10',
    glow: 'shadow-violet-500/20',
    badge: 'bg-violet-500/20 text-violet-300 border-violet-500/30',
  },
  pc_games: {
    gradient: 'from-blue-600/30 via-cyan-500/20 to-sky-500/10',
    glow: 'shadow-blue-500/20',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  },
  gift_cards: {
    gradient: 'from-amber-500/30 via-orange-400/20 to-yellow-400/10',
    glow: 'shadow-amber-500/20',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
  },
  services: {
    gradient: 'from-emerald-500/30 via-teal-400/20 to-green-400/10',
    glow: 'shadow-emerald-500/20',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  },
  general: {
    gradient: 'from-rose-500/30 via-pink-400/20 to-red-400/10',
    glow: 'shadow-rose-500/20',
    badge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
  },
};

const CATEGORY_ICONS: Record<string, string> = {
  mobile_games: '🎮',
  pc_games: '🖥️',
  gift_cards: '🎁',
  services: '⚡',
  general: '🛒',
};

// ─── Group products by their description (= Shams4Store category/game name) ──
function groupProducts(products: any[]) {
  const groups: { label: string; items: any[] }[] = [];
  for (const product of products) {
    const label = (product.description ?? '').trim();
    const last = groups[groups.length - 1];
    if (last && last.label === label) {
      last.items.push(product);
    } else {
      groups.push({ label, items: [product] });
    }
  }
  return groups;
}

// ─── Game Group Header ─────────────────────────────────────────────────────────
const GameGroupHeader = memo(function GameGroupHeader({
  label,
  count,
  category,
  isExpanded,
  onToggle,
}: {
  label: string;
  count: number;
  category?: string;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const { lang } = useLanguage();
  const brand = getBrandInfo(label, label, category, BASE);
  const [imgOk, setImgOk] = React.useState(true);

  if (!label) return null;

  return (
    <motion.button
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      onClick={onToggle}
      className="w-full flex items-center gap-3 mt-10 mb-4 pb-3 border-b border-border/60 hover:border-border transition-colors cursor-pointer group text-left"
    >
      {/* Game image / logo */}
      <div
        className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center overflow-hidden"
        style={{ background: `${brand.color}22`, border: `1.5px solid ${brand.color}55` }}
      >
        {brand.logoUrl && imgOk ? (
          <img
            src={brand.logoUrl}
            alt={label}
            className="w-10 h-10 object-contain"
            onError={() => setImgOk(false)}
          />
        ) : (
          <span className="text-xs font-black" style={{ color: brand.color }}>
            {brand.label}
          </span>
        )}
      </div>

      {/* Name + hint */}
      <div className="flex-1 min-w-0">
        <h2 className="font-bold text-base leading-tight truncate group-hover:text-white transition-colors">{label}</h2>
        <p className="text-xs text-muted-foreground mt-0.5">
          {count} {lang === 'ar' ? 'منتج' : 'products'} • {isExpanded ? (lang === 'ar' ? 'انقر للإخفاء' : 'Click to collapse') : (lang === 'ar' ? 'انقر لعرض المنتجات' : 'Click to view products')}
        </p>
      </div>

      {/* Expand / Collapse chevron */}
      <motion.div
        animate={{ rotate: isExpanded ? 90 : 0 }}
        transition={{ duration: 0.2 }}
        className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center"
        style={{ background: `${brand.color}18`, border: `1px solid ${brand.color}33` }}
      >
        <ChevronRight size={16} style={{ color: brand.color }} />
      </motion.div>
    </motion.button>
  );
});

// ─── Product Card ─────────────────────────────────────────────────────────────
const ProductCard = memo(function ProductCard({ product }: { product: any }) {
  const { formatPrice } = useCurrency();
  const { lang } = useLanguage();
  const { sypRate } = useSettings();
  const description = product.description ?? '';
  const brand = getBrandInfo(description, product.name, product.category, BASE);
  const name = lang === 'ar' && product.nameAr ? product.nameAr : product.name;
  // Use imageOverride (admin-set) over provider image; bust cache for local uploads
  const rawImg = (product as any).imageOverride || product.image || null;
  const imgSrc = rawImg ? bustUrl(rawImg) : getProductImage(description, product.name, product.category, product.image, BASE);
  const [imgLoaded, setImgLoaded] = React.useState(false);
  const [imgOk, setImgOk] = React.useState(true);
  const variant = getPackageVariant(product.name, description);

  // Reset when image changes (admin edited it)
  React.useEffect(() => { setImgLoaded(false); setImgOk(true); }, [imgSrc]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -5, scale: 1.02 }}
      className="group relative bg-card border border-border rounded-2xl overflow-hidden hover:border-white/10 transition-all duration-300"
      style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.3)' }}
    >
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-2xl"
        style={{ boxShadow: `inset 0 0 30px ${brand.color}22` }}
      />

      {/* Card image area — fixed aspect ratio, object-fit cover for uploaded images */}
      <div
        className="relative overflow-hidden"
        style={{
          height: 112,
          background: imgSrc && imgOk
            ? `linear-gradient(135deg, ${brand.color}30, ${brand.color}10)`
            : 'linear-gradient(135deg, #1a1f2e 0%, #0f1420 100%)',
        }}
      >
        {/* Skeleton pulse while loading */}
        {imgSrc && imgOk && !imgLoaded && (
          <div className="absolute inset-0 animate-pulse bg-white/5" />
        )}

        {/* Subtle pattern overlay */}
        <div className="absolute inset-0 opacity-40 pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(circle at 25% 25%, rgba(108,92,231,0.08) 0%, transparent 50%)' }}
        />

        {imgSrc && imgOk ? (
          <img
            src={imgSrc}
            alt={name}
            loading="lazy"
            decoding="async"
            className={`absolute inset-0 w-full h-full object-cover z-10 transition-opacity duration-300 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
            onLoad={() => setImgLoaded(true)}
            onError={() => { setImgOk(false); setImgLoaded(true); }}
          />
        ) : (
          <div className="z-10 absolute inset-0 flex flex-col items-center justify-center gap-1.5 p-2">
            <div
              className="relative w-14 h-14 rounded-2xl flex items-center justify-center font-black text-lg shadow-2xl"
              style={{
                background: 'linear-gradient(145deg, rgba(108,92,231,0.95) 0%, rgba(139,126,255,0.7) 100%)',
                boxShadow: '0 8px 24px rgba(108,92,231,0.45), inset 0 1px 0 rgba(255,255,255,0.2)',
                color: '#fff',
              }}
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/15 to-transparent" />
              <span className="relative z-10 tracking-tighter">
                {brand.label.length > 3 ? brand.label.slice(0, 2).toUpperCase() : brand.label.toUpperCase()}
              </span>
            </div>
            <span className="text-[9px] font-bold tracking-wide uppercase text-white/55 max-w-[100px] text-center leading-tight line-clamp-2 px-1">
              {description || name.slice(0, 22)}
            </span>
          </div>
        )}

        {/* Available badge */}
        <div
          className="absolute top-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold z-20"
          style={{
            background: `${brand.color}22`,
            border: `1px solid ${brand.color}44`,
            color: brand.color,
          }}
        >
          <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: brand.color }} />
          {lang === 'ar' ? 'متاح' : 'Live'}
        </div>

        {/* Package variant badge */}
        {variant && (
          <div
            className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-black z-20 shadow-lg"
            style={{
              background: `linear-gradient(135deg, ${variant.color}ee, ${variant.color}aa)`,
              border: `1px solid ${variant.color}`,
              color: '#fff',
              boxShadow: `0 4px 12px ${variant.color}55`,
            }}
            title={variant.label}
          >
            <span className="text-xs leading-none">{variant.icon}</span>
            <span className="leading-none">{variant.shortLabel}</span>
          </div>
        )}
      </div>

      <div className="p-3">
        <h3 className="font-semibold text-sm leading-tight line-clamp-2 min-h-[2.5rem]">{name}</h3>
        <div className="flex items-center justify-between mt-3">
          <div>
            <span className="text-xs text-muted-foreground block">
              {product.productType === 'amount'
                ? lang === 'ar' ? 'ابتداءً من' : 'From'
                : lang === 'ar' ? 'السعر' : 'Price'}
            </span>
            <span className="font-black text-sm" style={{ color: brand.color }}>
              {parseFloat(product.priceUsd ?? '0') === 0 ? (
                <span className="text-muted-foreground text-xs">
                  {lang === 'ar' ? 'يُحدَّد عند الطلب' : 'Custom'}
                </span>
              ) : (
                formatPrice(product.priceUsd)
              )}
            </span>
            {parseFloat(product.priceUsd ?? '0') > 0 && (
              <span className="text-[10px] text-muted-foreground block">
                ≈ {Math.round(parseFloat(product.priceUsd ?? '0') * sypRate).toLocaleString('en-US')} ل.س
              </span>
            )}
          </div>
          <Link
            href={`/products/${product.id}`}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-white transition-all hover:scale-105 active:scale-95"
            style={{
              background: 'linear-gradient(135deg, #6C5CE7, #8b7eff)',
              boxShadow: '0 4px 12px rgba(108,92,231,0.40)',
            }}
          >
            <Zap size={10} />
            {lang === 'ar' ? 'شحن' : 'Buy'}
          </Link>
        </div>
      </div>
    </motion.div>
  );
});

// ─── Game Banner ──────────────────────────────────────────────────────────────
function GameBanner({ gameName, category, count, lang }: {
  gameName: string; category: string; count: number; lang: string;
}) {
  const brand = getBrandInfo(gameName, gameName, category, BASE);
  const [imgOk, setImgOk] = React.useState(true);

  return (
    <div
      className="mb-6 rounded-3xl overflow-hidden relative flex items-stretch"
      style={{
        background: `linear-gradient(135deg, ${brand.color}25 0%, #0d1117 70%)`,
        border: `1.5px solid ${brand.color}30`,
        minHeight: 110,
      }}
    >
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: `radial-gradient(ellipse 60% 80% at 0% 50%, ${brand.color}20, transparent)` }}
      />

      {/* Left: logo */}
      <div
        className="relative flex-shrink-0 w-24 flex items-center justify-center overflow-hidden"
        style={{ background: `${brand.color}10` }}
      >
        {brand.logoUrl && imgOk ? (
          <img
            src={brand.logoUrl}
            alt={gameName}
            className="w-16 h-16 object-contain drop-shadow-xl z-10"
            onError={() => setImgOk(false)}
          />
        ) : (
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center font-black text-white text-xl z-10 shadow-2xl"
            style={{
              background: `linear-gradient(145deg, ${brand.color}dd, ${brand.color}88)`,
              boxShadow: `0 8px 32px ${brand.color}50`,
            }}
          >
            {brand.label}
          </div>
        )}
      </div>

      {/* Right: info */}
      <div className="flex-1 p-5 flex flex-col justify-center" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
        <h1 className="font-black text-2xl text-white leading-tight mb-1" dir="auto">
          {gameName}
        </h1>
        <div className="flex items-center gap-3 flex-wrap">
          <span
            className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full"
            style={{ background: `${brand.color}20`, color: brand.color, border: `1px solid ${brand.color}40` }}
          >
            <Zap size={10} />
            {count} {lang === 'ar' ? 'باقة متاحة' : 'packages'}
          </span>
          <span className="flex items-center gap-1.5 text-xs text-white/50">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
            {lang === 'ar' ? 'متاح الآن' : 'Available now'}
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Category Tab ─────────────────────────────────────────────────────────────
function CategoryTab({ cat, active, onClick }: { cat: any; active: boolean; onClick: () => void }) {
  const { lang } = useLanguage();
  const style = CATEGORY_STYLES[cat.id] ?? CATEGORY_STYLES.general;
  const name = lang === 'ar' && cat.nameAr ? cat.nameAr : cat.name;

  return (
    <motion.button
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={`relative flex items-center gap-2.5 px-4 py-2.5 rounded-xl border text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
        active
          ? 'border-white/20 text-white'
          : 'border-border bg-card text-muted-foreground hover:text-foreground hover:border-white/10'
      }`}
      style={
        active
          ? {
              background: `linear-gradient(135deg, ${
                style.badge?.replace('bg-', '').split('/')[0] || '#6c5ce7'
              }22, transparent)`,
            }
          : {}
      }
    >
      <span>{name}</span>
      <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${style.badge}`}>
        {cat.productCount}
      </span>
      {active && <motion.div layoutId="activeCat" className="absolute inset-0 rounded-xl ring-1 ring-white/20" />}
    </motion.button>
  );
}

// ─── Game Group Banner ─────────────────────────────────────────────────────────
type SubTab = { key: string; labelAr: string; labelEn: string; keywords: string[]; subGroups?: string[]; sortOrder?: number; isActive?: boolean };
type GameGroupMeta = { nameAr: string; nameEn: string; color: string; emoji: string; imageUrl?: string; tabs: SubTab[] };

const FALLBACK_GROUP_META: Record<string, { nameAr: string; nameEn: string; color: string; emoji: string; imageUrl?: string }> = {
  pubg:     { nameAr: 'ببجي موبايل', nameEn: 'PUBG Mobile', color: '#F5A623', emoji: '🎯' },
  freefire: { nameAr: 'فري فاير',    nameEn: 'Free Fire',   color: '#F97316', emoji: '🔥' },
};

function GameGroupBanner({ gameGroup, count, lang, meta }: { gameGroup: string; count: number; lang: string; meta?: { nameAr: string; nameEn: string; color: string; emoji: string; imageUrl?: string } }) {
  if (!meta) return null;
  const displayName = lang === 'ar' ? meta.nameAr : meta.nameEn;
  return (
    <div
      className="mb-5 rounded-3xl overflow-hidden relative flex items-stretch"
      style={{ background: `linear-gradient(135deg, ${meta.color}25 0%, #0d1117 70%)`, border: `1.5px solid ${meta.color}40`, minHeight: 110 }}
    >
      <div className="absolute inset-0 pointer-events-none" style={{ background: `radial-gradient(ellipse 60% 80% at 0% 50%, ${meta.color}20, transparent)` }} />
      <div className="relative flex-shrink-0 w-24 flex items-center justify-center overflow-hidden" style={{ background: `${meta.color}15` }}>
        {meta.imageUrl ? (
          <img src={meta.imageUrl} alt={displayName} className="w-20 h-20 rounded-2xl object-cover" onError={(e) => { (e.target as HTMLImageElement).replaceWith(Object.assign(document.createElement('span'), { textContent: meta.emoji, style: 'font-size:48px' })); }} />
        ) : (
          <span className="text-5xl">{meta.emoji}</span>
        )}
      </div>
      <div className="flex-1 p-5 flex flex-col justify-center" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
        <h1 className="font-black text-2xl text-white leading-tight mb-1">{displayName}</h1>
        <div className="flex items-center gap-3 flex-wrap">
          <span className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: `${meta.color}20`, color: meta.color, border: `1px solid ${meta.color}40` }}>
            <Zap size={10} />{count} {lang === 'ar' ? 'باقة متاحة' : 'packages'}
          </span>
          <span className="flex items-center gap-1.5 text-xs text-white/50">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
            {lang === 'ar' ? 'متاح الآن' : 'Available now'}
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function Products() {
  const searchStr = useSearch();
  const [, navigate] = useLocation();
  const urlParams = useMemo(() => new URLSearchParams(searchStr), [searchStr]);

  const gameName = urlParams.get('game') || '';
  const gameGroup = urlParams.get('game_group') || '';
  const [search, setSearch] = useState(() => urlParams.get('q') || '');
  const [activeCategory, setActiveCategory] = useState(() => urlParams.get('category') || '');
  const [page, setPage] = useState(1);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [activeSubTab, setActiveSubTab] = useState('all');
  const { lang } = useLanguage();

  const isGameView = !!gameName;
  const isGroupView = !!gameGroup;
  const PAGE_SIZE = (isGameView || isGroupView) ? 500 : 96;

  const toggleGroup = useCallback((key: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  useEffect(() => {
    const cat = urlParams.get('category') || '';
    const q = urlParams.get('q') || '';
    setActiveCategory(cat);
    setSearch(q);
    setPage(1);
    setActiveSubTab('all');
  }, [searchStr]);

  useEffect(() => {
    if (!gameName && !gameGroup) {
      navigate(`/games?category=${activeCategory || 'mobile_games'}`);
    }
  }, [gameName, gameGroup, activeCategory, navigate]);

  const { data: categoriesData } = useGetCategories();

  const { data: productData, isLoading } = useGetProducts({
    game: isGameView && gameName ? gameName : undefined,
    search: (!isGameView && !isGroupView) ? (search || undefined) : undefined,
    category: activeCategory || undefined,
    page,
    limit: PAGE_SIZE,
  });

  const { data: subTabConfig } = useQuery({
    queryKey: ['game-group-subtabs'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/game-group-subtabs`);
      if (!res.ok) return {} as Record<string, SubTab[]>;
      const j = await res.json();
      return (j.groups ?? {}) as Record<string, SubTab[]>;
    },
    staleTime: 5 * 60 * 1000,
  });

  const { data: featuredGamesList } = useQuery({
    queryKey: ['featured-games'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/featured-games`);
      if (!res.ok) return [] as any[];
      const j = await res.json();
      return (j.items ?? []) as any[];
    },
    staleTime: 5 * 60 * 1000,
  });

  const { data: groupProductData, isLoading: isGroupLoading } = useQuery({
    queryKey: ['game-group-products', gameGroup, activeCategory],
    enabled: isGroupView,
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set('game_group', gameGroup);
      if (activeCategory) params.set('category', activeCategory);
      params.set('limit', '500');
      const res = await fetch(`${BASE}/api/products?${params.toString()}`);
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });

  const allProducts = isGroupView ? (groupProductData?.products ?? []) : (productData?.products ?? []);
  const total = isGroupView ? (groupProductData?.total ?? 0) : (productData?.total ?? 0);
  const isLoadingAny = isGroupView ? isGroupLoading : isLoading;

  // Sub-tab filtering for game groups (admin-controlled config)
  const groupMeta: GameGroupMeta | null = useMemo(() => {
    if (!isGroupView) return null;
    const fg = (featuredGamesList ?? []).find((f: any) => f.id === gameGroup);
    const fallback = FALLBACK_GROUP_META[gameGroup];
    const base = fg
      ? { nameAr: fg.nameAr, nameEn: fg.nameEn, color: fg.color, emoji: fg.emoji, imageUrl: fg.imageUrl }
      : (fallback ?? { nameAr: gameGroup, nameEn: gameGroup, color: '#6c5ce7', emoji: '🎮' });
    const tabs = ((subTabConfig ?? {})[gameGroup] ?? [])
      .filter(t => t.isActive !== false)
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    const finalTabs: SubTab[] = tabs.length
      ? tabs
      : [{ key: 'all', labelAr: 'الكل', labelEn: 'All', keywords: [], subGroups: [] }];
    return { ...base, tabs: finalTabs };
  }, [isGroupView, gameGroup, featuredGamesList, subTabConfig]);

  const filteredGroupProducts = useMemo(() => {
    if (!isGroupView || !groupMeta || activeSubTab === 'all') return allProducts;
    const tab = groupMeta.tabs.find(t => t.key === activeSubTab);
    if (!tab) return allProducts;
    const kws = tab.keywords ?? [];
    const sgs = tab.subGroups ?? [];
    if (kws.length === 0 && sgs.length === 0) return allProducts;
    return allProducts.filter((p: any) => {
      if (sgs.length && p.subGroup && sgs.includes(p.subGroup)) return true;
      if (kws.length) {
        const desc = (p.description ?? '').toLowerCase() + ' ' + (p.name ?? '').toLowerCase();
        return kws.some(kw => desc.includes(kw.toLowerCase()));
      }
      return false;
    });
  }, [allProducts, isGroupView, groupMeta, activeSubTab]);

  // If viewing a specific game, keep only exact game/description matches.
  const products = useMemo(() => {
    if (isGroupView) return filteredGroupProducts;
    if (isGameView && gameName) {
      const lower = gameName.toLowerCase();
      return allProducts.filter((p: any) => {
        const desc = (p.description ?? '').toLowerCase();
        return desc === lower;
      });
    }
    return allProducts;
  }, [allProducts, filteredGroupProducts, isGameView, isGroupView, gameName]);

  // Group by description (game name) — only used when NOT in game view
  const groups = useMemo(() => groupProducts(products), [products]);

  const handleCategory = useCallback((id: string) => {
    setActiveCategory(prev => (id === prev ? '' : id));
    setPage(1);
  }, []);

  const catName = lang === 'ar'
    ? categoriesData?.find(c => c.id === activeCategory)?.nameAr ?? activeCategory
    : categoriesData?.find(c => c.id === activeCategory)?.name ?? activeCategory;

  return (
    <PublicLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">

        {/* Breadcrumb */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 mb-5 text-sm text-muted-foreground flex-wrap"
        >
          {isGroupView ? (
            <>
              <Link href="/" className="hover:text-foreground transition-colors font-medium">{lang === 'ar' ? 'الرئيسية' : 'Home'}</Link>
              <ChevronRight size={13} className={lang === 'ar' ? 'rotate-180' : ''} />
              <Link href={`/games?category=${activeCategory}`} className="hover:text-foreground transition-colors">{catName}</Link>
              <ChevronRight size={13} className={lang === 'ar' ? 'rotate-180' : ''} />
              <span className="text-foreground font-semibold">{lang === 'ar' ? groupMeta?.nameAr : groupMeta?.nameEn}</span>
            </>
          ) : isGameView ? (
            <>
              <Link href="/" className="flex items-center gap-1.5 hover:text-foreground transition-colors font-medium">
                {lang === 'ar' ? 'الرئيسية' : 'Home'}
              </Link>
              <ChevronRight size={13} className={lang === 'ar' ? 'rotate-180' : ''} />
              <Link href={`/games?category=${activeCategory}`} className="hover:text-foreground transition-colors">{catName}</Link>
              <ChevronRight size={13} className={lang === 'ar' ? 'rotate-180' : ''} />
              <span className="text-foreground font-semibold">{gameName}</span>
            </>
          ) : activeCategory ? (
            <>
              <Link href="/" className="flex items-center gap-1.5 hover:text-foreground transition-colors font-medium">
                <ArrowRight size={14} className={lang === 'ar' ? '' : 'rotate-180'} />
                {lang === 'ar' ? 'الرئيسية' : 'Home'}
              </Link>
              <ChevronRight size={13} className={lang === 'ar' ? 'rotate-180' : ''} />
              <span className="text-foreground font-semibold">{catName}</span>
            </>
          ) : null}
        </motion.div>

        {/* Header Banner */}
        {isGroupView ? (
          <GameGroupBanner gameGroup={gameGroup} count={allProducts.length} lang={lang} meta={groupMeta ?? undefined} />
        ) : isGameView ? (
          <GameBanner
            gameName={gameName!}
            category={activeCategory}
            count={products.length}
            lang={lang}
          />
        ) : (
          <div
            className="mb-6 rounded-3xl p-5 overflow-hidden relative"
            style={{
              background: 'linear-gradient(135deg, rgba(108,92,231,0.16), rgba(0,206,201,0.08), rgba(17,24,39,0.72))',
              border: '1px solid rgba(255,255,255,0.08)',
            }}
          >
            <div className="absolute -top-16 -left-16 h-40 w-40 rounded-full bg-primary/20 blur-3xl" />
            <div className="absolute -bottom-16 -right-16 h-40 w-40 rounded-full bg-secondary/10 blur-3xl" />
            <div className="relative">
              <h1 className="font-heading text-3xl font-black mb-1" dir="auto">
                {activeCategory ? catName : (lang === 'ar' ? 'المتجر' : 'Store')}
              </h1>
              <p className="text-muted-foreground text-sm">
                {`${total} ${lang === 'ar' ? 'منتج متاح' : 'products available'}`}
              </p>
            </div>
          </div>
        )}

        {/* Sub-tabs for game group view */}
        {isGroupView && groupMeta && (
          <div className="flex gap-2 overflow-x-auto pb-2 mb-5 scrollbar-none">
            {groupMeta.tabs.map(tab => (
              <motion.button
                key={tab.key}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setActiveSubTab(tab.key)}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border text-sm font-semibold transition-all whitespace-nowrap"
                style={activeSubTab === tab.key ? {
                  background: `${groupMeta.color}20`,
                  borderColor: `${groupMeta.color}60`,
                  color: groupMeta.color,
                } : {
                  background: 'rgba(255,255,255,0.04)',
                  borderColor: 'rgba(255,255,255,0.1)',
                  color: 'rgba(255,255,255,0.6)',
                }}
              >
                {lang === 'ar' ? tab.labelAr : tab.labelEn}
                {activeSubTab === tab.key && <motion.div layoutId="activeSubTab" className="absolute inset-0 rounded-xl" />}
              </motion.button>
            ))}
          </div>
        )}

        {/* Search — hidden in game view */}
        {!isGameView && !isGroupView && (
          <div className="relative mb-6">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              placeholder={lang === 'ar' ? 'ابحث عن منتج أو لعبة...' : 'Search games or products...'}
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-2xl text-sm focus:outline-none focus:border-primary/50 transition-colors"
            />
          </div>
        )}

        {/* Category Tabs — hidden in game/group view */}
        {!isGameView && !isGroupView && categoriesData && categoriesData.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-2 mb-8 scrollbar-none">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => { setActiveCategory(''); setPage(1); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-semibold transition-all whitespace-nowrap ${
                activeCategory === ''
                  ? 'bg-primary/20 border-primary/40 text-primary'
                  : 'border-border bg-card text-muted-foreground hover:text-foreground'
              }`}
            >
              🌟 {lang === 'ar' ? 'الكل' : 'All'}
            </motion.button>
            {categoriesData.map(cat => (
              <CategoryTab
                key={cat.id}
                cat={cat}
                active={activeCategory === cat.id}
                onClick={() => handleCategory(cat.id)}
              />
            ))}
          </div>
        )}

        {/* ── PRODUCTS ───────────────────────────────────────────────────────── */}
        {isLoadingAny ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {Array.from({ length: 15 }).map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-2xl overflow-hidden animate-pulse">
                <div className="h-28 bg-muted" />
                <div className="p-3 space-y-2">
                  <div className="h-3.5 bg-muted rounded w-4/5" />
                  <div className="h-3 bg-muted rounded w-2/5" />
                  <div className="flex justify-between mt-3">
                    <div className="h-5 bg-muted rounded w-1/3" />
                    <div className="h-7 bg-muted rounded w-1/4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-5xl mb-4">🔍</div>
            <p className="text-muted-foreground text-lg font-medium">
              {lang === 'ar' ? 'لا توجد منتجات' : 'No products found'}
            </p>
            {search && (
              <button onClick={() => setSearch('')} className="mt-3 text-primary text-sm hover:underline">
                {lang === 'ar' ? 'مسح البحث' : 'Clear search'}
              </button>
            )}
          </div>
        ) : (isGameView || isGroupView) ? (
          /* ── Game / Group view: products grouped by subGroup if set ── */
          (() => {
            const bySub = new Map<string, any[]>();
            for (const p of products) {
              const key = (p.subGroup ?? '').trim() || '__default__';
              if (!bySub.has(key)) bySub.set(key, []);
              bySub.get(key)!.push(p);
            }
            const hasSubGroups = Array.from(bySub.keys()).some(k => k !== '__default__');
            if (!hasSubGroups) {
              return (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {products.map((product: any) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              );
            }
            const sections = Array.from(bySub.entries()).sort(([a], [b]) => {
              if (a === '__default__') return 1;
              if (b === '__default__') return -1;
              return a.localeCompare(b, 'ar');
            });
            return (
              <div className="space-y-8">
                {sections.map(([sub, items]) => (
                  <section key={sub}>
                    <div className="flex items-center gap-3 mb-4 pb-2 border-b border-white/10" dir="rtl">
                      <span className="text-2xl">{sub === '__default__' ? '🎁' : '✨'}</span>
                      <h2 className="font-black text-lg text-white">
                        {sub === '__default__' ? (lang === 'ar' ? 'منتجات أخرى' : 'Other') : sub}
                      </h2>
                      <span className="text-xs text-white/50 font-semibold">({items.length})</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                      {items.map(p => <ProductCard key={p.id} product={p} />)}
                    </div>
                  </section>
                ))}
              </div>
            );
          })()
        ) : (
          /* ── Category view: grouped by game ── */
          <AnimatePresence mode="popLayout">
            <motion.div layout>
              {groups.map((group, gi) => {
                const groupKey = `${group.label}-${gi}`;
                const isExpanded = expandedGroups.has(groupKey);
                return (
                  <div key={groupKey}>
                    <GameGroupHeader
                      label={group.label}
                      count={group.items.length}
                      category={group.items[0]?.category}
                      isExpanded={isExpanded}
                      onToggle={() => toggleGroup(groupKey)}
                    />
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.25, ease: 'easeInOut' }}
                          className="overflow-hidden"
                        >
                          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 mb-2 pt-1">
                            {group.items.map(product => (
                              <ProductCard key={product.id} product={product} />
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </motion.div>
          </AnimatePresence>
        )}

        {/* Pagination — only in category view */}
        {!isGameView && !isGroupView && total > PAGE_SIZE && (
          <div className="flex justify-center items-center gap-3 mt-10">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-5 py-2.5 bg-card border border-border rounded-xl text-sm font-medium disabled:opacity-40 hover:border-primary/40 transition-colors flex items-center gap-1"
            >
              <ChevronRight size={14} className="rotate-180" />
              {lang === 'ar' ? 'السابق' : 'Prev'}
            </button>
            <span className="px-4 py-2 text-sm text-muted-foreground bg-card border border-border rounded-xl">
              {page} / {Math.ceil(total / PAGE_SIZE)}
            </span>
            <button
              onClick={() => setPage(p => p + 1)}
              disabled={page * PAGE_SIZE >= total}
              className="px-5 py-2.5 bg-card border border-border rounded-xl text-sm font-medium disabled:opacity-40 hover:border-primary/40 transition-colors flex items-center gap-1"
            >
              {lang === 'ar' ? 'التالي' : 'Next'}
              <ChevronRight size={14} />
            </button>
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
