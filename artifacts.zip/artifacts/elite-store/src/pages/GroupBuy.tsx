import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PublicLayout } from '@/components/Layout';
import { useAuth } from '@/hooks/use-auth';
import { useCurrency } from '@/hooks/use-currency';
import { useLanguage } from '@/i18n';
import { useToast } from '@/hooks/use-toast';
import { Users, Timer, Tag, CheckCircle, Loader2, ChevronLeft, Zap, Trophy, Copy } from 'lucide-react';
import { Link } from 'wouter';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authFetch(path: string, opts?: RequestInit) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...((opts?.headers) ?? {}) },
  });
}

function useCountdown(target: string | null) {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (!target) return;
    const tick = () => setLeft(Math.max(0, new Date(target).getTime() - Date.now()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [target]);
  const h = Math.floor(left / 3600000);
  const m = Math.floor((left % 3600000) / 60000);
  const s = Math.floor((left % 60000) / 1000);
  return { h, m, s, expired: left === 0 };
}

function CountdownBadge({ endsAt }: { endsAt: string }) {
  const { h, m, s, expired } = useCountdown(endsAt);
  if (expired) return <span className="text-[10px] text-red-400 font-bold">انتهى</span>;
  return (
    <span className="font-mono text-[11px] font-bold text-amber-300">
      {h > 0 ? `${h}س ` : ''}{String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}
    </span>
  );
}

function GroupBuyCard({ buy }: { buy: any }) {
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const { toast } = useToast();
  const qc = useQueryClient();

  const progress = Math.min(100, Math.round(((buy.currentQty ?? 0) / buy.targetQty) * 100));
  const discountPct = Math.round(parseFloat(buy.discountPct ?? '0'));
  const originalPrice = parseFloat(buy.originalPriceUsd ?? '0');
  const groupPrice = parseFloat(buy.groupPriceUsd ?? '0');

  const { data: statusData } = useQuery({
    queryKey: ['gb-status', buy.id],
    queryFn: async () => { const r = await authFetch(`/api/group-buys/${buy.id}/my-status`); return r.json(); },
    enabled: !!user,
    staleTime: 30_000,
  });

  const alreadyJoined = statusData?.joined === true;

  const joinMutation = useMutation({
    mutationFn: async () => {
      const r = await authFetch(`/api/group-buys/${buy.id}/join`, { method: 'POST' });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? 'فشل');
      return d;
    },
    onSuccess: (d: any) => {
      qc.invalidateQueries({ queryKey: ['group-buys'] });
      qc.invalidateQueries({ queryKey: ['gb-status', buy.id] });
      if (d.completed) {
        toast({ title: '🎉 اكتمل العرض الجماعي!', description: `كود الخصم: ${d.promoCode} — صالح 7 أيام` });
      } else {
        toast({ title: '✅ انضممت بنجاح!', description: `${d.currentQty}/${buy.targetQty} شخص` });
      }
    },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  return (
    <div className={`relative rounded-2xl overflow-hidden border transition-all ${buy.status === 'completed' ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-white/10 bg-white/3'}`}>
      {buy.status === 'completed' && (
        <div className="absolute top-2 right-2 z-10 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[9px] font-bold">
          <CheckCircle size={10} /> مكتمل
        </div>
      )}
      <div className="p-4">
        {/* Product info */}
        <div className="flex items-center gap-3 mb-3">
          {buy.productImageUrl && (
            <img src={buy.productImageUrl} alt={buy.productName} className="w-12 h-12 rounded-xl object-cover" />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm truncate">{buy.productName}</p>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-red-400 line-through text-xs">{formatPrice(originalPrice)}</span>
              <span className="text-emerald-400 font-black text-sm">{formatPrice(groupPrice)}</span>
              <span className="px-1.5 py-0.5 rounded-md bg-red-500/20 text-red-300 text-[9px] font-bold">-{discountPct}%</span>
            </div>
          </div>
          <div className="text-left">
            <Timer size={13} className="text-amber-400 mx-auto mb-0.5" />
            <CountdownBadge endsAt={buy.endsAt} />
          </div>
        </div>

        {/* Progress bar */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-[10px] mb-1">
            <span className="text-gray-400 flex items-center gap-1"><Users size={10} /> {buy.currentQty ?? 0}/{buy.targetQty} شخص</span>
            <span className="text-violet-400 font-bold">{progress}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${progress >= 100 ? 'bg-emerald-500' : 'bg-gradient-to-r from-violet-500 to-pink-500'}`}
              style={{ width: `${progress}%` }}
            />
          </div>
          {progress < 100 && (
            <p className="text-gray-500 text-[9px] mt-1 text-center">
              يحتاج {buy.targetQty - (buy.currentQty ?? 0)} شخص إضافي لتفعيل الخصم
            </p>
          )}
        </div>

        {/* Completed promo code */}
        {buy.status === 'completed' && buy.promoCode && (
          <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-3 py-2 mb-3">
            <span className="text-emerald-300 font-mono text-sm font-bold tracking-wider">{buy.promoCode}</span>
            <button onClick={() => { navigator.clipboard.writeText(buy.promoCode); toast({ title: 'تم نسخ الكود ✅' }); }}
              className="text-emerald-400 hover:text-emerald-300">
              <Copy size={14} />
            </button>
          </div>
        )}

        {/* Join button */}
        {buy.status === 'open' && (
          !user ? (
            <Link href="/login">
              <button className="w-full py-2.5 rounded-xl bg-violet-600/20 border border-violet-500/30 text-violet-300 text-xs font-bold hover:bg-violet-600/30 transition-colors">
                سجّل دخولك للانضمام
              </button>
            </Link>
          ) : alreadyJoined ? (
            <div className="w-full py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold text-center flex items-center justify-center gap-1">
              <CheckCircle size={13} /> انضممت بالفعل
            </div>
          ) : (
            <button
              onClick={() => joinMutation.mutate()}
              disabled={joinMutation.isPending}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-pink-600 text-white text-xs font-black hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {joinMutation.isPending ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
              انضم للعرض الجماعي
            </button>
          )
        )}
      </div>
    </div>
  );
}

export default function GroupBuyPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['group-buys'],
    queryFn: async () => { const r = await fetch(`${BASE}/api/group-buys`); return r.json(); },
    refetchInterval: 10_000,
    staleTime: 5_000,
  });

  const buys: any[] = data?.groupBuys ?? [];
  const active = buys.filter(b => b.status === 'open');
  const done = buys.filter(b => b.status !== 'open');

  return (
    <PublicLayout>
      <div className="p-4 max-w-lg mx-auto pb-24" dir="rtl">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-violet-500 to-pink-600 flex items-center justify-center shadow-lg shadow-violet-500/30">
              <Users size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-white text-xl font-black">الشراء الجماعي</h1>
              <p className="text-gray-400 text-xs">تجمّع مع الآخرين واحصل على خصم حصري</p>
            </div>
          </div>
        </div>

        {/* How it works */}
        <div className="rounded-2xl border border-violet-500/20 bg-violet-500/5 p-4 mb-5">
          <p className="text-white font-bold text-xs mb-2 flex items-center gap-1.5"><Trophy size={13} className="text-amber-400" /> كيف يعمل؟</p>
          <div className="flex gap-3 text-[10px] text-gray-400">
            <div className="text-center flex-1">
              <div className="w-6 h-6 rounded-full bg-violet-500/20 flex items-center justify-center mx-auto mb-1 text-violet-400 font-black">١</div>
              <p>انضم للعرض</p>
            </div>
            <div className="text-center flex-1">
              <div className="w-6 h-6 rounded-full bg-violet-500/20 flex items-center justify-center mx-auto mb-1 text-violet-400 font-black">٢</div>
              <p>شارك مع أصدقائك</p>
            </div>
            <div className="text-center flex-1">
              <div className="w-6 h-6 rounded-full bg-violet-500/20 flex items-center justify-center mx-auto mb-1 text-violet-400 font-black">٣</div>
              <p>احصل على كود الخصم</p>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-16"><div className="w-7 h-7 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" /></div>
        ) : active.length === 0 && done.length === 0 ? (
          <div className="text-center py-16">
            <Users size={40} className="text-gray-700 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">لا يوجد عروض جماعية نشطة حالياً</p>
            <p className="text-gray-600 text-xs mt-1">تابع المتجر لتعرف متى نطلق عروضاً جديدة</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {active.map(b => <GroupBuyCard key={b.id} buy={b} />)}
            {done.length > 0 && (
              <>
                <p className="text-gray-500 text-xs font-bold mt-2">عروض سابقة</p>
                {done.map(b => <GroupBuyCard key={b.id} buy={b} />)}
              </>
            )}
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
