import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import {
  MessageCircle, Send, Plus, ChevronRight, Clock, CheckCircle2,
  AlertCircle, X, Loader2, RefreshCw, Package, ArrowRight,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

type TicketStatus = 'open' | 'in_progress' | 'closed';
type Priority = 'low' | 'medium' | 'high' | 'urgent';

interface Ticket {
  id: number;
  subject: string;
  status: TicketStatus;
  priority: Priority;
  orderId: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Message {
  id: number;
  ticketId: number;
  userId: number;
  body: string;
  isAdmin: string;
  createdAt: string;
}

const STATUS_CFG: Record<TicketStatus, { label: string; color: string; icon: React.ElementType }> = {
  open:        { label: 'مفتوحة',        color: 'text-blue-400',    icon: MessageCircle },
  in_progress: { label: 'قيد المراجعة', color: 'text-yellow-400',  icon: Clock },
  closed:      { label: 'مغلقة',         color: 'text-emerald-400', icon: CheckCircle2 },
};

const PRIORITY_CFG: Record<Priority, { label: string; color: string }> = {
  low:    { label: 'منخفض', color: 'text-muted-foreground' },
  medium: { label: 'متوسط', color: 'text-blue-400' },
  high:   { label: 'عالي',  color: 'text-orange-400' },
  urgent: { label: 'عاجل',  color: 'text-red-400' },
};

function elapsed(d: string) {
  const s = Math.floor((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 60) return 'الآن';
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}د`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}س`;
  return `${Math.floor(h / 24)}ي`;
}

function NewTicketModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { toast } = useToast();
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [orderId, setOrderId] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!subject.trim() || !body.trim()) return;
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/support/tickets`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ subject, body, priority, orderId: orderId || undefined }),
      });
      if (!r.ok) throw new Error();
      toast({ title: '✅ تم إرسال تذكرتك', description: 'سنرد عليك في أقرب وقت ممكن', duration: 3000 });
      onCreated();
      onClose();
    } catch {
      toast({ title: 'خطأ', description: 'تعذّر إرسال التذكرة', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.92, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.92, y: 20 }}
        className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-black text-base">تذكرة دعم جديدة</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>
        </div>
        <form onSubmit={submit} className="p-5 space-y-4">
          <div>
            <label className="text-xs font-bold text-muted-foreground mb-1.5 block">الموضوع *</label>
            <input
              value={subject} onChange={e => setSubject(e.target.value)}
              className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:border-primary outline-none transition-colors"
              placeholder="اكتب موضوع المشكلة..."
              maxLength={200} required
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-muted-foreground mb-1.5 block">الأولوية</label>
              <select
                value={priority} onChange={e => setPriority(e.target.value as Priority)}
                className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:border-primary outline-none"
              >
                <option value="low">منخفض</option>
                <option value="medium">متوسط</option>
                <option value="high">عالي</option>
                <option value="urgent">عاجل 🔴</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground mb-1.5 block">رقم الطلب (اختياري)</label>
              <input
                value={orderId} onChange={e => setOrderId(e.target.value)}
                className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:border-primary outline-none"
                placeholder="#12345"
              />
            </div>
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground mb-1.5 block">وصف المشكلة *</label>
            <textarea
              value={body} onChange={e => setBody(e.target.value)}
              className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:border-primary outline-none resize-none h-28 transition-colors"
              placeholder="اشرح مشكلتك بالتفصيل..."
              maxLength={2000} required
            />
          </div>
          <button
            type="submit" disabled={loading || !subject.trim() || !body.trim()}
            className="w-full py-2.5 bg-primary text-white rounded-xl font-bold text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
            إرسال التذكرة
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
}

function ChatView({ ticket, onBack }: { ticket: Ticket; onBack: () => void }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [msg, setMsg] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data, isFetching, refetch } = useQuery<{ ticket: Ticket; messages: Message[] }>({
    queryKey: ['support-ticket', ticket.id],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/support/tickets/${ticket.id}`, { headers: authHeaders() });
      if (!r.ok) throw new Error();
      return r.json();
    },
    refetchInterval: 8_000,
    staleTime: 4_000,
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [data?.messages]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!msg.trim() || sending) return;
    setSending(true);
    try {
      const r = await fetch(`${BASE}/api/support/tickets/${ticket.id}/messages`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ body: msg }),
      });
      if (!r.ok) throw new Error();
      setMsg('');
      refetch();
      qc.invalidateQueries({ queryKey: ['support-tickets'] });
    } catch {
      toast({ title: 'خطأ', description: 'تعذّر إرسال الرسالة', variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  const currentTicket = data?.ticket ?? ticket;
  const StatusCfg = STATUS_CFG[currentTicket.status];
  const StatusIcon = StatusCfg.icon;
  const isClosed = currentTicket.status === 'closed';

  return (
    <div className="flex flex-col h-[calc(100vh-180px)]" dir="rtl">
      {/* Chat header */}
      <div className="flex items-center gap-3 mb-4">
        <button onClick={onBack} className="p-2 rounded-xl hover:bg-card border border-border text-muted-foreground hover:text-foreground transition-colors">
          <ArrowRight size={16} />
        </button>
        <div className="flex-1 min-w-0">
          <p className="font-black text-sm truncate">{currentTicket.subject}</p>
          <div className={`flex items-center gap-1.5 text-xs ${StatusCfg.color} mt-0.5`}>
            <StatusIcon size={11} />
            <span>{StatusCfg.label}</span>
            {isFetching && <RefreshCw size={9} className="animate-spin text-muted-foreground" />}
          </div>
        </div>
        {isClosed && (
          <span className="px-2 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold">مغلقة</span>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 pb-2 pr-1">
        {data?.messages.map(m => {
          const isAdm = m.isAdmin === 'true';
          return (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              className={`flex ${isAdm ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`max-w-[80%] ${isAdm ? 'bg-primary/10 border-primary/20' : 'bg-card border-border'} border rounded-2xl px-3.5 py-2.5`}>
                {isAdm && (
                  <p className="text-[10px] font-black text-primary mb-1">⚡ Elite Store</p>
                )}
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.body}</p>
                <p className="text-[9px] text-muted-foreground mt-1 text-end">{elapsed(m.createdAt)}</p>
              </div>
            </motion.div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form onSubmit={send} className="flex items-end gap-2 mt-3 pt-3 border-t border-border">
        {isClosed ? (
          <div className="flex-1 text-center text-xs text-muted-foreground py-2">
            هذه التذكرة مغلقة — افتح تذكرة جديدة إذا احتجت مساعدة
          </div>
        ) : (
          <>
            <textarea
              value={msg} onChange={e => setMsg(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(e as any); } }}
              className="flex-1 bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:border-primary outline-none resize-none min-h-[44px] max-h-[120px] transition-colors"
              placeholder="اكتب ردك... (Enter للإرسال)"
              rows={1}
            />
            <button
              type="submit" disabled={sending || !msg.trim()}
              className="p-3 rounded-xl bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-40"
            >
              {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
            </button>
          </>
        )}
      </form>
    </div>
  );
}

export default function SupportTicketsPage() {
  const [showNew, setShowNew] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const qc = useQueryClient();

  const { data, isLoading, refetch } = useQuery<{ tickets: Ticket[] }>({
    queryKey: ['support-tickets'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/support/tickets`, { headers: authHeaders() });
      if (!r.ok) throw new Error();
      return r.json();
    },
    refetchInterval: 15_000,
  });

  const selectedTicket = data?.tickets.find(t => t.id === selectedId);

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-2xl mx-auto" dir="rtl">
          {selectedTicket ? (
            <ChatView ticket={selectedTicket} onBack={() => setSelectedId(null)} />
          ) : (
            <>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h1 className="text-xl font-black flex items-center gap-2">
                    <MessageCircle size={20} className="text-primary" />
                    تذاكر الدعم
                  </h1>
                  <p className="text-xs text-muted-foreground mt-0.5">تواصل مع فريق الدعم مباشرةً</p>
                </div>
                <button
                  onClick={() => setShowNew(true)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-primary text-white rounded-xl text-sm font-bold hover:bg-primary/90 transition-colors"
                >
                  <Plus size={15} />
                  تذكرة جديدة
                </button>
              </div>

              {isLoading ? (
                <div className="flex justify-center py-16"><Loader2 className="animate-spin text-primary" size={32} /></div>
              ) : !data?.tickets.length ? (
                <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col items-center justify-center py-20 gap-4 text-center"
                >
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                    <MessageCircle size={28} className="text-primary" />
                  </div>
                  <div>
                    <p className="font-bold">لا توجد تذاكر بعد</p>
                    <p className="text-sm text-muted-foreground mt-1">افتح تذكرة جديدة وسنرد عليك في أقرب وقت</p>
                  </div>
                  <button onClick={() => setShowNew(true)}
                    className="px-5 py-2.5 bg-primary text-white rounded-xl font-bold text-sm hover:bg-primary/90 transition-colors"
                  >
                    افتح تذكرتك الأولى
                  </button>
                </motion.div>
              ) : (
                <div className="space-y-2">
                  {data.tickets.map((t, i) => {
                    const scfg = STATUS_CFG[t.status];
                    const SIcon = scfg.icon;
                    const pcfg = PRIORITY_CFG[t.priority];
                    return (
                      <motion.button
                        key={t.id}
                        initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.04 }}
                        onClick={() => setSelectedId(t.id)}
                        className="w-full text-right bg-card border border-border rounded-2xl p-4 hover:border-primary/40 hover:bg-primary/5 transition-all group flex items-center gap-3"
                      >
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${t.status === 'open' ? 'bg-blue-500/10' : t.status === 'in_progress' ? 'bg-yellow-500/10' : 'bg-emerald-500/10'}`}>
                          <SIcon size={16} className={scfg.color} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm truncate">{t.subject}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className={`text-[10px] font-bold ${scfg.color}`}>{scfg.label}</span>
                            <span className="text-[10px] text-muted-foreground">·</span>
                            <span className={`text-[10px] font-bold ${pcfg.color}`}>{pcfg.label}</span>
                            <span className="text-[10px] text-muted-foreground">·</span>
                            <span className="text-[10px] text-muted-foreground">{elapsed(t.updatedAt)}</span>
                            {t.orderId && (
                              <>
                                <span className="text-[10px] text-muted-foreground">·</span>
                                <span className="text-[10px] text-muted-foreground flex items-center gap-0.5"><Package size={9} /> {t.orderId}</span>
                              </>
                            )}
                          </div>
                        </div>
                        <ChevronRight size={15} className="text-muted-foreground group-hover:text-primary transition-colors" />
                      </motion.button>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </DashboardLayout>

      <AnimatePresence>
        {showNew && (
          <NewTicketModal
            onClose={() => setShowNew(false)}
            onCreated={() => qc.invalidateQueries({ queryKey: ['support-tickets'] })}
          />
        )}
      </AnimatePresence>
    </ProtectedRoute>
  );
}
