import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, Check, X, Eye, EyeOff, Loader2, Zap, Sparkles, ArrowUp, ArrowDown } from 'lucide-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const authHeaders = (): Record<string, string> => {
  const t = localStorage.getItem('elite_token');
  return t ? { Authorization: `Bearer ${t}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
};

type Banner = {
  id: number;
  title: string;
  subtitle: string;
  badgeText: string;
  badge2Text: string;
  ctaText: string;
  ctaHref: string;
  ctaSecondaryText: string;
  ctaSecondaryHref: string;
  bgGradient: string;
  accentColor: string;
  glow1: string;
  glow2: string;
  emoji: string;
  icon: string;
  iconEnabled: boolean;
  sortOrder: number;
  isActive: boolean;
};

const empty: Omit<Banner, 'id'> = {
  title: 'عنوان جديد\nسطر ثاني',
  subtitle: 'وصف قصير',
  badgeText: '🎮 جديد',
  badge2Text: '🏆 مميز',
  ctaText: 'تسوق الآن',
  ctaHref: '/games?category=mobile_games',
  ctaSecondaryText: 'اعرف المزيد',
  ctaSecondaryHref: '/games?category=mobile_games',
  bgGradient: 'linear-gradient(135deg, #0d0025 0%, #1e0060 40%, #0a0a2e 100%)',
  accentColor: '#6C5CE7',
  glow1: '#6C5CE7',
  glow2: '#a29bfe',
  emoji: '🎮',
  icon: '🕹️',
  iconEnabled: false,
  sortOrder: 0,
  isActive: true,
};

function BannerPreview({ b }: { b: Partial<Banner> }) {
  return (
    <div className="rounded-2xl overflow-hidden relative w-full" style={{ background: b.bgGradient || '#111', height: 160, border: `1px solid ${b.accentColor}40` }} dir="rtl">
      <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full" style={{ background: `radial-gradient(circle, ${b.glow1}50, transparent 70%)` }} />
      <div className="absolute -left-6 -bottom-6 w-28 h-28 rounded-full" style={{ background: `radial-gradient(circle, ${b.glow2}40, transparent 70%)` }} />
      <div className="relative p-3 flex flex-col justify-between h-full">
        <div className="flex items-center justify-between">
          <div className="px-2 py-1 rounded-full text-[10px] font-black text-white" style={{ background: `${b.accentColor}30`, border: `1px solid ${b.accentColor}50` }}>{b.badgeText}</div>
          <div className="px-2 py-1 rounded-full text-[10px] font-bold text-white/80" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}>{b.badge2Text}</div>
        </div>
        <div>
          <h3 className="font-black text-white text-sm leading-tight whitespace-pre-line" style={{ textShadow: `0 0 20px ${b.accentColor}60` }}>{b.title}</h3>
          <p className="text-[10px] mt-1" style={{ color: `${b.accentColor}cc` }}>{b.subtitle}</p>
          <div className="flex gap-2 mt-2">
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-black text-white" style={{ background: `linear-gradient(135deg, ${b.accentColor}, ${b.glow2})` }}>
              <Zap size={9} />{b.ctaText}
            </span>
            <span className="px-2 py-1 rounded-lg text-[10px] font-bold text-white/80" style={{ background: 'rgba(255,255,255,0.07)' }}>{b.ctaSecondaryText}</span>
          </div>
        </div>
        {b.iconEnabled && (
          <div className="absolute bottom-2 left-2 w-8 h-8 rounded-lg flex items-center justify-center text-base" style={{ background: `${b.accentColor}22`, border: `1px solid ${b.accentColor}40` }}>{b.icon}</div>
        )}
      </div>
    </div>
  );
}

function BannerForm({ initial, onSave, onCancel, saving }: {
  initial: Omit<Banner, 'id'>;
  onSave: (data: Omit<Banner, 'id'>) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [form, setForm] = useState(initial);
  const set = (k: keyof typeof form, v: any) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="space-y-4" dir="rtl">
      <BannerPreview b={form} />

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-gray-400 mb-1 block">العنوان (السطر الجديد بـ \n)</label>
          <textarea value={form.title} onChange={e => set('title', e.target.value)} rows={2} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white focus:outline-none focus:border-primary/50" />
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1 block">الوصف</label>
          <input value={form.subtitle} onChange={e => set('subtitle', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white focus:outline-none focus:border-primary/50" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-gray-400 mb-1 block">شارة 1</label>
          <input value={form.badgeText} onChange={e => set('badgeText', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1 block">شارة 2</label>
          <input value={form.badge2Text} onChange={e => set('badge2Text', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-gray-400 mb-1 block">زر رئيسي — نص</label>
          <input value={form.ctaText} onChange={e => set('ctaText', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1 block">زر رئيسي — رابط</label>
          <input value={form.ctaHref} onChange={e => set('ctaHref', e.target.value)} placeholder="/games?category=mobile_games" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-gray-400 mb-1 block">زر ثانوي — نص</label>
          <input value={form.ctaSecondaryText} onChange={e => set('ctaSecondaryText', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1 block">زر ثانوي — رابط</label>
          <input value={form.ctaSecondaryHref} onChange={e => set('ctaSecondaryHref', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
      </div>

      <div>
        <label className="text-xs text-gray-400 mb-1 block">تدرج الخلفية (CSS)</label>
        <input value={form.bgGradient} onChange={e => set('bgGradient', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
      </div>

      <div className="grid grid-cols-3 gap-3">
        {(['accentColor', 'glow1', 'glow2'] as const).map(k => (
          <div key={k}>
            <label className="text-xs text-gray-400 mb-1 block">{k}</label>
            <div className="flex items-center gap-2">
              <input type="color" value={form[k]} onChange={e => set(k, e.target.value)} className="w-10 h-9 rounded-lg border border-border cursor-pointer bg-transparent" />
              <input value={form[k]} onChange={e => set(k, e.target.value)} className="flex-1 px-2 py-2 bg-background border border-border rounded-xl text-xs text-white" />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div>
          <label className="text-xs text-gray-400 mb-1 block">إيموجي</label>
          <input value={form.emoji} onChange={e => set('emoji', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1 block">أيقونة جانبية</label>
          <input value={form.icon} onChange={e => set('icon', e.target.value)} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1 block">الترتيب</label>
          <input type="number" value={form.sortOrder} onChange={e => set('sortOrder', Number(e.target.value))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm text-white" />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <input type="checkbox" id="iconEnabled" checked={form.iconEnabled} onChange={e => set('iconEnabled', e.target.checked)} className="w-4 h-4 accent-purple-500" />
        <label htmlFor="iconEnabled" className="text-sm text-gray-300">إظهار الأيقونة الجانبية في الزاوية اليسار</label>
      </div>

      <div className="flex items-center gap-2">
        <input type="checkbox" id="isActive" checked={form.isActive} onChange={e => set('isActive', e.target.checked)} className="w-4 h-4 accent-purple-500" />
        <label htmlFor="isActive" className="text-sm text-gray-300">مفعّل (يظهر في الواجهة)</label>
      </div>

      <div className="flex gap-3 pt-2">
        <button onClick={() => onSave(form)} disabled={saving}
          className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)' }}>
          {saving ? <Loader2 size={15} className="animate-spin" /> : <><Check size={15} /> حفظ</>}
        </button>
        <button onClick={onCancel} className="px-5 py-2.5 rounded-xl text-sm font-bold text-gray-400 border border-border hover:border-primary/40">إلغاء</button>
      </div>
    </div>
  );
}

export default function AdminBanners() {
  const { toast } = useToast();
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ mode: 'create' | 'edit'; banner?: Banner } | null>(null);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);

  const handleSeedDefaults = async () => {
    if (!confirm('سيتم إضافة 5 بانرات جاهزة (مفعّلة) + 5 اقتراحات (موقوفة) — تابع؟')) return;
    setSeeding(true);
    try {
      const r = await fetch(`${BASE}/api/admin/banners/seed-defaults`, { method: 'POST', headers: authHeaders() });
      if (!r.ok) throw new Error();
      const data = await r.json();
      toast({ title: '✅ تمت الإضافة', description: `${data.activeCount} بانر مفعّل + ${data.inactiveCount} اقتراح موقوف` });
      load();
    } catch {
      toast({ title: 'خطأ', description: 'تعذر تعبئة البانرات', variant: 'destructive' });
    } finally {
      setSeeding(false);
    }
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/admin/banners`, { headers: authHeaders() });
      if (r.ok) setBanners(await r.json());
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const handleSave = async (data: Omit<Banner, 'id'>) => {
    setSaving(true);
    try {
      if (modal?.mode === 'edit' && modal.banner) {
        const r = await fetch(`${BASE}/api/admin/banners/${modal.banner.id}`, {
          method: 'PUT', headers: authHeaders(), body: JSON.stringify(data),
        });
        if (!r.ok) throw new Error();
        toast({ title: 'تم التعديل' });
      } else {
        const r = await fetch(`${BASE}/api/admin/banners`, {
          method: 'POST', headers: authHeaders(), body: JSON.stringify(data),
        });
        if (!r.ok) throw new Error();
        toast({ title: 'تمت الإضافة' });
      }
      setModal(null);
      load();
    } catch {
      toast({ title: 'خطأ', description: 'تعذر الحفظ', variant: 'destructive' });
    } finally { setSaving(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('حذف هذا البانر؟')) return;
    const r = await fetch(`${BASE}/api/admin/banners/${id}`, { method: 'DELETE', headers: authHeaders() });
    if (r.ok) { toast({ title: 'تم الحذف' }); load(); }
  };

  const toggleActive = async (b: Banner) => {
    await fetch(`${BASE}/api/admin/banners/${b.id}`, {
      method: 'PUT', headers: authHeaders(), body: JSON.stringify({ isActive: !b.isActive }),
    });
    load();
  };

  const swapOrder = async (idx: number, dir: -1 | 1) => {
    const sorted = [...banners].sort((a, b) => a.sortOrder - b.sortOrder);
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= sorted.length) return;
    const a = sorted[idx];
    const b = sorted[targetIdx];
    // optimistic UI
    setBanners(prev => prev.map(x =>
      x.id === a.id ? { ...x, sortOrder: b.sortOrder } :
      x.id === b.id ? { ...x, sortOrder: a.sortOrder } : x
    ));
    try {
      await Promise.all([
        fetch(`${BASE}/api/admin/banners/${a.id}`, { method: 'PUT', headers: authHeaders(), body: JSON.stringify({ sortOrder: b.sortOrder }) }),
        fetch(`${BASE}/api/admin/banners/${b.id}`, { method: 'PUT', headers: authHeaders(), body: JSON.stringify({ sortOrder: a.sortOrder }) }),
      ]);
      load();
    } catch {
      toast({ title: 'خطأ', description: 'تعذّر تحديث الترتيب', variant: 'destructive' });
      load();
    }
  };

  const sortedBanners = [...banners].sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h1 className="font-heading text-2xl font-bold text-white">بانرات الصفحة الرئيسية</h1>
              <p className="text-muted-foreground text-sm mt-1">{banners.length} بانر · يظهرون في السلايدر العلوي</p>
            </div>
            <div className="flex gap-2">
              <button onClick={handleSeedDefaults} disabled={seeding} className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-br from-amber-500 to-orange-600 text-white rounded-xl text-sm font-semibold hover:opacity-90 disabled:opacity-50">
                {seeding ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                تعبئة بانرات افتراضية
              </button>
              <button onClick={() => setModal({ mode: 'create' })} className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90">
                <Plus size={14} /> بانر جديد
              </button>
            </div>
          </div>

          {loading ? (
            <div className="py-12 text-center"><Loader2 className="animate-spin mx-auto text-primary" /></div>
          ) : banners.length === 0 ? (
            <div className="text-center py-16 bg-card border border-border rounded-2xl space-y-4">
              <p className="text-muted-foreground">لا توجد بانرات بعد</p>
              <div className="flex gap-3 justify-center flex-wrap">
                <button onClick={handleSeedDefaults} disabled={seeding} className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-gradient-to-br from-amber-500 to-orange-600 hover:opacity-90 disabled:opacity-50 flex items-center gap-2">
                  {seeding ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                  ابدأ بـ 10 بانرات جاهزة
                </button>
                <button onClick={() => setModal({ mode: 'create' })} className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold">
                  <Plus size={14} className="inline ml-1" /> أو أضف بانر يدوي
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sortedBanners.map((b, idx) => (
                <div key={b.id} className="bg-card border border-border rounded-2xl p-3 space-y-3">
                  <BannerPreview b={b} />
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="text-xs text-white/70">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-white/10 font-bold text-white ml-1">{idx + 1}</span>
                      {b.isActive ? '✅ مفعّل' : '⏸ متوقف'}
                    </div>
                    <div className="flex gap-1.5 flex-wrap">
                      <button onClick={() => swapOrder(idx, -1)} disabled={idx === 0}
                        className="p-2 rounded-lg bg-white/5 hover:bg-blue-500/30 disabled:opacity-30 disabled:cursor-not-allowed" title="رفع للأعلى">
                        <ArrowUp size={13} className="text-white" />
                      </button>
                      <button onClick={() => swapOrder(idx, 1)} disabled={idx === sortedBanners.length - 1}
                        className="p-2 rounded-lg bg-white/5 hover:bg-blue-500/30 disabled:opacity-30 disabled:cursor-not-allowed" title="نزول للأسفل">
                        <ArrowDown size={13} className="text-white" />
                      </button>
                      <button onClick={() => toggleActive(b)} className="p-2 rounded-lg bg-white/5 hover:bg-yellow-500/30" title={b.isActive ? 'إخفاء' : 'إظهار'}>
                        {b.isActive ? <EyeOff size={13} className="text-white" /> : <Eye size={13} className="text-white" />}
                      </button>
                      <button onClick={() => setModal({ mode: 'edit', banner: b })} className="p-2 rounded-lg bg-white/5 hover:bg-purple-500/30" title="تعديل">
                        <Pencil size={13} className="text-white" />
                      </button>
                      <button onClick={() => handleDelete(b.id)} className="p-2 rounded-lg bg-white/5 hover:bg-red-500/30" title="حذف">
                        <Trash2 size={13} className="text-white" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <AnimatePresence>
          {modal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/60" onClick={() => setModal(null)} />
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
                className="relative bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between p-4 border-b border-border sticky top-0 bg-card z-10">
                  <h2 className="font-bold text-white">{modal.mode === 'edit' ? 'تعديل بانر' : 'بانر جديد'}</h2>
                  <button onClick={() => setModal(null)} className="p-2 rounded-xl hover:bg-white/10"><X size={16} className="text-gray-400" /></button>
                </div>
                <div className="p-5">
                  <BannerForm
                    initial={modal.banner ? { ...modal.banner } : { ...empty }}
                    onSave={handleSave}
                    onCancel={() => setModal(null)}
                    saving={saving}
                  />
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
