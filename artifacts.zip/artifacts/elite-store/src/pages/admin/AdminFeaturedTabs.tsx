import React, { useEffect, useMemo, useState } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';
import {
  Star, Plus, Trash2, ArrowUp, ArrowDown, Save, Loader2,
  Image as ImageIcon, Pencil, X, Check, Search, GripVertical, Package, FlaskConical, Wand2,
} from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

const CATEGORY_OPTIONS = [
  { value: 'mobile_games', label: 'ألعاب الهاتف' },
  { value: 'pc_games', label: 'ألعاب الكمبيوتر' },
  { value: 'gift_cards', label: 'بطاقات الهدايا' },
  { value: 'services', label: 'الخدمات الرقمية' },
  { value: 'general', label: 'خدمات متنوعة' },
];

type FeaturedGame = {
  id: string; nameAr: string; nameEn: string; color: string; emoji: string;
  imageUrl?: string;
  category: string; keywords: string[]; sortOrder: number; isActive: boolean;
};
type SubTab = {
  key: string; labelAr: string; labelEn: string;
  keywords: string[]; subGroups: string[];
  sortOrder: number; isActive: boolean;
};
type Product = {
  id: string; name: string; nameAr?: string | null;
  description?: string | null; subGroup?: string | null;
  imageOverride?: string | null;
  priceUsd: number; profitMargin?: string | number;
  status: string; sortOrder: number;
  category: string; provider?: string;
  autoApprove?: boolean;
};

const tk = () => localStorage.getItem('elite_token') || '';
const adminFetch = (url: string, init: RequestInit = {}) =>
  fetch(url, { ...init, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tk()}`, ...(init.headers || {}) } });

async function uploadImage(file: File): Promise<string | null> {
  const fd = new FormData(); fd.append('image', file);
  const r = await fetch(`${BASE}/api/admin/upload/image`, { method: 'POST', headers: { Authorization: `Bearer ${tk()}` }, body: fd });
  if (!r.ok) return null;
  const j = await r.json();
  return j.url || null;
}

// ─── Live preview of a featured card (mimics storefront) ──────────────────────
function CardPreview({ g, count }: { g: FeaturedGame; count: number }) {
  return (
    <div className="relative rounded-2xl overflow-hidden border border-border" style={{ background: `linear-gradient(135deg, ${g.color}25, ${g.color}05)` }}>
      <div className="absolute inset-0 opacity-20" style={{ background: `radial-gradient(circle at 30% 30%, ${g.color}, transparent 60%)` }} />
      <div className="relative p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">⭐ الأكثر طلباً</span>
          <span className="text-xs font-bold text-white/80 bg-black/30 px-2 py-0.5 rounded-full">{count} ⚡</span>
        </div>
        <div className="flex items-center justify-center py-3">
          <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center overflow-hidden">
            {g.imageUrl ? <img src={g.imageUrl} alt="" className="w-full h-full object-cover" /> : <span className="text-4xl">{g.emoji}</span>}
          </div>
        </div>
        <div>
          <div className="text-base font-bold text-white">{g.nameAr}</div>
          <div className="text-[11px] text-white/60">{count} باقة متاحة</div>
        </div>
      </div>
    </div>
  );
}

// ─── Compact card item for the left sidebar list ──────────────────────────────
function CardListItem({ g, selected, onClick }: { g: FeaturedGame; selected: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className={`w-full text-right p-3 rounded-xl border transition-all flex items-center gap-3 ${selected ? 'bg-primary/15 border-primary/50 shadow-lg shadow-primary/10' : 'bg-card/60 border-border hover:border-primary/30 hover:bg-card'}`}>
      <div className="w-12 h-12 rounded-xl flex items-center justify-center overflow-hidden shrink-0" style={{ background: `${g.color}30`, border: `1px solid ${g.color}50` }}>
        {g.imageUrl ? <img src={g.imageUrl} alt="" className="w-full h-full object-cover" /> : <span className="text-2xl">{g.emoji}</span>}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-bold truncate">{g.nameAr || g.nameEn}</div>
        <div className="text-[10px] text-muted-foreground truncate font-mono">{g.id}</div>
      </div>
      {!g.isActive && <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30">معطّل</span>}
    </button>
  );
}

export default function AdminFeaturedTabs() {
  const { toast } = useToast();
  const [games, setGames] = useState<FeaturedGame[]>([]);
  const [subtabs, setSubtabs] = useState<Record<string, SubTab[]>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedTabKey, setSelectedTabKey] = useState<string>('all');
  const [editingTabIdx, setEditingTabIdx] = useState<number | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [editPriceFor, setEditPriceFor] = useState<Product | null>(null);
  const [testResult, setTestResult] = useState<null | { name: string; success: boolean; message: string; checks: Array<{ name: string; ok: boolean; detail?: string }> }>(null);
  const [testing, setTesting] = useState(false);

  const runTestOrder = async (p: Product) => {
    setTesting(true);
    setTestResult({ name: p.name, success: false, message: 'جاري الفحص...', checks: [] });
    try {
      const r = await adminFetch(`${BASE}/api/admin/products/${p.id}/test-order`, { method: 'POST', body: '{}' });
      const j = await r.json();
      setTestResult({ name: j.productName || p.name, success: j.success, message: j.message, checks: j.checks || [] });
    } catch {
      setTestResult({ name: p.name, success: false, message: 'فشل الاتصال بالخادم', checks: [] });
    } finally { setTesting(false); }
  };
  const [dragId, setDragId] = useState<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);
  const [dropOverCardId, setDropOverCardId] = useState<string | null>(null);
  const [showAutoGen, setShowAutoGen] = useState(false);
  const [autoGenLoading, setAutoGenLoading] = useState(false);
  const [autoGenSuggestions, setAutoGenSuggestions] = useState<Array<FeaturedGame & { productCount: number; alreadyExists: boolean; provider: string }>>([]);
  const [autoGenPicks, setAutoGenPicks] = useState<Set<string>>(new Set());
  const [autoGenCategory, setAutoGenCategory] = useState<string>('');

  const openAutoGen = async () => {
    setShowAutoGen(true);
    setAutoGenLoading(true);
    setAutoGenSuggestions([]);
    setAutoGenPicks(new Set());
    try {
      const qs = new URLSearchParams();
      if (autoGenCategory) qs.set('category', autoGenCategory);
      qs.set('min', '2');
      const r = await adminFetch(`${BASE}/api/admin/featured-games/auto-generate?${qs.toString()}`);
      const j = await r.json();
      const sug = (j.suggestions ?? []) as Array<FeaturedGame & { productCount: number; alreadyExists: boolean; provider: string }>;
      setAutoGenSuggestions(sug);
      // Pre-pick non-existing ones with >= 3 products
      setAutoGenPicks(new Set(sug.filter(s => !s.alreadyExists && (s.productCount ?? 0) >= 3).map(s => s.id)));
    } catch {
      toast({ title: 'تعذر جلب الاقتراحات', variant: 'destructive' });
    } finally {
      setAutoGenLoading(false);
    }
  };

  const applyAutoGen = () => {
    const picked = autoGenSuggestions.filter(s => autoGenPicks.has(s.id))
      .map(({ productCount: _pc, alreadyExists: _ae, provider: _pr, ...g }) => g);
    if (picked.length === 0) { setShowAutoGen(false); return; }
    setGames(prev => {
      const existingIds = new Set(prev.map(g => g.id));
      const fresh = picked.filter(p => !existingIds.has(p.id))
        .map((g, i) => ({ ...g, sortOrder: prev.length + i }));
      return [...prev, ...fresh];
    });
    setShowAutoGen(false);
    toast({ title: `✅ أُضيف ${picked.length} كرت — لا تنسى الضغط على "حفظ كل التغييرات"` });
  };

  const unassignProductFromCard = async (productId: string) => {
    if (!confirm('إزالة هذا المنتج من الكرت؟ سيرجع للظهور فقط عبر الكلمات المفتاحية إن طابقها.')) return;
    try {
      const r = await adminFetch(`${BASE}/api/admin/featured-games/assign-product`, {
        method: 'POST', body: JSON.stringify({ productId, cardId: null }),
      });
      if (!r.ok) throw new Error();
      toast({ title: '✅ أُزيل المنتج من الكرت' });
      setProducts(prev => prev.filter(p => p.id !== productId));
    } catch { toast({ title: 'فشل إزالة المنتج', variant: 'destructive' }); }
  };

  const assignProductToCard = async (productId: string, cardId: string) => {
    try {
      const r = await adminFetch(`${BASE}/api/admin/featured-games/assign-product`, {
        method: 'POST', body: JSON.stringify({ productId, cardId }),
      });
      if (!r.ok) throw new Error();
      toast({ title: '✅ تم نقل المنتج للكرت' });
      // If we moved AWAY from currently-viewed card, drop it from list
      if (cardId !== selectedId) {
        setProducts(prev => prev.filter(p => p.id !== productId));
      }
    } catch { toast({ title: 'فشل نقل المنتج', variant: 'destructive' }); }
  };

  const selected = games.find(g => g.id === selectedId) || null;
  const tabs = (selectedId && subtabs[selectedId]) || [];

  // ── Load
  const load = async () => {
    setLoading(true);
    try {
      const [r1, r2] = await Promise.all([
        fetch(`${BASE}/api/featured-games`),
        fetch(`${BASE}/api/game-group-subtabs`),
      ]);
      const j1 = await r1.json();
      const j2 = await r2.json();
      const list = (j1.items as FeaturedGame[]) ?? [];
      setGames(list);
      setSubtabs((j2.groups as Record<string, SubTab[]>) ?? {});
      if (!selectedId && list.length) setSelectedId(list[0].id);
    } catch { toast({ title: 'تعذر التحميل', variant: 'destructive' }); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  // ── Load products for selected card
  useEffect(() => {
    if (!selectedId) { setProducts([]); return; }
    setLoadingProducts(true);
    fetch(`${BASE}/api/products?game_group=${encodeURIComponent(selectedId)}&limit=1000`)
      .then(r => r.json())
      .then(j => setProducts((j.products ?? []) as Product[]))
      .catch(() => setProducts([]))
      .finally(() => setLoadingProducts(false));
    setSelectedTabKey('all');
    setEditingTabIdx(null);
  }, [selectedId]);

  // ── Card mutations
  const updateGame = (patch: Partial<FeaturedGame>) =>
    setGames(prev => prev.map(g => g.id === selectedId ? { ...g, ...patch } : g));

  const addGame = () => {
    const id = `game_${Date.now()}`;
    const ng: FeaturedGame = {
      id, nameAr: 'لعبة جديدة', nameEn: 'New Game', color: '#8b5cf6', emoji: '🎮',
      category: 'mobile_games', keywords: [], sortOrder: games.length, isActive: true,
    };
    setGames(prev => [...prev, ng]);
    setSelectedId(id);
  };

  const removeGame = (id: string) => {
    if (!confirm('حذف هذا الكرت؟')) return;
    setGames(prev => prev.filter(g => g.id !== id).map((g, i) => ({ ...g, sortOrder: i })));
    if (selectedId === id) setSelectedId(null);
  };

  const moveGame = (id: string, dir: -1 | 1) => {
    const idx = games.findIndex(g => g.id === id);
    const j = idx + dir;
    if (idx < 0 || j < 0 || j >= games.length) return;
    const next = [...games];
    [next[idx], next[j]] = [next[j], next[idx]];
    setGames(next.map((g, i) => ({ ...g, sortOrder: i })));
  };

  // ── Tab mutations
  const updateTab = (i: number, patch: Partial<SubTab>) =>
    setSubtabs(prev => ({ ...prev, [selectedId!]: (prev[selectedId!] ?? []).map((t, idx) => idx === i ? { ...t, ...patch } : t) }));

  const addTab = () => {
    if (!selectedId) return;
    setSubtabs(prev => {
      const list = prev[selectedId] ?? [];
      const ensureAll = list.some(t => t.key === 'all') ? list : [{ key: 'all', labelAr: 'الكل', labelEn: 'All', keywords: [], subGroups: [], sortOrder: 0, isActive: true }, ...list];
      const nt: SubTab = { key: `tab_${Date.now()}`, labelAr: 'تبويب جديد', labelEn: 'New tab', keywords: [], subGroups: [], sortOrder: ensureAll.length, isActive: true };
      return { ...prev, [selectedId]: [...ensureAll, nt] };
    });
    setEditingTabIdx((tabs.length || 0));
  };

  const removeTab = (i: number) => {
    if (!confirm('حذف هذا التبويب؟')) return;
    setSubtabs(prev => ({ ...prev, [selectedId!]: (prev[selectedId!] ?? []).filter((_, idx) => idx !== i).map((t, k) => ({ ...t, sortOrder: k })) }));
    setEditingTabIdx(null);
  };

  const moveTab = (i: number, dir: -1 | 1) => {
    const list = tabs;
    const j = i + dir;
    if (j < 0 || j >= list.length) return;
    const next = [...list];
    [next[i], next[j]] = [next[j], next[i]];
    setSubtabs(prev => ({ ...prev, [selectedId!]: next.map((t, k) => ({ ...t, sortOrder: k })) }));
  };

  // ── Save all (cards + tabs together)
  const saveAll = async () => {
    setSaving(true);
    try {
      const [r1, r2] = await Promise.all([
        adminFetch(`${BASE}/api/admin/featured-games`, { method: 'PUT', body: JSON.stringify({ items: games }) }),
        adminFetch(`${BASE}/api/admin/game-group-subtabs`, { method: 'PUT', body: JSON.stringify({ groups: subtabs }) }),
      ]);
      if (!r1.ok || !r2.ok) throw new Error();
      toast({ title: '✅ تم حفظ كل التغييرات' });
    } catch { toast({ title: 'فشل الحفظ', variant: 'destructive' }); }
    finally { setSaving(false); }
  };

  // ── Filter products by selected sub-tab
  const filteredProducts = useMemo(() => {
    let list = products;
    const tab = tabs.find(t => t.key === selectedTabKey);
    if (tab && tab.key !== 'all') {
      const subs = (tab.subGroups || []).map(s => s.toLowerCase());
      const kws = (tab.keywords || []).map(s => s.toLowerCase());
      list = list.filter(p => {
        const sg = (p.subGroup || '').toLowerCase();
        const desc = (p.description || '').toLowerCase();
        const name = (p.name || '').toLowerCase();
        const okSub = subs.length === 0 || subs.some(s => sg.includes(s));
        const okKw = kws.length === 0 || kws.some(k => desc.includes(k) || name.includes(k));
        return (subs.length > 0 ? okSub : true) || (kws.length > 0 ? okKw : false);
      });
    }
    if (productSearch.trim()) {
      const q = productSearch.trim().toLowerCase();
      list = list.filter(p => (p.name || '').toLowerCase().includes(q) || (p.nameAr || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q));
    }
    return [...list].sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0) || a.priceUsd - b.priceUsd);
  }, [products, tabs, selectedTabKey, productSearch]);

  // ── Per-product update helper
  const updateProductLocal = (id: string, patch: Partial<Product>) =>
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...patch } : p));

  const saveProduct = async (id: string, patch: Record<string, any>) => {
    try {
      const r = await adminFetch(`${BASE}/api/admin/products/${id}`, { method: 'PUT', body: JSON.stringify(patch) });
      if (!r.ok) throw new Error();
      updateProductLocal(id, patch as any);
      toast({ title: '✅ تم التحديث' });
    } catch { toast({ title: 'فشل التحديث', variant: 'destructive' }); }
  };

  // ── Drag & drop reorder ───────────────────────────────────────────────────
  const handleDrop = async (targetId: string) => {
    if (!dragId || dragId === targetId) { setDragId(null); setDragOverId(null); return; }
    const visible = filteredProducts;
    const fromIdx = visible.findIndex(p => p.id === dragId);
    const toIdx = visible.findIndex(p => p.id === targetId);
    if (fromIdx < 0 || toIdx < 0) { setDragId(null); setDragOverId(null); return; }
    const reordered = [...visible];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    // Assign sortOrder values based on new visual position (step 10 to allow inserts)
    const orders = reordered.map((p, i) => ({ id: p.id, sortOrder: (i + 1) * 10 }));
    // Optimistic local update
    setProducts(prev => {
      const map = new Map(orders.map(o => [o.id, o.sortOrder]));
      return prev.map(p => map.has(p.id) ? { ...p, sortOrder: map.get(p.id)! } : p);
    });
    setDragId(null); setDragOverId(null);
    try {
      const r = await adminFetch(`${BASE}/api/admin/products/reorder`, { method: 'POST', body: JSON.stringify({ orders }) });
      if (!r.ok) throw new Error();
    } catch { toast({ title: 'فشل تحديث الترتيب', variant: 'destructive' }); }
  };

  const handleProductImage = async (p: Product, file: File) => {
    const url = await uploadImage(file);
    if (!url) { toast({ title: 'فشل رفع الصورة', variant: 'destructive' }); return; }
    await saveProduct(p.id, { imageOverride: url });
  };

  const subgroupOptions = useMemo(() => {
    const set = new Set<string>();
    tabs.forEach(t => (t.subGroups || []).forEach(s => set.add(s)));
    products.forEach(p => p.subGroup && set.add(p.subGroup));
    return Array.from(set).filter(Boolean).sort();
  }, [tabs, products]);

  if (loading) {
    return (
      <ProtectedRoute adminOnly>
        <DashboardLayout>
          <div className="flex items-center justify-center py-24"><Loader2 className="animate-spin" /></div>
        </DashboardLayout>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-4" dir="rtl">
          {/* Header */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h1 className="font-heading text-xl sm:text-2xl font-bold flex items-center gap-2"><Star className="text-amber-400" /> الكروت المميزة والتبويبات</h1>
              <p className="text-muted-foreground text-xs sm:text-sm mt-1">حدّد كرت من اليمين لتعديله مباشرة وإدارة تبويباته ومنتجاته.</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={openAutoGen}
                className="px-4 py-2.5 rounded-xl text-sm font-bold bg-violet-500/15 text-violet-300 border border-violet-500/40 hover:bg-violet-500/25 flex items-center gap-2"
                title="أنشئ كروت تلقائياً من فئات المزوّد المتزامنة">
                <Wand2 size={14} /> توليد كروت من المنتجات
              </button>
              <button onClick={saveAll} disabled={saving}
                className="px-4 py-2.5 rounded-xl text-sm font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 flex items-center gap-2 disabled:opacity-50">
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                حفظ كل التغييرات
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-4">
            {/* ─── Left: Cards list ─────────────────────────────────────── */}
            <aside className="bg-card/40 border border-border rounded-2xl p-3 space-y-2 lg:sticky lg:top-4 lg:max-h-[calc(100vh-140px)] lg:overflow-y-auto">
              <button onClick={addGame}
                className="w-full p-2.5 rounded-xl text-sm font-bold bg-primary/15 text-primary border border-dashed border-primary/40 hover:bg-primary/25 flex items-center justify-center gap-2">
                <Plus size={14} /> إضافة كرت جديد
              </button>
              {games.length === 0 && <p className="text-center text-xs text-muted-foreground py-6">لا توجد كروت بعد.</p>}
              {games.length > 0 && (
                <p className="text-[10px] text-muted-foreground text-center px-1 pt-1">💡 اسحب أي منتج من اليسار وأفلِته على كرت هنا لنقله إليه</p>
              )}
              {games.map((g, i) => (
                <div key={g.id}
                  onDragOver={(e) => { if (dragId) { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; setDropOverCardId(g.id); } }}
                  onDragLeave={() => setDropOverCardId(prev => prev === g.id ? null : prev)}
                  onDrop={(e) => {
                    e.preventDefault();
                    const productId = dragId || e.dataTransfer.getData('text/plain');
                    setDropOverCardId(null);
                    setDragId(null); setDragOverId(null);
                    if (productId && g.id !== selectedId) assignProductToCard(productId, g.id);
                  }}
                  className={`group relative rounded-xl transition-all ${dropOverCardId === g.id && dragId ? 'ring-2 ring-violet-400 ring-offset-2 ring-offset-background scale-[1.02]' : ''}`}>
                  <CardListItem g={g} selected={selectedId === g.id} onClick={() => setSelectedId(g.id)} />
                  <div className="absolute left-1.5 top-1.5 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={(e) => { e.stopPropagation(); moveGame(g.id, -1); }} disabled={i === 0}
                      className="p-1 rounded bg-background/80 backdrop-blur hover:bg-background disabled:opacity-30"><ArrowUp size={11} /></button>
                    <button onClick={(e) => { e.stopPropagation(); moveGame(g.id, +1); }} disabled={i === games.length - 1}
                      className="p-1 rounded bg-background/80 backdrop-blur hover:bg-background disabled:opacity-30"><ArrowDown size={11} /></button>
                    <button onClick={(e) => { e.stopPropagation(); removeGame(g.id); }}
                      className="p-1 rounded bg-background/80 backdrop-blur text-destructive hover:bg-destructive/15"><Trash2 size={11} /></button>
                  </div>
                </div>
              ))}
            </aside>

            {/* ─── Right: Selected card editor + tabs + products ────────── */}
            <div className="space-y-4 min-w-0">
              {!selected ? (
                <div className="bg-card/40 border border-dashed border-border rounded-2xl p-12 text-center">
                  <Star className="mx-auto mb-3 text-amber-400/50" size={40} />
                  <p className="text-muted-foreground text-sm">اختر كرت من القائمة لبدء التعديل، أو أضف كرت جديد.</p>
                </div>
              ) : (
                <>
                  {/* ── Card editor + preview ───────────────────────── */}
                  <section className="bg-card border border-border rounded-2xl p-4 sm:p-5">
                    <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] gap-4">
                      {/* Live preview */}
                      <div className="space-y-2">
                        <div className="text-[11px] text-muted-foreground font-bold">معاينة مباشرة</div>
                        <CardPreview g={selected} count={products.length} />
                        <label className="block w-full text-center px-3 py-2 rounded-xl text-xs font-bold bg-primary/10 text-primary border border-dashed border-primary/40 hover:bg-primary/20 cursor-pointer">
                          {selected.imageUrl ? '🔄 تغيير صورة الكرت' : '📷 رفع صورة كبيرة للكرت'}
                          <input type="file" accept="image/*" className="hidden" onChange={async e => {
                            const f = e.target.files?.[0]; if (!f) return;
                            const url = await uploadImage(f);
                            if (url) updateGame({ imageUrl: url }); else toast({ title: 'فشل الرفع', variant: 'destructive' });
                            e.target.value = '';
                          }} />
                        </label>
                        {selected.imageUrl && (
                          <button onClick={() => updateGame({ imageUrl: '' })} className="w-full text-center px-3 py-1.5 rounded-xl text-[11px] text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                            🗑️ حذف الصورة (الرجوع للإيموجي)
                          </button>
                        )}
                      </div>

                      {/* Edit fields */}
                      <div className="space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <label className="text-[10px] text-muted-foreground font-bold mb-1 block">الاسم بالعربية</label>
                            <input value={selected.nameAr} onChange={e => updateGame({ nameAr: e.target.value })}
                              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm" />
                          </div>
                          <div>
                            <label className="text-[10px] text-muted-foreground font-bold mb-1 block">Name (EN)</label>
                            <input value={selected.nameEn} onChange={e => updateGame({ nameEn: e.target.value })}
                              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm" />
                          </div>
                          <div>
                            <label className="text-[10px] text-muted-foreground font-bold mb-1 block">المعرّف الفريد</label>
                            <input value={selected.id} onChange={e => updateGame({ id: e.target.value.replace(/\s+/g, '_') })} dir="ltr"
                              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-xs font-mono" />
                          </div>
                          <div>
                            <label className="text-[10px] text-muted-foreground font-bold mb-1 block">التصنيف الرئيسي</label>
                            <select value={selected.category} onChange={e => updateGame({ category: e.target.value })}
                              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm">
                              {CATEGORY_OPTIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] text-muted-foreground font-bold mb-1 block">إيموجي (يستخدم إذا لا توجد صورة)</label>
                            <input value={selected.emoji} onChange={e => updateGame({ emoji: e.target.value })}
                              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-center text-lg" />
                          </div>
                          <div>
                            <label className="text-[10px] text-muted-foreground font-bold mb-1 block">اللون المميز</label>
                            <div className="flex items-center gap-2">
                              <input type="color" value={selected.color} onChange={e => updateGame({ color: e.target.value })}
                                className="w-12 h-10 bg-background border border-border rounded-lg cursor-pointer" />
                              <input value={selected.color} onChange={e => updateGame({ color: e.target.value })} dir="ltr"
                                className="flex-1 px-3 py-2 bg-background border border-border rounded-lg text-xs font-mono" />
                            </div>
                          </div>
                        </div>
                        <div>
                          <label className="text-[10px] text-muted-foreground font-bold mb-1 block">كلمات مطابقة المنتجات (مفصولة بفواصل) — تحدد أي منتجات تظهر تحت هذا الكرت</label>
                          <input value={selected.keywords.join(', ')}
                            onChange={e => updateGame({ keywords: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                            placeholder="شدات, ببجي, pubg"
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm" />
                        </div>
                        <div className="flex items-center justify-between gap-2 pt-1">
                          <label className="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" checked={selected.isActive} onChange={e => updateGame({ isActive: e.target.checked })} className="w-4 h-4 accent-primary" />
                            مفعّل (يظهر في صفحة الألعاب)
                          </label>
                          <button onClick={() => removeGame(selected.id)}
                            className="px-3 py-1.5 rounded-lg text-xs bg-destructive/10 text-destructive border border-destructive/30 hover:bg-destructive/20 flex items-center gap-1">
                            <Trash2 size={12} /> حذف الكرت
                          </button>
                        </div>
                      </div>
                    </div>
                  </section>

                  {/* ── Sub-tabs row ─────────────────────────────────── */}
                  <section className="bg-card border border-border rounded-2xl p-4 sm:p-5">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-bold flex items-center gap-1.5"><Package size={14} className="text-cyan-400" /> تبويبات اللعبة</h3>
                      <button onClick={addTab} className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 flex items-center gap-1">
                        <Plus size={11} /> تبويب
                      </button>
                    </div>
                    <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
                      <button onClick={() => setSelectedTabKey('all')}
                        className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${selectedTabKey === 'all' ? 'bg-primary text-primary-foreground border-primary' : 'bg-background border-border hover:border-primary/40'}`}>
                        الكل ({products.length})
                      </button>
                      {tabs.filter(t => t.key !== 'all').map((t, i) => {
                        const realIdx = tabs.findIndex(x => x.key === t.key);
                        const cnt = products.filter(p => {
                          const sg = (p.subGroup || '').toLowerCase();
                          const desc = (p.description || '').toLowerCase();
                          const subs = (t.subGroups || []).map(s => s.toLowerCase());
                          const kws = (t.keywords || []).map(s => s.toLowerCase());
                          return (subs.length > 0 && subs.some(s => sg.includes(s))) || (kws.length > 0 && kws.some(k => desc.includes(k)));
                        }).length;
                        const isSel = selectedTabKey === t.key;
                        return (
                          <div key={t.key + i} className={`shrink-0 flex items-center gap-1 rounded-xl border transition-colors ${isSel ? 'bg-primary/15 border-primary/50' : 'bg-background border-border hover:border-primary/30'} ${!t.isActive ? 'opacity-50' : ''}`}>
                            <button onClick={() => setSelectedTabKey(t.key)} className="px-3 py-1.5 text-xs font-bold">
                              {t.labelAr} <span className="text-muted-foreground font-normal">({cnt})</span>
                            </button>
                            <button onClick={() => setEditingTabIdx(editingTabIdx === realIdx ? null : realIdx)} className="p-1.5 hover:bg-white/5 rounded-l-xl text-muted-foreground hover:text-primary">
                              <Pencil size={11} />
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    {/* Inline tab editor */}
                    {editingTabIdx !== null && tabs[editingTabIdx] && (
                      <div className="mt-3 p-3 bg-background/60 border border-primary/30 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="text-[11px] text-muted-foreground font-bold">تعديل تبويب: {tabs[editingTabIdx].labelAr}</div>
                          <div className="flex gap-1">
                            <button onClick={() => moveTab(editingTabIdx, -1)} disabled={editingTabIdx === 0} className="p-1 rounded hover:bg-muted disabled:opacity-30"><ArrowUp size={12} /></button>
                            <button onClick={() => moveTab(editingTabIdx, +1)} disabled={editingTabIdx === tabs.length - 1} className="p-1 rounded hover:bg-muted disabled:opacity-30"><ArrowDown size={12} /></button>
                            <button onClick={() => removeTab(editingTabIdx)} className="p-1 rounded text-destructive hover:bg-destructive/15"><Trash2 size={12} /></button>
                            <button onClick={() => setEditingTabIdx(null)} className="p-1 rounded hover:bg-muted"><X size={12} /></button>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <input value={tabs[editingTabIdx].labelAr} onChange={e => updateTab(editingTabIdx, { labelAr: e.target.value })}
                            placeholder="اسم بالعربية" className="px-2 py-1.5 bg-background border border-border rounded-lg text-xs" />
                          <input value={tabs[editingTabIdx].labelEn} onChange={e => updateTab(editingTabIdx, { labelEn: e.target.value })}
                            placeholder="Name (EN)" className="px-2 py-1.5 bg-background border border-border rounded-lg text-xs" />
                          <input value={tabs[editingTabIdx].key} onChange={e => updateTab(editingTabIdx, { key: e.target.value.replace(/\s+/g, '_') })}
                            placeholder="key" dir="ltr" className="px-2 py-1.5 bg-background border border-border rounded-lg text-[11px] font-mono" />
                        </div>
                        <input value={(tabs[editingTabIdx].subGroups || []).join(', ')}
                          onChange={e => updateTab(editingTabIdx, { subGroups: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                          placeholder="subGroups (مفصولة بفواصل): شدات, روبوت — المنتجات اللي subGroup تطابق هاد بتظهر هون"
                          className="w-full px-2 py-1.5 bg-background border border-border rounded-lg text-xs" />
                        <input value={(tabs[editingTabIdx].keywords || []).join(', ')}
                          onChange={e => updateTab(editingTabIdx, { keywords: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                          placeholder="كلمات مطابقة على الوصف (احتياطي): شدات, uc"
                          className="w-full px-2 py-1.5 bg-background border border-border rounded-lg text-xs" />
                        <label className="flex items-center gap-2 text-xs cursor-pointer">
                          <input type="checkbox" checked={tabs[editingTabIdx].isActive} onChange={e => updateTab(editingTabIdx, { isActive: e.target.checked })} className="accent-primary" />
                          مفعّل
                        </label>
                      </div>
                    )}
                  </section>

                  {/* ── Products grid ──────────────────────────────── */}
                  <section className="bg-card border border-border rounded-2xl p-4 sm:p-5">
                    <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
                      <h3 className="text-sm font-bold flex items-center gap-1.5">
                        <Package size={14} className="text-emerald-400" />
                        المنتجات ({filteredProducts.length})
                        <span className="text-[10px] text-muted-foreground font-normal">في تبويب: {tabs.find(t => t.key === selectedTabKey)?.labelAr || 'الكل'}</span>
                      </h3>
                      <div className="relative">
                        <Search size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                        <input value={productSearch} onChange={e => setProductSearch(e.target.value)}
                          placeholder="بحث..." className="pr-7 pl-3 py-1.5 bg-background border border-border rounded-lg text-xs w-44" />
                      </div>
                    </div>

                    {loadingProducts ? (
                      <div className="py-12 text-center"><Loader2 className="animate-spin mx-auto" /></div>
                    ) : filteredProducts.length === 0 ? (
                      <div className="py-12 text-center text-sm text-muted-foreground border border-dashed border-border rounded-xl">
                        لا توجد منتجات في هذا التبويب.
                        <div className="text-[11px] mt-1">جرّب إضافة كلمات مطابقة أو subGroup من تعديل التبويب.</div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-3">
                        {filteredProducts.map(p => (
                          <ProductTile key={p.id}
                            p={p}
                            color={selected.color}
                            subgroupOptions={subgroupOptions}
                            isDragging={dragId === p.id}
                            isDragOver={dragOverId === p.id && dragId !== p.id}
                            onDragStart={() => setDragId(p.id)}
                            onDragOver={() => setDragOverId(p.id)}
                            onDragEnd={() => { setDragId(null); setDragOverId(null); }}
                            onDrop={() => handleDrop(p.id)}
                            onImage={(file) => handleProductImage(p, file)}
                            onSubgroupChange={(sg) => saveProduct(p.id, { subGroup: sg })}
                            onToggleStatus={() => saveProduct(p.id, { status: p.status === 'active' ? 'inactive' : 'active' })}
                            onToggleAuto={() => saveProduct(p.id, { autoApprove: !p.autoApprove })}
                            onMove={(dir) => saveProduct(p.id, { sortOrder: (p.sortOrder ?? 0) + dir })}
                            onEditPrice={() => setEditPriceFor(p)}
                            onTest={() => runTestOrder(p)}
                            onUnassign={() => unassignProductFromCard(p.id)}
                          />
                        ))}
                      </div>
                    )}
                  </section>
                </>
              )}
            </div>
          </div>

          {/* Auto-generate suggestions modal */}
          {showAutoGen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setShowAutoGen(false)}>
              <div className="bg-card border border-border rounded-2xl shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()} dir="rtl">
                <div className="flex items-center gap-2 p-5 border-b border-border">
                  <Wand2 className="text-violet-400" size={22} />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">توليد كروت من فئات المزوّد</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">يقترح كرتاً لكل فئة موجودة في منتجاتك المتزامنة. اختر اللي بدك إياه واضغط إضافة.</p>
                  </div>
                  <button onClick={() => setShowAutoGen(false)} className="p-1 rounded hover:bg-muted"><X size={16} /></button>
                </div>
                <div className="px-5 py-3 border-b border-border flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-muted-foreground">فلتر التصنيف:</span>
                  <select value={autoGenCategory} onChange={e => setAutoGenCategory(e.target.value)}
                    className="px-2.5 py-1.5 bg-background border border-border rounded-lg text-xs">
                    <option value="">الكل</option>
                    {CATEGORY_OPTIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                  </select>
                  <button onClick={openAutoGen} disabled={autoGenLoading}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 disabled:opacity-50">
                    {autoGenLoading ? 'جاري...' : '🔄 إعادة جلب'}
                  </button>
                  <div className="mr-auto flex gap-2">
                    <button onClick={() => setAutoGenPicks(new Set(autoGenSuggestions.filter(s => !s.alreadyExists).map(s => s.id)))}
                      className="px-2 py-1 rounded text-[10px] bg-muted hover:bg-muted/70">تحديد كل الجديد</button>
                    <button onClick={() => setAutoGenPicks(new Set())}
                      className="px-2 py-1 rounded text-[10px] bg-muted hover:bg-muted/70">إلغاء التحديد</button>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
                  {autoGenLoading ? (
                    <div className="text-center py-12 text-muted-foreground"><Loader2 className="animate-spin mx-auto mb-2" /> جاري التحليل...</div>
                  ) : autoGenSuggestions.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground text-sm">لا توجد فئات في المنتجات المتزامنة بهذا الفلتر.</div>
                  ) : autoGenSuggestions.map(s => {
                    const checked = autoGenPicks.has(s.id);
                    return (
                      <label key={s.id} className={`flex items-center gap-3 p-2.5 rounded-xl border cursor-pointer transition-colors ${checked ? 'bg-violet-500/10 border-violet-500/40' : 'bg-background border-border hover:border-primary/30'} ${s.alreadyExists ? 'opacity-60' : ''}`}>
                        <input type="checkbox" checked={checked} onChange={() => {
                          setAutoGenPicks(prev => {
                            const n = new Set(prev);
                            if (n.has(s.id)) n.delete(s.id); else n.add(s.id);
                            return n;
                          });
                        }} className="w-4 h-4 accent-violet-400" />
                        <div className="w-9 h-9 rounded-lg flex items-center justify-center text-lg shrink-0" style={{ background: `${s.color}25`, border: `1px solid ${s.color}50` }}>{s.emoji}</div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-bold truncate">{s.nameAr}</div>
                          <div className="text-[10px] text-muted-foreground flex items-center gap-2">
                            <span>{CATEGORY_OPTIONS.find(c => c.value === s.category)?.label || s.category}</span>
                            <span>·</span>
                            <span className="font-mono">{s.id}</span>
                          </div>
                        </div>
                        <div className="text-left shrink-0">
                          <div className="text-[11px] font-bold text-primary">{s.productCount} منتج</div>
                          {s.alreadyExists && <div className="text-[9px] text-amber-400">موجود مسبقاً</div>}
                        </div>
                      </label>
                    );
                  })}
                </div>
                <div className="flex items-center justify-between gap-2 p-4 border-t border-border bg-card/60">
                  <span className="text-xs text-muted-foreground">المحدد: <strong className="text-foreground">{autoGenPicks.size}</strong> من {autoGenSuggestions.length}</span>
                  <div className="flex gap-2">
                    <button onClick={() => setShowAutoGen(false)} className="px-4 py-2 rounded-xl border border-border bg-background hover:bg-background/70 text-sm font-semibold">إلغاء</button>
                    <button onClick={applyAutoGen} disabled={autoGenPicks.size === 0}
                      className="px-4 py-2 rounded-xl bg-violet-500/20 text-violet-300 border border-violet-500/40 hover:bg-violet-500/30 text-sm font-bold disabled:opacity-50 flex items-center gap-2">
                      <Plus size={14} /> أضف {autoGenPicks.size} كرت
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Test order result modal */}
          {testResult && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60" onClick={() => !testing && setTestResult(null)}>
              <div className="bg-card border border-border rounded-2xl shadow-2xl max-w-md w-full p-5" onClick={(e) => e.stopPropagation()} dir="rtl">
                <div className="flex items-center gap-2 mb-3">
                  <FlaskConical className={testResult.success ? 'text-green-500' : 'text-amber-500'} size={22} />
                  <h3 className="font-bold text-lg flex-1 truncate">اختبار: {testResult.name}</h3>
                  <button onClick={() => setTestResult(null)} className="p-1 rounded hover:bg-muted"><X size={16} /></button>
                </div>
                <div className={`p-3 rounded-xl text-sm font-semibold mb-3 ${testResult.success ? 'bg-green-500/10 text-green-400 border border-green-500/30' : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'}`}>
                  {testResult.message}
                </div>
                {testing ? (
                  <div className="text-center py-6 text-muted-foreground"><Loader2 className="animate-spin mx-auto mb-2" /> جاري الفحص...</div>
                ) : (
                  <div className="space-y-1.5">
                    {testResult.checks.map((c, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs px-2 py-1.5 rounded-lg bg-muted/40">
                        {c.ok ? <Check size={14} className="text-green-500 shrink-0" /> : <X size={14} className="text-destructive shrink-0" />}
                        <span className="font-medium">{c.name}</span>
                        {c.detail && <span className="text-muted-foreground mr-auto truncate">{c.detail}</span>}
                      </div>
                    ))}
                  </div>
                )}
                <div className="text-[10px] text-muted-foreground mt-3 text-center">
                  💡 اختبار آمن: ما رح يخصم رصيد ولا يرسل للمزوّد
                </div>
              </div>
            </div>
          )}

          {/* Edit price modal */}
          {editPriceFor && (
            <PriceEditModal
              product={editPriceFor}
              onClose={() => setEditPriceFor(null)}
              onSave={async (priceUsd, profitMargin) => {
                const patch: Record<string, any> = { priceUsd: String(priceUsd) };
                if (profitMargin !== undefined) patch.profitMargin = String(profitMargin);
                await saveProduct(editPriceFor.id, patch);
                setEditPriceFor(null);
              }}
            />
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}

// ─── Product tile ───────────────────────────────────────────────────────────
function ProductTile({ p, color, subgroupOptions, isDragging, isDragOver, onDragStart, onDragOver, onDragEnd, onDrop, onImage, onSubgroupChange, onToggleStatus, onToggleAuto, onMove, onEditPrice, onTest, onUnassign }: {
  p: Product; color: string; subgroupOptions: string[];
  isDragging: boolean; isDragOver: boolean;
  onDragStart: () => void; onDragOver: () => void; onDragEnd: () => void; onDrop: () => void;
  onImage: (file: File) => void;
  onSubgroupChange: (sg: string) => void;
  onToggleStatus: () => void;
  onToggleAuto: () => void;
  onMove: (dir: 1 | -1) => void;
  onTest: () => void;
  onEditPrice: () => void;
  onUnassign: () => void;
}) {
  const [editingSg, setEditingSg] = useState(false);
  const [sgVal, setSgVal] = useState(p.subGroup || '');
  useEffect(() => { setSgVal(p.subGroup || ''); }, [p.subGroup]);
  const img = p.imageOverride;
  const initials = (p.name || '').slice(0, 2).toUpperCase();
  return (
    <div
      draggable
      onDragStart={(e) => { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', p.id); onDragStart(); }}
      onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; onDragOver(); }}
      onDragEnd={onDragEnd}
      onDrop={(e) => { e.preventDefault(); onDrop(); }}
      className={`relative bg-background border rounded-xl overflow-hidden group transition-all ${p.status === 'active' ? 'border-border' : 'border-red-500/40 opacity-70'} ${isDragging ? 'opacity-40 scale-95' : ''} ${isDragOver ? 'ring-2 ring-primary border-primary scale-[1.03]' : ''}`}>
      <div className="absolute top-1 right-1 z-10 p-1 rounded bg-black/40 backdrop-blur opacity-0 group-hover:opacity-100 transition-opacity cursor-grab active:cursor-grabbing" title="اسحب لإعادة الترتيب">
        <GripVertical size={12} className="text-white/80" />
      </div>
      <button
        type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); onUnassign(); }}
        className="absolute top-1 left-1 z-10 p-1 rounded-full bg-black/50 backdrop-blur text-white/90 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/80"
        title="إزالة المنتج من هذا الكرت (يرجع لمطابقة الكلمات المفتاحية فقط)"
        aria-label="إزالة من الكرت"
      >
        <X size={12} />
      </button>
      <label className="block aspect-square relative cursor-pointer overflow-hidden" style={{ background: `linear-gradient(135deg, ${color}30, ${color}10)` }}>
        {img ? (
          <img src={img} alt="" className="w-full h-full object-cover" onError={e => ((e.currentTarget as HTMLImageElement).style.display = 'none')} />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-white/70">{initials}</div>
        )}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
          <ImageIcon size={20} className="text-white" />
          <span className="text-white text-[10px] font-bold mr-1">تغيير الصورة</span>
        </div>
        <input type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onImage(f); e.target.value = ''; }} />
      </label>
      <div className="p-2 space-y-1.5">
        <div className="text-xs font-bold leading-tight line-clamp-2 min-h-[2.4em]" title={p.name}>{p.nameAr || p.name}</div>
        <div className="flex items-center justify-between gap-1">
          <button onClick={onEditPrice} className="text-[11px] font-bold text-primary hover:underline flex items-center gap-0.5" title="تعديل السعر">
            ${Number(p.priceUsd).toFixed(2)} <Pencil size={9} />
          </button>
          <button onClick={onToggleStatus}
            className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${p.status === 'active' ? 'bg-green-500/15 text-green-400 border border-green-500/30' : 'bg-red-500/15 text-red-400 border border-red-500/30'}`}>
            {p.status === 'active' ? 'مفعّل' : 'موقوف'}
          </button>
        </div>
        {editingSg ? (
          <div className="flex items-center gap-1">
            <input list={`sg-list-${p.id}`} value={sgVal} onChange={e => setSgVal(e.target.value)} autoFocus
              placeholder="subGroup" className="flex-1 min-w-0 px-1.5 py-1 bg-card border border-primary/40 rounded text-[10px]" />
            <datalist id={`sg-list-${p.id}`}>{subgroupOptions.map(s => <option key={s} value={s} />)}</datalist>
            <button onClick={() => { onSubgroupChange(sgVal.trim()); setEditingSg(false); }} className="p-1 text-green-400 hover:bg-green-500/15 rounded"><Check size={11} /></button>
            <button onClick={() => { setSgVal(p.subGroup || ''); setEditingSg(false); }} className="p-1 text-muted-foreground hover:bg-muted rounded"><X size={11} /></button>
          </div>
        ) : (
          <button onClick={() => setEditingSg(true)}
            className="w-full text-right text-[10px] px-1.5 py-1 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 hover:bg-cyan-500/20 truncate"
            title="نقل المنتج لتبويب آخر">
            📁 {p.subGroup || '— بدون subGroup —'}
          </button>
        )}
        <button onClick={onToggleAuto}
          title={p.autoApprove ? 'تنفيذ تلقائي مفعّل — اضغط للإيقاف' : 'يستنى موافقتك — اضغط لتفعيل التنفيذ التلقائي'}
          className={`w-full text-[10px] px-1.5 py-1 rounded font-bold flex items-center justify-center gap-1 border transition-colors ${p.autoApprove ? 'bg-amber-500/15 text-amber-400 border-amber-500/40 hover:bg-amber-500/25' : 'bg-muted/50 text-muted-foreground border-border hover:bg-muted'}`}>
          {p.autoApprove ? '⚡ تنفيذ تلقائي' : '🛡️ يحتاج موافقة'}
        </button>
        <button onClick={onTest}
          className="w-full text-[10px] px-1.5 py-1 rounded bg-blue-500/10 text-blue-300 border border-blue-500/30 hover:bg-blue-500/20 flex items-center justify-center gap-1"
          title="اختبر إذا المنتج جاهز للبيع — بدون أي خصم">
          <FlaskConical size={10} /> اختبار جاهزية
        </button>
        <div className="flex items-center justify-between">
          <div className="flex gap-0.5">
            <button onClick={() => onMove(-1)} className="p-0.5 rounded hover:bg-muted" title="رفع"><ArrowUp size={10} /></button>
            <button onClick={() => onMove(+1)} className="p-0.5 rounded hover:bg-muted" title="إنزال"><ArrowDown size={10} /></button>
          </div>
          <a href={`/admin/products`} className="text-[9px] text-muted-foreground hover:text-primary">المزيد...</a>
        </div>
      </div>
    </div>
  );
}

// ─── Price edit modal ───────────────────────────────────────────────────────
function PriceEditModal({ product, onClose, onSave }: { product: Product; onClose: () => void; onSave: (priceUsd: number, profitMargin?: number) => Promise<void> }) {
  const [price, setPrice] = useState(String(product.priceUsd));
  const [margin, setMargin] = useState(String(product.profitMargin ?? ''));
  const [saving, setSaving] = useState(false);
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4" dir="rtl" onClick={() => !saving && onClose()}>
      <div className="bg-card border border-border w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="min-w-0">
            <h3 className="font-bold text-base">تعديل سعر المنتج</h3>
            <p className="text-xs text-muted-foreground mt-1 truncate">{product.nameAr || product.name}</p>
          </div>
          <button onClick={onClose} disabled={saving} className="p-1.5 rounded-lg hover:bg-background text-muted-foreground"><X size={16} /></button>
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-bold mb-1 block">السعر بالدولار (USD)</label>
            <input type="number" step="0.01" value={price} onChange={e => setPrice(e.target.value)} dir="ltr"
              className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm font-mono" />
          </div>
          <div>
            <label className="text-xs font-bold mb-1 block">هامش الربح % (اختياري)</label>
            <input type="number" step="0.1" value={margin} onChange={e => setMargin(e.target.value)} dir="ltr"
              placeholder="10"
              className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm font-mono" />
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} disabled={saving} className="flex-1 px-4 py-2.5 rounded-xl border border-border bg-background hover:bg-background/70 text-sm font-semibold">إلغاء</button>
            <button onClick={async () => {
              const pn = parseFloat(price);
              if (!Number.isFinite(pn) || pn < 0) return;
              const mn = margin.trim() === '' ? undefined : parseFloat(margin);
              setSaving(true);
              try { await onSave(pn, Number.isFinite(mn as number) ? mn : undefined); }
              finally { setSaving(false); }
            }} disabled={saving}
              className="flex-1 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2">
              {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} حفظ
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
