import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';
import { Palette, Save, RotateCcw, Monitor, Smartphone, Check } from 'lucide-react';
import { motion } from 'framer-motion';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const SETTINGS_KEY = 'category_card_style';

function authHeaders() {
  return { Authorization: `Bearer ${localStorage.getItem('elite_token')}`, 'Content-Type': 'application/json' };
}

export type CatCardConfig = {
  layout: 'grid' | 'single' | 'minimal';
  iconStyle: 'rounded' | 'circle' | 'square';
  iconSize: 'sm' | 'md' | 'lg';
  hoverEffect: 'scale' | 'lift' | 'glow' | 'none';
  showEnLabel: boolean;
  showVipBadge: boolean;
  cardRadius: number;
  borderGlow: boolean;
  nameSize: 'xs' | 'sm' | 'md';
};

export const DEFAULT_CAT_CONFIG: CatCardConfig = {
  layout: 'grid',
  iconStyle: 'rounded',
  iconSize: 'md',
  hoverEffect: 'scale',
  showEnLabel: true,
  showVipBadge: true,
  cardRadius: 16,
  borderGlow: false,
  nameSize: 'sm',
};

async function loadConfig(): Promise<CatCardConfig> {
  try {
    const r = await fetch(`${BASE}/api/settings`);
    if (!r.ok) return DEFAULT_CAT_CONFIG;
    const d = await r.json();
    if (!d[SETTINGS_KEY]) return DEFAULT_CAT_CONFIG;
    return { ...DEFAULT_CAT_CONFIG, ...JSON.parse(d[SETTINGS_KEY]) };
  } catch { return DEFAULT_CAT_CONFIG; }
}

async function saveConfig(cfg: CatCardConfig): Promise<void> {
  await fetch(`${BASE}/api/admin/settings`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify({ [SETTINGS_KEY]: JSON.stringify(cfg) }),
  });
}

const DEMO_CAT = {
  nameAr: 'الألعاب',
  nameEn: 'Games',
  color: '#6C5CE7',
  bg: 'linear-gradient(145deg, #1a0040, #2d0080)',
  icons: [
    { label: 'PUBG', bg: '#f59e0b' },
    { label: 'FF',   bg: '#f97316' },
    { label: 'ML',   bg: '#dc2626' },
    { label: 'CoC',  bg: '#3b82f6' },
  ],
};

function PreviewCard({ cfg, mobile }: { cfg: CatCardConfig; mobile: boolean }) {
  const iconSizePx = cfg.iconSize === 'sm' ? 28 : cfg.iconSize === 'lg' ? 44 : 36;
  const iconBr = cfg.iconStyle === 'circle' ? 9999 : cfg.iconStyle === 'square' ? 6 : 14;
  const nameSizeCls = cfg.nameSize === 'xs' ? 'text-[10px]' : cfg.nameSize === 'md' ? 'text-sm' : 'text-[12px]';
  const shadow = cfg.borderGlow ? `0 0 18px ${DEMO_CAT.color}55, 0 4px 20px ${DEMO_CAT.color}18` : `0 4px 20px ${DEMO_CAT.color}18`;

  const icons = cfg.layout === 'single' ? [DEMO_CAT.icons[0]] : DEMO_CAT.icons;

  return (
    <div
      className="relative overflow-hidden select-none"
      style={{
        background: DEMO_CAT.bg,
        border: `1px solid ${DEMO_CAT.color}${cfg.borderGlow ? '80' : '40'}`,
        boxShadow: shadow,
        borderRadius: cfg.cardRadius,
        width: mobile ? 130 : 160,
        minHeight: cfg.layout === 'minimal' ? 56 : 148,
        transition: 'all 0.2s',
      }}
    >
      {cfg.showVipBadge && (
        <div className="absolute top-2 right-2 z-10 flex items-center gap-0.5 px-1.5 py-0.5 rounded-full"
          style={{ background: 'rgba(0,0,0,0.55)', border: '1px solid rgba(255,215,0,0.5)' }}>
          <span className="text-[8px] font-black text-yellow-400">⭐ VIP</span>
        </div>
      )}

      {cfg.layout === 'minimal' ? (
        <div className="flex items-center gap-2.5 p-3">
          <div className="flex items-center justify-center font-black text-white text-xs shrink-0"
            style={{ width: iconSizePx, height: iconSizePx, borderRadius: iconBr, background: `${DEMO_CAT.icons[0].bg}33`, border: `1px solid ${DEMO_CAT.icons[0].bg}55` }}>
            {DEMO_CAT.icons[0].label.slice(0,2)}
          </div>
          <span className={`${nameSizeCls} font-black text-white`}>{DEMO_CAT.nameAr}</span>
        </div>
      ) : cfg.layout === 'single' ? (
        <>
          <div className="p-3 pb-1.5 flex justify-center">
            <div className="flex items-center justify-center font-black text-white"
              style={{ width: iconSizePx * 2 + 8, height: iconSizePx * 2 + 8, borderRadius: iconBr, background: `${icons[0].bg}33`, border: `1px solid ${icons[0].bg}55`, fontSize: 20 }}>
              {icons[0].label.slice(0, 2)}
            </div>
          </div>
          <div className="w-full text-center py-2.5 px-2"
            style={{ background: `linear-gradient(0deg, ${DEMO_CAT.color}33 0%, transparent 100%)`, borderTop: `1px solid ${DEMO_CAT.color}30` }}>
            <p className={`${nameSizeCls} font-black text-white leading-none`}>{DEMO_CAT.nameAr}</p>
            {cfg.showEnLabel && <p className="text-[9px] text-white/45 mt-1">{DEMO_CAT.nameEn}</p>}
          </div>
        </>
      ) : (
        <>
          <div className="p-3 pb-1.5">
            <div className="grid grid-cols-2 gap-1.5">
              {DEMO_CAT.icons.map((ic, i) => (
                <div key={i} className="aspect-square flex items-center justify-center font-black text-white text-[10px]"
                  style={{ borderRadius: iconBr, background: `${ic.bg}22`, border: `1px solid ${ic.bg}33`, minHeight: iconSizePx + 8 }}>
                  {ic.label.slice(0, 2)}
                </div>
              ))}
            </div>
          </div>
          <div className="w-full text-center py-2.5 px-2"
            style={{ background: `linear-gradient(0deg, ${DEMO_CAT.color}33 0%, transparent 100%)`, borderTop: `1px solid ${DEMO_CAT.color}30` }}>
            <p className={`${nameSizeCls} font-black text-white leading-none`}>{DEMO_CAT.nameAr}</p>
            {cfg.showEnLabel && <p className="text-[9px] text-white/45 mt-1">{DEMO_CAT.nameEn}</p>}
          </div>
        </>
      )}
    </div>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between cursor-pointer gap-4">
      <span className="text-sm text-foreground">{label}</span>
      <div onClick={() => onChange(!value)}
        className={`relative w-10 h-5 rounded-full transition-colors cursor-pointer ${value ? 'bg-primary' : 'bg-white/10'}`}>
        <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-5' : 'translate-x-0.5'}`} />
      </div>
    </label>
  );
}

function OptionRow<T extends string>({ label, value, options, onChange }: {
  label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void;
}) {
  return (
    <div>
      <p className="text-sm font-medium mb-2">{label}</p>
      <div className="flex flex-wrap gap-2">
        {options.map(o => (
          <button key={o.value} onClick={() => onChange(o.value)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${value === o.value ? 'bg-primary text-white border-primary' : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/30'}`}>
            {value === o.value && <Check size={10} className="inline mr-1" />}{o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function AdminCategoryCardBuilder() {
  const [cfg, setCfg] = useState<CatCardConfig>(DEFAULT_CAT_CONFIG);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [mobile, setMobile] = useState(false);
  const { toast } = useToast();

  useEffect(() => { loadConfig().then(c => { setCfg(c); setDirty(false); }); }, []);

  const set = <K extends keyof CatCardConfig>(key: K, val: CatCardConfig[K]) => {
    setCfg(prev => ({ ...prev, [key]: val }));
    setDirty(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveConfig(cfg);
      toast({ title: '✅ تم الحفظ', description: 'شكل كروت الأقسام محدّث' });
      setDirty(false);
    } catch { toast({ title: '❌ خطأ في الحفظ', variant: 'destructive' }); }
    finally { setSaving(false); }
  };

  const handleReset = () => { setCfg(DEFAULT_CAT_CONFIG); setDirty(true); };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="max-w-5xl mx-auto space-y-6" dir="rtl">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Palette size={24} className="text-primary" /> محرّر كروت الأقسام
              </h1>
              <p className="text-sm text-muted-foreground mt-0.5">تخصيص شكل كروت الأقسام في الصفحة الرئيسية وقائمة الألعاب</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex gap-1 bg-white/5 border border-white/10 rounded-xl p-1">
                {([false, true] as const).map(m => {
                  const Icon = m ? Smartphone : Monitor;
                  return (
                    <button key={String(m)} onClick={() => setMobile(m)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${mobile === m ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}>
                      <Icon size={13} />{m ? 'موبايل' : 'ديسكتوب'}
                    </button>
                  );
                })}
              </div>
              <button onClick={handleReset} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-white/10 text-sm hover:bg-white/5 transition-colors">
                <RotateCcw size={13} /> إعادة تعيين
              </button>
              {dirty && (
                <motion.button initial={{ scale: 0.9 }} animate={{ scale: 1 }}
                  onClick={handleSave} disabled={saving}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white text-sm font-semibold hover:opacity-90 disabled:opacity-50">
                  <Save size={14} />{saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                </motion.button>
              )}
            </div>
          </div>

          <div className="grid lg:grid-cols-[1fr_280px] gap-6">
            <div className="space-y-5">
              <div className="bg-card border border-border rounded-2xl p-5 space-y-5">
                <h2 className="font-semibold text-sm border-b border-border pb-3">التخطيط والشكل العام</h2>

                <OptionRow label="تخطيط الأيقونات" value={cfg.layout} onChange={v => set('layout', v)}
                  options={[
                    { value: 'grid', label: 'شبكة 2×2 (افتراضي)' },
                    { value: 'single', label: 'أيقونة واحدة كبيرة' },
                    { value: 'minimal', label: 'مضغوط (أيقونة + اسم)' },
                  ]} />

                <OptionRow label="شكل حاوية الأيقونة" value={cfg.iconStyle} onChange={v => set('iconStyle', v)}
                  options={[
                    { value: 'rounded', label: 'دائري خفيف' },
                    { value: 'circle', label: 'دائري كامل' },
                    { value: 'square', label: 'مربع' },
                  ]} />

                <OptionRow label="حجم الأيقونة" value={cfg.iconSize} onChange={v => set('iconSize', v)}
                  options={[
                    { value: 'sm', label: 'صغير' },
                    { value: 'md', label: 'متوسط (افتراضي)' },
                    { value: 'lg', label: 'كبير' },
                  ]} />

                <OptionRow label="حجم الاسم" value={cfg.nameSize} onChange={v => set('nameSize', v)}
                  options={[
                    { value: 'xs', label: 'صغير جداً' },
                    { value: 'sm', label: 'صغير (افتراضي)' },
                    { value: 'md', label: 'متوسط' },
                  ]} />
              </div>

              <div className="bg-card border border-border rounded-2xl p-5 space-y-5">
                <h2 className="font-semibold text-sm border-b border-border pb-3">التفاعل والتأثيرات</h2>

                <OptionRow label="تأثير الـ Hover" value={cfg.hoverEffect} onChange={v => set('hoverEffect', v)}
                  options={[
                    { value: 'scale', label: 'تكبير (افتراضي)' },
                    { value: 'lift', label: 'ارتفاع' },
                    { value: 'glow', label: 'توهّج' },
                    { value: 'none', label: 'بدون' },
                  ]} />

                <div>
                  <p className="text-sm font-medium mb-2">انحناء الزوايا</p>
                  <div className="flex items-center gap-4">
                    <input type="range" min={4} max={28} value={cfg.cardRadius}
                      onChange={e => set('cardRadius', Number(e.target.value))}
                      className="flex-1 accent-primary" />
                    <span className="text-sm font-mono w-10 text-center">{cfg.cardRadius}px</span>
                  </div>
                </div>
              </div>

              <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h2 className="font-semibold text-sm border-b border-border pb-3">خيارات العرض</h2>
                <Toggle label="إظهار الاسم الإنجليزي" value={cfg.showEnLabel} onChange={v => set('showEnLabel', v)} />
                <Toggle label="شارة VIP للمستخدمين المميزين" value={cfg.showVipBadge} onChange={v => set('showVipBadge', v)} />
                <Toggle label="توهّج الحدود (Border Glow)" value={cfg.borderGlow} onChange={v => set('borderGlow', v)} />
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-card border border-border rounded-2xl p-5 sticky top-4">
                <h2 className="font-semibold text-sm mb-4">معاينة مباشرة</h2>
                <div className="flex justify-center mb-4">
                  <PreviewCard cfg={cfg} mobile={mobile} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <PreviewCard cfg={{ ...cfg, bg: 'linear-gradient(145deg, #002010, #004020)' } as any} mobile={mobile} />
                  <PreviewCard cfg={{ ...cfg, bg: 'linear-gradient(145deg, #001030, #002060)' } as any} mobile={mobile} />
                </div>
                <p className="text-xs text-muted-foreground text-center mt-3">معاينة بألوان مختلفة</p>

                {dirty && (
                  <button onClick={handleSave} disabled={saving}
                    className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-primary text-white text-sm font-semibold hover:opacity-90 disabled:opacity-50 transition-opacity">
                    <Save size={14} />{saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
