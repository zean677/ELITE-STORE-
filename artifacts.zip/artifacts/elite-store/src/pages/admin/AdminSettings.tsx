import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Settings, Save, Loader2, DollarSign, TrendingUp, RefreshCw, Key, Megaphone, Shield, Eye, EyeOff, Zap, Crown, Send, Webhook, CheckCircle, XCircle, Link, Download, Archive } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function SectionCard({ icon: Icon, title, sub, color, delay = 0, children }: { icon: any; title: string; sub?: string; color?: string; delay?: number; children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-card border border-border rounded-2xl p-6 space-y-5"
    >
      <div className="flex items-center gap-3 mb-1">
        <div className={`w-9 h-9 rounded-xl bg-${color ?? 'primary'}/15 border border-${color ?? 'primary'}/20 flex items-center justify-center`}>
          <Icon size={16} className={`text-${color ?? 'primary'}`} />
        </div>
        <div>
          <h2 className="font-bold text-sm">{title}</h2>
          {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
        </div>
      </div>
      {children}
    </motion.div>
  );
}

export default function AdminSettings() {
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [testingProvider, setTestingProvider] = useState(false);
  const [fetchingSample, setFetchingSample] = useState(false);
  const [showProviderToken, setShowProviderToken] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [webhookInfo, setWebhookInfo] = useState<any>(null);
  const [settingWebhook, setSettingWebhook] = useState(false);
  const [testingBot, setTestingBot] = useState(false);
  const [providerStatus, setProviderStatus] = useState<any>(null);
  const [providerTest, setProviderTest] = useState<any>(null);
  const [productSample, setProductSample] = useState<{ count: number; sample: string[] } | null>(null);
  const [loadingProvider, setLoadingProvider] = useState(false);
  const [urlDiagInput, setUrlDiagInput] = useState('');
  const [urlDiagResults, setUrlDiagResults] = useState<any[] | null>(null);
  const [urlDiagRunning, setUrlDiagRunning] = useState(false);

  const loadProviderStatus = async () => {
    setLoadingProvider(true);
    try {
      const res = await fetch(`${BASE}/api/admin/system`, { headers: { Authorization: `Bearer ${localStorage.getItem('elite_token')}` } });
      if (!res.ok) throw new Error('failed');
      const data = await res.json();
      const providers = data?.providers ?? {};
      const firstKey = Object.keys(providers)[0];
      setProviderStatus(firstKey ? { name: firstKey, ...providers[firstKey] } : null);
    } catch {
      // silent
    } finally {
      setLoadingProvider(false);
    }
  };

  useEffect(() => { loadProviderStatus(); }, []);

  const [settings, setSettings] = useState({
    syp_rate: '13000',
    eur_rate: '0.92',
    default_profit_margin: '10',
    announcement: '',
    announcement_active: 'false',
    announcement_type: 'info',
    maintenance_mode: 'false',
    provider_name: 'megagame',
    provider_display_name: 'Fast API (Mega Game)',
    provider_base_url: 'https://mega-game.net/api',
    provider_api_token: '',
    provider_enabled: 'true',
    provider_low_balance_threshold_syp: '100000',
    vip_level_1_threshold: '100',
    vip_level_1_discount: '1',
    vip_level_2_threshold: '300',
    vip_level_2_discount: '2',
    vip_level_3_threshold: '700',
    vip_level_3_discount: '4',
    vip_level_4_threshold: '1500',
    vip_level_4_discount: '7',
    vip_leaderboard_enabled: 'false',
  });

  useEffect(() => {
    fetch(`${BASE}/api/settings`)
      .then(r => r.json())
      .then(data => {
        setSettings(s => ({
          syp_rate: data.syp_rate ?? s.syp_rate,
          eur_rate: data.eur_rate ?? s.eur_rate,
          default_profit_margin: data.default_profit_margin ?? s.default_profit_margin,
          announcement: data.announcement ?? '',
          announcement_active: data.announcement_active ?? 'false',
          announcement_type: data.announcement_type ?? 'info',
          maintenance_mode: data.maintenance_mode ?? 'false',
          provider_name: data.provider_name ?? s.provider_name,
          provider_display_name: data.provider_display_name ?? s.provider_display_name,
          provider_base_url: data.provider_base_url ?? s.provider_base_url,
          provider_api_token: data.provider_api_token ?? '',
          provider_enabled: data.provider_enabled ?? s.provider_enabled,
          provider_low_balance_threshold_syp: data.provider_low_balance_threshold_syp ?? s.provider_low_balance_threshold_syp,
          vip_level_1_threshold: data.vip_level_1_threshold ?? s.vip_level_1_threshold,
          vip_level_1_discount: data.vip_level_1_discount ?? s.vip_level_1_discount,
          vip_level_2_threshold: data.vip_level_2_threshold ?? s.vip_level_2_threshold,
          vip_level_2_discount: data.vip_level_2_discount ?? s.vip_level_2_discount,
          vip_level_3_threshold: data.vip_level_3_threshold ?? s.vip_level_3_threshold,
          vip_level_3_discount: data.vip_level_3_discount ?? s.vip_level_3_discount,
          vip_level_4_threshold: data.vip_level_4_threshold ?? s.vip_level_4_threshold,
          vip_level_4_discount: data.vip_level_4_discount ?? s.vip_level_4_discount,
          vip_leaderboard_enabled: data.vip_leaderboard_enabled ?? s.vip_leaderboard_enabled,
        }));
        setLoading(false);
      })
      .catch(() => setLoading(false));
    // Load telegram webhook info
    fetch(`${BASE}/api/admin/telegram/info`, { headers: { Authorization: `Bearer ${localStorage.getItem('elite_token')}` } })
      .then(r => r.ok ? r.json() : null).then(d => d && setWebhookInfo(d)).catch(() => {});
  }, []);

  const set = (key: keyof typeof settings, value: string) => setSettings(s => ({ ...s, [key]: value }));

  const handleSave = async () => {
    setSaving(true);
    try {
      const token = localStorage.getItem('elite_token');
      const res = await fetch(`${BASE}/api/admin/settings`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          syp_rate: parseFloat(settings.syp_rate),
          eur_rate: parseFloat(settings.eur_rate),
          default_profit_margin: parseFloat(settings.default_profit_margin),
          announcement: settings.announcement,
          announcement_active: settings.announcement_active,
          announcement_type: settings.announcement_type,
          maintenance_mode: settings.maintenance_mode,
          provider_name: settings.provider_name,
          provider_display_name: settings.provider_display_name,
          provider_base_url: settings.provider_base_url,
          provider_api_token: settings.provider_api_token,
          provider_enabled: settings.provider_enabled,
          provider_low_balance_threshold_syp: parseFloat(settings.provider_low_balance_threshold_syp),
          vip_level_1_threshold: parseFloat(settings.vip_level_1_threshold),
          vip_level_1_discount: parseFloat(settings.vip_level_1_discount),
          vip_level_2_threshold: parseFloat(settings.vip_level_2_threshold),
          vip_level_2_discount: parseFloat(settings.vip_level_2_discount),
          vip_level_3_threshold: parseFloat(settings.vip_level_3_threshold),
          vip_level_3_discount: parseFloat(settings.vip_level_3_discount),
          vip_level_4_threshold: parseFloat(settings.vip_level_4_threshold),
          vip_level_4_discount: parseFloat(settings.vip_level_4_discount),
          vip_leaderboard_enabled: settings.vip_leaderboard_enabled,
        }),
      });
      if (!res.ok) throw new Error();
      toast({ title: '✅ تم الحفظ', description: 'تم تحديث جميع الإعدادات بنجاح' });
    } catch {
      toast({ title: 'خطأ', description: 'تعذر حفظ الإعدادات', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const authHeader = () => ({ 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('elite_token')}` });

  const handleSyncProvider = async () => {
    setSyncing(true);
    try {
      const res = await fetch(`${BASE}/api/admin/products/sync`, {
        method: 'POST',
        headers: authHeader(),
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok || data.success === false) throw new Error(data?.message ?? data?.error ?? 'Failed');
      toast({ title: '✅ بدأت المزامنة', description: data.message ?? 'يتم سحب المنتجات في الخلفية' });
      // refresh status shortly after
      setTimeout(() => loadProviderStatus(), 2500);
    } catch (e: any) {
      toast({ title: 'فشلت المزامنة', description: e?.message ?? 'تعذر بدء المزامنة', variant: 'destructive' });
    } finally {
      setSyncing(false);
    }
  };

  const handleTestProvider = async () => {
    setTestingProvider(true);
    setProviderTest(null);
    try {
      const res = await fetch(`${BASE}/api/admin/providers/test`, {
        method: 'POST',
        headers: authHeader(),
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? 'Failed');
      const result = data.result ?? data.results?.[0];
      setProviderTest(result);
      const ms = result?.responseMs;
      const health = result?.health ?? (result?.ok ? 'green' : 'red');
      const dot = health === 'green' ? '🟢' : health === 'yellow' ? '🟡' : '🔴';
      toast({
        title: result?.ok ? `${dot} الاتصال يعمل` : `${dot} فشل الاتصال`,
        description: result?.ok
          ? `زمن الاستجابة: ${ms} مللي ثانية${result?.balanceUsd != null ? ` • الرصيد: $${Number(result.balanceUsd).toFixed(2)}` : ''}`
          : (result?.error ?? 'تحقق من الـ Token وعنوان الـ Base URL'),
        variant: result?.ok ? undefined : 'destructive',
      });
      loadProviderStatus();
    } catch (e: any) {
      toast({ title: 'فشل الاختبار', description: e?.message ?? 'تعذر الاتصال', variant: 'destructive' });
    } finally {
      setTestingProvider(false);
    }
  };

  const handleTestUrl = async () => {
    const base = urlDiagInput.trim() || settings.provider_base_url;
    if (!base) return;
    setUrlDiagRunning(true);
    setUrlDiagResults(null);
    try {
      const res = await fetch(`${BASE}/api/admin/providers/test-url`, {
        method: 'POST',
        headers: authHeader(),
        body: JSON.stringify({ baseUrl: base, token: settings.provider_api_token }),
      });
      const data = await res.json();
      setUrlDiagResults(data.results ?? []);
      const working = (data.results ?? []).find((r: any) => r.ok);
      if (working) {
        toast({ title: '✅ وُجد endpoint يعمل!', description: `جرّب استخدام: ${base}` });
      } else {
        toast({ title: '❌ لا يوجد endpoint يعمل', description: 'تحقق من الـ token وعنوان URL', variant: 'destructive' });
      }
    } catch (e: any) {
      toast({ title: 'فشل الاختبار', description: e?.message, variant: 'destructive' });
    } finally {
      setUrlDiagRunning(false);
    }
  };

  const handleFetchSample = async () => {
    setFetchingSample(true);
    setProductSample(null);
    try {
      const res = await fetch(`${BASE}/api/products?limit=8`);
      const data = await res.json();
      const products = Array.isArray(data?.products) ? data.products : [];
      setProductSample({
        count: data?.total ?? products.length,
        sample: products.slice(0, 8).map((p: any) => p.nameAr ?? p.name).filter(Boolean),
      });
      toast({ title: '📦 معاينة المنتجات', description: `تم جلب ${products.length} منتج (إجمالي: ${data?.total ?? 0})` });
    } catch (e: any) {
      toast({ title: 'فشل الجلب', description: e?.message ?? 'تعذر تحميل المنتجات', variant: 'destructive' });
    } finally {
      setFetchingSample(false);
    }
  };

  const handleSetupWebhook = async () => {
    setSettingWebhook(true);
    try {
      const res = await fetch(`${BASE}/api/admin/telegram/setup-webhook`, {
        method: 'POST',
        headers: authHeader(),
        body: JSON.stringify({ siteUrl: webhookUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? 'Failed');
      setWebhookInfo(data.webhookInfo);
      toast({ title: '✅ تم ضبط Webhook', description: 'سيصلك رسائل Telegram الآن بشكل صحيح' });
    } catch (e: any) {
      toast({ title: 'فشل ضبط Webhook', description: e?.message, variant: 'destructive' });
    } finally {
      setSettingWebhook(false);
    }
  };

  const handleTestBot = async () => {
    setTestingBot(true);
    try {
      const res = await fetch(`${BASE}/api/admin/telegram/test`, {
        method: 'POST',
        headers: authHeader(),
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: '✅ البوت يعمل!', description: 'تحقق من Telegram - يجب أن تصلك رسالة اختبار' });
      } else {
        toast({ title: '⚠️ لم يتم الإرسال', description: 'تأكد من صحة BOT_TOKEN و ADMIN_CHAT_ID', variant: 'destructive' });
      }
    } catch (e: any) {
      toast({ title: 'خطأ', description: e?.message, variant: 'destructive' });
    } finally {
      setTestingBot(false);
    }
  };

  const loadWebhookInfo = async () => {
    try {
      const res = await fetch(`${BASE}/api/admin/telegram/info`, { headers: authHeader() });
      if (res.ok) setWebhookInfo(await res.json());
    } catch {}
  };

  const inputCls = "w-full px-4 py-3 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors";

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="max-w-2xl space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/20 flex items-center justify-center">
              <Settings size={18} className="text-primary" />
            </div>
            <div>
              <h1 className="font-heading text-2xl font-bold">إعدادات المتجر</h1>
              <p className="text-muted-foreground text-sm mt-0.5">تحكم بجميع إعدادات Elite Store</p>
            </div>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 size={28} className="animate-spin text-primary" />
            </div>
          ) : (
            <>
              {/* Exchange Rates */}
              <SectionCard icon={DollarSign} title="أسعار الصرف" sub="تؤثر على عرض الأسعار للمستخدمين" color="secondary" delay={0}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">سعر الدولار / الليرة (SYP)</label>
                    <input type="number" step="any" value={settings.syp_rate} onChange={e => set('syp_rate', e.target.value)} className={inputCls} />
                  </div>
                  <div>
                    <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">سعر اليورو / الدولار (EUR)</label>
                    <input type="number" step="any" value={settings.eur_rate} onChange={e => set('eur_rate', e.target.value)} className={inputCls} />
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-background border border-border text-xs text-muted-foreground">
                  <p>💡 الليرة: 1$ = <strong>{Number(settings.syp_rate).toLocaleString('en-US')}</strong> ل.س — اليورو: 1$ = <strong>{settings.eur_rate}€</strong></p>
                </div>
              </SectionCard>

              <SectionCard icon={Crown} title="نظام VIP" sub="حدود الإنفاق والخصومات التلقائية" color="warning" delay={0.06}>
                <div className="space-y-3">
                  {[1, 2, 3, 4].map(level => {
                    const thresholdKey = `vip_level_${level}_threshold` as keyof typeof settings;
                    const discountKey = `vip_level_${level}_discount` as keyof typeof settings;
                    const threshold = Number(settings[thresholdKey] || 0);
                    return (
                      <div key={level} className="grid grid-cols-[70px_1fr_1fr] gap-3 items-end rounded-2xl border border-border bg-background p-3">
                        <div className="rounded-xl bg-gradient-to-br from-yellow-300 to-amber-600 px-3 py-2 text-center text-xs font-black text-slate-950">VIP {level}</div>
                        <div>
                          <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">حد الإنفاق بالدولار</label>
                          <input type="number" step="any" value={settings[thresholdKey]} onChange={e => set(thresholdKey, e.target.value)} className={inputCls} />
                        </div>
                        <div>
                          <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">نسبة الخصم %</label>
                          <input type="number" step="any" min="0" value={settings[discountKey]} onChange={e => set(discountKey, e.target.value)} className={inputCls} />
                        </div>
                        <p className="col-span-3 text-[11px] text-muted-foreground">
                          يعادل تقريباً {Math.round(threshold * Number(settings.syp_rate || 13000)).toLocaleString('en-US')} ل.س أو €{(threshold * Number(settings.eur_rate || 0.92)).toFixed(0)}
                        </p>
                      </div>
                    );
                  })}

                  {/* VIP Leaderboard toggle */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-background border border-border">
                    <div>
                      <p className="text-sm font-semibold">لوحة صدارة VIP</p>
                      <p className="text-xs text-muted-foreground">تعرض أفضل العملاء VIP بأسماء مخفية جزئياً على صفحة /vip-leaderboard</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => set('vip_leaderboard_enabled', settings.vip_leaderboard_enabled === 'true' ? 'false' : 'true')}
                      className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${settings.vip_leaderboard_enabled === 'true' ? 'bg-primary' : 'bg-muted'}`}
                    >
                      <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${settings.vip_leaderboard_enabled === 'true' ? 'right-0.5' : 'left-0.5'}`} />
                    </button>
                  </div>
                </div>
              </SectionCard>

              {/* Profit Margin */}
              <SectionCard icon={TrendingUp} title="نسبة الربح" sub="تُضاف على أسعار المورّدين تلقائياً" color="success" delay={0.04}>
                <div className="max-w-xs">
                  <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">نسبة الربح الافتراضية (%)</label>
                  <input type="number" step="any" value={settings.default_profit_margin} onChange={e => set('default_profit_margin', e.target.value)} className={inputCls} />
                </div>
                <div className="p-3 rounded-xl bg-background border border-border text-xs text-muted-foreground">
                  <p>💡 منتج بـ <strong>1$</strong> من المورد + ربح {settings.default_profit_margin}% = يُعرض للزبون بـ <strong>${(1 * (1 + parseFloat(settings.default_profit_margin || '0') / 100)).toFixed(2)}</strong></p>
                </div>
              </SectionCard>

              {/* API Provider — single source */}
              <SectionCard icon={Key} title="إعدادات مزود الـ API" sub="مزود واحد فعّال — يمكن تعديل العنوان والـ Token دون لمس الكود" color="accent" delay={0.08}>
                <div className="space-y-4">
                  {/* Status header */}
                  <div className="rounded-xl border border-border bg-background p-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">
                        {(() => {
                          const h = providerStatus?.health ?? (providerStatus?.balanceSyp != null ? 'green' : providerStatus?.error ? 'red' : 'yellow');
                          return h === 'green' ? '🟢' : h === 'yellow' ? '🟡' : '🔴';
                        })()}
                      </div>
                      <div>
                        <p className="font-bold text-sm">{providerStatus?.displayName ?? settings.provider_display_name}</p>
                        <p className="text-[11px] text-muted-foreground">
                          {providerStatus?.enabled === false
                            ? 'معطّل'
                            : providerStatus?.responseMs != null
                              ? `زمن الاستجابة: ${providerStatus.responseMs} مللي ثانية`
                              : 'بانتظار الاختبار'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={loadProviderStatus}
                      disabled={loadingProvider}
                      className="text-[11px] text-primary hover:text-primary/80 disabled:opacity-50 flex items-center gap-1"
                    >
                      <RefreshCw size={11} className={loadingProvider ? 'animate-spin' : ''} />
                      تحديث الحالة
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">اسم المزود الظاهر</label>
                      <input
                        type="text"
                        value={settings.provider_display_name}
                        onChange={e => set('provider_display_name', e.target.value)}
                        className={inputCls}
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">المعرّف الداخلي</label>
                      <input
                        type="text"
                        value={settings.provider_name}
                        onChange={e => set('provider_name', e.target.value.replace(/[^a-z0-9_]/gi, '').toLowerCase())}
                        className={`${inputCls} font-mono text-xs`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">Base URL</label>
                    <input
                      type="url"
                      value={settings.provider_base_url}
                      onChange={e => set('provider_base_url', e.target.value)}
                      placeholder="https://mega-game.net/api"
                      className={`${inputCls} font-mono text-xs`}
                      dir="ltr"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">API Token</label>
                    <div className="relative">
                      <input
                        type={showProviderToken ? 'text' : 'password'}
                        value={settings.provider_api_token}
                        onChange={e => set('provider_api_token', e.target.value)}
                        placeholder="أدخل الـ Token الخاص بالمزود"
                        className={`${inputCls} pr-10 font-mono text-xs`}
                        dir="ltr"
                      />
                      <button type="button" onClick={() => setShowProviderToken(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                        {showProviderToken ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">حد التنبيه على الرصيد (ل.س)</label>
                      <input
                        type="number"
                        value={settings.provider_low_balance_threshold_syp}
                        onChange={e => set('provider_low_balance_threshold_syp', e.target.value)}
                        className={inputCls}
                        dir="ltr"
                      />
                      <p className="text-[10px] text-muted-foreground mt-1">
                        ≈ ${(Number(settings.provider_low_balance_threshold_syp || 0) / Number(settings.syp_rate || 13000)).toFixed(2)} دولار
                      </p>
                    </div>
                    <div>
                      <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">حالة المزود</label>
                      <button
                        type="button"
                        onClick={() => set('provider_enabled', settings.provider_enabled === 'true' ? 'false' : 'true')}
                        className={`w-full py-3 px-4 rounded-xl text-sm font-semibold border transition-all ${settings.provider_enabled === 'true' ? 'bg-success/20 text-success border-success/30' : 'bg-background text-muted-foreground border-border'}`}
                      >
                        {settings.provider_enabled === 'true' ? '🟢 مفعّل' : '⚫ معطّل'}
                      </button>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={handleTestProvider}
                      disabled={testingProvider}
                      className="flex items-center justify-center gap-2 px-4 py-2.5 bg-primary/15 text-primary border border-primary/30 rounded-xl font-semibold text-xs hover:bg-primary/25 disabled:opacity-60"
                    >
                      {testingProvider ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
                      اختبار الاتصال
                    </button>
                    <button
                      type="button"
                      onClick={handleFetchSample}
                      disabled={fetchingSample}
                      className="flex items-center justify-center gap-2 px-4 py-2.5 bg-secondary/15 text-secondary border border-secondary/30 rounded-xl font-semibold text-xs hover:bg-secondary/25 disabled:opacity-60"
                    >
                      {fetchingSample ? <Loader2 size={13} className="animate-spin" /> : <Download size={13} />}
                      جلب المنتجات
                    </button>
                    <button
                      type="button"
                      onClick={handleSyncProvider}
                      disabled={syncing}
                      className="flex items-center justify-center gap-2 px-4 py-2.5 bg-accent/15 text-accent border border-accent/30 rounded-xl font-semibold text-xs hover:bg-accent/25 disabled:opacity-60"
                    >
                      {syncing ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
                      مزامنة الأسعار/الخدمات
                    </button>
                  </div>

                  {/* Test result */}
                  {providerTest && (
                    <div className={`rounded-xl border p-3 text-xs space-y-1 ${providerTest.ok ? 'bg-success/10 border-success/30 text-success' : 'bg-destructive/10 border-destructive/30 text-destructive'}`}>
                      <div className="flex items-center justify-between font-semibold">
                        <span>{providerTest.ok ? '✅ نجح الاتصال' : '❌ فشل الاتصال'}</span>
                        {providerTest.responseMs != null && <span>⏱ {providerTest.responseMs}ms</span>}
                      </div>
                      {providerTest.balanceSyp != null && (
                        <p className="text-foreground">الرصيد: {Number(providerTest.balanceSyp).toLocaleString('en-US')} ل.س ≈ ${Number(providerTest.balanceUsd ?? 0).toFixed(2)}</p>
                      )}
                      {providerTest.error && <p className="break-all">{providerTest.error}</p>}
                    </div>
                  )}

                  {/* Sample products result */}
                  {productSample && (
                    <div className="rounded-xl border border-border bg-background p-3 text-xs space-y-2">
                      <p className="font-semibold">📦 إجمالي المنتجات في النظام: {productSample.count}</p>
                      {productSample.sample.length > 0 && (
                        <ul className="text-muted-foreground space-y-0.5 pr-4 list-disc">
                          {productSample.sample.map((n, i) => <li key={i} className="truncate">{n}</li>)}
                        </ul>
                      )}
                    </div>
                  )}

                  {/* Live balance & last sync */}
                  <div className="rounded-xl border border-border bg-background p-4 space-y-2">
                    <h3 className="text-xs font-bold flex items-center gap-2">
                      <DollarSign size={14} className="text-success" />
                      رصيد المزود الحالي وآخر مزامنة
                    </h3>
                    {!providerStatus?.configured ? (
                      <p className="text-xs text-muted-foreground">المزود غير مضبوط — أدخل الـ Token وفعّله</p>
                    ) : (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-[11px] text-muted-foreground mb-1">الرصيد (ل.س)</p>
                          <p className="text-base font-black text-success">
                            {providerStatus?.balanceSyp != null ? Number(providerStatus.balanceSyp).toLocaleString('en-US') : '—'}
                          </p>
                        </div>
                        <div>
                          <p className="text-[11px] text-muted-foreground mb-1">الرصيد (USD)</p>
                          <p className="text-base font-black text-success">
                            {providerStatus?.balanceUsd != null ? `$${Number(providerStatus.balanceUsd).toFixed(2)}` : '—'}
                          </p>
                        </div>
                        {providerStatus?.lastSyncAt && (
                          <div className="col-span-2">
                            <p className="text-[11px] text-muted-foreground">آخر مزامنة: {new Date(providerStatus.lastSyncAt).toLocaleString('ar-EG')}</p>
                          </div>
                        )}
                        {providerStatus?.error && (
                          <p className="col-span-2 text-xs text-destructive break-all">{providerStatus.error}</p>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="p-3 rounded-xl bg-background border border-border text-xs text-muted-foreground">
                    <p>🔐 يُحفظ الـ Token في قاعدة البيانات بشكل آمن. عند تعطيل المزود تُوقَف المزامنات وإرسال الطلبات تلقائياً.</p>
                  </div>

                  {/* ── URL Diagnostic Tool ── */}
                  <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 space-y-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-base">🔍</span>
                      <h4 className="text-sm font-bold text-amber-300">أداة تشخيص عنوان URL</h4>
                    </div>
                    <p className="text-xs text-white/50">
                      إذا كان الاتصال يفشل بخطأ 404، استخدم هذه الأداة لاختبار عناوين مختلفة واكتشاف الصحيح.
                      جرّب:
                      <code className="text-amber-300 mx-1">https://mega-game.net/api</code>
                      أو
                      <code className="text-amber-300 mx-1">https://mega-game.net/API</code>
                    </p>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={urlDiagInput}
                        onChange={e => setUrlDiagInput(e.target.value)}
                        placeholder={settings.provider_base_url || 'https://mega-game.net/api'}
                        className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-xs font-mono text-white focus:outline-none focus:border-amber-500/50"
                        dir="ltr"
                      />
                      <button
                        type="button"
                        onClick={handleTestUrl}
                        disabled={urlDiagRunning}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 transition-colors disabled:opacity-50 whitespace-nowrap"
                      >
                        {urlDiagRunning ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                        اختبر
                      </button>
                    </div>
                    {urlDiagResults && (
                      <div className="space-y-1.5">
                        {urlDiagResults.map((r: any, i: number) => (
                          <div key={i} className={`flex items-center justify-between p-2 rounded-lg text-xs font-mono ${r.ok ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/25 text-red-400'}`}>
                            <span className="truncate flex-1">{r.url}</span>
                            <div className="flex items-center gap-2 flex-shrink-0 mr-2">
                              <span>{r.ok ? '✅' : `❌ ${r.status ?? ''}`}</span>
                              <span className="text-white/40">{r.ms}ms</span>
                              {r.ok && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const base = r.url.replace(/\/games$/, '');
                                    set('provider_base_url', base);
                                    setUrlDiagInput('');
                                    toast({ title: '✅ تم تحديث Base URL', description: `تم ضبطه على: ${base}` });
                                  }}
                                  className="px-2 py-0.5 rounded bg-green-500/20 text-green-300 text-[10px] font-bold hover:bg-green-500/30 transition-colors"
                                >
                                  استخدم
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                        {urlDiagResults.length > 0 && urlDiagResults.every((r: any) => !r.ok) && (
                          <p className="text-[11px] text-red-400 mt-1">
                            ⚠️ لا يوجد مسار يعمل — تحقق من صحة الـ Token أو تواصل مع مزوّد API.
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </SectionCard>

              {/* Announcement Banner */}
              <SectionCard icon={Megaphone} title="بانر الإعلانات" sub="رسالة تظهر لجميع زوار المتجر" color="warning" delay={0.12}>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">نص الإعلان</label>
                    <textarea
                      value={settings.announcement}
                      onChange={e => set('announcement', e.target.value)}
                      placeholder="مثال: 🎉 عرض خاص! خصم 20% على جميع شحن PUBG اليوم فقط"
                      rows={3}
                      className={`${inputCls} resize-none`}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">نوع الإعلان</label>
                      <select value={settings.announcement_type} onChange={e => set('announcement_type', e.target.value)} className={inputCls}>
                        <option value="info">ℹ️ معلومات</option>
                        <option value="success">✅ نجاح</option>
                        <option value="warning">⚠️ تحذير</option>
                        <option value="error">🚨 تنبيه</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">حالة الإعلان</label>
                      <button
                        onClick={() => set('announcement_active', settings.announcement_active === 'true' ? 'false' : 'true')}
                        className={`w-full py-3 px-4 rounded-xl text-sm font-semibold border transition-all ${settings.announcement_active === 'true' ? 'bg-success/20 text-success border-success/30' : 'bg-background text-muted-foreground border-border'}`}
                      >
                        {settings.announcement_active === 'true' ? '🟢 مفعّل' : '⚫ معطّل'}
                      </button>
                    </div>
                  </div>
                </div>
              </SectionCard>

              {/* Maintenance Mode */}
              <SectionCard icon={Shield} title="وضع الصيانة" sub="يعطّل المتجر ويُظهر رسالة الصيانة للزوار" color="destructive" delay={0.16}>
                <div className="flex items-center justify-between p-4 rounded-xl bg-background border border-border">
                  <div>
                    <p className="font-semibold text-sm">وضع الصيانة</p>
                    <p className="text-xs text-muted-foreground mt-0.5">عند التفعيل، يرى الزوار صفحة صيانة فقط</p>
                  </div>
                  <button
                    onClick={() => set('maintenance_mode', settings.maintenance_mode === 'true' ? 'false' : 'true')}
                    className={`px-5 py-2 rounded-xl text-sm font-semibold border transition-all ${settings.maintenance_mode === 'true' ? 'bg-destructive/20 text-destructive border-destructive/30' : 'bg-background text-muted-foreground border-border'}`}
                  >
                    {settings.maintenance_mode === 'true' ? '🔴 مفعّل' : '⚫ معطّل'}
                  </button>
                </div>
                {settings.maintenance_mode === 'true' && (
                  <div className="p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-xs text-destructive">
                    ⚠️ تحذير: المتجر معطّل حالياً. لن يتمكن الزوار من تصفح المنتجات أو الشراء.
                  </div>
                )}
              </SectionCard>

              {/* Save Button */}
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-primary text-white rounded-xl font-semibold text-sm hover:bg-primary/90 transition-colors disabled:opacity-60"
                >
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
                  حفظ جميع الإعدادات
                </button>
              </motion.div>

              {/* Sync Provider quick action */}
              <SectionCard icon={Zap} title="مزامنة المنتجات والأسعار" sub="سحب أحدث المنتجات والأسعار من المزود" color="primary" delay={0.24}>
                <button
                  onClick={handleSyncProvider}
                  disabled={syncing}
                  className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-primary text-white rounded-xl font-bold text-sm hover:bg-primary/90 transition-colors disabled:opacity-60"
                >
                  {syncing ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
                  مزامنة الآن
                </button>
                <p className="text-xs text-muted-foreground">نسبة الربح المطبّقة: <strong className="text-foreground">{settings.default_profit_margin}%</strong> • سعر الصرف: <strong className="text-foreground">{Number(settings.syp_rate).toLocaleString('en-US')}</strong> ل.س لكل دولار</p>
              </SectionCard>

              {/* Telegram Bot Management */}
              <SectionCard icon={Send} title="إدارة بوت Telegram" sub="ضبط الـ Webhook واختبار البوت" color="secondary" delay={0.28}>
                {webhookInfo && (
                  <div className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm mb-3 ${webhookInfo.result?.url ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'}`}>
                    {webhookInfo.result?.url ? <CheckCircle size={14} /> : <XCircle size={14} />}
                    {webhookInfo.result?.url
                      ? `✅ Webhook نشط: ${webhookInfo.result.url.slice(0, 50)}...`
                      : '⚠️ لا يوجد Webhook مضبوط — البوت يستخدم polling'}
                  </div>
                )}

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold block mb-1.5 text-muted-foreground">رابط الموقع في Production (لضبط الـ Webhook)</label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        placeholder="https://elite-store.example.com"
                        value={webhookUrl}
                        onChange={e => setWebhookUrl(e.target.value)}
                        className="flex-1 px-4 py-3 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors"
                      />
                      <button
                        onClick={handleSetupWebhook}
                        disabled={settingWebhook}
                        className="flex items-center gap-2 px-4 py-3 bg-secondary text-white rounded-xl font-semibold text-sm hover:bg-secondary/90 transition-colors disabled:opacity-60"
                      >
                        {settingWebhook ? <Loader2 size={14} className="animate-spin" /> : <Webhook size={14} />}
                        ضبط
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">بعد الرفع للـ Production، ضع رابط موقعك هنا واضغط "ضبط" لتفعيل إشعارات Telegram</p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={handleTestBot}
                      disabled={testingBot}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-primary/15 text-primary border border-primary/20 rounded-xl font-semibold text-sm hover:bg-primary/25 transition-colors disabled:opacity-60"
                    >
                      {testingBot ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                      اختبار البوت
                    </button>
                    <button
                      onClick={loadWebhookInfo}
                      className="flex items-center gap-2 px-4 py-2.5 bg-muted/50 border border-border rounded-xl text-sm hover:bg-muted transition-colors"
                    >
                      <RefreshCw size={14} />
                      تحديث الحالة
                    </button>
                  </div>
                </div>

                <div className="mt-3 p-3 bg-muted/30 rounded-xl text-xs text-muted-foreground space-y-1">
                  <p className="font-semibold text-foreground text-xs">📌 إعداد البوت في Production:</p>
                  <p>1. أرفع الموقع أولاً على خدمة الاستضافة</p>
                  <p>2. ضع رابط الموقع في الحقل أعلاه (مثال: https://elite-store.com)</p>
                  <p>3. اضغط "ضبط" — سيتم ضبط الـ Webhook تلقائياً</p>
                  <p>4. اضغط "اختبار البوت" للتأكد من العمل الصحيح</p>
                </div>
              </SectionCard>

              {/* Project Archive Download */}
              <SectionCard icon={Archive} title="تحميل المشروع" sub="تحميل الكود الكامل لرفعه على أي سيرفر" color="primary" delay={0.32}>
                <div className="p-4 bg-muted/30 rounded-xl text-sm space-y-1 mb-4">
                  <p className="font-semibold text-foreground">📦 ما يتضمنه الأرشيف:</p>
                  <p className="text-muted-foreground">• جميع ملفات الكود (API + Frontend)</p>
                  <p className="text-muted-foreground">• ملفات الإعداد والبيئة</p>
                  <p className="text-muted-foreground">• دليل النشر الكامل (DEPLOYMENT.md)</p>
                  <p className="text-muted-foreground">• نماذج ملفات .env للاستضافة</p>
                </div>
                <button
                  onClick={async () => {
                    try {
                      const res = await fetch(`${BASE}/api/admin/download/project`, { headers: authHeader() });
                      if (!res.ok) { toast({ title: 'خطأ', description: 'تعذر تحميل الأرشيف', variant: 'destructive' }); return; }
                      const blob = await res.blob();
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url; a.download = 'elite-store-complete.tar.gz';
                      document.body.appendChild(a); a.click();
                      document.body.removeChild(a); URL.revokeObjectURL(url);
                    } catch {
                      toast({ title: 'خطأ في التحميل', variant: 'destructive' });
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-primary text-white rounded-xl font-bold text-sm hover:bg-primary/90 transition-colors"
                >
                  <Download size={14} />
                  تحميل المشروع الكامل (.tar.gz)
                </button>
                <p className="text-xs text-muted-foreground mt-2 text-center">بعد التحميل: <code className="text-primary">pnpm install && pnpm --filter @workspace/db run push && pnpm run build</code></p>
              </SectionCard>
            </>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
