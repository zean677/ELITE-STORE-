import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { AlertTriangle, RefreshCw, Trash2, Filter } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}` };
}

type ProviderErr = {
  id: number;
  provider: string;
  operation: string;
  status: number | null;
  message: string;
  context: string | null;
  createdAt: string;
};

const OP_LABELS: Record<string, string> = {
  fetchBalance: 'جلب الرصيد',
  dispatchOrder: 'إرسال طلب',
  checkOrderStatus: 'فحص حالة',
  testConnection: 'اختبار الاتصال',
  syncProducts: 'مزامنة المنتجات',
};

export default function AdminProviderErrors() {
  const [errors, setErrors] = useState<ProviderErr[]>([]);
  const [stats, setStats] = useState<{ provider: string; count: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const [providerLabels, setProviderLabels] = useState<Record<string, string>>({});
  const { toast } = useToast();

  // Load active provider name + label from /system
  useEffect(() => {
    fetch(`${BASE}/api/admin/system`, { headers: authHeaders() })
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (!d?.providers) return;
        const labels: Record<string, string> = {};
        for (const k of Object.keys(d.providers)) {
          labels[k] = d.providers[k]?.displayName ?? k;
        }
        setProviderLabels(labels);
      })
      .catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const url = `${BASE}/api/admin/provider-errors${filter !== 'all' ? `?provider=${filter}` : ''}`;
      const res = await fetch(url, { headers: authHeaders() });
      if (res.ok) {
        const data = await res.json();
        setErrors(data.errors ?? []);
        setStats(data.stats ?? []);
      }
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const clearAll = async () => {
    if (!confirm('هل تريد فعلاً مسح كل سجلات الأخطاء؟')) return;
    const res = await fetch(`${BASE}/api/admin/provider-errors`, { method: 'DELETE', headers: authHeaders() });
    if (res.ok) {
      toast({ title: '✅ تم مسح السجل' });
      load();
    } else {
      toast({ title: 'خطأ', variant: 'destructive' });
    }
  };

  // Combine providers from labels and stats so we always show the active provider, even if no errors yet
  const knownProviders = Array.from(new Set([
    ...Object.keys(providerLabels),
    ...stats.map(s => s.provider),
  ]));
  const labelOf = (key: string) => providerLabels[key] ?? key;
  const filterOptions: string[] = ['all', ...knownProviders];

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
                <AlertTriangle size={22} className="text-amber-400" /> أخطاء المزوّدين
              </h1>
              <p className="text-muted-foreground text-sm mt-1">آخر {errors.length} خطأ مسجّل</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={load} disabled={loading}
                className="flex items-center gap-1 px-3 py-2 bg-card border border-border rounded-xl text-sm hover:border-primary/50 transition-colors disabled:opacity-50">
                <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> تحديث
              </button>
              <button onClick={clearAll}
                className="flex items-center gap-1 px-3 py-2 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl text-sm hover:bg-red-500/20 transition-colors">
                <Trash2 size={13} /> مسح الكل
              </button>
            </div>
          </div>

          {knownProviders.length > 0 && (
            <div className={`grid gap-3 ${knownProviders.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
              {knownProviders.map(p => {
                const cnt = stats.find(s => s.provider === p)?.count ?? 0;
                return (
                  <div key={p} className="bg-card border border-border rounded-2xl p-4">
                    <p className="text-xs text-muted-foreground">{labelOf(p)} - آخر 24 ساعة</p>
                    <p className={`text-2xl font-bold mt-1 ${cnt > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>{cnt}</p>
                  </div>
                );
              })}
            </div>
          )}

          {filterOptions.length > 2 && (
            <div className="flex items-center gap-2 flex-wrap">
              <Filter size={14} className="text-muted-foreground" />
              {filterOptions.map(opt => (
                <button key={opt} onClick={() => setFilter(opt)}
                  className={`px-3 py-1.5 rounded-xl text-xs border transition-colors ${
                    filter === opt
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'bg-card border-border hover:border-primary/50'
                  }`}>
                  {opt === 'all' ? 'الكل' : labelOf(opt)}
                </button>
              ))}
            </div>
          )}

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {loading ? (
              <div className="py-12 text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : errors.length === 0 ? (
              <div className="py-16 text-center">
                <AlertTriangle size={40} className="mx-auto text-emerald-400/40 mb-4" />
                <p className="text-muted-foreground">لا توجد أخطاء مسجّلة 🎉</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-background/50">
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الوقت</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المزوّد</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">العملية</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الحالة</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الرسالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {errors.map(err => (
                      <motion.tr key={err.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background transition-colors">
                        <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(err.createdAt).toLocaleString('en-GB', { timeZone: 'Asia/Damascus' })}
                        </td>
                        <td className="px-4 py-3 text-sm font-medium">{labelOf(err.provider)}</td>
                        <td className="px-4 py-3 text-sm text-muted-foreground">{OP_LABELS[err.operation] ?? err.operation}</td>
                        <td className="px-4 py-3">
                          {err.status ? (
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-mono border ${
                              err.status >= 500 ? 'text-red-400 bg-red-500/10 border-red-500/20'
                              : err.status >= 400 ? 'text-amber-400 bg-amber-500/10 border-amber-500/20'
                              : 'text-muted-foreground bg-muted/10 border-border'
                            }`}>{err.status}</span>
                          ) : <span className="text-xs text-muted-foreground">—</span>}
                        </td>
                        <td className="px-4 py-3 text-xs max-w-md">
                          <div className="text-foreground/80 break-words">{err.message}</div>
                          {err.context && (
                            <div className="text-muted-foreground/60 mt-1 font-mono text-[10px] truncate" title={err.context}>
                              {err.context}
                            </div>
                          )}
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
