import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useQuery } from '@tanstack/react-query';
import { TrendingUp, ShoppingBag, Users, DollarSign, Crown, BarChart3, Loader2, Package, Target } from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const COLORS = ['#a855f7', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#3b82f6', '#ec4899', '#84cc16'];

function api(method: string, path: string) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, { method, headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) } });
}

function StatCard({ icon: Icon, label, value, sub, color = 'primary' }: any) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-2xl p-4 relative overflow-hidden">
      <div className={`absolute -top-6 -left-6 w-20 h-20 rounded-full opacity-10 blur-2xl bg-${color}`} />
      <div className="relative">
        <div className={`w-9 h-9 rounded-xl bg-${color}/15 flex items-center justify-center mb-2`}>
          <Icon size={16} className={`text-${color}`} />
        </div>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="text-xl lg:text-2xl font-black mt-0.5 truncate">{value}</p>
        {sub && <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>}
      </div>
    </motion.div>
  );
}

function AnalyticsContent() {
  const [range, setRange] = useState(30);

  const { data, isLoading } = useQuery<any>({
    queryKey: ['admin-analytics', range],
    queryFn: async () => (await api('GET', `/api/admin/analytics?range=${range}`)).json(),
    refetchInterval: 60000,
  });

  const { data: profitData } = useQuery<any>({
    queryKey: ['admin-profit-daily', range],
    queryFn: async () => (await api('GET', `/api/admin/profit-daily?days=${range}`)).json(),
    refetchInterval: 60000,
  });

  if (isLoading || !data) {
    return <div className="flex justify-center py-16"><Loader2 size={28} className="animate-spin text-primary" /></div>;
  }

  const s = data.summary;
  const successRate = s.totalOrders > 0 ? Math.round((s.completedOrders / s.totalOrders) * 100) : 0;

  // Merge daily orders + users for combined chart
  const dailyMap = new Map<string, any>();
  (data.daily ?? []).forEach((d: any) => dailyMap.set(d.day, { ...d, users: 0 }));
  (data.dailyUsers ?? []).forEach((d: any) => {
    const existing = dailyMap.get(d.day) ?? { day: d.day, orders: 0, completed: 0, failed: 0, revenue: 0 };
    dailyMap.set(d.day, { ...existing, users: d.users });
  });
  const combined = Array.from(dailyMap.values()).sort((a, b) => a.day.localeCompare(b.day))
    .map(d => ({ ...d, label: d.day.slice(5) /* MM-DD */ }));

  return (
    <div dir="rtl" className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl lg:text-3xl font-black flex items-center gap-2">
            <BarChart3 className="text-purple-400" size={28} /> التحليلات المتقدمة
          </h1>
          <p className="text-xs text-muted-foreground mt-1">رؤى ذكية لاتخاذ قرارات مبنية على أرقام حقيقية</p>
        </div>
        <div className="flex gap-1 bg-card border border-border rounded-xl p-1">
          {[7, 30, 90, 365].map(d => (
            <button key={d} onClick={() => setRange(d)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${range === d ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              {d === 7 ? '٧ أيام' : d === 30 ? '٣٠ يوم' : d === 90 ? '٩٠ يوم' : 'سنة'}
            </button>
          ))}
        </div>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard icon={DollarSign} color="emerald-400" label="إجمالي الإيرادات" value={`$${s.totalRevenue.toFixed(2)}`} sub={`متوسط الطلب $${s.avgOrderValue.toFixed(2)}`} />
        <StatCard icon={ShoppingBag} color="blue-400" label="الطلبات المكتملة" value={s.completedOrders} sub={`نسبة النجاح ${successRate}%`} />
        <StatCard icon={Users} color="purple-400" label="إجمالي المستخدمين" value={s.usersCount} sub={`${s.productsCount} منتج نشط`} />
        <StatCard icon={Target} color="yellow-400" label="توقع 30 يوم" value={`$${s.forecast30.toFixed(0)}`} sub={`بمعدل $${s.dailyAvg.toFixed(2)}/يوم`} />
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard icon={ShoppingBag} color="orange-400" label="معلّق" value={s.pendingOrders} />
        <StatCard icon={ShoppingBag} color="red-400" label="فاشل" value={s.failedOrders} />
        <StatCard icon={DollarSign} color="cyan-400" label="إيداعات" value={`$${s.depositsTotal.toFixed(2)}`} sub={`${s.depositsCount} عملية`} />
        <StatCard icon={TrendingUp} color="pink-400" label="إجمالي الطلبات" value={s.totalOrders} />
      </div>

      {/* Revenue chart */}
      <div className="bg-card border border-border rounded-2xl p-4 lg:p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-bold flex items-center gap-2"><TrendingUp size={16} className="text-emerald-400" /> الإيرادات اليومية</h3>
          <span className="text-xs text-muted-foreground">آخر {range} يوم</span>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={combined}>
            <defs>
              <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
            <XAxis dataKey="label" tick={{ fill: '#9ca3af', fontSize: 10 }} />
            <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} />
            <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }}
              formatter={(v: any) => [`$${Number(v).toFixed(2)}`, 'الإيراد']} />
            <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="url(#rev)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Orders + Users */}
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-2xl p-4 lg:p-5">
          <h3 className="font-heading font-bold mb-3 flex items-center gap-2"><ShoppingBag size={16} className="text-blue-400" /> الطلبات اليومية</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={combined}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="label" tick={{ fill: '#9ca3af', fontSize: 10 }} />
              <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} />
              <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="completed" name="مكتمل" stackId="a" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="failed" name="فاشل" stackId="a" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-2xl p-4 lg:p-5">
          <h3 className="font-heading font-bold mb-3 flex items-center gap-2"><Users size={16} className="text-purple-400" /> مستخدمون جدد</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={combined}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="label" tick={{ fill: '#9ca3af', fontSize: 10 }} />
              <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} />
              <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }} />
              <Line type="monotone" dataKey="users" stroke="#a855f7" strokeWidth={2.5} dot={{ fill: '#a855f7', r: 3 }} name="جدد" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top products + Categories */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-2xl p-4 lg:p-5">
          <h3 className="font-heading font-bold mb-3 flex items-center gap-2"><Package size={16} className="text-orange-400" /> أكثر 10 منتجات مبيعاً</h3>
          {data.topProducts.length === 0 ? <p className="text-sm text-muted-foreground py-8 text-center">لا توجد بيانات بعد</p> : (
            <div className="space-y-2">
              {data.topProducts.map((p: any, i: number) => {
                const max = data.topProducts[0]?.revenue || 1;
                const pct = (p.revenue / max) * 100;
                return (
                  <div key={p.product_id} className="relative bg-background/40 rounded-xl p-3 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-l from-orange-500/15 to-transparent" style={{ width: `${pct}%` }} />
                    <div className="relative flex items-center justify-between gap-2">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className={`w-7 h-7 shrink-0 rounded-lg flex items-center justify-center text-xs font-black ${i < 3 ? 'bg-orange-500/20 text-orange-400' : 'bg-muted text-muted-foreground'}`}>
                          {i + 1}
                        </span>
                        <p className="text-sm font-semibold truncate">{p.product_name}</p>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-sm font-black text-emerald-400">${p.revenue.toFixed(2)}</p>
                        <p className="text-[10px] text-muted-foreground">{p.units} وحدة · {p.orders} طلب</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-card border border-border rounded-2xl p-4 lg:p-5">
          <h3 className="font-heading font-bold mb-3 flex items-center gap-2"><BarChart3 size={16} className="text-cyan-400" /> الفئات</h3>
          {data.categoryBreakdown.length === 0 ? <p className="text-sm text-muted-foreground py-8 text-center">—</p> : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={data.categoryBreakdown} dataKey="revenue" nameKey="category" cx="50%" cy="50%" innerRadius={45} outerRadius={80} paddingAngle={2}>
                  {data.categoryBreakdown.map((_: any, i: number) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }}
                  formatter={(v: any) => `$${Number(v).toFixed(2)}`} />
              </PieChart>
            </ResponsiveContainer>
          )}
          <div className="mt-2 space-y-1">
            {data.categoryBreakdown.slice(0, 5).map((c: any, i: number) => (
              <div key={c.category} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-muted-foreground">{c.category}</span>
                </div>
                <span className="font-bold">${c.revenue.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top customers */}
      <div className="bg-card border border-border rounded-2xl p-4 lg:p-5">
        <h3 className="font-heading font-bold mb-3 flex items-center gap-2"><Crown size={16} className="text-yellow-400" /> أعلى 10 عملاء إنفاقاً</h3>
        {data.topCustomers.length === 0 ? <p className="text-sm text-muted-foreground py-8 text-center">لا توجد بيانات</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-right text-xs text-muted-foreground border-b border-border">
                  <th className="py-2 font-medium">#</th>
                  <th className="py-2 font-medium">المستخدم</th>
                  <th className="py-2 font-medium">VIP</th>
                  <th className="py-2 font-medium text-center">الطلبات</th>
                  <th className="py-2 font-medium text-left">الإنفاق</th>
                </tr>
              </thead>
              <tbody>
                {data.topCustomers.map((c: any, i: number) => (
                  <tr key={c.user_id} className="border-b border-border/50 hover:bg-background/40">
                    <td className="py-2.5">
                      <span className={`text-xs font-black ${i === 0 ? 'text-yellow-400' : i === 1 ? 'text-gray-300' : i === 2 ? 'text-orange-400' : 'text-muted-foreground'}`}>
                        {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
                      </span>
                    </td>
                    <td className="py-2.5">
                      <p className="font-semibold">{c.username}</p>
                      {c.public_code && <p className="text-[10px] text-muted-foreground font-mono">{c.public_code}</p>}
                    </td>
                    <td className="py-2.5">
                      {c.vip_level > 0 ? <span className="px-2 py-0.5 rounded-full bg-yellow-500/15 text-yellow-400 text-[10px] font-bold">VIP{c.vip_level}</span> : <span className="text-[10px] text-muted-foreground">عادي</span>}
                    </td>
                    <td className="py-2.5 text-center font-semibold">{c.orders}</td>
                    <td className="py-2.5 text-left font-black text-emerald-400">${c.spent.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AdminAnalytics() {
  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="mb-4 flex justify-end px-4">
          <a href="../intelligence" className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold hover:bg-amber-500/20 transition-colors">
            ⚡ ذكاء الإيرادات →
          </a>
        </div>
        <AnalyticsContent />
      </DashboardLayout>
    </ProtectedRoute>
  );
}
