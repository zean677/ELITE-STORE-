import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Shield, UserCog, Search, Plus, Save, X, Lock, Unlock, UserMinus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token')}`, 'Content-Type': 'application/json' });

const PERM_LABELS: Record<string, string> = {
  'orders.view': 'عرض الطلبات',
  'orders.write': 'إدارة/قبول/رفض الطلبات',
  'payments.view': 'عرض المدفوعات',
  'payments.approve': 'الموافقة على المدفوعات',
  'payments.manage': 'إدارة طرق الدفع',
  'users.view': 'عرض المستخدمين',
  'users.write': 'تعديل المستخدمين',
  'products.view': 'عرض المنتجات',
  'products.write': 'تعديل/إضافة المنتجات',
  'notifications.view': 'عرض سجل الإشعارات',
  'notifications.write': 'إرسال إشعارات',
  'settings.write': 'تعديل الإعدادات',
  'analytics.view': 'عرض التحليلات',
  'support.manage': 'إدارة تذاكر الدعم',
  'loyalty.manage': 'إدارة الولاء والمكافآت',
  'offers.manage': 'إدارة العروض والحزم',
  'store.manage': 'إدارة واجهة المتجر والإعلانات',
  'media.manage': 'إدارة الصور والوسائط',
  'system.monitor': 'عرض مراقبة النظام',
};

const ROLE_PRESETS: Record<string, { label: string; emoji: string; perms: string[]; desc: string }> = {
  manager: {
    label: 'مدير',
    emoji: '👔',
    desc: 'طلبات + منتجات + تحليلات',
    perms: ['orders.view', 'orders.write', 'products.view', 'products.write', 'analytics.view'],
  },
  support: {
    label: 'دعم فني',
    emoji: '🎧',
    desc: 'طلبات + عملاء فقط',
    perms: ['orders.view', 'orders.write', 'users.view', 'support.manage'],
  },
  finance: {
    label: 'مالية',
    emoji: '💰',
    desc: 'مدفوعات + تحليلات',
    perms: ['payments.view', 'payments.approve', 'analytics.view'],
  },
  content: {
    label: 'محتوى',
    emoji: '📦',
    desc: 'منتجات + إشعارات',
    perms: ['products.view', 'products.write', 'notifications.view', 'notifications.write'],
  },
};

const displayName = (user: any) => user.username?.trim() || user.email?.trim() || `مستخدم #${user.id}`;

export default function AdminStaff() {
  const [staff, setStaff] = useState<any[]>([]);
  const [allPerms, setAllPerms] = useState<string[]>([]);
  const [editing, setEditing] = useState<any | null>(null);
  const [editPerms, setEditPerms] = useState<string[]>([]);
  const [editRole, setEditRole] = useState<'staff' | 'admin' | 'user'>('staff');
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [busyUserId, setBusyUserId] = useState<number | null>(null);
  const { toast } = useToast();

  const reload = async () => {
    try {
      const [staffResponse, permissionsResponse] = await Promise.all([
        fetch(`${BASE}/api/admin/staff`, { headers: headers() }),
        fetch(`${BASE}/api/admin/permissions/list`, { headers: headers() }),
      ]);
      const [staffData, permissionsData] = await Promise.all([
        staffResponse.json().catch(() => ({})),
        permissionsResponse.json().catch(() => ({})),
      ]);
      if (!staffResponse.ok) throw new Error(staffData.error || 'تعذر تحميل الموظفين');
      if (!permissionsResponse.ok) throw new Error(permissionsData.error || 'تعذر تحميل الصلاحيات');
      setStaff(staffData.staff || []);
      setAllPerms(permissionsData.permissions || []);
    } catch (error: any) {
      toast({ title: 'فشل تحميل البيانات', description: error?.message, variant: 'destructive' });
    }
  };
  useEffect(() => { void reload(); }, []);

  useEffect(() => {
    const q = search.trim();
    if (q.length < 2) {
      setSearchResults([]);
      setSearchError('');
      setSearchLoading(false);
      return;
    }
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setSearchLoading(true);
      setSearchError('');
      try {
        const r = await fetch(`${BASE}/api/admin/search?q=${encodeURIComponent(q)}&scope=users`, { headers: headers(), signal: controller.signal });
        const d = await r.json();
        if (!r.ok) throw new Error(d?.error || 'فشل البحث');
        setSearchResults(d.users || []);
      } catch (error: any) {
        if (error?.name !== 'AbortError') {
          setSearchResults([]);
          setSearchError(error?.message || 'تعذر البحث');
        }
      } finally {
        if (!controller.signal.aborted) setSearchLoading(false);
      }
    }, 300);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [search]);

  const startEdit = (u: any) => {
    if (!['user', 'staff', 'admin'].includes(u.role)) {
      toast({ title: 'تعذر تعديل المستخدم', description: 'لم يصل الدور الحالي بشكل صحيح.', variant: 'destructive' });
      return;
    }
    setEditing(u);
    setEditPerms(Array.isArray(u.permissions) ? u.permissions : []);
    setEditRole(u.role);
  };

  const save = async () => {
    if (!editing) return;
    setBusyUserId(editing.id);
    try {
      const r = await fetch(`${BASE}/api/admin/users/${editing.id}/permissions`, {
        method: 'PATCH', headers: headers(),
        body: JSON.stringify({ role: editRole, permissions: editPerms }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || 'فشل حفظ الدور والصلاحيات');
      toast({ title: 'تم الحفظ', description: 'تم تحديث الدور والصلاحيات وإبطال الجلسات القديمة.' });
      setEditing(null); setSearchResults([]); setSearch('');
      await reload();
    } catch (error: any) {
      toast({ title: 'فشل الحفظ', description: error?.message, variant: 'destructive' });
    } finally {
      setBusyUserId(null);
    }
  };

  const toggleSuspension = async (user: any) => {
    const suspended = !user.isSuspended;
    setBusyUserId(user.id);
    try {
      const response = await fetch(`${BASE}/api/admin/users/${user.id}/suspend`, {
        method: 'PATCH',
        headers: headers(),
        body: JSON.stringify({ suspended }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'تعذر تحديث حالة الحساب');
      toast({ title: suspended ? 'تم تعطيل الحساب' : 'تم تفعيل الحساب' });
      await reload();
    } catch (error: any) {
      toast({ title: 'فشل تحديث الحالة', description: error?.message, variant: 'destructive' });
    } finally {
      setBusyUserId(null);
    }
  };

  const removeStaffRole = async (user: any) => {
    if (user.role !== 'staff') return;
    if (!confirm(`إزالة ${displayName(user)} من الموظفين؟ سيعود الحساب إلى مستخدم عادي، ولن تُحذف بياناته أو طلباته.`)) return;
    setBusyUserId(user.id);
    try {
      const response = await fetch(`${BASE}/api/admin/users/${user.id}/permissions`, {
        method: 'PATCH',
        headers: headers(),
        body: JSON.stringify({ role: 'user', permissions: [] }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'تعذر إزالة دور الموظف');
      toast({ title: 'تمت إزالة دور الموظف', description: 'الحساب وبياناته محفوظة كمستخدم عادي.' });
      await reload();
    } catch (error: any) {
      toast({ title: 'فشل إزالة الموظف', description: error?.message, variant: 'destructive' });
    } finally {
      setBusyUserId(null);
    }
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div>
            <h1 className="font-heading text-2xl font-bold">الموظفون والصلاحيات</h1>
            <p className="text-muted-foreground text-sm mt-1">امنح موظفيك صلاحيات محددة دون مشاركة حساب الأدمن</p>
          </div>

          {/* Add/Promote */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-bold mb-3 flex items-center gap-2"><Plus size={16} /> ترقية مستخدم إلى موظف</h2>
            <div className="relative mb-3">
              <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="اسم المستخدم أو الإيميل أو الكود أو ID..."
                className="w-full pr-9 pl-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
            </div>
            {searchLoading && <p className="text-xs text-muted-foreground">جاري البحث...</p>}
            {searchError && <p className="text-xs text-destructive">{searchError}</p>}
            {searchResults.length > 0 && (
              <div className="space-y-1.5">
                {searchResults.map(u => (
                  <button key={u.id} onClick={() => startEdit(u)}
                    className="w-full flex items-center gap-3 p-3 rounded-xl border border-border hover:border-primary/40 hover:bg-background text-right">
                    <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center text-primary text-sm font-bold">
                       {displayName(u).slice(0, 1).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                       <p className="text-sm font-semibold truncate">{displayName(u)}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{u.email} · #{u.id}{u.publicCode ? ` · ${u.publicCode}` : ''}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Existing staff/admins */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-border">
              <h2 className="font-bold">الموظفون الحاليون ({staff.length})</h2>
            </div>
            <div className="divide-y divide-border">
              {staff.map((u: any) => (
                <div key={u.id} className="p-4 flex items-center gap-3 hover:bg-background">
                  <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center text-primary font-bold">
                     {displayName(u).slice(0, 1).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                       <p className="text-sm font-bold truncate">{displayName(u)}</p>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${u.role === 'admin' ? 'bg-primary/20 text-primary' : 'bg-cyan-500/15 text-cyan-300'}`}>
                        {u.role === 'admin' ? <><Shield size={9} className="inline" /> مدير كامل</> : <><UserCog size={9} className="inline" /> موظف</>}
                      </span>
                    </div>
                    <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                       {u.email} · {u.isSuspended ? 'معطّل' : 'مفعّل'} · {u.role === 'staff' ? `${(u.permissions ?? []).length} صلاحية` : 'كل الصلاحيات'}
                    </p>
                  </div>
                   {u.role === 'staff' && (
                     <button onClick={() => void toggleSuspension(u)} disabled={busyUserId === u.id}
                       aria-label={u.isSuspended ? 'تفعيل الحساب' : 'تعطيل الحساب'}
                       className="p-2 rounded-lg border border-border hover:bg-background disabled:opacity-50">
                       {u.isSuspended ? <Unlock size={15} /> : <Lock size={15} />}
                     </button>
                   )}
                   {u.role === 'staff' && (
                     <button onClick={() => void removeStaffRole(u)} disabled={busyUserId === u.id}
                       aria-label="إزالة دور الموظف"
                       className="p-2 rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10 disabled:opacity-50">
                       <UserMinus size={15} />
                     </button>
                   )}
                   <button onClick={() => startEdit(u)}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25">
                    تعديل
                  </button>
                </div>
              ))}
              {staff.length === 0 && (
                <div className="p-6 text-center text-sm text-muted-foreground">لا يوجد موظفون بعد. ابحث أعلاه عن مستخدم وقم بترقيته.</div>
              )}
            </div>
          </div>
        </div>

        {editing && (
          <div className="fixed inset-0 z-[200] bg-black/70 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setEditing(null)}>
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              className="bg-card border border-border rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()} dir="rtl">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-bold">{displayName(editing)}</h3>
                     <p className="text-xs text-muted-foreground">{editing.email} · #{editing.id}{editing.publicCode ? ` · ${editing.publicCode}` : ''}</p>
                </div>
                <button onClick={() => setEditing(null)} className="p-1 hover:bg-white/5 rounded"><X size={16} /></button>
              </div>

              <label className="text-xs font-semibold text-muted-foreground mb-2 block">الدور</label>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {(['user', 'staff', 'admin'] as const).map(r => (
                  <button key={r} onClick={() => setEditRole(r)}
                    className="py-2 rounded-xl text-xs font-bold border-2"
                    style={{
                      borderColor: editRole === r ? '#6C5CE7' : '#2a2a40',
                      color: editRole === r ? '#a29bfe' : '#888',
                      background: editRole === r ? 'rgba(108,92,231,0.12)' : 'transparent',
                    }}>
                    {r === 'user' ? 'مستخدم عادي' : r === 'staff' ? 'موظف' : 'مدير كامل'}
                  </button>
                ))}
              </div>

              {editRole === 'staff' && (
                <>
                  {/* Role Presets */}
                  <label className="text-xs font-semibold text-muted-foreground mb-2 block">قوالب الأدوار الجاهزة</label>
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    {Object.entries(ROLE_PRESETS).map(([key, preset]) => (
                      <button
                        key={key}
                        onClick={() => setEditPerms([...preset.perms])}
                        className={`flex flex-col items-start p-2.5 rounded-xl border text-xs transition-all text-right ${
                          JSON.stringify([...editPerms].sort()) === JSON.stringify([...preset.perms].sort())
                            ? 'border-primary bg-primary/10 text-primary'
                            : 'border-white/15 bg-white/5 hover:border-white/30'
                        }`}
                      >
                        <span className="font-bold">{preset.emoji} {preset.label}</span>
                        <span className="text-muted-foreground mt-0.5">{preset.desc}</span>
                      </button>
                    ))}
                  </div>

                  <label className="text-xs font-semibold text-muted-foreground mb-2 block">الصلاحيات الممنوحة</label>
                  <div className="space-y-1.5 mb-4">
                    {allPerms.map(p => (
                      <label key={p} className="flex items-center gap-3 p-2.5 rounded-lg border border-border hover:bg-background cursor-pointer">
                        <input type="checkbox" checked={editPerms.includes(p)}
                          onChange={e => setEditPerms(prev => e.target.checked ? [...prev, p] : prev.filter(x => x !== p))}
                          className="w-4 h-4 accent-primary" />
                        <span className="text-xs">{PERM_LABELS[p] || p}</span>
                      </label>
                    ))}
                  </div>
                </>
              )}

              <button onClick={save} disabled={busyUserId === editing.id}
                className="w-full py-2.5 rounded-xl text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)' }}>
                <Save size={14} className="inline ml-1" /> {busyUserId === editing.id ? 'جارٍ الحفظ...' : 'حفظ التغييرات'}
              </button>
            </motion.div>
          </div>
        )}
      </DashboardLayout>
    </ProtectedRoute>
  );
}
