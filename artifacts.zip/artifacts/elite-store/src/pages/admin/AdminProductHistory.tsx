import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'wouter';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { History, ArrowRight, ArrowLeft, ChevronRight } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token')}` });

const FIELD_LABELS: Record<string, string> = {
  priceUsd: 'السعر النهائي (USD)', unitPriceUsd: 'سعر التكلفة (USD)',
  profitMargin: 'هامش الربح (%)', status: 'الحالة',
  name: 'الاسم', category: 'الفئة', isManual: 'يدوي',
};

function formatActor(username: string): { label: string; cls: string } {
  if (username.startsWith('sync:')) {
    const provider = username.slice(5);
    return { label: `🔄 مزامنة (${provider})`, cls: 'bg-blue-500/15 text-blue-400 border-blue-500/30' };
  }
  return { label: `👤 ${username}`, cls: 'bg-primary/15 text-primary border-primary/30' };
}

function pctChange(oldV: string | null, newV: string | null): string | null {
  if (!oldV || !newV) return null;
  const o = parseFloat(oldV); const n = parseFloat(newV);
  if (!isFinite(o) || !isFinite(n) || o === 0) return null;
  const pct = ((n - o) / o) * 100;
  if (Math.abs(pct) < 0.1) return null;
  return (pct > 0 ? '+' : '') + pct.toFixed(1) + '%';
}

export default function AdminProductHistory() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [productName, setProductName] = useState('');

  useEffect(() => {
    setLoading(true);
    fetch(`${BASE}/api/admin/products/${id}/history`, { headers: headers() })
      .then(r => r.json())
      .then(d => { setLogs(d.logs || []); if (d.logs?.[0]) setProductName(d.logs[0].productName); })
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <Link href="/admin/products" className="text-xs text-primary inline-flex items-center gap-1 hover:underline">
            <ChevronRight size={12} /> عودة للمنتجات
          </Link>
          <div>
            <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
              <History size={22} className="text-primary" /> سجل تغييرات المنتج
            </h1>
            <p className="text-muted-foreground text-sm mt-1">{productName || id}</p>
          </div>

          {loading ? <p className="text-center py-8 text-muted-foreground">جاري التحميل...</p>
            : logs.length === 0 ? (
              <div className="bg-card border border-border rounded-2xl p-8 text-center">
                <History size={32} className="mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-sm text-muted-foreground">لا توجد تغييرات مسجلة على هذا المنتج بعد</p>
              </div>
            ) : (
              <div className="bg-card border border-border rounded-2xl overflow-hidden divide-y divide-border">
                {logs.map(l => {
                  const actor = formatActor(l.adminUsername || 'غير معروف');
                  const pct = (l.field === 'priceUsd' || l.field === 'unitPriceUsd') ? pctChange(l.oldValue, l.newValue) : null;
                  const pctCls = pct && pct.startsWith('+') ? 'text-orange-400' : 'text-emerald-400';
                  return (
                    <div key={l.id} className="p-4">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-md border text-[11px] font-semibold ${actor.cls}`}>{actor.label}</span>
                        <span>·</span>
                        <span>{new Date(l.createdAt).toLocaleString('ar-EG')}</span>
                      </div>
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className="text-xs px-2 py-1 rounded-lg bg-primary/15 text-primary font-semibold">
                          {FIELD_LABELS[l.field] || l.field}
                        </span>
                        <span className="text-xs line-through text-red-400 font-mono">{l.oldValue ?? '—'}</span>
                        <ArrowLeft size={12} className="text-muted-foreground" />
                        <span className="text-xs text-green-400 font-mono font-bold">{l.newValue ?? '—'}</span>
                        {pct && <span className={`text-xs font-bold font-mono ${pctCls}`}>{pct}</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
