import React, { useState } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Sparkles, TrendingUp, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token')}`, 'Content-Type': 'application/json' });

export default function AdminSmartPricing() {
  const [margin, setMargin] = useState(15);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [applying, setApplying] = useState(false);
  const { toast } = useToast();

  const compute = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/admin/products/suggest-prices`, {
        method: 'POST', headers: headers(), body: JSON.stringify({ margin }),
      });
      const d = await r.json();
      setSuggestions(d.suggestions || []);
      toast({ title: `🧮 تم حساب ${d.suggestions?.length ?? 0} منتج` });
    } catch { toast({ title: 'فشل', variant: 'destructive' }); }
    finally { setLoading(false); }
  };

  const apply = async () => {
    if (!confirm(`سيتم تطبيق هامش ${margin}% على ${suggestions.length} منتج. هل أنت متأكد؟`)) return;
    setApplying(true);
    try {
      const r = await fetch(`${BASE}/api/admin/products/suggest-prices`, {
        method: 'POST', headers: headers(),
        body: JSON.stringify({ margin, apply: true, productIds: suggestions.map(s => s.id) }),
      });
      const d = await r.json();
      toast({ title: `✅ تم تطبيق ${d.applied} منتج` });
      setSuggestions([]);
    } catch { toast({ title: 'فشل التطبيق', variant: 'destructive' }); }
    finally { setApplying(false); }
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div>
            <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
              <Sparkles size={22} className="text-yellow-400" /> اقتراح السعر الذكي
            </h1>
            <p className="text-muted-foreground text-sm mt-1">يحسب السعر المقترح بناءً على سعر التكلفة + هامش الربح</p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-5">
            <label className="text-xs font-semibold text-muted-foreground mb-2 block">هامش الربح (%)</label>
            <div className="flex items-center gap-3 mb-3">
              <input type="range" min={0} max={100} value={margin} onChange={e => setMargin(Number(e.target.value))} className="flex-1" />
              <input type="number" min={0} max={500} value={margin} onChange={e => setMargin(Number(e.target.value))}
                className="w-20 px-3 py-2 bg-background border border-border rounded-xl text-sm text-center font-bold" />
              <span className="text-sm">%</span>
            </div>
            <div className="flex gap-2">
              <button onClick={compute} disabled={loading}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)' }}>
                {loading ? 'جاري الحساب...' : 'احسب الأسعار المقترحة'}
              </button>
              {suggestions.length > 0 && (
                <button onClick={apply} disabled={applying}
                  className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
                  style={{ background: 'linear-gradient(135deg, #22c55e, #16a34a)' }}>
                  <Check size={14} className="inline ml-1" /> طبّق على {suggestions.length} منتج
                </button>
              )}
            </div>
          </div>

          {suggestions.length > 0 && (
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-border flex items-center justify-between">
                <h2 className="font-bold flex items-center gap-2"><TrendingUp size={16} /> الأسعار المقترحة</h2>
                <span className="text-xs text-muted-foreground">{suggestions.length} منتج</span>
              </div>
              <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
                {suggestions.map(s => {
                  const diff = s.suggested - s.current;
                  const pct = s.current > 0 ? ((diff / s.current) * 100).toFixed(1) : '—';
                  return (
                    <div key={s.id} className="p-3 flex items-center gap-3 hover:bg-background">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold truncate">{s.name}</p>
                        <p className="text-[10px] text-muted-foreground">تكلفة: ${s.cost.toFixed(4)}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-[10px] text-muted-foreground">الحالي</p>
                        <p className="text-xs font-mono">${s.current.toFixed(4)}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-[10px] text-muted-foreground">المقترح</p>
                        <p className="text-xs font-mono font-bold text-green-400">${s.suggested.toFixed(4)}</p>
                      </div>
                      <div className={`text-xs font-bold w-16 text-left ${diff > 0 ? 'text-green-400' : diff < 0 ? 'text-red-400' : 'text-muted-foreground'}`}>
                        {diff >= 0 ? '+' : ''}{pct}%
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
