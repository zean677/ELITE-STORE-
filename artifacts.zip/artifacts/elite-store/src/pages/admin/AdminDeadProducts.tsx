import React, { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Skull, RefreshCw, Power, Trash2, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = (json = false) => {
  const h: Record<string, string> = { Authorization: `Bearer ${localStorage.getItem('elite_token') || ''}` };
  if (json) h['Content-Type'] = 'application/json';
  return h;
};

interface DeadProduct {
  id: string;
  name: string;
  imageUrl?: string | null;
  priceUsd: string;
  status: string;
  provider: string | null;
  featuredCard: string | null;
  lastActivity: string;
  orderCount: number;
}

export default function AdminDeadProducts() {
  const [days, setDays] = useState(30);
  const [data, setData] = useState<DeadProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const { toast } = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/admin/reports/dead-products?days=${days}`, { headers: headers() });
      const j = await r.json();
      setData(j.products || []);
    } catch { toast({ title: 'فشل التحميل', variant: 'destructive' }); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [days]);

  const setStatus = async (id: string, status: 'active' | 'inactive') => {
    setBusy(id);
    try {
      await fetch(`${BASE}/api/admin/products/${id}`, { method: 'PUT', headers: headers(true), body: JSON.stringify({ status }) });
      toast({ title: status === 'inactive' ? 'تم إخفاء المنتج' : 'تم تفعيل المنتج' });
      setData((d) => d.map((p) => p.id === id ? { ...p, status } : p));
    } catch { toast({ title: 'فشل', variant: 'destructive' }); }
    finally { setBusy(null); }
  };

  const remove = async (id: string, name: string) => {
    if (!confirm(`حذف "${name}" نهائياً؟`)) return;
    setBusy(id);
    try {
      await fetch(`${BASE}/api/admin/products/${id}`, { method: 'DELETE', headers: headers() });
      toast({ title: '🗑️ حذف' });
      setData((d) => d.filter((p) => p.id !== id));
    } catch { toast({ title: 'فشل الحذف', variant: 'destructive' }); }
    finally { setBusy(null); }
  };

  const fmtDate = (s: string) => {
    const d = new Date(s);
    const diff = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
    return diff > 365 ? `قبل ${Math.floor(diff / 365)} سنة` : diff > 30 ? `قبل ${Math.floor(diff / 30)} شهر` : `قبل ${diff} يوم`;
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-5" dir="rtl">
          <div className="flex flex-wrap items-center gap-3 justify-between">
            <div>
              <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
                <Skull className="text-destructive" size={26} />
                المنتجات الميتة
              </h1>
              <p className="text-muted-foreground text-sm mt-1">
                منتجات ما طُلبت ولا مرة آخر <strong>{days}</strong> يوم. فكر بإخفائها أو خصم عليها.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select value={days} onChange={(e) => setDays(Number(e.target.value))}
                className="bg-card border border-border rounded-xl px-3 py-2 text-sm font-semibold">
                <option value={7}>آخر 7 أيام</option>
                <option value={14}>آخر 14 يوم</option>
                <option value={30}>آخر 30 يوم</option>
                <option value={60}>آخر 60 يوم</option>
                <option value={90}>آخر 90 يوم</option>
                <option value={180}>آخر 6 أشهر</option>
              </select>
              <button onClick={load} className="p-2 rounded-xl bg-card border border-border hover:bg-muted" title="تحديث">
                <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm">
                <strong className="text-2xl text-destructive">{data.length}</strong>
                <span className="text-muted-foreground mr-2">منتج بدون مبيعات</span>
              </div>
              {data.filter((p) => p.status === 'active').length > 0 && (
                <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30">
                  {data.filter((p) => p.status === 'active').length} منن لسا ظاهرين للعملاء
                </span>
              )}
            </div>
          </div>

          {loading ? (
            <div className="text-center py-20 text-muted-foreground">جاري التحميل...</div>
          ) : data.length === 0 ? (
            <div className="text-center py-20 bg-card border border-border rounded-2xl">
              <Skull className="mx-auto mb-3 text-muted-foreground/30" size={48} />
              <p className="text-muted-foreground">ما في منتجات ميتة 🎉 كل منتجاتك بتبيع.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {data.map((p) => (
                <div key={p.id} className="bg-card border border-border rounded-xl p-3 hover:border-destructive/40 transition-colors">
                  <div className="flex gap-3 mb-2">
                    {p.imageUrl ? (
                      <img src={p.imageUrl} alt={p.name} className="w-16 h-16 rounded-lg object-cover bg-muted" />
                    ) : (
                      <div className="w-16 h-16 rounded-lg bg-muted flex items-center justify-center text-muted-foreground text-xs">بدون صورة</div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{p.name}</div>
                      <div className="text-[11px] text-muted-foreground mt-0.5">${p.priceUsd}</div>
                      <div className="text-[10px] text-muted-foreground/70 mt-0.5">آخر نشاط: {fmtDate(p.lastActivity)}</div>
                      <div className="flex gap-1 mt-1">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${p.status === 'active' ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
                          {p.status === 'active' ? 'فعّال' : 'مخفي'}
                        </span>
                        {p.provider && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">{p.provider}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    <Link href={`/products/${p.id}`} className="flex-1 text-center text-[11px] py-1.5 rounded-lg bg-muted hover:bg-muted/80 flex items-center justify-center gap-1">
                      <ExternalLink size={11} /> فتح
                    </Link>
                    {p.status === 'active' ? (
                      <button onClick={() => setStatus(p.id, 'inactive')} disabled={busy === p.id}
                        className="flex-1 text-[11px] py-1.5 rounded-lg bg-amber-500/15 text-amber-400 border border-amber-500/30 hover:bg-amber-500/25 disabled:opacity-50 flex items-center justify-center gap-1">
                        <Power size={11} /> إخفاء
                      </button>
                    ) : (
                      <button onClick={() => setStatus(p.id, 'active')} disabled={busy === p.id}
                        className="flex-1 text-[11px] py-1.5 rounded-lg bg-success/15 text-success border border-success/30 hover:bg-success/25 disabled:opacity-50">
                        تفعيل
                      </button>
                    )}
                    <button onClick={() => remove(p.id, p.name)} disabled={busy === p.id}
                      className="text-[11px] py-1.5 px-2 rounded-lg bg-destructive/15 text-destructive border border-destructive/30 hover:bg-destructive/25 disabled:opacity-50">
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
