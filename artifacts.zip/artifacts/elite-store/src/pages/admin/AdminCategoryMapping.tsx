import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';
import {
  Layers, Save, Search, RotateCcw, Smartphone, Monitor, Gift, Wrench, Package,
  GripVertical, X, Loader2, ArrowLeftRight, CheckCircle2,
} from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

type Provider = string;

const STORE_CATS: {
  id: string;
  label: string;
  icon: React.ComponentType<any>;
  color: string;
  gradient: string;
}[] = [
  { id: 'mobile_games', label: 'ألعاب الموبايل', icon: Smartphone, color: '#8B5CF6', gradient: 'from-violet-500/20 to-purple-700/10' },
  { id: 'pc_games',     label: 'ألعاب الكمبيوتر', icon: Monitor,    color: '#3B82F6', gradient: 'from-blue-500/20 to-sky-700/10' },
  { id: 'gift_cards',   label: 'بطاقات هدايا',    icon: Gift,       color: '#EC4899', gradient: 'from-pink-500/20 to-rose-700/10' },
  { id: 'services',     label: 'خدمات / تطبيقات', icon: Wrench,     color: '#10B981', gradient: 'from-emerald-500/20 to-green-700/10' },
  { id: 'general',      label: 'عام',             icon: Package,    color: '#F59E0B', gradient: 'from-amber-500/20 to-orange-700/10' },
];

type ApiResp = {
  provider: Provider;
  mapping: Record<string, string>;
  seenCategories: string[];
};

function CategoryMappingPage() {
  const { toast } = useToast();
  const [provider, setProvider] = useState<Provider | null>(null);
  const [providerLabel, setProviderLabel] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [seen, setSeen] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [dragging, setDragging] = useState<string | null>(null);
  const [hoverCat, setHoverCat] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);

  // Discover the active provider from /system
  useEffect(() => {
    fetch(`${BASE}/api/admin/system`, { headers: authHeaders() })
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        const provs = d?.providers ?? {};
        const first = Object.keys(provs)[0];
        if (first) {
          setProvider(first);
          setProviderLabel(provs[first]?.displayName ?? first);
        } else {
          setLoading(false);
        }
      })
      .catch(() => setLoading(false));
  }, []);

  async function load(p: Provider) {
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/admin/sync/category-map/${p}`, { headers: authHeaders() });
      if (!r.ok) throw new Error(await r.text());
      const data: ApiResp = await r.json();
      setSeen(data.seenCategories || []);
      setMapping(data.mapping || {});
      setDirty(false);
    } catch (e: any) {
      toast({ title: 'فشل التحميل', description: e?.message || 'خطأ', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { if (provider) load(provider); }, [provider]);

  const seenLower = useMemo(() => seen.map(s => ({ raw: s, key: s.toLowerCase() })), [seen]);

  const unmapped = useMemo(() => {
    const q = search.trim().toLowerCase();
    return seenLower
      .filter(s => !mapping[s.key])
      .filter(s => !q || s.key.includes(q));
  }, [seenLower, mapping, search]);

  const groups = useMemo(() => {
    const out: Record<string, { raw: string; key: string }[]> = {};
    for (const c of STORE_CATS) out[c.id] = [];
    for (const s of seenLower) {
      const target = mapping[s.key];
      if (target && out[target]) out[target].push(s);
    }
    return out;
  }, [seenLower, mapping]);

  function assign(rawKey: string, target: string | null) {
    setMapping(prev => {
      const next = { ...prev };
      if (!target) delete next[rawKey];
      else next[rawKey] = target;
      return next;
    });
    setDirty(true);
  }

  async function save() {
    if (!provider) return;
    setSaving(true);
    try {
      const r = await fetch(`${BASE}/api/admin/sync/category-map/${provider}`, {
        method: 'PUT',
        headers: authHeaders(),
        body: JSON.stringify({ mapping }),
      });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: 'تم الحفظ', description: 'سيتم تطبيق الربط في المزامنة القادمة' });
      setDirty(false);
    } catch (e: any) {
      toast({ title: 'فشل الحفظ', description: e?.message || 'خطأ', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  async function applyNow() {
    if (!provider) return;
    if (dirty) await save();
    setSaving(true);
    try {
      const r = await fetch(`${BASE}/api/admin/products/sync`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({}),
      });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: 'بدأت المزامنة', description: 'سيتم إعادة تصنيف المنتجات بحسب الخريطة الجديدة' });
    } catch (e: any) {
      toast({ title: 'فشل تشغيل المزامنة', description: e?.message || 'خطأ', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  function autoSuggest() {
    const next = { ...mapping };
    let added = 0;
    for (const s of seenLower) {
      if (next[s.key]) continue;
      const t = s.key;
      let target: string | null = null;
      if (/(pc|steam|origin|epic|battle|blizzard|riot|gog|uplay|valorant|cs:?go|league|dota|wow)/.test(t)) target = 'pc_games';
      else if (/(card|بطاق|gift|prepaid|voucher|recharge|amazon|google play|playstation|psn|xbox|itunes|apple)/.test(t)) target = 'gift_cards';
      else if (/(vpn|netflix|spotify|chatgpt|canva|youtube|deezer|anghami|crunchyroll|tv|music|premium|plus|pro|subscription|اشتراك|تطبيق)/.test(t)) target = 'services';
      else if (/(pubg|free fire|garena|mobile legends|cod mobile|clash|brawl|8ball|شد|جواه|آيدي|كوينز|game|لعب|قيم|قيمز)/.test(t)) target = 'mobile_games';
      if (target) { next[s.key] = target; added++; }
    }
    setMapping(next);
    setDirty(true);
    toast({ title: 'اقتراح تلقائي', description: `تم اقتراح ${added} ربط — راجعها ثم احفظ` });
  }

  function clearAll() {
    if (!confirm('مسح كل الروابط لهذا المزود؟')) return;
    setMapping({});
    setDirty(true);
  }

  const totalSeen = seen.length;
  const totalMapped = Object.keys(mapping).filter(k => seenLower.some(s => s.key === k)).length;

  return (
    <DashboardLayout>
      <div dir="rtl" className="space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-2xl md:text-3xl font-black text-white flex items-center gap-2">
              <span className="w-9 h-9 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
                <ArrowLeftRight className="w-5 h-5 text-primary" />
              </span>
              ربط فئات المزود بفئات المتجر
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              اسحب فئة المزود وأفلتها على إحدى فئات المتجر. عند المزامنة القادمة، أي منتج بهذه الفئة الخام سيُصنّف تلقائياً.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={autoSuggest}
              className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm text-white flex items-center gap-2"
              data-testid="button-auto-suggest"
            >
              <Layers className="w-4 h-4" /> اقتراح تلقائي
            </button>
            <button
              onClick={clearAll}
              className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm text-white flex items-center gap-2"
              data-testid="button-clear-all"
            >
              <RotateCcw className="w-4 h-4" /> مسح الكل
            </button>
            <button
              onClick={save}
              disabled={!dirty || saving}
              className="px-4 py-2 rounded-xl bg-primary hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed text-sm font-bold text-white flex items-center gap-2"
              data-testid="button-save-mapping"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              حفظ
            </button>
            <button
              onClick={applyNow}
              disabled={saving}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-sm font-bold text-white flex items-center gap-2"
              data-testid="button-apply-now"
            >
              <CheckCircle2 className="w-4 h-4" /> حفظ + مزامنة الآن
            </button>
          </div>
        </div>

        {/* Provider header (single) + stats */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="px-4 py-1.5 rounded-xl bg-primary/15 border border-primary/30 text-sm font-bold text-primary">
            {providerLabel || provider || '— لا يوجد مزود مفعّل —'}
          </div>
          <div className="text-xs text-gray-400">
            {loading ? 'جاري التحميل…' : `تم ربط ${totalMapped} من أصل ${totalSeen} فئة`}
          </div>
          {dirty && (
            <span className="text-xs text-amber-400 font-bold">● تغييرات غير محفوظة</span>
          )}
        </div>

        {/* Body grid */}
        <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-4">
          {/* Left: unmapped pool */}
          <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden flex flex-col h-[70vh]">
            <div className="p-3 border-b border-white/10 sticky top-0 bg-background/50 backdrop-blur">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-bold text-white text-sm flex-1">فئات المزود غير المربوطة ({unmapped.length})</h3>
              </div>
              <div className="relative">
                <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="ابحث عن فئة…"
                  className="w-full pr-9 pl-3 py-2 bg-background border border-border rounded-lg text-sm text-white focus:outline-none focus:border-primary/50"
                  data-testid="input-search"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
              {loading && (
                <div className="flex items-center justify-center py-10 text-gray-500">
                  <Loader2 className="w-5 h-5 animate-spin" />
                </div>
              )}
              {!loading && unmapped.length === 0 && (
                <div className="text-center text-xs text-gray-500 py-10">
                  {totalSeen === 0 ? 'لا توجد فئات بعد — شغّل مزامنة أولاً.' : '🎉 كل الفئات مربوطة'}
                </div>
              )}
              {unmapped.map(s => (
                <div
                  key={s.key}
                  draggable
                  onDragStart={() => setDragging(s.key)}
                  onDragEnd={() => { setDragging(null); setHoverCat(null); }}
                  className={`group flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 cursor-grab active:cursor-grabbing transition-colors ${
                    dragging === s.key ? 'opacity-50' : ''
                  }`}
                  data-testid={`source-cat-${s.key}`}
                >
                  <GripVertical className="w-4 h-4 text-gray-500 shrink-0" />
                  <span className="text-sm text-white truncate flex-1" title={s.raw}>{s.raw}</span>
                  <select
                    value=""
                    onChange={e => e.target.value && assign(s.key, e.target.value)}
                    className="text-[10px] bg-background border border-white/10 rounded px-1 py-0.5 text-gray-400 opacity-0 group-hover:opacity-100 focus:opacity-100"
                    title="ربط سريع بدون سحب"
                  >
                    <option value="">↗</option>
                    {STORE_CATS.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>

          {/* Right: drop zones */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 content-start">
            {STORE_CATS.map(cat => {
              const Icon = cat.icon;
              const items = groups[cat.id] || [];
              const isHover = hoverCat === cat.id;
              return (
                <motion.div
                  key={cat.id}
                  layout
                  onDragOver={e => { e.preventDefault(); setHoverCat(cat.id); }}
                  onDragLeave={() => setHoverCat(h => h === cat.id ? null : h)}
                  onDrop={e => {
                    e.preventDefault();
                    if (dragging) assign(dragging, cat.id);
                    setDragging(null); setHoverCat(null);
                  }}
                  className={`rounded-2xl border bg-gradient-to-br ${cat.gradient} transition-all min-h-[200px] flex flex-col ${
                    isHover ? 'border-white/40 ring-2 ring-white/20 scale-[1.01]' : 'border-white/10'
                  }`}
                  style={{ boxShadow: isHover ? `0 0 0 1px ${cat.color}66 inset` : undefined }}
                  data-testid={`drop-zone-${cat.id}`}
                >
                  <div className="flex items-center gap-2 p-3 border-b border-white/10">
                    <span
                      className="w-9 h-9 rounded-xl flex items-center justify-center"
                      style={{ background: `${cat.color}25`, border: `1px solid ${cat.color}55` }}
                    >
                      <Icon className="w-5 h-5" style={{ color: cat.color }} />
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-white text-sm truncate">{cat.label}</div>
                      <div className="text-[10px] text-gray-400 font-mono">{cat.id}</div>
                    </div>
                    <span
                      className="text-xs font-black px-2 py-0.5 rounded-full"
                      style={{ background: `${cat.color}25`, color: cat.color }}
                    >
                      {items.length}
                    </span>
                  </div>
                  <div className="p-2 flex-1 flex flex-wrap gap-1.5 content-start">
                    {items.length === 0 && (
                      <div className="w-full text-center text-[11px] text-gray-500 py-6 border border-dashed border-white/10 rounded-xl">
                        اسحب فئة المزود إلى هنا
                      </div>
                    )}
                    {items.map(it => (
                      <span
                        key={it.key}
                        draggable
                        onDragStart={() => setDragging(it.key)}
                        onDragEnd={() => { setDragging(null); setHoverCat(null); }}
                        className="inline-flex items-center gap-1 max-w-full px-2 py-1 rounded-lg bg-white/10 hover:bg-white/15 border border-white/10 text-xs text-white cursor-grab active:cursor-grabbing"
                        title={it.raw}
                        data-testid={`mapped-${it.key}`}
                      >
                        <span className="truncate max-w-[160px]">{it.raw}</span>
                        <button
                          onClick={() => assign(it.key, null)}
                          className="text-gray-300 hover:text-white"
                          title="إلغاء الربط"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <div className="text-[11px] text-gray-500 leading-relaxed bg-white/[0.03] border border-white/10 rounded-xl p-3">
          <b className="text-gray-300">ملاحظات:</b> الربط يُطبَّق في المزامنة التالية. المنتجات التي عدّلت تصنيفها يدوياً من صفحة المنتجات لن تتغيّر (محمية بنظام الأقفال). استخدم زر «حفظ + مزامنة الآن» لإعادة تصنيف فوري.
        </div>
      </div>
    </DashboardLayout>
  );
}

export default function AdminCategoryMapping() {
  return (
    <ProtectedRoute adminOnly>
      <CategoryMappingPage />
    </ProtectedRoute>
  );
}
