import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguage } from '@/i18n';
import { Plus, Tag, Trash2, ToggleLeft, ToggleRight, Copy, CheckCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function adminApi(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

export default function AdminPromoCodes() {
  const { lang } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [copied, setCopied] = useState('');
  const [form, setForm] = useState({
    code: '',
    discountType: 'percent' as 'percent' | 'fixed',
    discountValue: '',
    maxUses: '',
    minOrderUsd: '',
    maxDiscountUsd: '',
    expiresAt: '',
  });

  const { data: promoCodes = [], isLoading } = useQuery({
    queryKey: ['admin-promo-codes'],
    queryFn: async () => {
      const res = await adminApi('GET', '/api/admin/promo-codes');
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await adminApi('POST', '/api/admin/promo-codes', {
        code: data.code.toUpperCase(),
        discountType: data.discountType,
        discountValue: parseFloat(data.discountValue),
        maxUses: data.maxUses ? parseInt(data.maxUses) : undefined,
        minOrderUsd: data.minOrderUsd ? parseFloat(data.minOrderUsd) : undefined,
        maxDiscountUsd: data.maxDiscountUsd ? parseFloat(data.maxDiscountUsd) : undefined,
        expiresAt: data.expiresAt || undefined,
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed'); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-promo-codes'] });
      setShowCreate(false);
      setForm({ code: '', discountType: 'percent', discountValue: '', maxUses: '', minOrderUsd: '', maxDiscountUsd: '', expiresAt: '' });
      toast({ title: lang === 'ar' ? 'تم إنشاء الكوبون' : 'Promo code created' });
    },
    onError: (e: any) => toast({ title: e.message, variant: 'destructive' }),
  });

  const toggleMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await adminApi('PATCH', `/api/admin/promo-codes/${id}/toggle`);
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['admin-promo-codes'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await adminApi('DELETE', `/api/admin/promo-codes/${id}`);
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-promo-codes'] });
      toast({ title: lang === 'ar' ? 'تم الحذف' : 'Deleted' });
    },
  });

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    setTimeout(() => setCopied(''), 2000);
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="p-6 max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-black text-white">{lang === 'ar' ? 'أكواد الخصم' : 'Promo Codes'}</h1>
              <p className="text-muted-foreground text-sm mt-0.5">{promoCodes.length} {lang === 'ar' ? 'كوبون' : 'codes'}</p>
            </div>
            <button
              onClick={() => setShowCreate(!showCreate)}
              className="flex items-center gap-2 px-4 py-2.5 bg-primary/20 border border-primary/40 text-primary rounded-xl font-semibold text-sm hover:bg-primary/30 transition-colors"
            >
              <Plus size={16} />{lang === 'ar' ? 'إنشاء كوبون' : 'Create Code'}
            </button>
          </div>

          <AnimatePresence>
            {showCreate && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-6 rounded-2xl border border-border bg-card p-5 overflow-hidden"
              >
                <h2 className="font-bold text-white mb-4">{lang === 'ar' ? 'كوبون جديد' : 'New Promo Code'}</h2>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'الكود' : 'Code'}</label>
                    <input
                      value={form.code}
                      onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
                      placeholder="ELITE20"
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm font-mono focus:outline-none focus:border-primary/50"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'نوع الخصم' : 'Discount Type'}</label>
                    <select
                      value={form.discountType}
                      onChange={e => setForm(f => ({ ...f, discountType: e.target.value as 'percent' | 'fixed' }))}
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                    >
                      <option value="percent">{lang === 'ar' ? 'نسبة مئوية %' : 'Percentage %'}</option>
                      <option value="fixed">{lang === 'ar' ? 'مبلغ ثابت $' : 'Fixed amount $'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'قيمة الخصم' : 'Discount Value'}</label>
                    <input
                      type="number" value={form.discountValue}
                      onChange={e => setForm(f => ({ ...f, discountValue: e.target.value }))}
                      placeholder={form.discountType === 'percent' ? '20' : '2.5'}
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'أقصى عدد استخدامات' : 'Max Uses'}</label>
                    <input
                      type="number" value={form.maxUses}
                      onChange={e => setForm(f => ({ ...f, maxUses: e.target.value }))}
                      placeholder={lang === 'ar' ? 'غير محدود' : 'Unlimited'}
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'الحد الأدنى للطلب ($)' : 'Min Order ($)'}</label>
                    <input
                      type="number" step="0.01" value={form.minOrderUsd}
                      onChange={e => setForm(f => ({ ...f, minOrderUsd: e.target.value }))}
                      placeholder="0"
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                    />
                  </div>
                  {form.discountType === 'percent' && (
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'أقصى خصم ($)' : 'Max Discount ($)'}</label>
                      <input
                        type="number" step="0.01" value={form.maxDiscountUsd}
                        onChange={e => setForm(f => ({ ...f, maxDiscountUsd: e.target.value }))}
                        placeholder={lang === 'ar' ? 'غير محدود' : 'Unlimited'}
                        className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                      />
                    </div>
                  )}
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">{lang === 'ar' ? 'تاريخ الانتهاء' : 'Expires At'}</label>
                    <input
                      type="datetime-local" value={form.expiresAt}
                      onChange={e => setForm(f => ({ ...f, expiresAt: e.target.value }))}
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => createMutation.mutate(form)}
                    disabled={!form.code || !form.discountValue || createMutation.isPending}
                    className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-xl font-semibold text-sm disabled:opacity-50 hover:opacity-90 transition-opacity"
                  >
                    {createMutation.isPending ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                    {lang === 'ar' ? 'إنشاء' : 'Create'}
                  </button>
                  <button onClick={() => setShowCreate(false)} className="px-5 py-2.5 border border-border rounded-xl text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 size={24} className="animate-spin text-muted-foreground" />
            </div>
          ) : promoCodes.length === 0 ? (
            <div className="text-center py-16">
              <Tag size={40} className="text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground">{lang === 'ar' ? 'لا توجد أكواد خصم بعد' : 'No promo codes yet'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {promoCodes.map((code: any) => (
                <div key={code.id} className="flex items-center gap-4 p-4 rounded-2xl bg-card border border-border">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-black text-white text-lg">{code.code}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${code.isActive ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'}`}>
                        {code.isActive ? (lang === 'ar' ? 'نشط' : 'Active') : (lang === 'ar' ? 'متوقف' : 'Inactive')}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                      <span>
                        {code.discountType === 'percent' ? `${code.discountValue}%` : `$${code.discountValue}`}
                        {lang === 'ar' ? ' خصم' : ' off'}
                      </span>
                      <span>•</span>
                      <span>{code.usedCount}/{code.maxUses ?? '∞'} {lang === 'ar' ? 'استخدامات' : 'uses'}</span>
                      {code.minOrderUsd > 0 && <><span>•</span><span>{lang === 'ar' ? 'حد أدنى' : 'Min'}: ${code.minOrderUsd}</span></>}
                      {code.expiresAt && <><span>•</span><span>{lang === 'ar' ? 'ينتهي' : 'Expires'}: {new Date(code.expiresAt).toLocaleDateString()}</span></>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={() => copyCode(code.code)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors border border-white/10">
                      {copied === code.code ? <CheckCircle size={14} className="text-emerald-400" /> : <Copy size={14} className="text-muted-foreground" />}
                    </button>
                    <button onClick={() => toggleMutation.mutate(code.id)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors border border-white/10">
                      {code.isActive ? <ToggleRight size={16} className="text-emerald-400" /> : <ToggleLeft size={16} className="text-muted-foreground" />}
                    </button>
                    <button onClick={() => { if (confirm(lang === 'ar' ? 'حذف هذا الكوبون؟' : 'Delete this code?')) deleteMutation.mutate(code.id); }} className="w-8 h-8 rounded-lg bg-red-500/10 hover:bg-red-500/20 flex items-center justify-center transition-colors border border-red-500/20">
                      <Trash2 size={14} className="text-red-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
