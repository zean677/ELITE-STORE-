import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useGetAdminUsers, useSuspendUser } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Users, Search, Shield, User, Ban, Edit3, Crown, Lock, Unlock, Copy, Download, StickyNote, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

export default function AdminUsers() {
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [page, setPage] = useState(1);
  const [balanceModal, setBalanceModal] = useState<{ id: number; username: string; balance: string } | null>(null);
  const [newBalance, setNewBalance] = useState('');
  const [balanceOp, setBalanceOp] = useState<'add' | 'subtract' | 'set'>('add');
  const [updatingBalance, setUpdatingBalance] = useState(false);
  const [vipModal, setVipModal] = useState<{ id: number; username: string; publicCode?: string; vipLevel: number; vipLocked: boolean } | null>(null);
  const [newVipLevel, setNewVipLevel] = useState(0);
  const [newVipLocked, setNewVipLocked] = useState(true);
  const [updatingVip, setUpdatingVip] = useState(false);
  const [notesModal, setNotesModal] = useState<{ id: number; username: string; notes: string } | null>(null);
  const [savingNotes, setSavingNotes] = useState(false);
  const [exporting, setExporting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const timer = window.setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => window.clearTimeout(timer);
  }, [search]);

  const exportCsv = async () => {
    setExporting(true);
    try {
      const res = await fetch(`${BASE}/api/admin/export/users`, { headers: { Authorization: `Bearer ${localStorage.getItem('elite_token')}` } });
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `users_${new Date().toISOString().split('T')[0]}.csv`;
      a.click(); URL.revokeObjectURL(a.href);
      toast({ title: '✅ تم التصدير' });
    } catch { toast({ title: 'فشل', variant: 'destructive' }); }
    finally { setExporting(false); }
  };

  const saveNotes = async () => {
    if (!notesModal) return;
    setSavingNotes(true);
    try {
      const r = await fetch(`${BASE}/api/admin/users/${notesModal.id}/notes`, {
        method: 'PATCH', headers: authHeaders(), body: JSON.stringify({ notes: notesModal.notes }),
      });
      if (!r.ok) throw new Error();
      toast({ title: '📝 تم حفظ الملاحظات' });
      setNotesModal(null); refetch();
    } catch { toast({ title: 'فشل الحفظ', variant: 'destructive' }); }
    finally { setSavingNotes(false); }
  };

  const { data, refetch, isLoading } = useGetAdminUsers({ page, limit: 25, search: debouncedSearch || undefined });
  const suspendUser = useSuspendUser();
  const users = data?.users ?? [];
  const total = data?.total ?? 0;

  const handleToggleStatus = async (id: number, suspended: boolean) => {
    try {
      await suspendUser.mutateAsync({ id, data: { suspended: !suspended } });
      toast({ title: !suspended ? '🚫 تم تعليق الحساب' : '✅ تم تفعيل الحساب' });
      refetch();
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحديث المستخدم', variant: 'destructive' });
    }
  };

  const handleUpdateVip = async () => {
    if (!vipModal) return;
    setUpdatingVip(true);
    try {
      const res = await fetch(`${BASE}/api/admin/users/${vipModal.id}/vip`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify({ level: newVipLevel, locked: newVipLocked }),
      });
      if (!res.ok) throw new Error(await res.text());
      toast({ title: '👑 تم تحديث مستوى VIP' });
      setVipModal(null);
      refetch();
    } catch (err: any) {
      toast({ title: 'خطأ', description: err.message, variant: 'destructive' });
    } finally {
      setUpdatingVip(false);
    }
  };

  const copyCode = (code?: string) => {
    if (!code) return;
    navigator.clipboard?.writeText(code);
    toast({ title: 'تم نسخ الكود', description: code });
  };

  const handleUpdateBalance = async () => {
    if (!balanceModal) return;
    setUpdatingBalance(true);
    try {
      const res = await fetch(`${BASE}/api/admin/users/${balanceModal.id}/balance`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify({ operation: balanceOp, amount: parseFloat(newBalance) }),
      });
      if (!res.ok) throw new Error(await res.text());
      toast({ title: '✅ تم تحديث الرصيد' });
      setBalanceModal(null);
      setNewBalance('');
      refetch();
    } catch (err: any) {
      toast({ title: 'خطأ', description: err.message, variant: 'destructive' });
    } finally {
      setUpdatingBalance(false);
    }
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="font-heading text-2xl font-bold">إدارة المستخدمين</h1>
              <p className="text-muted-foreground text-sm mt-1">{total} مستخدم مسجّل</p>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input type="search" placeholder="بحث: إيميل، اسم، كود، أو رقم ID..." value={search}
                  onChange={e => { setSearch(e.target.value); setPage(1); }}
                  className="pr-9 pl-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors w-full sm:w-72" dir="rtl" />
              </div>
              <button onClick={exportCsv} disabled={exporting}
                className="flex items-center gap-1.5 px-3 py-2.5 bg-green-500/10 text-green-400 border border-green-500/30 rounded-xl text-sm hover:bg-green-500/20 disabled:opacity-50">
                <Download size={14} /> {exporting ? '...' : 'CSV'}
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {isLoading ? (
              <div className="py-12 text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : users.length === 0 ? (
              <div className="py-16 text-center">
                <Users size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">لا يوجد مستخدمون</p>
              </div>
            ) : (
              <>
                {/* Desktop Table */}
                <div className="hidden lg:block overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-background/50">
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المستخدم</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">كود العميل</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الرصيد</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">VIP</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الدور</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">تاريخ التسجيل</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الحالة</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {users.map((user: any) => (
                        <motion.tr key={user.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background transition-colors">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                                <span className="text-primary text-xs font-bold">
                                  {(user.username?.trim() || user.email?.trim() || `#${user.id}`).slice(0, 1).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <p className="text-sm font-medium">{user.username?.trim() || 'بدون اسم مستخدم'}</p>
                                <p className="text-xs text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <button onClick={() => copyCode(user.publicCode)} className="flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 rounded-lg px-2 py-1 hover:bg-cyan-500/20 transition-colors" title="انسخ الكود">
                              <Copy size={10} />
                              {user.publicCode || `EL-${String(user.id).padStart(6, '0')}`}
                            </button>
                          </td>
                          <td className="px-4 py-3">
                            <span className="text-sm font-bold text-green-400">${parseFloat(user.balance || '0').toFixed(2)}</span>
                          </td>
                          <td className="px-4 py-3">
                            {(user.vipLevel ?? 0) > 0 ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-full bg-yellow-500/15 text-yellow-300 border border-yellow-500/30">
                                <Crown size={10} fill="currentColor" /> VIP {user.vipLevel}
                                {user.vipLocked && <Lock size={9} className="opacity-70" />}
                              </span>
                            ) : (
                              <span className="text-[11px] text-muted-foreground">—</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full w-fit ${user.role === 'admin' ? 'bg-primary/15 text-primary border border-primary/20' : 'bg-muted text-muted-foreground'}`}>
                              {user.role === 'admin' ? <><Shield size={10} /> مدير</> : <><User size={10} /> مستخدم</>}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(user.createdAt).toLocaleDateString('en-GB')}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${user.isSuspended ? 'bg-red-500/15 text-red-400 border border-red-500/20' : 'bg-green-500/15 text-green-400 border border-green-500/20'}`}>
                              {user.isSuspended ? 'موقوف' : 'نشط'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1.5">
                              <button onClick={() => { setBalanceModal({ id: user.id, username: user.username, balance: user.balance }); setNewBalance(user.balance); }}
                                className="p-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors" title="تعديل الرصيد">
                                <Edit3 size={12} />
                              </button>
                              <button onClick={() => { setVipModal({ id: user.id, username: user.username, publicCode: user.publicCode, vipLevel: user.vipLevel ?? 0, vipLocked: user.vipLocked ?? false }); setNewVipLevel(user.vipLevel ?? 0); setNewVipLocked(user.vipLocked ?? true); }}
                                className="p-1.5 rounded-lg bg-yellow-500/10 text-yellow-300 hover:bg-yellow-500/20 transition-colors" title="تعديل VIP">
                                <Crown size={12} />
                              </button>
                              {user.role !== 'admin' && (
                                <button onClick={() => handleToggleStatus(user.id, user.isSuspended)}
                                  className={`p-1.5 rounded-lg transition-colors ${user.isSuspended ? 'bg-green-500/10 text-green-400 hover:bg-green-500/20' : 'bg-red-500/10 text-red-400 hover:bg-red-500/20'}`}
                                  title={user.isSuspended ? 'رفع التعليق' : 'تعليق الحساب'}>
                                  <Ban size={12} />
                                </button>
                              )}
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile/Tablet Cards */}
                <div className="lg:hidden divide-y divide-border">
                  {users.map((user: any) => (
                    <motion.div key={user.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="p-4 hover:bg-background/50 transition-colors">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                          <span className="text-primary text-sm font-bold">
                            {(user.username?.trim() || user.email?.trim() || `#${user.id}`).slice(0, 1).toUpperCase()}
                          </span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-bold truncate">{user.username?.trim() || 'بدون اسم مستخدم'}</p>
                            <span className={`flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full ${user.role === 'admin' ? 'bg-primary/15 text-primary border border-primary/20' : 'bg-muted text-muted-foreground'}`}>
                              {user.role === 'admin' ? <><Shield size={9} /> مدير</> : <><User size={9} /> مستخدم</>}
                            </span>
                          </div>
                          <p className="text-[11px] text-muted-foreground truncate mt-0.5">{user.email}</p>
                        </div>
                        <span className={`text-[10px] px-2 py-1 rounded-full font-medium shrink-0 ${user.isSuspended ? 'bg-red-500/15 text-red-400 border border-red-500/20' : 'bg-green-500/15 text-green-400 border border-green-500/20'}`}>
                          {user.isSuspended ? 'موقوف' : 'نشط'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                        <div className="bg-background/50 border border-border/40 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground block mb-0.5">كود العميل</span>
                          <button onClick={() => copyCode(user.publicCode)} className="flex items-center gap-1 text-xs font-mono font-bold text-cyan-300 hover:text-cyan-200">
                            <Copy size={10} />
                            {user.publicCode || `EL-${String(user.id).padStart(6, '0')}`}
                          </button>
                        </div>
                        <div className="bg-background/50 border border-border/40 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground block mb-0.5">الرصيد</span>
                          <span className="text-sm font-bold text-green-400">${parseFloat(user.balance || '0').toFixed(2)}</span>
                        </div>
                        <div className="bg-background/50 border border-border/40 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground block mb-0.5">VIP</span>
                          {(user.vipLevel ?? 0) > 0 ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-yellow-300">
                              <Crown size={10} fill="currentColor" /> VIP {user.vipLevel}
                              {user.vipLocked && <Lock size={9} className="opacity-70" />}
                            </span>
                          ) : (
                            <span className="text-[11px] text-muted-foreground">عادي</span>
                          )}
                        </div>
                        <div className="bg-background/50 border border-border/40 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground block mb-0.5">التسجيل</span>
                          <span className="text-[11px] text-foreground/80">{new Date(user.createdAt).toLocaleDateString('en-GB')}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2 border-t border-border/40">
                        <button onClick={() => { setBalanceModal({ id: user.id, username: user.username, balance: user.balance }); setNewBalance(user.balance); }}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 transition-colors font-semibold">
                          <Edit3 size={12} /> الرصيد
                        </button>
                        <button onClick={() => { setVipModal({ id: user.id, username: user.username, publicCode: user.publicCode, vipLevel: user.vipLevel ?? 0, vipLocked: user.vipLocked ?? false }); setNewVipLevel(user.vipLevel ?? 0); setNewVipLocked(user.vipLocked ?? true); }}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-yellow-500/15 text-yellow-300 border border-yellow-500/30 hover:bg-yellow-500/25 transition-colors font-semibold">
                          <Crown size={12} /> VIP
                        </button>
                        <button onClick={() => setNotesModal({ id: user.id, username: user.username, notes: user.notes ?? '' })}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 hover:bg-cyan-500/25 transition-colors font-semibold">
                          <StickyNote size={12} /> ملاحظات{user.notes ? ' ●' : ''}
                        </button>
                        {user.role !== 'admin' && (
                          <button onClick={() => handleToggleStatus(user.id, user.isSuspended)}
                            className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg border transition-colors font-semibold ${user.isSuspended ? 'bg-green-500/15 text-green-400 border-green-500/30 hover:bg-green-500/25' : 'bg-red-500/15 text-red-400 border-red-500/30 hover:bg-red-500/25'}`}>
                            <Ban size={12} /> {user.isSuspended ? 'تفعيل' : 'تعليق'}
                          </button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </>
            )}
          </div>

          {total > 25 && (
            <div className="flex justify-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">السابق</button>
              <span className="px-4 py-2 text-sm text-muted-foreground">صفحة {page}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page * 25 >= total}
                className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">التالي</button>
            </div>
          )}
        </div>

        {/* VIP Modal */}
        {vipModal && (
          <div className="fixed inset-0 z-[200] bg-black/70 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setVipModal(null)}>
            <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()} dir="rtl">
              <div className="flex items-center gap-2 mb-1">
                <Crown size={18} className="text-yellow-400" fill="currentColor" />
                <h3 className="font-bold text-white">تعديل مستوى VIP</h3>
              </div>
              <p className="text-sm text-gray-400 mb-1">{vipModal.username}</p>
              <p className="text-xs text-cyan-300 font-mono mb-4">{vipModal.publicCode}</p>

              <label className="text-xs text-gray-400 mb-2 block">مستوى VIP الجديد</label>
              <div className="grid grid-cols-5 gap-2 mb-4">
                {[0, 1, 2, 3, 4].map(lvl => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setNewVipLevel(lvl)}
                    className="py-2.5 rounded-xl text-xs font-bold border-2 transition-all"
                    style={{
                      borderColor: newVipLevel === lvl ? '#facc15' : '#2a2a40',
                      color: newVipLevel === lvl ? '#facc15' : '#666',
                      background: newVipLevel === lvl ? 'rgba(250,204,21,0.12)' : 'transparent',
                    }}
                  >
                    {lvl === 0 ? 'عادي' : `VIP ${lvl}`}
                  </button>
                ))}
              </div>

              <label className="flex items-start gap-3 p-3 rounded-xl border border-border cursor-pointer hover:bg-white/5 mb-4">
                <input type="checkbox" checked={newVipLocked} onChange={e => setNewVipLocked(e.target.checked)} className="w-4 h-4 mt-0.5 accent-yellow-500" />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 text-sm font-bold text-white">
                    {newVipLocked ? <Lock size={12} className="text-yellow-400" /> : <Unlock size={12} className="text-gray-400" />}
                    قفل المستوى يدوياً
                  </div>
                  <p className="text-[11px] text-gray-400 mt-1">
                    {newVipLocked
                      ? 'لن يتم تغيير المستوى تلقائياً عند الشراء'
                      : 'سيتم احتساب المستوى تلقائياً حسب إجمالي المشتريات'}
                  </p>
                </div>
              </label>

              <div className="flex gap-3">
                <button onClick={handleUpdateVip} disabled={updatingVip}
                  className="flex-1 py-2.5 rounded-xl text-sm font-bold text-black disabled:opacity-50"
                  style={{ background: 'linear-gradient(135deg, #facc15, #f59e0b)' }}>
                  {updatingVip ? 'جاري...' : 'حفظ'}
                </button>
                <button onClick={() => setVipModal(null)} className="px-5 py-2.5 rounded-xl text-sm text-gray-400 border border-border">إلغاء</button>
              </div>
            </div>
          </div>
        )}

        {/* Notes Modal */}
        {notesModal && (
          <div className="fixed inset-0 z-[200] bg-black/70 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setNotesModal(null)}>
            <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()} dir="rtl">
              <h3 className="font-bold text-white mb-1 flex items-center gap-2"><StickyNote size={16} className="text-cyan-400" /> ملاحظات داخلية</h3>
              <p className="text-xs text-gray-400 mb-4">{notesModal.username} — تظهر للمشرفين فقط</p>
              <textarea value={notesModal.notes} onChange={e => setNotesModal(m => m ? { ...m, notes: e.target.value } : m)}
                rows={6} maxLength={2000} placeholder="مثال: يفضّل الدفع كاش — تواصلت معه يوم ١٠/٤..."
                className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-white text-sm mb-4 focus:outline-none focus:border-primary/50 resize-none" />
              <div className="flex gap-3">
                <button onClick={saveNotes} disabled={savingNotes}
                  className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
                  style={{ background: 'linear-gradient(135deg, #06b6d4, #0891b2)' }}>
                  <Save size={14} className="inline ml-1" /> {savingNotes ? 'جاري...' : 'حفظ'}
                </button>
                <button onClick={() => setNotesModal(null)} className="px-5 py-2.5 rounded-xl text-sm text-gray-400 border border-border">إلغاء</button>
              </div>
            </div>
          </div>
        )}

        {/* Balance Modal */}
        {balanceModal && (
          <div className="fixed inset-0 z-[200] bg-black/70 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setBalanceModal(null)}>
            <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()} dir="rtl">
              <h3 className="font-bold text-white mb-1">تعديل رصيد المستخدم</h3>
              <p className="text-sm text-gray-400 mb-1">{balanceModal.username}</p>
              <p className="text-xs text-green-400 mb-4">الرصيد الحالي: ${parseFloat(balanceModal.balance || '0').toFixed(2)}</p>

              <label className="text-xs text-gray-400 mb-2 block">نوع العملية</label>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {([
                  { val: 'add', label: '+ إضافة', color: '#22c55e' },
                  { val: 'subtract', label: '− خصم', color: '#ef4444' },
                  { val: 'set', label: '= تحديد', color: '#6C5CE7' },
                ] as const).map(op => (
                  <button
                    key={op.val}
                    type="button"
                    onClick={() => setBalanceOp(op.val)}
                    className="py-2 rounded-xl text-xs font-bold border-2 transition-all"
                    style={{
                      borderColor: balanceOp === op.val ? op.color : '#2a2a40',
                      color: balanceOp === op.val ? op.color : '#666',
                      background: balanceOp === op.val ? `${op.color}18` : 'transparent',
                    }}
                  >
                    {op.label}
                  </button>
                ))}
              </div>

              <label className="text-xs text-gray-400 mb-1 block">
                {balanceOp === 'add' ? 'مبلغ الإضافة (USD)' : balanceOp === 'subtract' ? 'مبلغ الخصم (USD)' : 'الرصيد الجديد (USD)'}
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={newBalance}
                onChange={e => setNewBalance(e.target.value)}
                className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-white text-sm mb-4 focus:outline-none focus:border-primary/50"
              />
              <div className="flex gap-3">
                <button onClick={handleUpdateBalance} disabled={updatingBalance || !newBalance}
                  className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
                  style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)' }}>
                  {updatingBalance ? 'جاري...' : 'تطبيق'}
                </button>
                <button onClick={() => setBalanceModal(null)} className="px-5 py-2.5 rounded-xl text-sm text-gray-400 border border-border">إلغاء</button>
              </div>
            </div>
          </div>
        )}
      </DashboardLayout>
    </ProtectedRoute>
  );
}
