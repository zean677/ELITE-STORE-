import React, { useState, useEffect, useCallback } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Palette, Save, RotateCcw, Eye, Monitor, Smartphone, Zap, Star, Check } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

export type CardStyleConfig = {
  shape: 'banner' | 'classic' | 'square' | 'compact' | 'featured';
  imagePosition: 'top' | 'left' | 'background' | 'overlay';
  imageHeight: number;
  showName: boolean;
  showPrice: boolean;
  showBadgeLive: boolean;
  showVariant: boolean;
  showVipBadge: boolean;
  showDiscount: boolean;
  buttonStyle: 'rounded' | 'square' | 'pill';
  buttonColor: string;
  buttonHoverAnim: 'scale' | 'glow' | 'none';
  cardRadius: number;
  cardShadow: boolean;
  mobileImageHeight: number;
};

const DEFAULT_CONFIG: CardStyleConfig = {
  shape: 'classic',
  imagePosition: 'top',
  imageHeight: 112,
  showName: true,
  showPrice: true,
  showBadgeLive: true,
  showVariant: true,
  showVipBadge: false,
  showDiscount: false,
  buttonStyle: 'rounded',
  buttonColor: '#6C5CE7',
  buttonHoverAnim: 'scale',
  cardRadius: 16,
  cardShadow: true,
  mobileImageHeight: 96,
};

const SETTINGS_KEY = 'product_card_style';

async function loadConfig(): Promise<CardStyleConfig> {
  try {
    const r = await fetch(`${BASE}/api/settings`);
    if (!r.ok) return DEFAULT_CONFIG;
    const data = await r.json();
    const raw = data[SETTINGS_KEY];
    if (!raw) return DEFAULT_CONFIG;
    return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CONFIG;
  }
}

async function saveConfig(cfg: CardStyleConfig): Promise<void> {
  const token = localStorage.getItem('elite_token');
  await fetch(`${BASE}/api/admin/settings`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ [SETTINGS_KEY]: JSON.stringify(cfg) }),
  });
}

// ─── Live Preview Card ────────────────────────────────────────────────────────
function PreviewCard({ cfg, mobile }: { cfg: CardStyleConfig; mobile: boolean }) {
  const imgH = mobile ? cfg.mobileImageHeight : cfg.imageHeight;
  const br = cfg.cardRadius;
  const btnRadius = cfg.buttonStyle === 'pill' ? 999 : cfg.buttonStyle === 'rounded' ? 12 : 4;
  const demoName = 'UC 180 + 36 مجاناً';
  const demoPrice = '$2.49';

  const isLeft = cfg.imagePosition === 'left';
  const isBg = cfg.imagePosition === 'background' || cfg.imagePosition === 'overlay';

  return (
    <div
      className="relative overflow-hidden border border-border select-none"
      style={{
        borderRadius: br,
        background: '#1a1f2e',
        boxShadow: cfg.cardShadow ? '0 4px 24px rgba(0,0,0,0.4)' : 'none',
        width: mobile ? 160 : 220,
        display: isLeft ? 'flex' : 'block',
      }}
    >
      {/* Image area */}
      {!isBg && (
        <div
          className="relative flex items-center justify-center overflow-hidden flex-shrink-0"
          style={{
            height: isLeft ? undefined : imgH,
            width: isLeft ? imgH : '100%',
            background: 'linear-gradient(135deg, #6C5CE730, #0d111700)',
            minHeight: isLeft ? '100%' : undefined,
          }}
        >
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center font-black text-white text-xl"
            style={{ background: 'linear-gradient(145deg, #6C5CE7dd, #8b7effaa)', boxShadow: `0 8px 24px #6C5CE755` }}
          >
            UC
          </div>
          {cfg.showBadgeLive && (
            <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold"
              style={{ background: '#6C5CE722', border: '1px solid #6C5CE744', color: '#a29bfe' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              متاح
            </div>
          )}
          {cfg.showVariant && (
            <div className="absolute top-2 left-2 px-2 py-1 rounded-lg text-[10px] font-black text-white"
              style={{ background: 'linear-gradient(135deg, #F5A623ee, #F5A623aa)', boxShadow: `0 4px 12px #F5A62355` }}>
              🏆 UC
            </div>
          )}
        </div>
      )}

      {/* Background image style */}
      {isBg && (
        <div className="relative" style={{ height: imgH, background: 'linear-gradient(135deg, #6C5CE750, #0d1117)' }}>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center font-black text-white text-xl"
              style={{ background: 'linear-gradient(145deg, #6C5CE7dd, #8b7effaa)' }}>UC</div>
          </div>
          {cfg.imagePosition === 'overlay' && (
            <div className="absolute inset-0" style={{ background: 'linear-gradient(0deg, rgba(0,0,0,0.75) 0%, transparent 60%)' }} />
          )}
          {cfg.imagePosition === 'overlay' && cfg.showName && (
            <div className="absolute bottom-2 left-0 right-0 px-3">
              <p className="font-bold text-xs text-white leading-tight">{demoName}</p>
            </div>
          )}
        </div>
      )}

      {/* Info */}
      <div className="p-3 flex-1">
        {cfg.showName && cfg.imagePosition !== 'overlay' && (
          <h3 className="font-semibold text-xs leading-tight line-clamp-2 min-h-[2rem] text-white">{demoName}</h3>
        )}
        {(cfg.showPrice || cfg.showVipBadge) && (
          <div className="flex items-center justify-between mt-2">
            <div>
              {cfg.showPrice && (
                <span className="font-black text-sm" style={{ color: cfg.buttonColor }}>{demoPrice}</span>
              )}
              {cfg.showDiscount && (
                <span className="text-[10px] line-through text-white/40 ml-1">$3.50</span>
              )}
            </div>
            {cfg.showVipBadge && (
              <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-black"
                style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,215,0,0.4)', color: '#facc15' }}>
                <Star size={8} fill="#facc15" /> VIP
              </span>
            )}
          </div>
        )}
        <button
          className="mt-2.5 w-full flex items-center justify-center gap-1 py-1.5 text-xs font-bold text-white transition-all"
          style={{
            background: `linear-gradient(135deg, ${cfg.buttonColor}, ${cfg.buttonColor}cc)`,
            borderRadius: btnRadius,
            boxShadow: `0 4px 12px ${cfg.buttonColor}50`,
          }}
        >
          <Zap size={10} /> شحن
        </button>
      </div>
    </div>
  );
}

// ─── Toggle Switch ─────────────────────────────────────────────────────────
function Toggle({ value, onChange, label }: { value: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="flex items-center gap-2.5 w-full text-right"
    >
      <div className={`relative w-10 h-5 rounded-full transition-colors ${value ? 'bg-primary' : 'bg-white/10'}`}>
        <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-5' : 'translate-x-0.5'}`} />
      </div>
      <span className="text-sm text-white/80">{label}</span>
    </button>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────
function AdminCardBuilderContent() {
  const [cfg, setCfg] = useState<CardStyleConfig>(DEFAULT_CONFIG);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [mobilePreview, setMobilePreview] = useState(false);
  const { toast } = useToast();
  const qc = useQueryClient();

  useEffect(() => {
    loadConfig().then(c => { setCfg(c); setLoading(false); });
  }, []);

  const set = useCallback(<K extends keyof CardStyleConfig>(k: K, v: CardStyleConfig[K]) => {
    setCfg(prev => ({ ...prev, [k]: v }));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveConfig(cfg);
      qc.invalidateQueries({ queryKey: ['card-style'] });
      toast({ title: '✅ تم حفظ إعدادات الكرت', description: 'ستظهر التغييرات في الموقع فوراً' });
    } catch {
      toast({ title: '❌ فشل الحفظ', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setCfg(DEFAULT_CONFIG);
    toast({ title: '↩️ تم إعادة الإعدادات الافتراضية' });
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
    </div>
  );

  const shapeOptions: { value: CardStyleConfig['shape']; label: string }[] = [
    { value: 'classic', label: 'كلاسيك' },
    { value: 'banner', label: 'بانر' },
    { value: 'square', label: 'مربع' },
    { value: 'compact', label: 'مضغوط' },
    { value: 'featured', label: 'مميز كبير' },
  ];
  const imgPosOptions: { value: CardStyleConfig['imagePosition']; label: string }[] = [
    { value: 'top', label: 'أعلى' },
    { value: 'left', label: 'يسار' },
    { value: 'background', label: 'خلفية' },
    { value: 'overlay', label: 'طبقة فوق' },
  ];
  const btnStyleOptions: { value: CardStyleConfig['buttonStyle']; label: string }[] = [
    { value: 'pill', label: 'دائري' },
    { value: 'rounded', label: 'مدوّر' },
    { value: 'square', label: 'مربع' },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Palette size={20} className="text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-black text-white">Product Card Builder</h1>
            <p className="text-xs text-muted-foreground">تحكم بشكل كروت المنتجات بدون لمس الكود</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleReset} className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold bg-white/5 border border-white/10 text-white/70 hover:text-white transition-colors">
            <RotateCcw size={14} /> إعادة
          </button>
          <button onClick={handleSave} disabled={saving} className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-sm font-bold bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-50">
            {saving ? <div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" /> : <Save size={14} />}
            حفظ التغييرات
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ── Controls ── */}
        <div className="lg:col-span-2 space-y-5">
          {/* Shape */}
          <section className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-bold text-white mb-4 flex items-center gap-2"><span className="text-lg">🧱</span> شكل الكرت</h2>
            <div className="flex flex-wrap gap-2">
              {shapeOptions.map(o => (
                <button key={o.value} onClick={() => set('shape', o.value)}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${cfg.shape === o.value ? 'bg-primary/20 border-primary/60 text-primary' : 'bg-white/5 border-white/10 text-white/60 hover:text-white'}`}>
                  {o.label}
                </button>
              ))}
            </div>
          </section>

          {/* Image position + dimensions */}
          <section className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-bold text-white mb-4 flex items-center gap-2"><span className="text-lg">🖼️</span> الصورة</h2>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-white/50 mb-2 block">مكان الصورة</label>
                <div className="flex flex-wrap gap-2">
                  {imgPosOptions.map(o => (
                    <button key={o.value} onClick={() => set('imagePosition', o.value)}
                      className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${cfg.imagePosition === o.value ? 'bg-primary/20 border-primary/60 text-primary' : 'bg-white/5 border-white/10 text-white/60 hover:text-white'}`}>
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-white/50 mb-1 block">ارتفاع الصورة — ديسكتوب ({cfg.imageHeight}px)</label>
                  <input type="range" min={64} max={240} step={8} value={cfg.imageHeight} onChange={e => set('imageHeight', Number(e.target.value))}
                    className="w-full accent-primary" />
                </div>
                <div>
                  <label className="text-xs text-white/50 mb-1 block">ارتفاع الصورة — موبايل ({cfg.mobileImageHeight}px)</label>
                  <input type="range" min={56} max={180} step={8} value={cfg.mobileImageHeight} onChange={e => set('mobileImageHeight', Number(e.target.value))}
                    className="w-full accent-primary" />
                </div>
              </div>
            </div>
          </section>

          {/* Visibility toggles */}
          <section className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-bold text-white mb-4 flex items-center gap-2"><span className="text-lg">📝</span> عناصر الكرت</h2>
            <div className="grid grid-cols-2 gap-3">
              <Toggle value={cfg.showName} onChange={v => set('showName', v)} label="اسم المنتج" />
              <Toggle value={cfg.showPrice} onChange={v => set('showPrice', v)} label="السعر" />
              <Toggle value={cfg.showBadgeLive} onChange={v => set('showBadgeLive', v)} label="بادج متاح" />
              <Toggle value={cfg.showVariant} onChange={v => set('showVariant', v)} label="نوع الباقة" />
              <Toggle value={cfg.showVipBadge} onChange={v => set('showVipBadge', v)} label="بادج VIP" />
              <Toggle value={cfg.showDiscount} onChange={v => set('showDiscount', v)} label="تسمية الخصم" />
            </div>
          </section>

          {/* Buy button */}
          <section className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-bold text-white mb-4 flex items-center gap-2"><span className="text-lg">🎯</span> زر الشراء</h2>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-white/50 mb-2 block">شكل الزر</label>
                <div className="flex gap-2">
                  {btnStyleOptions.map(o => (
                    <button key={o.value} onClick={() => set('buttonStyle', o.value)}
                      className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${cfg.buttonStyle === o.value ? 'bg-primary/20 border-primary/60 text-primary' : 'bg-white/5 border-white/10 text-white/60 hover:text-white'}`}>
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-white/50 mb-2 block">لون الزر</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={cfg.buttonColor} onChange={e => set('buttonColor', e.target.value)}
                      className="w-10 h-9 rounded-lg border border-border cursor-pointer bg-transparent" />
                    <input value={cfg.buttonColor} onChange={e => set('buttonColor', e.target.value)}
                      className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm text-white focus:outline-none" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-white/50 mb-2 block">حركة Hover</label>
                  <div className="flex gap-2">
                    {(['scale', 'glow', 'none'] as const).map(v => (
                      <button key={v} onClick={() => set('buttonHoverAnim', v)}
                        className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${cfg.buttonHoverAnim === v ? 'bg-primary/20 border-primary/60 text-primary' : 'bg-white/5 border-white/10 text-white/50'}`}>
                        {v === 'scale' ? 'تكبير' : v === 'glow' ? 'توهج' : 'لا شيء'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Card styling */}
          <section className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-bold text-white mb-4 flex items-center gap-2"><span className="text-lg">🎨</span> تصميم الكرت</h2>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-white/50 mb-1 block">استدارة الحواف ({cfg.cardRadius}px)</label>
                <input type="range" min={0} max={32} step={2} value={cfg.cardRadius} onChange={e => set('cardRadius', Number(e.target.value))}
                  className="w-full accent-primary" />
              </div>
              <Toggle value={cfg.cardShadow} onChange={v => set('cardShadow', v)} label="ظل الكرت" />
            </div>
          </section>
        </div>

        {/* ── Live Preview ── */}
        <div className="lg:col-span-1">
          <div className="sticky top-6">
            <div className="bg-card border border-border rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-white flex items-center gap-2"><Eye size={16} /> معاينة مباشرة</h2>
                <div className="flex items-center gap-1 bg-white/5 rounded-xl p-1">
                  <button onClick={() => setMobilePreview(false)}
                    className={`p-1.5 rounded-lg transition-colors ${!mobilePreview ? 'bg-primary/20 text-primary' : 'text-white/40'}`}>
                    <Monitor size={14} />
                  </button>
                  <button onClick={() => setMobilePreview(true)}
                    className={`p-1.5 rounded-lg transition-colors ${mobilePreview ? 'bg-primary/20 text-primary' : 'text-white/40'}`}>
                    <Smartphone size={14} />
                  </button>
                </div>
              </div>
              <div className={`flex gap-3 ${mobilePreview ? 'flex-col items-center' : 'flex-wrap justify-center'}`}>
                <PreviewCard cfg={cfg} mobile={mobilePreview} />
                <PreviewCard cfg={cfg} mobile={mobilePreview} />
              </div>
              <p className="text-[11px] text-white/30 text-center mt-4">
                ⚡ التغييرات حية — اضغط "حفظ" لتطبيقها على الموقع
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminCardBuilder() {
  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <AdminCardBuilderContent />
      </DashboardLayout>
    </ProtectedRoute>
  );
}
