import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Database, Download, Trash2, RefreshCw, Play, ShieldCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token') || ''}` });

interface Backup { name: string; size: number; createdAt: string; }

const fmtSize = (b: number): string => {
  if (b < 1024) return `${b} B`;
  if (b < 1024 ** 2) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1024 ** 3) return `${(b / 1024 / 1024).toFixed(1)} MB`;
  return `${(b / 1024 / 1024 / 1024).toFixed(2)} GB`;
};

const fmtDate = (iso: string): string => {
  const d = new Date(iso);
  return d.toLocaleString('ar-SY', { timeZone: 'Asia/Damascus', dateStyle: 'medium', timeStyle: 'short' });
};

export default function AdminBackups() {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const { toast } = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${BASE}/api/admin/backup/list`, { headers: headers() });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'تعذر تحميل قائمة النسخ');
      setBackups(j.backups || []);
    } catch (error: any) { toast({ title: 'فشل التحميل', description: error?.message, variant: 'destructive' }); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const create = async () => {
    if (!confirm('سيتم إنشاء نسخة احتياطية كاملة لقاعدة البيانات الآن. قد يستغرق دقائق. متابعة؟')) return;
    setCreating(true);
    try {
      const r = await fetch(`${BASE}/api/admin/backup/now`, { method: 'POST', headers: headers() });
      const j = await r.json();
      if (!r.ok || !j.ok) { toast({ title: 'فشل النسخ', description: j.error || '', variant: 'destructive' }); return; }
      toast({ title: '✅ تم إنشاء النسخة', description: `${j.file} (${fmtSize(j.size || 0)})` });
      await load();
    } catch (e: any) {
      toast({ title: 'فشل', description: String(e?.message || e), variant: 'destructive' });
    } finally { setCreating(false); }
  };

  const download = (name: string) => {
    const url = `${BASE}/api/admin/backup/download/${encodeURIComponent(name)}`;
    const token = localStorage.getItem('elite_token') || '';
    fetch(url, { headers: { Authorization: `Bearer ${token}` } })
      .then(async r => {
        if (!r.ok) {
          const body = await r.json().catch(() => ({}));
          throw new Error(body.error || 'فشل تنزيل النسخة الاحتياطية');
        }
        return r.blob();
      })
      .then(blob => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = name;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      })
      .catch((error: any) => toast({ title: 'فشل التحميل', description: error?.message, variant: 'destructive' }));
  };

  const remove = async (name: string) => {
    if (!confirm(`حذف النسخة "${name}" نهائياً؟`)) return;
    setBusy(name);
    try {
      const r = await fetch(`${BASE}/api/admin/backup/${encodeURIComponent(name)}`, { method: 'DELETE', headers: headers() });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || 'فشل حذف النسخة الاحتياطية');
      toast({ title: '🗑️ تم الحذف' });
      setBackups(b => b.filter(x => x.name !== name));
    } catch (error: any) { toast({ title: 'فشل الحذف', description: error?.message, variant: 'destructive' }); }
    finally { setBusy(null); }
  };

  const totalSize = backups.reduce((s, b) => s + b.size, 0);

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-5" dir="rtl">
          <div className="flex flex-wrap items-center gap-3 justify-between">
            <div>
              <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
                <Database className="text-primary" size={26} />
                النسخ الاحتياطية
              </h1>
              <p className="text-muted-foreground text-sm mt-1">
                نسخ احتياطية يدوية لقاعدة البيانات. حمّلها على جهازك للحفظ الآمن.
              </p>
            </div>
            <div className="flex gap-2">
              <button onClick={load} className="p-2 rounded-xl bg-card border border-border hover:bg-muted" title="تحديث">
                <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
              </button>
              <button onClick={create} disabled={creating}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground hover:opacity-90 font-semibold text-sm disabled:opacity-60">
                <Play size={16} /> {creating ? 'جارٍ الإنشاء...' : 'إنشاء نسخة الآن'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="text-xs text-muted-foreground mb-1">عدد النسخ</div>
              <div className="text-2xl font-extrabold">{backups.length}</div>
            </div>
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="text-xs text-muted-foreground mb-1">المساحة المستخدمة</div>
              <div className="text-2xl font-extrabold">{fmtSize(totalSize)}</div>
            </div>
            <div className="bg-gradient-to-br from-success/10 to-primary/10 border border-success/30 rounded-2xl p-4 col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 text-xs text-success font-bold mb-1">
                <ShieldCheck size={14} /> الجدولة التلقائية
              </div>
              <div className="text-sm font-bold">معطّلة — تشغيل يدوي فقط</div>
            </div>
          </div>

          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-300 leading-relaxed">
            ⚠️ <strong>مهم:</strong> الملفات تُخزَّن على الخادم. <strong>حمّلها على جهازك</strong> بعد إنشائها — لو تم إعادة نشر التطبيق قد تختفي. نوصي بإنشاء نسخة وتحميلها قبل أي تحديث كبير.
          </div>

          {loading ? (
            <div className="text-center py-20 text-muted-foreground">جاري التحميل...</div>
          ) : backups.length === 0 ? (
            <div className="text-center py-20 bg-card border border-border rounded-2xl">
              <Database className="mx-auto mb-3 text-muted-foreground/30" size={48} />
              <p className="text-muted-foreground mb-3">لا توجد نسخ احتياطية حالياً</p>
              <button onClick={create} disabled={creating} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold text-sm disabled:opacity-60">
                <Play size={16} /> أنشئ أولى نسخة
              </button>
            </div>
          ) : (
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="divide-y divide-border">
                {backups.map(b => (
                  <div key={b.name} className="flex flex-wrap items-center gap-3 p-3 hover:bg-muted/30 transition-colors">
                    <div className="flex-1 min-w-0">
                      <div className="font-mono text-xs font-bold truncate">{b.name}</div>
                      <div className="text-[11px] text-muted-foreground mt-0.5 flex flex-wrap gap-3">
                        <span>📅 {fmtDate(b.createdAt)}</span>
                        <span>📏 {fmtSize(b.size)}</span>
                      </div>
                    </div>
                    <div className="flex gap-1.5">
                      <button onClick={() => download(b.name)}
                        className="inline-flex items-center gap-1 text-xs py-1.5 px-3 rounded-lg bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25">
                        <Download size={12} /> تحميل
                      </button>
                      <button onClick={() => remove(b.name)} disabled={busy === b.name}
                        className="text-xs py-1.5 px-2.5 rounded-lg bg-destructive/15 text-destructive border border-destructive/30 hover:bg-destructive/25 disabled:opacity-50">
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
