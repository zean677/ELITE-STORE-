import React, { useState, useCallback } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { bumpImageVersion } from '@/lib/image-utils';
import {
  Image as ImageIcon, RefreshCw, Search, Trash2, Upload,
  AlertTriangle, CheckCircle, XCircle, Loader2, Eye,
} from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

type BrokenImage = {
  id: string;
  name: string;
  type: 'product' | 'category';
  imageUrl: string;
  reason: string;
};

type ScanResult = {
  total: number;
  broken: BrokenImage[];
  scannedAt: string;
};

// ─── Clear Cache Card ─────────────────────────────────────────────────────────
function ClearCacheCard({ qc }: { qc: ReturnType<typeof useQueryClient> }) {
  const { toast } = useToast();
  const [clearing, setClearing] = useState(false);

  const handleClear = async () => {
    setClearing(true);
    try {
      const v = bumpImageVersion();
      // Also persist the version in admin settings for server-side awareness
      const token = localStorage.getItem('elite_token');
      await fetch(`${BASE}/api/admin/settings`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ image_cache_version: v }),
      });
      // Invalidate all image-heavy queries
      await Promise.all([
        qc.invalidateQueries({ queryKey: ['products'] }),
        qc.invalidateQueries({ queryKey: ['categories'] }),
        qc.invalidateQueries({ queryKey: ['public-db-categories'] }),
        qc.invalidateQueries({ queryKey: ['featured-games'] }),
        qc.invalidateQueries({ queryKey: ['category-games'] }),
      ]);
      toast({ title: '🔄 تم مسح Cache الصور', description: 'المتصفح سيحمّل كل الصور من جديد' });
    } catch {
      toast({ title: 'فشل المسح', variant: 'destructive' });
    } finally {
      setClearing(false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-blue-500/15 flex items-center justify-center flex-shrink-0">
          <RefreshCw size={22} className="text-blue-400" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-white mb-1">مسح Cache الصور فوراً</h3>
          <p className="text-sm text-white/50 mb-4">
            يُجبر كل المتصفحات على إعادة تحميل الصور المعدّلة بدون انتظار. استخدم هذا بعد أي تعديل على صورة.
          </p>
          <button
            onClick={handleClear}
            disabled={clearing}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold bg-blue-500/20 border border-blue-500/40 text-blue-300 hover:bg-blue-500/30 transition-colors disabled:opacity-50"
          >
            {clearing ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
            مسح Cache الآن
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Image Scanner Card ───────────────────────────────────────────────────────
function ImageScannerCard() {
  const { toast } = useToast();
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [fixing, setFixing] = useState<string | null>(null);

  const handleScan = async () => {
    setScanning(true);
    setResult(null);
    try {
      const token = localStorage.getItem('elite_token');
      const r = await fetch(`${BASE}/api/admin/images/scan`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!r.ok) throw new Error(await r.text());
      setResult(await r.json());
    } catch (e: any) {
      toast({ title: 'فشل الفحص', description: e.message, variant: 'destructive' });
    } finally {
      setScanning(false);
    }
  };

  const handleRemoveImage = async (item: BrokenImage) => {
    setFixing(item.id);
    try {
      const token = localStorage.getItem('elite_token');
      const url = item.type === 'product'
        ? `${BASE}/api/admin/products/${item.id}`
        : `${BASE}/api/admin/categories/${item.id}`;
      const body = item.type === 'product'
        ? { imageOverride: null, image: null }
        : { imageUrl: null };
      await fetch(url, { method: 'PUT', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      setResult(prev => prev ? { ...prev, broken: prev.broken.filter(b => b.id !== item.id) } : null);
      toast({ title: '✅ تم إزالة الصورة المكسورة' });
    } catch {
      toast({ title: 'فشل الإزالة', variant: 'destructive' });
    } finally {
      setFixing(null);
    }
  };

  const handleFixAll = async () => {
    if (!result?.broken.length) return;
    if (!confirm(`إزالة ${result.broken.length} صورة مكسورة؟`)) return;
    for (const item of result.broken) {
      await handleRemoveImage(item);
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5">
      <div className="flex items-start gap-4 mb-5">
        <div className="w-12 h-12 rounded-xl bg-amber-500/15 flex items-center justify-center flex-shrink-0">
          <Search size={22} className="text-amber-400" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-white mb-1">فاحص الصور المكسورة</h3>
          <p className="text-sm text-white/50 mb-4">يفحص كل صور المنتجات والأقسام ويكشف الروابط المعطوبة تلقائياً.</p>
          <button
            onClick={handleScan}
            disabled={scanning}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold bg-amber-500/15 border border-amber-500/35 text-amber-300 hover:bg-amber-500/25 transition-colors disabled:opacity-50"
          >
            {scanning ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
            {scanning ? 'جاري الفحص...' : 'ابدأ الفحص'}
          </button>
        </div>
      </div>

      {result && (
        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between p-3 rounded-xl bg-background border border-border">
            <span className="text-sm text-white/70">تم فحص <strong className="text-white">{result.total}</strong> صورة</span>
            {result.broken.length === 0 ? (
              <span className="flex items-center gap-1.5 text-emerald-400 text-sm font-bold">
                <CheckCircle size={14} /> كل الصور سليمة ✓
              </span>
            ) : (
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1.5 text-red-400 text-sm font-bold">
                  <XCircle size={14} /> {result.broken.length} صورة مكسورة
                </span>
                <button
                  onClick={handleFixAll}
                  className="px-3 py-1 rounded-lg text-xs font-bold bg-red-500/20 border border-red-500/40 text-red-300 hover:bg-red-500/30 transition-colors"
                >
                  إصلاح الكل
                </button>
              </div>
            )}
          </div>

          {result.broken.length > 0 && (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {result.broken.map(item => (
                <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl bg-red-500/5 border border-red-500/20">
                  <XCircle size={14} className="text-red-400 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{item.name}</p>
                    <p className="text-xs text-white/40 truncate">{item.imageUrl}</p>
                    <p className="text-xs text-red-400">{item.reason}</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <a href={item.imageUrl} target="_blank" rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-colors">
                      <Eye size={12} />
                    </a>
                    <button
                      onClick={() => handleRemoveImage(item)}
                      disabled={fixing === item.id}
                      className="p-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-400 transition-colors disabled:opacity-50"
                    >
                      {fixing === item.id ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Bulk Image Upload Card ───────────────────────────────────────────────────
function BulkImageCard() {
  const { toast } = useToast();
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [results, setResults] = useState<{ name: string; url: string }[]>([]);

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fs = Array.from(e.target.files ?? []);
    setFiles(fs);
    e.target.value = '';
  };

  const handleUpload = async () => {
    if (!files.length) return;
    setUploading(true);
    const token = localStorage.getItem('elite_token');
    const uploaded: { name: string; url: string }[] = [];
    for (const file of files) {
      try {
        const fd = new FormData();
        fd.append('image', file);
        const r = await fetch(`${BASE}/api/admin/upload/image`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: fd,
        });
        if (r.ok) {
          const { url } = await r.json();
          uploaded.push({ name: file.name, url });
        }
      } catch {}
    }
    setResults(uploaded);
    setFiles([]);
    setUploading(false);
    toast({ title: `✅ تم رفع ${uploaded.length} صورة`, description: 'انسخ الروابط وضعها على المنتجات' });
    bumpImageVersion();
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5">
      <div className="flex items-start gap-4 mb-5">
        <div className="w-12 h-12 rounded-xl bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
          <Upload size={22} className="text-emerald-400" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-white mb-1">رفع صور دفعي Bulk Upload</h3>
          <p className="text-sm text-white/50 mb-4">ارفع عدة صور مرة واحدة واحصل على روابطها.</p>
          <label className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 hover:bg-emerald-500/25 transition-colors cursor-pointer w-fit">
            <ImageIcon size={14} /> اختر صور ({files.length} محدد)
            <input type="file" accept="image/*" multiple className="hidden" onChange={handleFiles} />
          </label>
        </div>
      </div>

      {files.length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2 mb-3">
            {files.slice(0, 6).map((f, i) => (
              <div key={i} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-background border border-border text-xs text-white/70">
                <ImageIcon size={10} className="text-emerald-400" />
                {f.name.slice(0, 20)}{f.name.length > 20 ? '…' : ''}
              </div>
            ))}
            {files.length > 6 && <div className="px-2.5 py-1 rounded-lg bg-background border border-border text-xs text-white/50">+{files.length - 6} أخرى</div>}
          </div>
          <button
            onClick={handleUpload}
            disabled={uploading}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
            {uploading ? 'جاري الرفع...' : `رفع ${files.length} صورة`}
          </button>
        </div>
      )}

      {results.length > 0 && (
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {results.map((r, i) => (
            <div key={i} className="flex items-center gap-3 p-2.5 rounded-xl bg-background border border-border">
              <img src={r.url} alt="" className="w-10 h-10 rounded-lg object-cover border border-border flex-shrink-0" onError={e => (e.currentTarget.style.display = 'none')} />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-white/70 truncate">{r.name}</p>
                <p className="text-xs text-emerald-400 truncate font-mono">{r.url}</p>
              </div>
              <button onClick={() => { navigator.clipboard.writeText(r.url); }}
                className="px-2.5 py-1 rounded-lg bg-primary/15 text-primary text-xs font-bold hover:bg-primary/25 transition-colors flex-shrink-0">
                نسخ
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Bulk Unassign Card ───────────────────────────────────────────────────────
function BulkUnassignCard() {
  const { toast } = useToast();
  const [running, setRunning] = useState(false);
  const [target, setTarget] = useState<'products' | 'categories'>('products');

  const handleUnassign = async () => {
    const label = target === 'products' ? 'المنتجات' : 'الأقسام';
    if (!confirm(`هل تريد إزالة جميع الصور المخصصة من ${label}؟`)) return;
    setRunning(true);
    try {
      const token = localStorage.getItem('elite_token');
      const r = await fetch(`${BASE}/api/admin/images/bulk-unassign`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ target }),
      });
      if (!r.ok) throw new Error(await r.text());
      const { updated } = await r.json();
      bumpImageVersion();
      toast({ title: `✅ تم إزالة الصور من ${updated} عنصر` });
    } catch (e: any) {
      toast({ title: 'فشلت العملية', description: e.message, variant: 'destructive' });
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-red-500/15 flex items-center justify-center flex-shrink-0">
          <Trash2 size={22} className="text-red-400" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-white mb-1">إزالة صور دفعية Bulk Unassign</h3>
          <p className="text-sm text-white/50 mb-4">إزالة الصور المخصصة من المنتجات أو الأقسام دفعة واحدة.</p>
          <div className="flex items-center gap-3 mb-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="unassign_target" value="products" checked={target === 'products'} onChange={() => setTarget('products')} className="accent-primary" />
              <span className="text-sm text-white/80">المنتجات</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="unassign_target" value="categories" checked={target === 'categories'} onChange={() => setTarget('categories')} className="accent-primary" />
              <span className="text-sm text-white/80">الأقسام</span>
            </label>
          </div>
          <button
            onClick={handleUnassign}
            disabled={running}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold bg-red-500/15 border border-red-500/35 text-red-300 hover:bg-red-500/25 transition-colors disabled:opacity-50"
          >
            {running ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
            إزالة الصور ({target === 'products' ? 'منتجات' : 'أقسام'})
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
function AdminImageToolsContent() {
  const qc = useQueryClient();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6" dir="rtl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
          <ImageIcon size={20} className="text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-black text-white">أدوات الصور</h1>
          <p className="text-xs text-muted-foreground">فحص، مسح، رفع دفعي، وإدارة صور الموقع كاملاً</p>
        </div>
      </div>

      <div className="space-y-4">
        <ClearCacheCard qc={qc} />
        <ImageScannerCard />
        <BulkImageCard />
        <BulkUnassignCard />
      </div>
    </div>
  );
}

export default function AdminImageTools() {
  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <AdminImageToolsContent />
      </DashboardLayout>
    </ProtectedRoute>
  );
}
