import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Calendar, Clock, Trash2, Send, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token')}`, 'Content-Type': 'application/json' });

function localISOForInput(d: Date): string {
  const tzOff = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - tzOff).toISOString().slice(0, 16);
}

export default function AdminScheduled() {
  const [list, setList] = useState<any[]>([]);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState('announcement');
  const [sendAt, setSendAt] = useState(localISOForInput(new Date(Date.now() + 3600 * 1000)));
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const reload = async () => {
    const r = await fetch(`${BASE}/api/admin/scheduled-notifications`, { headers: headers() });
    const d = await r.json(); setList(d.scheduled || []);
  };
  useEffect(() => { reload(); }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;
    setSubmitting(true);
    try {
      const r = await fetch(`${BASE}/api/admin/scheduled-notifications`, {
        method: 'POST', headers: headers(),
        body: JSON.stringify({ title, message, type, sendAt: new Date(sendAt).toISOString() }),
      });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: '🕒 تم الجدولة' });
      setTitle(''); setMessage('');
      reload();
    } catch (err: any) {
      toast({ title: 'فشل الجدولة', description: err?.message, variant: 'destructive' });
    } finally { setSubmitting(false); }
  };

  const cancel = async (id: number) => {
    if (!confirm('إلغاء هذا الإشعار المجدول؟')) return;
    await fetch(`${BASE}/api/admin/scheduled-notifications/${id}`, { method: 'DELETE', headers: headers() });
    reload();
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div>
            <h1 className="font-heading text-2xl font-bold">الإشعارات المجدولة</h1>
            <p className="text-muted-foreground text-sm mt-1">جدول إشعار للعملاء يصلهم في الوقت اللي تختاره</p>
          </div>

          <form onSubmit={submit} className="bg-card border border-border rounded-2xl p-5 space-y-3">
            <input value={title} onChange={e => setTitle(e.target.value)} required maxLength={120}
              placeholder="عنوان الإشعار (مثال: عرض الجمعة)" className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm" />
            <textarea value={message} onChange={e => setMessage(e.target.value)} required rows={3} maxLength={500}
              placeholder="نص الرسالة" className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm" />
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">النوع</label>
                <select value={type} onChange={e => setType(e.target.value)}
                  className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm">
                  <option value="announcement">إعلان</option>
                  <option value="offer">عرض</option>
                  <option value="info">معلومة</option>
                  <option value="warning">تنبيه</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">وقت الإرسال</label>
                <input type="datetime-local" value={sendAt} onChange={e => setSendAt(e.target.value)}
                  className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm" />
              </div>
            </div>
            <button type="submit" disabled={submitting}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
              style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)' }}>
              <Calendar size={14} className="inline ml-1" /> {submitting ? 'جاري الجدولة...' : 'جدولة الإشعار'}
            </button>
          </form>

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-border"><h2 className="font-bold">القائمة المجدولة ({list.length})</h2></div>
            <div className="divide-y divide-border">
              {list.map(it => {
                const status = it.status ?? (it.sentAt ? 'sent' : it.cancelled === 'yes' ? 'cancelled' : 'scheduled');
                const sent = status === 'sent';
                const failed = status === 'failed';
                const processing = status === 'processing';
                const cancelled = status === 'cancelled';
                return (
                  <motion.div key={it.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center"
                        style={{ background: sent ? 'rgba(34,197,94,0.15)' : cancelled ? 'rgba(107,114,128,0.15)' : 'rgba(108,92,231,0.15)',
                                 color: sent ? '#22c55e' : cancelled ? '#9ca3af' : '#a29bfe' }}>
                        {sent ? <CheckCircle2 size={16} /> : cancelled ? <Trash2 size={16} /> : failed ? <Trash2 size={16} /> : <Clock size={16} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold truncate">{it.title}</p>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{it.message}</p>
                        <p className="text-[11px] text-muted-foreground mt-1">
                           {sent ? `أُرسل في ${new Date(it.sentAt).toLocaleString('ar-EG')}`
                             : failed ? `فشل الإرسال: ${it.errorMessage || 'خطأ غير معروف'}`
                             : processing ? 'جاري الإرسال...'
                             : cancelled ? 'مُلغى'
                             : `يُرسل في ${new Date(it.sendAt).toLocaleString('ar-EG')}`}
                          {it.targetUserId ? ` · لمستخدم #${it.targetUserId}` : ' · لكل العملاء'}
                        </p>
                      </div>
                       {status === 'scheduled' && (
                        <button onClick={() => cancel(it.id)} className="p-2 rounded-lg text-red-400 hover:bg-red-500/10">
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
              {list.length === 0 && <div className="p-6 text-center text-sm text-muted-foreground">لا توجد إشعارات مجدولة</div>}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
