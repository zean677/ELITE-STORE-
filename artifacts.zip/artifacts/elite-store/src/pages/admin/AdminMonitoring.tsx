import { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, Database, MessageCircle, Zap, AlertTriangle, CheckCircle, Clock,
  RefreshCw, Shield, Image, Package, TrendingDown, Server, Cpu, HardDrive,
  RotateCcw, Play, Trash2, WifiOff, Wifi, Bell, BellOff, ChevronDown,
  ChevronUp, Download, Upload, Eye, EyeOff, AlertCircle, Info, X,
  BarChart3, ArrowRight, Wrench, ShoppingCart, DollarSign, Camera,
} from 'lucide-react';
import { useToast } from '../../hooks/use-toast';
import { useAdminWs, isAdminSoundEnabled, setAdminSoundEnabled } from '../../hooks/use-admin-ws';
import { useAuth } from '../../hooks/use-auth';
import { DashboardLayout } from '../../components/Layout';
import { ProtectedRoute } from '../../components/ProtectedRoute';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const authHeaders = () => ({
  Authorization: `Bearer ${localStorage.getItem('elite_token') || ''}`,
});

// ─── Types ────────────────────────────────────────────────────────────────────

interface MonitoringData {
  responseMs: number;
  system: {
    status: string;
    uptime: { seconds: number; human: string };
    database: { status: string; latencyMs: number };
    telegram: { status: string; configured: boolean };
    memory: { usedMb: number; totalMb: number; percent: number };
    load: { '1m': number; '5m': number; '15m': number };
  };
  provider: {
    name: string;
    configured: boolean;
    balance: number | null;
    balanceSyp: number | null;
    error: string | null;
    stability: 'stable' | 'slow' | 'unstable';
    stats: { totalToday: number; completedToday: number; failedToday: number; successRate: number };
  } | null;
  orders: {
    stuckCount: number;
    stuckList: Array<{ id: number; status: string; totalPrice: string; createdAt: string; retryCount: number }>;
    processing: number;
    failed24h: number;
    pending: number;
    failedCheckouts1h: number;
  };
  priceProtection: {
    lossCount: number;
    products: Array<{ id: number; name: string; priceUsd: string; unitPriceUsd: string; status: string }>;
  };
  images: {
    missingCount: number;
    products: Array<{ id: number; name: string }>;
  };
  backup: { name: string | null; createdAt: string | null; count: number };
  crons: Record<string, string>;
}

type MaintenanceAction =
  | 'clear-image-cache'
  | 'fix-stuck-orders'
  | 'resync-products'
  | 'force-balance-sync'
  | 'recalculate-prices'
  | 're-sync-orders'
  | 'restart-queue'
  | 'refresh-images';

// ─── Fetch helpers ────────────────────────────────────────────────────────────

async function fetchMonitoring(): Promise<MonitoringData> {
  const res = await fetch(`${BASE}/api/admin/monitoring/full`, { headers: authHeaders() });
  if (!res.ok) throw new Error(res.status === 401 || res.status === 403 ? 'لا تملك صلاحية عرض مركز المراقبة' : 'فشل تحميل بيانات المراقبة');
  return res.json();
}

async function runMaintenanceAction(action: MaintenanceAction): Promise<{ ok: boolean; detail: string }> {
  const res = await fetch(`${BASE}/api/admin/maintenance/${action}`, {
    method: 'POST',
    headers: authHeaders(),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? 'Action failed');
  return json;
}

async function triggerBackup(): Promise<{ ok: boolean; file?: string }> {
  const res = await fetch(`${BASE}/api/admin/backup/now`, { method: 'POST', headers: authHeaders() });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? 'فشل إنشاء النسخة الاحتياطية');
  return json;
}

// ─── Status helpers ───────────────────────────────────────────────────────────

function statusColor(status: string) {
  if (status === 'ok' || status === 'healthy' || status === 'stable') return 'text-emerald-400';
  if (status === 'slow') return 'text-amber-400';
  return 'text-red-400';
}
function statusBg(status: string) {
  if (status === 'ok' || status === 'healthy' || status === 'stable') return 'bg-emerald-500/10 border-emerald-500/20';
  if (status === 'slow') return 'bg-amber-500/10 border-amber-500/20';
  return 'bg-red-500/10 border-red-500/20';
}
function statusDot(status: string) {
  if (status === 'ok' || status === 'healthy' || status === 'stable') return 'bg-emerald-400';
  if (status === 'slow') return 'bg-amber-400';
  return 'bg-red-400';
}
function StatusIcon({ status, size = 16 }: { status: string; size?: number }) {
  if (status === 'ok' || status === 'healthy' || status === 'stable') return <CheckCircle size={size} className="text-emerald-400" />;
  if (status === 'slow') return <AlertTriangle size={size} className="text-amber-400" />;
  return <AlertCircle size={size} className="text-red-400" />;
}

function fmtMs(ms: number) {
  if (ms < 0) return 'N/A';
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}
function fmtDate(iso: string | null) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString('ar-SY', { dateStyle: 'short', timeStyle: 'short' });
}
function timeAgo(iso: string) {
  const ms = Date.now() - new Date(iso).getTime();
  const min = Math.floor(ms / 60000);
  if (min < 1) return 'الآن';
  if (min < 60) return `${min} د`;
  const hr = Math.floor(min / 60);
  return `${hr} س`;
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function Dot({ status }: { status: string }) {
  return (
    <span className="relative flex h-2.5 w-2.5">
      <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-60 ${statusDot(status)}`} />
      <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${statusDot(status)}`} />
    </span>
  );
}

function StatusCard({
  icon: Icon,
  label,
  value,
  status,
  sub,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  status: string;
  sub?: string;
}) {
  return (
    <div className={`rounded-2xl border p-4 flex gap-3 items-start ${statusBg(status)}`}>
      <div className={`mt-0.5 ${statusColor(status)}`}>
        <Icon size={20} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <Dot status={status} />
          <span className="text-xs text-muted-foreground">{label}</span>
        </div>
        <div className={`font-bold text-base leading-tight ${statusColor(status)}`}>{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

function SectionHeader({
  icon: Icon,
  title,
  badge,
  badgeColor = 'bg-red-500',
  expanded,
  onToggle,
}: {
  icon: React.ElementType;
  title: string;
  badge?: number | string;
  badgeColor?: string;
  expanded: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="w-full flex items-center gap-3 text-right p-4 hover:bg-white/5 transition-colors rounded-xl"
    >
      <Icon size={18} className="text-primary shrink-0" />
      <span className="flex-1 font-semibold text-sm">{title}</span>
      {badge !== undefined && badge !== 0 && (
        <span className={`px-2 py-0.5 rounded-full text-xs font-bold text-white ${badgeColor}`}>
          {badge}
        </span>
      )}
      {expanded ? <ChevronUp size={16} className="text-muted-foreground" /> : <ChevronDown size={16} className="text-muted-foreground" />}
    </button>
  );
}

function ActionButton({
  label,
  icon: Icon,
  action,
  onRun,
  loading,
  variant = 'default',
}: {
  label: string;
  icon: React.ElementType;
  action: MaintenanceAction;
  onRun: (a: MaintenanceAction) => void;
  loading: MaintenanceAction | null;
  variant?: 'default' | 'danger';
}) {
  const isLoading = loading === action;
  return (
    <button
      onClick={() => onRun(action)}
      disabled={!!loading}
      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-all
        ${variant === 'danger'
          ? 'bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20'
          : 'bg-white/5 border-white/10 text-foreground hover:bg-white/10'}
        disabled:opacity-50 disabled:cursor-not-allowed`}
    >
      {isLoading ? <RefreshCw size={13} className="animate-spin" /> : <Icon size={13} />}
      {label}
    </button>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function AdminMonitoring() {
  const { toast } = useToast();
  const { user } = useAuth();
  const canRunMaintenance = user?.role === 'admin';
  const canViewMonitoring = canRunMaintenance || !!user?.permissions?.includes('system.monitor');
  const qc = useQueryClient();
  const { status: wsStatus, items: wsItems } = useAdminWs({ enabled: canViewMonitoring });
  const [soundOn, setSoundOn] = useState(isAdminSoundEnabled());
  const [runningAction, setRunningAction] = useState<MaintenanceAction | null>(null);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set(['orders', 'price', 'provider', 'maintenance'])
  );
  const [showAllLoss, setShowAllLoss] = useState(false);
  const [showAllImages, setShowAllImages] = useState(false);
  const prevDataRef = useRef<MonitoringData | null>(null);
  const alertedIssues = useRef<Set<string>>(new Set());

  const { data, isLoading, isFetching, dataUpdatedAt } = useQuery({
    queryKey: ['admin', 'monitoring', 'full'],
    queryFn: fetchMonitoring,
    enabled: canViewMonitoring,
    refetchInterval: 15_000,
    refetchIntervalInBackground: true,
    staleTime: 10_000,
  });

  // ── Real-time alert detection on data change ─────────────────────────────
  useEffect(() => {
    if (!data) return;
    const prev = prevDataRef.current;

    const alert = (key: string, title: string, description: string, urgent = false) => {
      if (alertedIssues.current.has(key)) return;
      alertedIssues.current.add(key);
      setTimeout(() => alertedIssues.current.delete(key), 120_000);
      toast({ title, description });
    };

    if (data.orders.stuckCount > 0) alert('stuck', `⚠️ طلبات عالقة (${data.orders.stuckCount})`, 'اضغط Fix Stuck Orders للإصلاح الفوري', true);
    if (data.priceProtection.lossCount > 0) alert('loss', `💸 منتجات بخسارة (${data.priceProtection.lossCount})`, 'أسعار البيع أقل من تكلفة المزود');
    if (data.system.database.status !== 'ok') alert('db', '🔴 قاعدة البيانات', 'فشل الاتصال بقاعدة البيانات');
    if (data.provider?.stability === 'unstable') alert('provider_unstable', '🔴 المزود غير مستقر', `نسبة نجاح: ${data.provider.stats.successRate}%`);
    if (data.orders.failedCheckouts1h > 5) alert('checkout', `⚠️ ${data.orders.failedCheckouts1h} فشل في إتمام الطلبات`, 'خلال آخر ساعة — تحقق من بوابة الدفع');
    if (data.images.missingCount > 0 && !prev) alert('images', `🖼️ ${data.images.missingCount} منتج بدون صورة`, 'يؤثر على تجربة العملاء');

    prevDataRef.current = data;
  }, [data, toast]);

  // ── WS status change alerts ───────────────────────────────────────────────
  const prevWsStatus = useRef(wsStatus);
  useEffect(() => {
    if (prevWsStatus.current !== 'disconnected' && wsStatus === 'disconnected') {
      toast({ title: '🔌 انقطع الاتصال المباشر', description: 'جاري إعادة الاتصال...' });
    }
    prevWsStatus.current = wsStatus;
  }, [wsStatus, toast]);

  const toggleSection = useCallback((key: string) => {
    setExpandedSections(prev => {
      const s = new Set(prev);
      if (s.has(key)) s.delete(key);
      else s.add(key);
      return s;
    });
  }, []);

  const handleMaintenance = useCallback(async (action: MaintenanceAction) => {
    setRunningAction(action);
    try {
      const result = await runMaintenanceAction(action);
      toast({ title: '✅ تم بنجاح', description: result.detail });
      qc.invalidateQueries({ queryKey: ['admin', 'monitoring'] });
    } catch (err: any) {
      toast({ title: '❌ فشل', description: err.message });
    } finally {
      setRunningAction(null);
    }
  }, [toast, qc]);

  const handleBackup = useCallback(async () => {
    setRunningAction('resync-products');
    try {
      const result = await triggerBackup();
      toast({ title: result.ok ? '✅ تم الحفظ الاحتياطي' : '❌ فشل الحفظ', description: result.file ?? 'تحقق من سجلات الخادم' });
      qc.invalidateQueries({ queryKey: ['admin', 'monitoring'] });
    } catch {
      toast({ title: '❌ خطأ', description: 'فشل تشغيل النسخ الاحتياطي' });
    } finally {
      setRunningAction(null);
    }
  }, [toast, qc]);

  // ── Derive alert level ───────────────────────────────────────────────────
  const criticalIssues: string[] = [];
  const warningIssues: string[] = [];
  if (data) {
    if (data.system.database.status !== 'ok') criticalIssues.push('قاعدة البيانات لا تستجيب');
    if (data.provider?.stability === 'unstable') criticalIssues.push(`المزود غير مستقر — نجاح ${data.provider.stats.successRate}%`);
    if (data.orders.stuckCount > 0) criticalIssues.push(`${data.orders.stuckCount} طلب عالق`);
    if (data.orders.failedCheckouts1h > 5) warningIssues.push(`${data.orders.failedCheckouts1h} فشل في الـ Checkout خلال آخر ساعة`);
    if (data.priceProtection.lossCount > 0) warningIssues.push(`${data.priceProtection.lossCount} منتج يُباع بخسارة`);
    if (data.provider?.stability === 'slow') warningIssues.push('المزود بطيء في الاستجابة');
    if (data.system.telegram.status !== 'ok' && data.system.telegram.configured) warningIssues.push('بوت تيليجرام لا يستجيب');
  }
  const overallOk = criticalIssues.length === 0 && warningIssues.length === 0;

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6" dir="rtl">
      {/* ── Header ── */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">مركز المراقبة والتشخيص</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            مراقبة مباشرة — آخر تحديث: {dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString('ar') : '—'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* WS status badge */}
          <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
            wsStatus === 'connected' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' :
            wsStatus === 'connecting' ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' :
            'bg-red-500/10 border-red-500/30 text-red-400'
          }`}>
            {wsStatus === 'connected' ? <Wifi size={12} /> : <WifiOff size={12} />}
            {wsStatus === 'connected' ? 'متصل مباشر' : wsStatus === 'connecting' ? 'يتصل...' : 'منقطع'}
          </span>
          {/* Sound toggle */}
          <button
            onClick={() => { const n = !soundOn; setSoundOn(n); setAdminSoundEnabled(n); }}
            className="p-2 rounded-xl border border-white/10 hover:bg-white/5 transition-colors"
            title={soundOn ? 'إيقاف الصوت' : 'تشغيل الصوت'}
          >
            {soundOn ? <Bell size={16} /> : <BellOff size={16} />}
          </button>
          {/* Refresh */}
          <button
            onClick={() => qc.invalidateQueries({ queryKey: ['admin', 'monitoring'] })}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
          >
            <RefreshCw size={13} className={isFetching ? 'animate-spin' : ''} />
            تحديث
          </button>
        </div>
      </div>

      {/* ── Overall alert banner ── */}
      <AnimatePresence>
        {!isLoading && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-2xl border p-4 flex items-start gap-3 ${
              criticalIssues.length > 0 ? 'bg-red-500/10 border-red-500/30' :
              warningIssues.length > 0 ? 'bg-amber-500/10 border-amber-500/30' :
              'bg-emerald-500/10 border-emerald-500/20'
            }`}
          >
            {overallOk
              ? <CheckCircle size={20} className="text-emerald-400 shrink-0 mt-0.5" />
              : criticalIssues.length > 0
                ? <AlertCircle size={20} className="text-red-400 shrink-0 mt-0.5" />
                : <AlertTriangle size={20} className="text-amber-400 shrink-0 mt-0.5" />
            }
            <div>
              <div className="font-semibold text-sm mb-1">
                {overallOk ? '✅ جميع الأنظمة تعمل بشكل طبيعي' :
                  criticalIssues.length > 0 ? `🔴 ${criticalIssues.length} مشكلة حرجة` : `⚠️ ${warningIssues.length} تحذير`}
              </div>
              {[...criticalIssues, ...warningIssues].map((issue, i) => (
                <div key={i} className="text-xs text-muted-foreground">• {issue}</div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Status grid ── */}
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="rounded-2xl border border-white/10 bg-white/5 p-4 h-24 animate-pulse" />
          ))}
        </div>
      ) : data && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatusCard
            icon={Database}
            label="قاعدة البيانات"
            value={data.system.database.status === 'ok' ? 'متصلة' : 'خطأ'}
            status={data.system.database.status}
            sub={`استجابة ${fmtMs(data.system.database.latencyMs)}`}
          />
          <StatusCard
            icon={MessageCircle}
            label="بوت تيليجرام"
            value={data.system.telegram.configured
              ? data.system.telegram.status === 'ok' ? 'يعمل' : 'خطأ'
              : 'غير مُفعَّل'}
            status={data.system.telegram.configured ? data.system.telegram.status : 'slow'}
          />
          <StatusCard
            icon={Zap}
            label="المزود"
            value={data.provider
              ? data.provider.stability === 'stable' ? 'مستقر' : data.provider.stability === 'slow' ? 'بطيء' : 'غير مستقر'
              : 'غير مُفعَّل'}
            status={data.provider?.stability ?? 'error'}
            sub={data.provider ? `نجاح ${data.provider.stats.successRate}% اليوم` : undefined}
          />
          <StatusCard
            icon={Cpu}
            label="استخدام الذاكرة"
            value={`${data.system.memory.percent}%`}
            status={data.system.memory.percent > 90 ? 'error' : data.system.memory.percent > 75 ? 'slow' : 'ok'}
            sub={`${data.system.memory.usedMb} / ${data.system.memory.totalMb} MB`}
          />
        </div>
      )}

      {/* ── Additional metrics row ── */}
      {data && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
            <div className="text-2xl font-bold text-amber-400">{data.orders.stuckCount}</div>
            <div className="text-xs text-muted-foreground mt-1">طلب عالق</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
            <div className="text-2xl font-bold text-red-400">{data.orders.failed24h}</div>
            <div className="text-xs text-muted-foreground mt-1">فشل آخر 24س</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
            <div className="text-2xl font-bold text-blue-400">{data.orders.pending}</div>
            <div className="text-xs text-muted-foreground mt-1">طلب معلق</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
            <div className="text-2xl font-bold">{data.system.uptime.human}</div>
            <div className="text-xs text-muted-foreground mt-1">وقت التشغيل</div>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────────────── */}
      {/* ── Section: Stuck / Failed Orders ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={Clock}
          title="الطلبات العالقة والفاشلة"
          badge={data?.orders.stuckCount}
          expanded={expandedSections.has('orders')}
          onToggle={() => toggleSection('orders')}
        />
        <AnimatePresence>
          {expandedSections.has('orders') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-3">
                {/* Broken checkout alert */}
                {data.orders.failedCheckouts1h > 0 && (
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm">
                    <ShoppingCart size={16} />
                    <span>⚠️ {data.orders.failedCheckouts1h} طلب فشل في إتمام الدفع خلال آخر ساعة</span>
                  </div>
                )}

                {data.orders.stuckCount === 0 ? (
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    <CheckCircle size={20} className="text-emerald-400 mx-auto mb-1" />
                    لا توجد طلبات عالقة 🎉
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
                      <span>الطلبات العالقة أكثر من 10 دقائق</span>
                      <ActionButton
                        label="إصلاح جميع العالقة"
                        icon={Wrench}
                        action="fix-stuck-orders"
                        onRun={handleMaintenance}
                        loading={runningAction}
                        variant="danger"
                      />
                    </div>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {data.orders.stuckList.map(order => (
                        <div key={order.id} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-red-500/5 border border-red-500/20 text-sm">
                          <Package size={14} className="text-red-400 shrink-0" />
                          <span className="flex-1">طلب #{order.id}</span>
                          <span className="text-xs text-muted-foreground">{timeAgo(order.createdAt)} مضى</span>
                          <span className="text-xs text-amber-400">محاولات: {order.retryCount}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Stats row */}
                <div className="grid grid-cols-3 gap-2 mt-2">
                  <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2 text-center">
                    <div className="text-lg font-bold">{data.orders.processing}</div>
                    <div className="text-xs text-muted-foreground">قيد التنفيذ</div>
                  </div>
                  <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2 text-center">
                    <div className="text-lg font-bold text-red-400">{data.orders.failed24h}</div>
                    <div className="text-xs text-muted-foreground">فشل اليوم</div>
                  </div>
                  <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2 text-center">
                    <div className="text-lg font-bold text-blue-400">{data.orders.pending}</div>
                    <div className="text-xs text-muted-foreground">معلق</div>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground px-1">
                  <Info size={11} className="inline me-1" />
                  <strong>السبب المتوقع:</strong> تأخر المزود، انقطاع الشبكة، أو رفض من API
                  <br />
                  <strong>الإصلاح:</strong> اضغط "إصلاح جميع العالقة" لإعادة الطلبات للحالة المعلقة وإعادة المحاولة
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: Price Protection ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={DollarSign}
          title="حماية الربح والأسعار"
          badge={data?.priceProtection.lossCount}
          badgeColor="bg-amber-500"
          expanded={expandedSections.has('price')}
          onToggle={() => toggleSection('price')}
        />
        <AnimatePresence>
          {expandedSections.has('price') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-3">
                {data.priceProtection.lossCount === 0 ? (
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    <CheckCircle size={20} className="text-emerald-400 mx-auto mb-1" />
                    جميع الأسعار محمية — لا خسائر مكتشفة ✅
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-red-400 font-semibold">{data.priceProtection.lossCount} منتج يُباع بأقل من سعر التكلفة</span>
                      {canRunMaintenance && <ActionButton
                          label="إيقاف المنتجات الخاسرة"
                          icon={Shield}
                          action="recalculate-prices"
                          onRun={handleMaintenance}
                          loading={runningAction}
                          variant="danger"
                        />}
                    </div>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {(showAllLoss ? data.priceProtection.products : data.priceProtection.products.slice(0, 5)).map(p => (
                        <div key={p.id} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-red-500/5 border border-red-500/20 text-sm">
                          <TrendingDown size={14} className="text-red-400 shrink-0" />
                          <span className="flex-1 truncate">{p.name}</span>
                          <span className="text-xs text-muted-foreground">سعر: ${parseFloat(p.priceUsd).toFixed(4)}</span>
                          <span className="text-xs text-red-400">تكلفة: ${parseFloat(p.unitPriceUsd).toFixed(4)}</span>
                        </div>
                      ))}
                    </div>
                    {data.priceProtection.products.length > 5 && (
                      <button onClick={() => setShowAllLoss(!showAllLoss)} className="text-xs text-primary hover:underline">
                        {showAllLoss ? 'عرض أقل' : `عرض جميع ${data.priceProtection.products.length}`}
                      </button>
                    )}
                  </>
                )}
                <div className="text-xs text-muted-foreground px-1">
                  <Info size={11} className="inline me-1" />
                  <strong>السبب المتوقع:</strong> تغير سعر المزود بعد رفع السعر الأصلي
                  <br />
                  <strong>الإصلاح:</strong> راجع الأسعار يدوياً أو استخدم "إيقاف المنتجات الخاسرة" لحمايتها فوراً
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: Provider Stability ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={BarChart3}
          title="استقرار المزود"
          expanded={expandedSections.has('provider')}
          onToggle={() => toggleSection('provider')}
        />
        <AnimatePresence>
          {expandedSections.has('provider') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-4">
                {!data.provider ? (
                  <div className="text-center py-4 text-muted-foreground text-sm">لا يوجد مزود مُفعَّل</div>
                ) : (
                  <>
                    <div className="flex items-center gap-3">
                      <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-sm font-bold ${statusBg(data.provider.stability)}`}>
                        <Dot status={data.provider.stability} />
                        <span className={statusColor(data.provider.stability)}>
                          {data.provider.stability === 'stable' ? '🟢 مستقر' : data.provider.stability === 'slow' ? '🟡 بطيء' : '🔴 غير مستقر'}
                        </span>
                      </div>
                      <span className="text-sm text-muted-foreground">{data.provider.name}</span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="rounded-xl bg-white/5 border border-white/10 p-3 text-center">
                        <div className="text-xl font-bold text-emerald-400">{data.provider.stats.successRate}%</div>
                        <div className="text-xs text-muted-foreground">نسبة النجاح</div>
                      </div>
                      <div className="rounded-xl bg-white/5 border border-white/10 p-3 text-center">
                        <div className="text-xl font-bold">{data.provider.stats.totalToday}</div>
                        <div className="text-xs text-muted-foreground">إجمالي اليوم</div>
                      </div>
                      <div className="rounded-xl bg-white/5 border border-white/10 p-3 text-center">
                        <div className="text-xl font-bold text-emerald-400">{data.provider.stats.completedToday}</div>
                        <div className="text-xs text-muted-foreground">مكتمل</div>
                      </div>
                      <div className="rounded-xl bg-white/5 border border-white/10 p-3 text-center">
                        <div className="text-xl font-bold text-red-400">{data.provider.stats.failedToday}</div>
                        <div className="text-xs text-muted-foreground">فاشل</div>
                      </div>
                    </div>

                    {/* Provider balance */}
                    {(data.provider.balanceSyp != null || data.provider.balance != null) && (
                      <div className={`rounded-xl p-3 border flex items-center gap-2 text-sm ${
                        (data.provider.balanceSyp ?? 0) < 50000
                          ? 'bg-red-500/10 border-red-500/30 text-red-400'
                          : 'bg-white/5 border-white/10'
                      }`}>
                        <HardDrive size={14} />
                        <span>رصيد المزود: </span>
                        <strong>
                          {data.provider.balanceSyp != null
                            ? `${Number(data.provider.balanceSyp).toLocaleString()} SYP`
                            : `$${data.provider.balance}`}
                        </strong>
                        {(data.provider.balanceSyp ?? 0) < 50000 && <span className="text-xs me-auto">⚠️ رصيد منخفض!</span>}
                      </div>
                    )}

                    {data.provider.error && (
                      <div className="rounded-xl p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs">
                        <strong>آخر خطأ:</strong> {data.provider.error}
                      </div>
                    )}

                    <div className="text-xs text-muted-foreground">
                      <Info size={11} className="inline me-1" />
                      إذا كان المزود غير مستقر، تحقق من الرصيد أو اضغط Force Balance Sync أدناه
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: Image Scanner ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={Image}
          title="فاحص الصور والواجهة"
          badge={data?.images.missingCount}
          badgeColor="bg-purple-500"
          expanded={expandedSections.has('images')}
          onToggle={() => toggleSection('images')}
        />
        <AnimatePresence>
          {expandedSections.has('images') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">
                    {data.images.missingCount === 0
                      ? <span className="text-emerald-400">✅ جميع المنتجات النشطة لديها صور</span>
                      : <span className="text-amber-400">{data.images.missingCount} منتج نشط بدون صورة</span>}
                  </span>
                  {canRunMaintenance && <div className="flex gap-2">
                    <ActionButton label="تحديث الصور" icon={Camera} action="refresh-images" onRun={handleMaintenance} loading={runningAction} />
                    <ActionButton label="مسح كاش الصور" icon={Trash2} action="clear-image-cache" onRun={handleMaintenance} loading={runningAction} />
                  </div>}
                </div>
                {data.images.missingCount > 0 && (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {(showAllImages ? data.images.products : data.images.products.slice(0, 8)).map(p => (
                      <div key={p.id} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-purple-500/5 border border-purple-500/20 text-sm">
                        <Image size={13} className="text-purple-400 shrink-0" />
                        <span className="flex-1 truncate">{p.name}</span>
                        <span className="text-xs text-muted-foreground">#{p.id}</span>
                      </div>
                    ))}
                    {data.images.products.length > 8 && (
                      <button onClick={() => setShowAllImages(!showAllImages)} className="text-xs text-primary hover:underline">
                        {showAllImages ? 'عرض أقل' : `عرض جميع ${data.images.products.length}`}
                      </button>
                    )}
                  </div>
                )}
                <div className="text-xs text-muted-foreground">
                  <Info size={11} className="inline me-1" />
                  المنتجات بدون صور قد تُقلل معدل التحويل — استخدم أدوات الصور لإضافتها
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: Cron Jobs Status ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={Activity}
          title="حالة المهام التلقائية (Cron Jobs)"
          expanded={expandedSections.has('crons')}
          onToggle={() => toggleSection('crons')}
        />
        <AnimatePresence>
          {expandedSections.has('crons') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {Object.entries({
                    'مراقب الطلبات العالقة': data.crons.stuckMonitorInterval,
                    'جدول إعادة المحاولة': data.crons.retrySchedulerInterval,
                    'مراقب رصيد المزود': data.crons.balanceMonitorInterval,
                    'منتهي صلاحية الطلبات': data.crons.orderTimeoutInterval,
                    'النسخ الاحتياطي التلقائي': data.crons.backupSchedule,
                    'فحص تنبيهات الأسعار': 'كل ساعة',
                  }).map(([label, interval]) => (
                    <div key={label} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-sm">
                      <CheckCircle size={13} className="text-emerald-400 shrink-0" />
                      <span className="flex-1">{label}</span>
                      <span className="text-xs text-muted-foreground">{interval}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: One-Click Maintenance ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={Wrench}
          title="أدوات الصيانة الفورية"
          expanded={expandedSections.has('maintenance')}
          onToggle={() => toggleSection('maintenance')}
        />
        <AnimatePresence>
          {expandedSections.has('maintenance') && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-3">
                {canRunMaintenance && <div className="flex flex-wrap gap-2">
                  <ActionButton label="مسح الكاش" icon={Trash2} action="clear-image-cache" onRun={handleMaintenance} loading={runningAction} />
                  <ActionButton label="تحديث الصور" icon={Camera} action="refresh-images" onRun={handleMaintenance} loading={runningAction} />
                  <ActionButton label="مزامنة المنتجات" icon={RefreshCw} action="resync-products" onRun={handleMaintenance} loading={runningAction} />
                  <ActionButton label="إعادة مزامنة الطلبات" icon={RotateCcw} action="re-sync-orders" onRun={handleMaintenance} loading={runningAction} />
                  <ActionButton label="إصلاح العالقة" icon={Wrench} action="fix-stuck-orders" onRun={handleMaintenance} loading={runningAction} variant="danger" />
                  <ActionButton label="إعادة حساب الأسعار" icon={DollarSign} action="recalculate-prices" onRun={handleMaintenance} loading={runningAction} variant="danger" />
                  <ActionButton label="فحص رصيد المزود" icon={Zap} action="force-balance-sync" onRun={handleMaintenance} loading={runningAction} />
                  <ActionButton label="إعادة تشغيل Queue" icon={Play} action="restart-queue" onRun={handleMaintenance} loading={runningAction} />
                </div>}
                <div className="text-xs text-muted-foreground">
                  <Info size={11} className="inline me-1" />
                  الأزرار باللون الأحمر تُنفّذ عمليات حرجة — استخدمها بحذر
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: Backup ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={Download}
          title="النسخ الاحتياطي التلقائي"
          expanded={expandedSections.has('backup')}
          onToggle={() => toggleSection('backup')}
        />
        <AnimatePresence>
          {expandedSections.has('backup') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="rounded-xl bg-white/5 border border-white/10 p-3">
                    <div className="text-xs text-muted-foreground mb-1">آخر نسخة احتياطية</div>
                    <div className="font-semibold text-sm">{fmtDate(data.backup.createdAt)}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 truncate">{data.backup.name ?? '—'}</div>
                  </div>
                  <div className="rounded-xl bg-white/5 border border-white/10 p-3">
                    <div className="text-xs text-muted-foreground mb-1">عدد النسخ المحفوظة</div>
                    <div className="font-semibold text-xl">{data.backup.count}</div>
                  </div>
                  <div className="rounded-xl bg-white/5 border border-white/10 p-3">
                    <div className="text-xs text-muted-foreground mb-1">جدول تلقائي</div>
                    <div className="font-semibold text-sm">{data.crons.backupSchedule}</div>
                    <div className="text-xs text-emerald-400 mt-0.5">✅ يعمل تلقائياً</div>
                  </div>
                </div>
                {canRunMaintenance && <div className="flex gap-2">
                  <button
                    onClick={handleBackup}
                    disabled={!!runningAction}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 disabled:opacity-50 transition-opacity"
                  >
                    <Download size={14} />
                    نسخة احتياطية الآن
                  </button>
                  <a
                    href={`${BASE}/admin/backups`}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm font-semibold hover:bg-white/10 transition-colors"
                  >
                    <Eye size={14} />
                    إدارة النسخ
                  </a>
                </div>}
                <div className="text-xs text-muted-foreground">
                  <Info size={11} className="inline me-1" />
                  تُحذف النسخ الأقدم من 14 يوماً تلقائياً — النسخ محفوظة مُضغوطة (.sql.gz)
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Section: Customer Experience Monitor ── */}
      <div className="rounded-2xl border border-white/10 bg-card overflow-hidden">
        <SectionHeader
          icon={Eye}
          title="تجربة العملاء"
          expanded={expandedSections.has('cx')}
          onToggle={() => toggleSection('cx')}
        />
        <AnimatePresence>
          {expandedSections.has('cx') && data && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="px-4 pb-4 space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className={`rounded-xl p-3 border ${
                    data.responseMs < 500 ? 'bg-emerald-500/5 border-emerald-500/20' :
                    data.responseMs < 1500 ? 'bg-amber-500/5 border-amber-500/20' :
                    'bg-red-500/5 border-red-500/20'
                  }`}>
                    <div className="text-xs text-muted-foreground mb-1">زمن استجابة API</div>
                    <div className={`font-bold text-lg ${
                      data.responseMs < 500 ? 'text-emerald-400' :
                      data.responseMs < 1500 ? 'text-amber-400' : 'text-red-400'
                    }`}>{fmtMs(data.responseMs)}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {data.responseMs < 500 ? '✅ ممتاز' : data.responseMs < 1500 ? '⚠️ مقبول' : '🔴 بطيء'}
                    </div>
                  </div>
                  <div className={`rounded-xl p-3 border ${
                    data.system.database.latencyMs < 50 ? 'bg-emerald-500/5 border-emerald-500/20' :
                    data.system.database.latencyMs < 200 ? 'bg-amber-500/5 border-amber-500/20' :
                    'bg-red-500/5 border-red-500/20'
                  }`}>
                    <div className="text-xs text-muted-foreground mb-1">استجابة قاعدة البيانات</div>
                    <div className={`font-bold text-lg ${
                      data.system.database.latencyMs < 50 ? 'text-emerald-400' :
                      data.system.database.latencyMs < 200 ? 'text-amber-400' : 'text-red-400'
                    }`}>{fmtMs(data.system.database.latencyMs)}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {data.system.database.latencyMs < 50 ? '✅ ممتاز' : data.system.database.latencyMs < 200 ? '⚠️ مقبول' : '🔴 بطيء'}
                    </div>
                  </div>
                  <div className={`rounded-xl p-3 border ${
                    data.orders.failedCheckouts1h === 0 ? 'bg-emerald-500/5 border-emerald-500/20' :
                    data.orders.failedCheckouts1h < 5 ? 'bg-amber-500/5 border-amber-500/20' :
                    'bg-red-500/5 border-red-500/20'
                  }`}>
                    <div className="text-xs text-muted-foreground mb-1">فشل Checkout (ساعة)</div>
                    <div className={`font-bold text-lg ${
                      data.orders.failedCheckouts1h === 0 ? 'text-emerald-400' :
                      data.orders.failedCheckouts1h < 5 ? 'text-amber-400' : 'text-red-400'
                    }`}>{data.orders.failedCheckouts1h}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {data.orders.failedCheckouts1h === 0 ? '✅ لا مشاكل' :
                       data.orders.failedCheckouts1h < 5 ? '⚠️ تحقق من الدفع' : '🔴 مشكلة في الدفع!'}
                    </div>
                  </div>
                </div>
                {data.responseMs > 1500 && (
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-sm text-amber-400">
                    <AlertTriangle size={15} className="shrink-0 mt-0.5" />
                    <div>
                      <strong>صفحات بطيئة:</strong> زمن الاستجابة {fmtMs(data.responseMs)} — قد يؤثر على تجربة العملاء
                      <br />
                      <span className="text-xs text-muted-foreground">الإصلاح: مسح الكاش أو إعادة مزامنة المنتجات قد يساعد</span>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── System info footer ── */}
      {data && (
        <div className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div>
            <div className="text-muted-foreground">وقت التشغيل</div>
            <div className="font-semibold mt-0.5">{data.system.uptime.human}</div>
          </div>
          <div>
            <div className="text-muted-foreground">تحميل النظام</div>
            <div className="font-semibold mt-0.5">{data.system.load['1m']} / {data.system.load['5m']} / {data.system.load['15m']}</div>
          </div>
          <div>
            <div className="text-muted-foreground">الذاكرة المستخدمة</div>
            <div className="font-semibold mt-0.5">{data.system.memory.usedMb} MB / {data.system.memory.totalMb} MB</div>
          </div>
          <div>
            <div className="text-muted-foreground">استجابة الـ API</div>
            <div className="font-semibold mt-0.5">{fmtMs(data.responseMs)}</div>
          </div>
        </div>
      )}
    </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
