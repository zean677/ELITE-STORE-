import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { History, RefreshCw, Search } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}` };
}

type LogEntry = {
  id: number;
  adminId: number;
  adminUsername: string;
  action: string;
  entity: string;
  entityId?: string;
  details?: Record<string, unknown>;
  ip?: string;
  createdAt: string;
};

const ACTION_LABELS: Record<string, { label: string; color: string }> = {
  delete: { label: 'حذف', color: 'text-red-400 bg-red-500/10 border-red-500/20' },
  export: { label: 'تصدير', color: 'text-green-400 bg-green-500/10 border-green-500/20' },
  update: { label: 'تعديل', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' },
  create: { label: 'إنشاء', color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' },
  update_profit: { label: 'تحديث ربح', color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' },
  approve: { label: 'قبول', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
  reject: { label: 'رفض', color: 'text-red-400 bg-red-500/10 border-red-500/20' },
  sync: { label: 'مزامنة', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' },
};

const ENTITY_LABELS: Record<string, string> = {
  product: 'منتج', category: 'فئة', orders: 'طلبات', user: 'مستخدم',
  payment: 'إيداع', settings: 'الإعدادات', promo: 'كود خصم',
};

type ProductChange = {
  id: number; productId: string; field: string;
  oldValue?: string | null; newValue?: string | null;
  source?: string | null; createdAt: string;
};

export default function AdminActivityLog() {
  const [tab, setTab] = useState<'admin' | 'products'>('admin');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [changes, setChanges] = useState<ProductChange[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const limit = 50;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const ep = tab === 'admin' ? 'activity-log' : 'product-changes';
      const res = await fetch(`${BASE}/api/admin/${ep}?page=${page}&limit=${limit}`, { headers: authHeaders() });
      if (res.ok) {
        const data = await res.json();
        if (tab === 'admin') { setLogs(data.logs ?? []); }
        else { setChanges(data.changes ?? []); }
        setTotal(data.total ?? 0);
      }
    } finally {
      setLoading(false);
    }
  }, [page, tab]);

  useEffect(() => { setPage(1); }, [tab]);
  useEffect(() => { load(); }, [load]);

  const filtered = search.trim()
    ? logs.filter(l => l.action.includes(search) || l.entity.includes(search) || l.adminUsername.toLowerCase().includes(search.toLowerCase()) || l.entityId?.includes(search))
    : logs;
  const filteredChanges = search.trim()
    ? changes.filter(c => c.productId.includes(search) || c.field.includes(search) || (c.source ?? '').includes(search))
    : changes;

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
                <History size={22} className="text-primary" /> سجل نشاط المشرفين
              </h1>
              <p className="text-muted-foreground text-sm mt-1">{total} إجراء مسجّل</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="بحث..."
                  className="pr-9 pl-3 py-2 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 w-40" />
              </div>
              <button onClick={load} disabled={loading}
                className="flex items-center gap-1 px-3 py-2 bg-card border border-border rounded-xl text-sm hover:border-primary/50 transition-colors disabled:opacity-50">
                <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> تحديث
              </button>
            </div>
          </div>

          <div className="flex gap-1 bg-card border border-border rounded-xl p-1 w-fit">
            <button onClick={() => setTab('admin')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${tab === 'admin' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              نشاط المشرفين
            </button>
            <button onClick={() => setTab('products')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${tab === 'products' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              تغييرات المنتجات
            </button>
          </div>

          {tab === 'products' ? (
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              {loading ? (
                <div className="py-12 text-center"><div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" /></div>
              ) : filteredChanges.length === 0 ? (
                <div className="py-16 text-center"><History size={40} className="mx-auto text-muted-foreground/30 mb-4" /><p className="text-muted-foreground">لا توجد تغييرات مسجّلة</p></div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-background/50">
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الوقت</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المنتج</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الحقل</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">قبل</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">بعد</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المصدر</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredChanges.map(c => (
                        <tr key={c.id} className="hover:bg-background transition-colors">
                          <td className="px-4 py-2.5 text-xs text-muted-foreground whitespace-nowrap">{new Date(c.createdAt).toLocaleString('en-GB', { timeZone: 'Asia/Damascus' })}</td>
                          <td className="px-4 py-2.5 text-xs font-mono">{c.productId.slice(0, 10)}</td>
                          <td className="px-4 py-2.5 text-xs font-bold">{c.field}</td>
                          <td className="px-4 py-2.5 text-xs text-red-300 max-w-[160px] truncate">{c.oldValue ?? '—'}</td>
                          <td className="px-4 py-2.5 text-xs text-emerald-300 max-w-[160px] truncate">{c.newValue ?? '—'}</td>
                          <td className="px-4 py-2.5 text-xs text-muted-foreground">{c.source ?? 'admin'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : (
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {loading ? (
              <div className="py-12 text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="py-16 text-center">
                <History size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">لا يوجد سجل نشاط</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-background/50">
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الوقت</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المشرف</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الإجراء</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الكيان</th>
                      <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">التفاصيل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filtered.map(log => {
                      const action = ACTION_LABELS[log.action] ?? { label: log.action, color: 'text-gray-400 bg-gray-500/10 border-gray-500/20' };
                      const entity = ENTITY_LABELS[log.entity] ?? log.entity;
                      return (
                        <motion.tr key={log.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background transition-colors">
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                            {new Date(log.createdAt).toLocaleString('en-GB', { timeZone: 'Asia/Damascus' })}
                          </td>
                          <td className="px-4 py-3 text-sm font-medium">{log.adminUsername}</td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-medium border ${action.color}`}>
                              {action.label}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">
                            {entity}
                            {log.entityId && <span className="ml-1 text-xs font-mono opacity-60">#{log.entityId.slice(0, 8)}</span>}
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground max-w-xs truncate">
                            {log.details ? (
                              <span title={JSON.stringify(log.details, null, 2)}>
                                {Object.entries(log.details).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                              </span>
                            ) : '—'}
                          </td>
                        </motion.tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          )}

          {total > limit && (
            <div className="flex justify-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">السابق</button>
              <span className="px-4 py-2 text-sm text-muted-foreground">صفحة {page}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page * limit >= total}
                className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">التالي</button>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
