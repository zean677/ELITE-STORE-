import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Star, Gift, TrendingUp, Users, Coins, Plus, Pencil, Trash2, Check, X, Sparkles, History, Award, Loader2, ToggleLeft, ToggleRight, ImagePlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { uploadAdminImage } from '@/lib/upload-admin-image';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function api(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

const REWARD_TYPES = [
  { value: 'balance', label: '💰 رصيد محفظة (تلقائي)', color: '#10b981' },
  { value: 'product', label: '🎮 منتج مجاني', color: '#8b5cf6' },
  { value: 'vip_boost', label: '👑 ترقية VIP مؤقتة', color: '#f59e0b' },
  { value: 'physical', label: '📦 جائزة عينية', color: '#ec4899' },
  { value: 'custom', label: '🎁 مخصص', color: '#fbbf24' },
];

type Tab = 'overview' | 'rewards' | 'redemptions' | 'tools';

function AdminLoyaltyContent() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>('overview');

  const { data: stats } = useQuery({
    queryKey: ['admin-loyalty-stats'],
    queryFn: async () => (await api('GET', '/api/admin/loyalty/stats')).json(),
  });

  const { data: rewards = [] } = useQuery<any[]>({
    queryKey: ['admin-loyalty-rewards'],
    queryFn: async () => (await api('GET', '/api/admin/loyalty/rewards')).json(),
  });

  const { data: redemptions = [] } = useQuery<any[]>({
    queryKey: ['admin-loyalty-redemptions'],
    queryFn: async () => (await api('GET', '/api/admin/loyalty/redemptions')).json(),
  });

  const cfg = stats?.config;
  const s = stats?.stats;

  // ─── Adjust user points modal ─────────
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [adjustForm, setAdjustForm] = useState({ userId: '', delta: '', reason: '' });

  const adjustMut = useMutation({
    mutationFn: async () => {
      const res = await api('POST', `/api/admin/users/${adjustForm.userId}/loyalty`, {
        delta: parseInt(adjustForm.delta, 10),
        reason: adjustForm.reason,
      });
      if (!res.ok) throw new Error((await res.json()).message ?? 'فشل');
      return res.json();
    },
    onSuccess: (d) => {
      toast({ title: '✅ تم التعديل', description: `الرصيد الجديد: ${d.newTotal} نقطة` });
      setAdjustOpen(false);
      setAdjustForm({ userId: '', delta: '', reason: '' });
      qc.invalidateQueries({ queryKey: ['admin-loyalty-stats'] });
    },
    onError: (e: any) => toast({ title: '❌ خطأ', description: e.message, variant: 'destructive' }),
  });

  // ─── Bulk grant ───────
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkForm, setBulkForm] = useState({ points: '', vipLevel: 'all', reason: '' });

  const bulkMut = useMutation({
    mutationFn: async () => {
      const res = await api('POST', '/api/admin/loyalty/bulk-grant', {
        points: parseInt(bulkForm.points, 10),
        vipLevel: bulkForm.vipLevel === 'all' ? null : parseInt(bulkForm.vipLevel, 10),
        reason: bulkForm.reason || 'منحة عامة',
      });
      if (!res.ok) throw new Error((await res.json()).message ?? 'فشل');
      return res.json();
    },
    onSuccess: (d) => {
      toast({ title: '🎁 تم المنح للجميع', description: `${d.granted} مستخدم استلموا ${d.points} نقطة` });
      setBulkOpen(false);
      setBulkForm({ points: '', vipLevel: 'all', reason: '' });
      qc.invalidateQueries({ queryKey: ['admin-loyalty-stats'] });
    },
    onError: (e: any) => toast({ title: '❌ خطأ', description: e.message, variant: 'destructive' }),
  });

  // ─── Config (rates) ─────
  const [cfgForm, setCfgForm] = useState({ earned: '', redeemed: '' });
  React.useEffect(() => {
    if (cfg) setCfgForm({ earned: String(cfg.pointsPerUsdEarned), redeemed: String(cfg.pointsPerUsdRedeemed) });
  }, [cfg?.pointsPerUsdEarned, cfg?.pointsPerUsdRedeemed]);

  const cfgMut = useMutation({
    mutationFn: async () => {
      const res = await api('PATCH', '/api/admin/loyalty/config', {
        pointsPerUsdEarned: parseFloat(cfgForm.earned),
        pointsPerUsdRedeemed: parseFloat(cfgForm.redeemed),
      });
      if (!res.ok) throw new Error('فشل');
      return res.json();
    },
    onSuccess: () => {
      toast({ title: '✅ تم حفظ الإعدادات', description: 'سيتم تطبيق المعدلات الجديدة فوراً' });
      qc.invalidateQueries({ queryKey: ['admin-loyalty-stats'] });
    },
  });

  // ─── Reward modal ──────
  const [rewardOpen, setRewardOpen] = useState(false);
  const [editingReward, setEditingReward] = useState<any | null>(null);
  const [rewardForm, setRewardForm] = useState({
    nameAr: '', description: '', pointsCost: '', type: 'balance',
    value: '', emoji: '🎁', imageUrl: '', accentColor: '#fbbf24', stock: '', isActive: true, sortOrder: '0',
  });
  const [rewardImageUploading, setRewardImageUploading] = useState(false);
  const [rewardImageFile, setRewardImageFile] = useState<File | null>(null);
  const [rewardImagePreview, setRewardImagePreview] = useState<string | null>(null);

  useEffect(() => {
    if (!rewardImagePreview?.startsWith('blob:')) return;
    return () => URL.revokeObjectURL(rewardImagePreview);
  }, [rewardImagePreview]);

  function openNewReward() {
    setEditingReward(null);
    setRewardImageFile(null);
    setRewardImagePreview(null);
    setRewardForm({ nameAr: '', description: '', pointsCost: '', type: 'balance', value: '', emoji: '🎁', imageUrl: '', accentColor: '#fbbf24', stock: '', isActive: true, sortOrder: '0' });
    setRewardOpen(true);
  }
  function openEditReward(r: any) {
    setEditingReward(r);
    setRewardImageFile(null);
    setRewardImagePreview(null);
    setRewardForm({
      nameAr: r.nameAr ?? '', description: r.description ?? '', pointsCost: String(r.pointsCost ?? ''),
      type: r.type ?? 'balance', value: r.value != null ? String(r.value) : '',
      emoji: r.emoji ?? '🎁', imageUrl: r.imageUrl ?? '', accentColor: r.accentColor ?? '#fbbf24',
      stock: r.stock != null ? String(r.stock) : '', isActive: r.isActive !== false,
      sortOrder: String(r.sortOrder ?? 0),
    });
    setRewardOpen(true);
  }

  const saveRewardMut = useMutation({
    mutationFn: async () => {
      setRewardImageUploading(true);
      try {
        const imageUrl = rewardImageFile
          ? await uploadAdminImage(rewardImageFile, 'loyalty')
          : rewardForm.imageUrl || null;
        const payload: any = {
          nameAr: rewardForm.nameAr, description: rewardForm.description,
          pointsCost: parseInt(rewardForm.pointsCost, 10),
          type: rewardForm.type,
          value: rewardForm.value ? parseFloat(rewardForm.value) : null,
          emoji: rewardForm.emoji, imageUrl, accentColor: rewardForm.accentColor,
          stock: rewardForm.stock ? parseInt(rewardForm.stock, 10) : null,
          isActive: rewardForm.isActive,
          sortOrder: parseInt(rewardForm.sortOrder || '0', 10),
        };
        const res = editingReward
          ? await api('PATCH', `/api/admin/loyalty/rewards/${editingReward.id}`, payload)
          : await api('POST', '/api/admin/loyalty/rewards', payload);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || 'فشل حفظ المكافأة');
        return data;
      } finally {
        setRewardImageUploading(false);
      }
    },
    onSuccess: () => {
      toast({ title: editingReward ? '✅ تم التحديث' : '✅ تم إنشاء المكافأة' });
      setRewardOpen(false);
      setRewardImageFile(null);
      setRewardImagePreview(null);
      qc.invalidateQueries({ queryKey: ['admin-loyalty-rewards'] });
    },
    onError: (e: any) => toast({ title: '❌ خطأ', description: e.message, variant: 'destructive' }),
  });

  const toggleRewardMut = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      const res = await api('PATCH', `/api/admin/loyalty/rewards/${id}`, { isActive });
      return res.json();
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-loyalty-rewards'] }),
  });

  const deleteRewardMut = useMutation({
    mutationFn: async (id: number) => api('DELETE', `/api/admin/loyalty/rewards/${id}`),
    onSuccess: () => {
      toast({ title: '✅ تم الحذف' });
      qc.invalidateQueries({ queryKey: ['admin-loyalty-rewards'] });
    },
  });

  const markDeliveredMut = useMutation({
    mutationFn: async ({ id, status, note }: { id: number; status: string; note?: string }) => {
      const res = await api('PATCH', `/api/admin/loyalty/redemptions/${id}`, { status, adminNote: note });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: '✅ تم التحديث' });
      qc.invalidateQueries({ queryKey: ['admin-loyalty-redemptions'] });
    },
  });

  const tabs: { key: Tab; label: string; icon: any }[] = [
    { key: 'overview', label: 'نظرة عامة', icon: TrendingUp },
    { key: 'rewards', label: 'كتالوج المكافآت', icon: Gift },
    { key: 'redemptions', label: 'سجل الاستبدالات', icon: History },
    { key: 'tools', label: 'أدوات الإدارة', icon: Sparkles },
  ];

  return (
    <div dir="rtl" className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg shadow-yellow-500/30">
          <Star className="text-white" size={24} fill="white" />
        </div>
        <div>
          <h1 className="font-heading text-2xl lg:text-3xl font-black">نظام نقاط الولاء</h1>
          <p className="text-xs text-muted-foreground mt-0.5">إدارة شاملة للنقاط والمكافآت والاستبدالات</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {tabs.map(t => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${active ? 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white shadow-lg shadow-yellow-500/30' : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}>
              <Icon size={15} /> {t.label}
            </button>
          );
        })}
      </div>

      {/* OVERVIEW TAB */}
      {tab === 'overview' && (
        <div className="space-y-5">
          {/* Stats grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard icon={<Coins size={20} />} label="إجمالي النقاط المتاحة" value={s ? s.totalOutstanding.toLocaleString() : '—'} sub={s ? `≈ $${s.liabilityUsd.toFixed(2)} التزام` : ''} color="from-yellow-500 to-orange-500" />
            <StatCard icon={<Users size={20} />} label="مستخدمون لديهم نقاط" value={s ? s.activeUsers.toLocaleString() : '—'} sub={s ? `متوسط ${s.avgPoints} نقطة` : ''} color="from-blue-500 to-cyan-500" />
            <StatCard icon={<Award size={20} />} label="إجمالي النقاط المكتسبة" value={s ? s.totalEarned.toLocaleString() : '—'} sub="منذ بدء النظام" color="from-emerald-500 to-green-500" />
            <StatCard icon={<Gift size={20} />} label="نقاط مستبدلة" value={s ? s.totalRedeemed.toLocaleString() : '—'} sub={s ? `= $${s.totalRedeemedUsd.toFixed(2)} رصيد` : ''} color="from-purple-500 to-pink-500" />
          </div>

          {/* Top earners */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border bg-background/40 flex items-center gap-2">
              <Award className="text-yellow-400" size={16} />
              <h3 className="font-heading font-bold">🏆 أعلى 10 مستخدمين بالنقاط</h3>
            </div>
            <div className="divide-y divide-border">
              {(stats?.topEarners ?? []).map((u: any, i: number) => (
                <div key={u.id} className="flex items-center gap-3 px-4 py-3 hover:bg-background/40 transition-colors">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${i === 0 ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-white' : i === 1 ? 'bg-gradient-to-br from-gray-300 to-gray-400 text-white' : i === 2 ? 'bg-gradient-to-br from-amber-600 to-amber-700 text-white' : 'bg-muted text-muted-foreground'}`}>
                    {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{u.username}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{u.publicCode} · VIP {u.vipLevel ?? 0}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-black text-yellow-400">{u.loyaltyPoints?.toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground">نقطة</p>
                  </div>
                  <button onClick={() => { setAdjustForm({ userId: String(u.id), delta: '', reason: '' }); setAdjustOpen(true); }}
                    className="p-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors" title="تعديل نقاط">
                    <Pencil size={13} />
                  </button>
                </div>
              ))}
              {(stats?.topEarners ?? []).length === 0 && (
                <p className="px-4 py-8 text-center text-sm text-muted-foreground">لا يوجد مستخدمون بنقاط بعد</p>
              )}
            </div>
          </div>

          {/* Recent transactions */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border bg-background/40 flex items-center gap-2">
              <History className="text-blue-400" size={16} />
              <h3 className="font-heading font-bold">آخر الحركات (30)</h3>
            </div>
            <div className="divide-y divide-border max-h-[500px] overflow-y-auto">
              {(stats?.recent ?? []).map((tx: any) => {
                const positive = tx.points > 0;
                return (
                  <div key={tx.id} className="flex items-center gap-3 px-4 py-2.5 text-xs hover:bg-background/40">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${positive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'}`}>
                      {positive ? '+' : '−'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold truncate">{tx.username ?? `#${tx.userId}`} · <span className="text-muted-foreground">{tx.publicCode}</span></p>
                      <p className="text-[10px] text-muted-foreground truncate">{tx.description}</p>
                    </div>
                    <div className="text-left shrink-0">
                      <p className={`font-black ${positive ? 'text-emerald-400' : 'text-red-400'}`}>{positive ? '+' : ''}{tx.points}</p>
                      <p className="text-[9px] text-muted-foreground">{new Date(tx.createdAt).toLocaleDateString('en-GB')}</p>
                    </div>
                  </div>
                );
              })}
              {(stats?.recent ?? []).length === 0 && <p className="px-4 py-8 text-center text-sm text-muted-foreground">لا توجد حركات بعد</p>}
            </div>
          </div>
        </div>
      )}

      {/* REWARDS TAB */}
      {tab === 'rewards' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{rewards.length} مكافأة في الكتالوج</p>
            <button onClick={openNewReward} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold text-sm shadow-lg shadow-yellow-500/30 hover:scale-105 transition-transform">
              <Plus size={15} /> مكافأة جديدة
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {rewards.map((r: any) => (
              <motion.div key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                className="bg-card border border-border rounded-2xl p-4 hover:border-primary/40 transition-colors">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shrink-0" style={{ background: `${r.accentColor}20`, border: `1px solid ${r.accentColor}40` }}>
                    {r.imageUrl ? <img src={r.imageUrl} alt="" loading="lazy" className="w-full h-full rounded-2xl object-cover" /> : r.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start gap-2">
                      <h4 className="font-bold text-sm truncate flex-1">{r.nameAr}</h4>
                      {!r.isActive && <span className="text-[9px] bg-muted text-muted-foreground px-1.5 py-0.5 rounded">معطّل</span>}
                    </div>
                    <p className="text-[11px] text-muted-foreground line-clamp-2 mt-0.5">{r.description || 'لا يوجد وصف'}</p>
                    <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/15 text-secondary">{REWARD_TYPES.find(t => t.value === r.type)?.label.replace(/^[^\s]+\s/, '') ?? r.type}</span>
                      {r.value != null && <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400">${parseFloat(r.value).toFixed(2)}</span>}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs border-t border-border/40 pt-2 mb-3">
                  <div>
                    <p className="text-[10px] text-muted-foreground">السعر</p>
                    <p className="font-black text-yellow-400">{r.pointsCost}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground">المخزون</p>
                    <p className="font-bold">{r.stock != null ? r.stock : '∞'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground">مستبدلة</p>
                    <p className="font-bold text-purple-400">{r.redeemedCount ?? 0}</p>
                  </div>
                </div>

                <div className="flex gap-1.5">
                  <button onClick={() => toggleRewardMut.mutate({ id: r.id, isActive: !r.isActive })}
                    className={`flex-1 flex items-center justify-center gap-1 px-2 py-1.5 text-xs rounded-lg font-semibold transition-colors ${r.isActive ? 'bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25' : 'bg-muted text-muted-foreground hover:bg-muted/70'}`}>
                    {r.isActive ? <ToggleRight size={13} /> : <ToggleLeft size={13} />}
                    {r.isActive ? 'مفعّل' : 'معطّل'}
                  </button>
                  <button onClick={() => openEditReward(r)} className="px-2.5 py-1.5 rounded-lg bg-primary/15 text-primary hover:bg-primary/25 transition-colors"><Pencil size={12} /></button>
                  <button onClick={() => { if (confirm(`حذف "${r.nameAr}"؟`)) deleteRewardMut.mutate(r.id); }}
                    className="px-2.5 py-1.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"><Trash2 size={12} /></button>
                </div>
              </motion.div>
            ))}
            {rewards.length === 0 && (
              <div className="col-span-full text-center py-12 bg-card border border-dashed border-border rounded-2xl">
                <Gift size={40} className="mx-auto text-muted-foreground/30 mb-3" />
                <p className="text-muted-foreground text-sm">لا توجد مكافآت بعد. أضف مكافأتك الأولى!</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* REDEMPTIONS TAB */}
      {tab === 'redemptions' && (
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-background/40">
            <h3 className="font-heading font-bold">سجل آخر 100 استبدال</h3>
          </div>
          {redemptions.length === 0 ? (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">لا توجد استبدالات بعد</p>
          ) : (
            <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
              {redemptions.map((r: any) => (
                <div key={r.id} className="px-4 py-3 hover:bg-background/40">
                  <div className="flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm">{r.rewardName}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${r.status === 'delivered' ? 'bg-emerald-500/15 text-emerald-400' : r.status === 'pending' ? 'bg-yellow-500/15 text-yellow-400' : 'bg-red-500/15 text-red-400'}`}>
                          {r.status === 'delivered' ? '✓ تم التسليم' : r.status === 'pending' ? '⏳ قيد التنفيذ' : '✗ ملغي'}
                        </span>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {r.username} · {r.publicCode} · <span className="text-yellow-400 font-semibold">{r.pointsCost} نقطة</span>
                        {r.rewardValue ? ` · $${parseFloat(r.rewardValue).toFixed(2)}` : ''}
                        {' · '}{new Date(r.createdAt).toLocaleString('en-GB', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}
                      </p>
                      {r.adminNote && <p className="text-[11px] text-blue-400 mt-1">📝 {r.adminNote}</p>}
                    </div>
                    {r.status === 'pending' && (
                      <button onClick={() => {
                        const note = prompt('ملاحظة للعميل (اختياري):') ?? undefined;
                        markDeliveredMut.mutate({ id: r.id, status: 'delivered', note });
                      }} className="px-3 py-1.5 rounded-lg bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-xs font-semibold hover:bg-emerald-500/25">
                        <Check size={12} className="inline ml-1" /> تسليم
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TOOLS TAB */}
      {tab === 'tools' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Adjust user */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Pencil size={16} className="text-primary" />
              <h3 className="font-heading font-bold">تعديل نقاط مستخدم محدد</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-4">أضف أو اخصم نقاط من حساب مستخدم بعينه (استخدم رقم سالب للخصم)</p>
            <button onClick={() => { setAdjustForm({ userId: '', delta: '', reason: '' }); setAdjustOpen(true); }}
              className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90">
              فتح أداة التعديل
            </button>
          </div>

          {/* Bulk grant */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={16} className="text-yellow-400" />
              <h3 className="font-heading font-bold">منحة جماعية</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-4">امنح نقاط لكل المستخدمين أو لمستوى VIP محدد دفعة واحدة (مع إشعار تلقائي)</p>
            <button onClick={() => setBulkOpen(true)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold text-sm shadow-lg shadow-yellow-500/30">
              🎁 منحة لجميع المستخدمين
            </button>
          </div>

          {/* Config */}
          <div className="lg:col-span-2 bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Coins size={16} className="text-emerald-400" />
              <h3 className="font-heading font-bold">إعدادات معدلات النقاط</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">نقاط مكتسبة لكل $1 إنفاق</label>
                <input type="number" step="0.1" value={cfgForm.earned} onChange={e => setCfgForm(f => ({ ...f, earned: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl bg-background border border-border text-sm" />
                <p className="text-[10px] text-muted-foreground mt-1">حالياً: {cfg?.pointsPerUsdEarned} نقطة لكل دولار يصرفه العميل</p>
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">نقاط مطلوبة لاسترداد $1</label>
                <input type="number" step="1" value={cfgForm.redeemed} onChange={e => setCfgForm(f => ({ ...f, redeemed: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl bg-background border border-border text-sm" />
                <p className="text-[10px] text-muted-foreground mt-1">حالياً: {cfg?.pointsPerUsdRedeemed} نقطة = $1 رصيد</p>
              </div>
            </div>
            <button onClick={() => cfgMut.mutate()} disabled={cfgMut.isPending}
              className="mt-4 px-5 py-2 rounded-xl bg-emerald-500 text-white font-semibold text-sm hover:bg-emerald-600 disabled:opacity-50">
              {cfgMut.isPending ? <Loader2 size={14} className="inline ml-1 animate-spin" /> : null} حفظ الإعدادات
            </button>
          </div>
        </div>
      )}

      {/* ────── MODALS ────── */}
      <AnimatePresence>
        {adjustOpen && (
          <Modal onClose={() => setAdjustOpen(false)} title="تعديل نقاط مستخدم" icon={<Pencil size={18} />}>
            <div className="space-y-3">
              <Field label="معرّف المستخدم (User ID)">
                <input value={adjustForm.userId} onChange={e => setAdjustForm(f => ({ ...f, userId: e.target.value }))} placeholder="123" className="input-base" />
              </Field>
              <Field label="عدد النقاط (سالب للخصم)">
                <input type="number" value={adjustForm.delta} onChange={e => setAdjustForm(f => ({ ...f, delta: e.target.value }))} placeholder="مثلاً 500 أو -100" className="input-base" />
              </Field>
              <Field label="السبب (سيظهر للعميل)">
                <input value={adjustForm.reason} onChange={e => setAdjustForm(f => ({ ...f, reason: e.target.value }))} placeholder="منحة ترحيب / تعويض" className="input-base" />
              </Field>
              <button disabled={!adjustForm.userId || !adjustForm.delta || adjustMut.isPending}
                onClick={() => adjustMut.mutate()}
                className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold disabled:opacity-50">
                {adjustMut.isPending ? <Loader2 size={14} className="inline animate-spin" /> : 'تنفيذ التعديل'}
              </button>
            </div>
          </Modal>
        )}

        {bulkOpen && (
          <Modal onClose={() => setBulkOpen(false)} title="منحة نقاط جماعية" icon={<Sparkles size={18} />}>
            <div className="space-y-3">
              <Field label="عدد النقاط لكل مستخدم">
                <input type="number" value={bulkForm.points} onChange={e => setBulkForm(f => ({ ...f, points: e.target.value }))} placeholder="100" className="input-base" />
              </Field>
              <Field label="الفئة المستهدفة">
                <select value={bulkForm.vipLevel} onChange={e => setBulkForm(f => ({ ...f, vipLevel: e.target.value }))} className="input-base">
                  <option value="all">جميع المستخدمين</option>
                  <option value="0">عاديون فقط (VIP 0)</option>
                  <option value="1">VIP 1</option>
                  <option value="2">VIP 2</option>
                  <option value="3">VIP 3</option>
                  <option value="4">VIP 4</option>
                </select>
              </Field>
              <Field label="السبب (سيظهر بإشعار العميل)">
                <input value={bulkForm.reason} onChange={e => setBulkForm(f => ({ ...f, reason: e.target.value }))} placeholder="هدية رمضان / احتفال" className="input-base" />
              </Field>
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3 text-xs text-yellow-200">
                ⚠️ تنبيه: هذا الإجراء سيمنح النقاط فوراً لجميع المستخدمين المطابقين ويرسل إشعار لكل واحد منهم.
              </div>
              <button disabled={!bulkForm.points || bulkMut.isPending}
                onClick={() => bulkMut.mutate()}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold disabled:opacity-50">
                {bulkMut.isPending ? <Loader2 size={14} className="inline animate-spin" /> : '🎁 تأكيد المنحة'}
              </button>
            </div>
          </Modal>
        )}

        {rewardOpen && (
          <Modal onClose={() => {
            setRewardOpen(false);
            setRewardImageFile(null);
            setRewardImagePreview(null);
          }} title={editingReward ? 'تعديل مكافأة' : 'مكافأة جديدة'} icon={<Gift size={18} />} wide>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Field label="اسم المكافأة بالعربي *">
                <input value={rewardForm.nameAr} onChange={e => setRewardForm(f => ({ ...f, nameAr: e.target.value }))} className="input-base" placeholder="مثلاً: $5 رصيد محفظة" />
              </Field>
              <Field label="نوع المكافأة *">
                <select value={rewardForm.type} onChange={e => setRewardForm(f => ({ ...f, type: e.target.value }))} className="input-base">
                  {REWARD_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </Field>
              <Field label="تكلفة بالنقاط *">
                <input type="number" value={rewardForm.pointsCost} onChange={e => setRewardForm(f => ({ ...f, pointsCost: e.target.value }))} className="input-base" placeholder="500" />
              </Field>
              <Field label={rewardForm.type === 'balance' ? 'قيمة الرصيد بالدولار *' : 'القيمة (اختياري)'}>
                <input type="number" step="0.01" value={rewardForm.value} onChange={e => setRewardForm(f => ({ ...f, value: e.target.value }))} className="input-base" placeholder="5.00" />
              </Field>
              <Field label="الإيموجي">
                <input value={rewardForm.emoji} onChange={e => setRewardForm(f => ({ ...f, emoji: e.target.value }))} className="input-base text-2xl" />
              </Field>
              <div className="md:col-span-2">
                <Field label="صورة المكافأة">
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border bg-background cursor-pointer hover:border-primary/50 text-sm">
                      <ImagePlus size={15} />
                      {rewardImageUploading ? 'جاري الحفظ والرفع...' : rewardForm.imageUrl || rewardImageFile ? 'تغيير الصورة' : 'اختيار صورة'}
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp,image/gif"
                        className="hidden"
                        disabled={rewardImageUploading}
                        onChange={(event) => {
                          const file = event.target.files?.[0];
                          if (file) {
                            setRewardImageFile(file);
                            setRewardImagePreview(URL.createObjectURL(file));
                          }
                          event.currentTarget.value = '';
                        }}
                      />
                    </label>
                    {(rewardImagePreview || rewardForm.imageUrl) && (
                      <div className="relative w-14 h-14">
                        <img src={rewardImagePreview ?? rewardForm.imageUrl} alt="معاينة المكافأة" className="w-14 h-14 rounded-xl object-cover border border-border" />
                        <button type="button" onClick={() => {
                          setRewardImageFile(null);
                          setRewardImagePreview(null);
                          setRewardForm(f => ({ ...f, imageUrl: '' }));
                        }} className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-destructive text-white flex items-center justify-center">
                          <X size={11} />
                        </button>
                      </div>
                    )}
                  </div>
                </Field>
              </div>
              <Field label="لون التمييز">
                <input type="color" value={rewardForm.accentColor} onChange={e => setRewardForm(f => ({ ...f, accentColor: e.target.value }))} className="input-base h-10" />
              </Field>
              <Field label="الكمية المتاحة (فارغ = غير محدود)">
                <input type="number" value={rewardForm.stock} onChange={e => setRewardForm(f => ({ ...f, stock: e.target.value }))} className="input-base" placeholder="∞" />
              </Field>
              <Field label="ترتيب العرض">
                <input type="number" value={rewardForm.sortOrder} onChange={e => setRewardForm(f => ({ ...f, sortOrder: e.target.value }))} className="input-base" />
              </Field>
              <div className="md:col-span-2">
                <Field label="الوصف">
                  <textarea value={rewardForm.description} onChange={e => setRewardForm(f => ({ ...f, description: e.target.value }))} rows={2} className="input-base resize-none" />
                </Field>
              </div>
              <label className="md:col-span-2 flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={rewardForm.isActive} onChange={e => setRewardForm(f => ({ ...f, isActive: e.target.checked }))} className="w-4 h-4" />
                <span>المكافأة مفعّلة وتظهر للعملاء</span>
              </label>
            </div>
            <button disabled={!rewardForm.nameAr || !rewardForm.pointsCost || saveRewardMut.isPending}
              onClick={() => saveRewardMut.mutate()}
              className="w-full mt-4 py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold disabled:opacity-50">
              {saveRewardMut.isPending ? <Loader2 size={14} className="inline animate-spin" /> : (editingReward ? '💾 حفظ التعديلات' : '✨ إنشاء المكافأة')}
            </button>
          </Modal>
        )}
      </AnimatePresence>

      <style>{`.input-base { width: 100%; padding: 0.5rem 0.75rem; border-radius: 0.75rem; background: hsl(var(--background)); border: 1px solid hsl(var(--border)); font-size: 0.875rem; }`}</style>
    </div>
  );
}

function StatCard({ icon, label, value, sub, color }: any) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-2xl p-4 relative overflow-hidden">
      <div className={`absolute -top-6 -left-6 w-20 h-20 rounded-full bg-gradient-to-br ${color} opacity-20 blur-xl`} />
      <div className={`relative w-10 h-10 rounded-xl bg-gradient-to-br ${color} text-white flex items-center justify-center mb-3`}>{icon}</div>
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className="font-black text-2xl mt-1 leading-tight">{value}</p>
      {sub && <p className="text-[10px] text-muted-foreground mt-1">{sub}</p>}
    </motion.div>
  );
}

function Field({ label, children }: any) {
  return (
    <div>
      <label className="block text-xs text-muted-foreground mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function Modal({ onClose, title, icon, wide, children }: any) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        onClick={e => e.stopPropagation()}
        className={`bg-card border border-border rounded-2xl w-full ${wide ? 'max-w-2xl' : 'max-w-md'} max-h-[90vh] overflow-y-auto`}>
        <div className="flex items-center justify-between p-4 border-b border-border sticky top-0 bg-card">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-primary/15 text-primary flex items-center justify-center">{icon}</div>
            <h3 className="font-heading font-bold">{title}</h3>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-background"><X size={16} /></button>
        </div>
        <div className="p-4">{children}</div>
      </motion.div>
    </motion.div>
  );
}

export default function AdminLoyalty() {
  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <AdminLoyaltyContent />
      </DashboardLayout>
    </ProtectedRoute>
  );
}
