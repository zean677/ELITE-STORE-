import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { bumpImageVersion } from '@/lib/image-utils';
import { useGetProducts, useSyncProducts, useCreateProduct, useUpdateProduct, useDeleteProduct } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import { Layers, Search, ShoppingBag, RefreshCw, Loader2, Plus, Pencil, Trash2, X, Check, Image as ImageIcon, ArrowUp, ArrowDown, Filter, ListPlus, Copy, Zap, Tag, Percent, History, Download, Upload } from 'lucide-react';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';

const CATEGORIES = [
  { value: 'mobile_games', label: 'ألعاب موبايل' },
  { value: 'pc_games', label: 'ألعاب كمبيوتر' },
  { value: 'gift_cards', label: 'بطاقات هدية' },
  { value: 'services', label: 'خدمات' },
  { value: 'general', label: 'عام' },
];

const emptyForm = {
  name: '',
  nameAr: '',
  description: '',
  image: '',
  imageOverride: '',
  priceUsd: '',
  category: 'mobile_games',
  status: 'active' as 'active' | 'inactive',
  profitMargin: '10',
  sortOrder: '0',
  requiredFields: 'playerId',
  subGroup: '',
};

const emptyEditForm = {
  name: '',
  nameAr: '',
  description: '',
  imageOverride: '',
  priceUsd: '',
  profitMargin: '',
  category: 'mobile_games',
  status: 'active',
  sortOrder: '0',
  subGroup: '',
  autoApprove: false,
};

const DEFAULT_SUB_GROUPS = ['شدات', 'عضويات', 'بطاقات', 'كنوز', 'هدايا', 'يدوي', 'روبوت', 'عالمي'];

type CustomField = {
  key: string;
  type: 'text' | 'number' | 'email' | 'phone' | 'notes' | 'dropdown';
  labelAr: string;
  labelEn?: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
};

const FIELD_TYPE_LABELS: Record<CustomField['type'], string> = {
  text: 'نص',
  number: 'رقم',
  email: 'بريد',
  phone: 'هاتف',
  notes: 'ملاحظات',
  dropdown: 'قائمة منسدلة',
};

const FIELD_PRESETS: Array<{ name: string; field: CustomField }> = [
  { name: 'Player ID', field: { key: 'playerId', type: 'text', labelAr: 'معرّف اللاعب', labelEn: 'Player ID', placeholder: 'أدخل معرّف اللاعب', required: true } },
  { name: 'بريد الحساب', field: { key: 'email', type: 'email', labelAr: 'بريد الحساب', labelEn: 'Account Email', placeholder: 'example@mail.com', required: true } },
  { name: 'رقم واتساب', field: { key: 'whatsapp', type: 'phone', labelAr: 'رقم واتساب', labelEn: 'WhatsApp', placeholder: '+963...', required: true } },
  { name: 'Zone ID', field: { key: 'zoneId', type: 'text', labelAr: 'Zone ID', labelEn: 'Zone ID', placeholder: 'مثال: 1234', required: true } },
  { name: 'ملاحظات', field: { key: 'notes', type: 'notes', labelAr: 'ملاحظات إضافية', labelEn: 'Notes', placeholder: 'أي تفاصيل إضافية', required: false } },
];

function CustomFieldsEditor({ value, onChange }: { value: CustomField[]; onChange: (v: CustomField[]) => void }) {
  const fields = value || [];
  const update = (i: number, patch: Partial<CustomField>) => {
    onChange(fields.map((f, idx) => idx === i ? { ...f, ...patch } : f));
  };
  const remove = (i: number) => onChange(fields.filter((_, idx) => idx !== i));
  const add = (preset?: CustomField) => {
    onChange([...fields, preset ?? { key: `field_${fields.length + 1}`, type: 'text', labelAr: '', labelEn: '', placeholder: '', required: true }]);
  };
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= fields.length) return;
    const next = [...fields];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs text-muted-foreground flex items-center gap-1.5"><ListPlus size={12} /> الحقول الديناميكية للعميل</label>
        <span className="text-[10px] text-muted-foreground">{fields.length} حقل</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {FIELD_PRESETS.map(p => (
          <button key={p.name} type="button" onClick={() => add({ ...p.field })} className="px-2 py-1 rounded-lg text-[11px] border border-primary/30 text-primary bg-primary/5 hover:bg-primary/15 transition-colors">
            + {p.name}
          </button>
        ))}
        <button type="button" onClick={() => add()} className="px-2 py-1 rounded-lg text-[11px] border border-border bg-background hover:bg-muted">
          + حقل مخصص
        </button>
      </div>
      {fields.length === 0 && (
        <p className="text-[11px] text-muted-foreground text-center py-2 border border-dashed border-border rounded-lg">لا توجد حقول. النموذج الافتراضي سيُستخدم.</p>
      )}
      {fields.map((f, i) => (
        <div key={i} className="border border-border rounded-xl p-2.5 bg-background/50 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground w-6 text-center">#{i + 1}</span>
            <input
              value={f.labelAr}
              onChange={e => update(i, { labelAr: e.target.value })}
              placeholder="التسمية بالعربية"
              dir="rtl"
              className="flex-1 px-2 py-1.5 bg-card border border-border rounded-lg text-xs focus:outline-none focus:border-primary/50"
            />
            <select
              value={f.type}
              onChange={e => update(i, { type: e.target.value as CustomField['type'] })}
              className="px-2 py-1.5 bg-card border border-border rounded-lg text-xs focus:outline-none focus:border-primary/50"
            >
              {Object.entries(FIELD_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button type="button" onClick={() => move(i, -1)} disabled={i === 0} className="p-1 rounded hover:bg-muted disabled:opacity-30"><ArrowUp size={12} /></button>
            <button type="button" onClick={() => move(i, +1)} disabled={i === fields.length - 1} className="p-1 rounded hover:bg-muted disabled:opacity-30"><ArrowDown size={12} /></button>
            <button type="button" onClick={() => remove(i)} className="p-1 rounded hover:bg-destructive/15 text-destructive"><Trash2 size={12} /></button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input
              value={f.key}
              onChange={e => update(i, { key: e.target.value.replace(/\s+/g, '_') })}
              placeholder="key (مثل: player_id)"
              className="px-2 py-1.5 bg-card border border-border rounded-lg text-[11px] font-mono focus:outline-none focus:border-primary/50"
            />
            <input
              value={f.placeholder ?? ''}
              onChange={e => update(i, { placeholder: e.target.value })}
              placeholder="نص توضيحي داخل الحقل"
              dir="rtl"
              className="px-2 py-1.5 bg-card border border-border rounded-lg text-[11px] focus:outline-none focus:border-primary/50"
            />
          </div>
          {f.type === 'dropdown' && (
            <input
              value={(f.options ?? []).join(', ')}
              onChange={e => update(i, { options: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
              placeholder="الخيارات مفصولة بفاصلة (مثال: PC, Mobile, Console)"
              dir="rtl"
              className="w-full px-2 py-1.5 bg-card border border-border rounded-lg text-[11px] focus:outline-none focus:border-primary/50"
            />
          )}
          <label className="flex items-center gap-2 text-[11px] text-muted-foreground cursor-pointer">
            <input type="checkbox" checked={f.required} onChange={e => update(i, { required: e.target.checked })} className="accent-primary" />
            مطلوب
          </label>
        </div>
      ))}
    </div>
  );
}

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

export default function AdminProducts() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [categoryFilter, setCategoryFilter] = useState('');
  const { toast } = useToast();
  const token = localStorage.getItem('elite_token');

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<null | { id: string; name: string }>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<null | { id: string; name: string }>(null);
  const [form, setForm] = useState(emptyForm);
  const [editForm, setEditForm] = useState(emptyEditForm);
  const [formCustomFields, setFormCustomFields] = useState<CustomField[]>([]);
  const [editCustomFields, setEditCustomFields] = useState<CustomField[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkForm, setBulkForm] = useState<{ field: 'priceUsd' | 'profitMargin'; mode: 'set' | 'increase_pct' | 'decrease_pct'; value: string }>({ field: 'profitMargin', mode: 'increase_pct', value: '10' });
  const [bulkScope, setBulkScope] = useState<'price' | 'subgroup'>('price');
  const [bulkSubmitting, setBulkSubmitting] = useState(false);
  const [flashSaleProduct, setFlashSaleProduct] = useState<null | { id: string; name: string; priceUsd: number; salePriceUsd?: number | null; saleEndsAt?: string | null }>(null);
  const [flashForm, setFlashForm] = useState<{ discountPct: string; durationHours: string }>({ discountPct: '15', durationHours: '24' });
  const [flashSubmitting, setFlashSubmitting] = useState(false);
  const [bulkAutoBusy, setBulkAutoBusy] = useState(false);
  const [clearAllConfirmText, setClearAllConfirmText] = useState('');
  const [clearAllRunning, setClearAllRunning] = useState(false);
  const [showClearAllModal, setShowClearAllModal] = useState(false);
  const [bulkDeleteRunning, setBulkDeleteRunning] = useState(false);

  const handleClearAllProducts = async () => {
    if (clearAllConfirmText !== 'احذف الكل') {
      toast({ title: 'النص غير مطابق', description: 'اكتب "احذف الكل" للتأكيد', variant: 'destructive' });
      return;
    }
    setClearAllRunning(true);
    try {
      const res = await adminFetch(`/api/admin/products/clear-all?confirm=DELETE_ALL_PRODUCTS`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error(await res.text());
      const { deletedCount } = await res.json();
      toast({ title: `🗑️ تم حذف ${deletedCount} منتج`, description: 'قاعدة البيانات فارغة الآن. يمكنك مزامنة المنتجات من جديد.' });
      setShowClearAllModal(false);
      setClearAllConfirmText('');
      refetch();
    } catch (e: any) {
      toast({ title: 'فشل الحذف', description: e?.message, variant: 'destructive' });
    } finally {
      setClearAllRunning(false);
    }
  };

  const handleBulkAutoApprove = async (enable: boolean) => {
    if (selectedIds.size === 0) return;
    const label = enable ? 'تفعيل التنفيذ التلقائي' : 'إيقاف التنفيذ التلقائي';
    if (!confirm(`${label} على ${selectedIds.size} منتج؟\n\n${enable ? '⚠️ الطلبات على هاي المنتجات رح تنفذ تلقائياً بدون موافقتك. تأكد إنها منتجات API موثوقة.' : 'الطلبات رح ترجع تستنى موافقتك يدوياً.'}`)) return;
    setBulkAutoBusy(true);
    try {
      const res = await adminFetch('/api/admin/products/bulk-update', {
        method: 'POST',
        body: JSON.stringify({ productIds: Array.from(selectedIds), field: 'autoApprove', valueBool: enable }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      toast({ title: enable ? '⚡ تم تفعيل التنفيذ التلقائي' : '🛡️ يحتاج موافقة الآن', description: `تم تحديث ${data.updated} منتج` });
      clearSelection();
      refetch();
    } catch {
      toast({ title: 'فشل التحديث', variant: 'destructive' });
    } finally {
      setBulkAutoBusy(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;
    if (!confirm(`حذف ${selectedIds.size} منتجاً نهائياً؟\n\nلا يمكن التراجع عن هذا الإجراء.`)) return;
    setBulkDeleteRunning(true);
    const ids = Array.from(selectedIds);
    let processed = 0;
    let deletedCount = 0;
    let missingCount = 0;
    try {
      for (let offset = 0; offset < ids.length; offset += 100) {
        const productIds = ids.slice(offset, offset + 100);
        const res = await adminFetch('/api/admin/products/bulk-delete', {
          method: 'DELETE',
          body: JSON.stringify({ productIds }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || 'فشل الحذف');
        deletedCount += Number(data.deletedCount) || 0;
        missingCount += Number(data.missingCount) || 0;
        processed += productIds.length;
      }
      toast({
        title: `تم حذف ${deletedCount} منتج`,
        description: missingCount ? `تعذر العثور على ${missingCount} منتج` : undefined,
      });
      clearSelection();
      refetch();
    } catch (error: any) {
      setSelectedIds(new Set(ids.slice(processed)));
      toast({
        title: 'تعذر إكمال الحذف الجماعي',
        description: `${error?.message || 'حدث خطأ غير معروف'}${processed ? ` — تم حذف ${deletedCount} منتج قبل التوقف` : ''}`,
        variant: 'destructive',
      });
      if (processed) refetch();
    } finally {
      setBulkDeleteRunning(false);
    }
  };

  const adminFetch = async (url: string, init: RequestInit = {}) => {
    const token = localStorage.getItem('elite_token');
    return fetch(url, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init.headers || {}),
      },
    });
  };

  const handleBulkUpdate = async () => {
    const num = parseFloat(bulkForm.value);
    if (!Number.isFinite(num) || num < 0) {
      toast({ title: 'قيمة غير صالحة', variant: 'destructive' });
      return;
    }
    setBulkSubmitting(true);
    try {
      const res = await adminFetch('/api/admin/products/bulk-update', {
        method: 'POST',
        body: JSON.stringify({ productIds: Array.from(selectedIds), field: bulkForm.field, mode: bulkForm.mode, value: num }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      toast({ title: '✅ تم التحديث', description: `تم تعديل ${data.updated} منتج` });
      setShowBulkModal(false);
      clearSelection();
      refetch();
    } catch {
      toast({ title: 'فشل التحديث', variant: 'destructive' });
    } finally {
      setBulkSubmitting(false);
    }
  };

  const handleSetFlashSale = async () => {
    if (!flashSaleProduct) return;
    const pct = parseFloat(flashForm.discountPct);
    const hrs = parseFloat(flashForm.durationHours);
    if (!(pct > 0 && pct < 100)) {
      toast({ title: 'نسبة خصم غير صالحة (1-99)', variant: 'destructive' });
      return;
    }
    if (!(hrs > 0)) {
      toast({ title: 'مدة غير صالحة', variant: 'destructive' });
      return;
    }
    setFlashSubmitting(true);
    try {
      const res = await adminFetch(`/api/admin/products/${flashSaleProduct.id}/sale`, {
        method: 'POST',
        body: JSON.stringify({ discountPct: pct, durationHours: hrs }),
      });
      if (!res.ok) throw new Error(await res.text());
      toast({ title: '⚡ تم تفعيل التخفيض', description: `${pct}% لمدة ${hrs} ساعة` });
      setFlashSaleProduct(null);
      refetch();
    } catch {
      toast({ title: 'فشل تفعيل التخفيض', variant: 'destructive' });
    } finally {
      setFlashSubmitting(false);
    }
  };

  const handleClearFlashSale = async () => {
    if (!flashSaleProduct) return;
    setFlashSubmitting(true);
    try {
      const res = await adminFetch(`/api/admin/products/${flashSaleProduct.id}/sale`, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      toast({ title: 'تم إلغاء التخفيض' });
      setFlashSaleProduct(null);
      refetch();
    } catch {
      toast({ title: 'فشل إلغاء التخفيض', variant: 'destructive' });
    } finally {
      setFlashSubmitting(false);
    }
  };

  const { data, isLoading, refetch } = useGetProducts({ page, limit: 25, search: search || undefined, category: categoryFilter || undefined });
  const syncProducts = useSyncProducts();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();

  const products = data?.products ?? [];
  const total = data?.total ?? 0;

  const handleSync = async () => {
    try {
      await syncProducts.mutateAsync();
      toast({ title: 'تمت المزامنة', description: 'تم جلب المنتجات بنجاح وتصفية منتجات الروبوت' });
      refetch();
      loadSyncStatus();
    } catch {
      toast({ title: 'فشلت المزامنة', description: 'تعذر جلب المنتجات', variant: 'destructive' });
    }
  };

  // ── Sub-groups (settings-backed, managed in this page) ─────────────────────
  const [subGroupOptions, setSubGroupOptions] = useState<string[]>(DEFAULT_SUB_GROUPS);
  const [showSubGroupManager, setShowSubGroupManager] = useState(false);
  const [newSubGroup, setNewSubGroup] = useState('');
  const [renamingSubGroup, setRenamingSubGroup] = useState<{ from: string; to: string } | null>(null);
  const loadSubGroups = async () => {
    try {
      const r = await fetch(`${BASE}/api/sub-groups`);
      if (!r.ok) return;
      const j = await r.json();
      if (Array.isArray(j.items) && j.items.length) setSubGroupOptions(j.items);
    } catch { /* ignore */ }
  };
  useEffect(() => { loadSubGroups(); }, []);
  const saveSubGroups = async (next: string[]) => {
    setSubGroupOptions(next);
    try {
      await adminFetch(`${BASE}/api/admin/sub-groups`, { method: 'PUT', body: JSON.stringify({ items: next }) });
    } catch { /* ignore */ }
  };
  const addSubGroup = async () => {
    const v = newSubGroup.trim();
    if (!v || subGroupOptions.includes(v)) { setNewSubGroup(''); return; }
    await saveSubGroups([...subGroupOptions, v]);
    setNewSubGroup('');
    toast({ title: '✅ تمت الإضافة', description: v });
  };
  const removeSubGroup = async (s: string) => {
    if (!confirm(`حذف المجموعة "${s}" من القائمة؟ (المنتجات لن تتأثر)`)) return;
    await saveSubGroups(subGroupOptions.filter(x => x !== s));
  };
  const renameSubGroup = async () => {
    if (!renamingSubGroup) return;
    const { from, to } = renamingSubGroup;
    const t = to.trim();
    if (!t || t === from) { setRenamingSubGroup(null); return; }
    try {
      const r = await adminFetch(`${BASE}/api/admin/sub-groups/rename`, { method: 'POST', body: JSON.stringify({ from, to: t }) });
      const j = await r.json();
      if (Array.isArray(j.items)) setSubGroupOptions(j.items);
      toast({ title: '✅ تم التعديل', description: `تم تحديث ${j.updated ?? 0} منتج` });
      setRenamingSubGroup(null);
      refetch();
    } catch {
      toast({ title: 'تعذر التعديل', variant: 'destructive' });
    }
  };

  // Bulk move to sub-group
  const [bulkSubGroupValue, setBulkSubGroupValue] = useState('');
  const handleBulkSubGroup = async () => {
    setBulkSubmitting(true);
    try {
      const r = await adminFetch('/api/admin/products/bulk-update', {
        method: 'POST',
        body: JSON.stringify({ productIds: Array.from(selectedIds), field: 'subGroup', mode: 'set', valueText: bulkSubGroupValue }),
      });
      if (!r.ok) throw new Error();
      const j = await r.json();
      toast({ title: '✅ تم النقل', description: `${j.updated} منتج → ${bulkSubGroupValue || '— (بدون مجموعة)'}` });
      setShowBulkModal(false);
      clearSelection();
      refetch();
    } catch {
      toast({ title: 'فشل النقل', variant: 'destructive' });
    } finally {
      setBulkSubmitting(false);
    }
  };

  type ProvSync = { at: string; durationMs: number; fetched: number; created: number; updated: number; skipped: number; priceChanges: number; errors: string[] } | null;
  const [syncInfo, setSyncInfo] = useState<Array<{ key: string; label: string; status: ProvSync }>>([]);
  const loadSyncStatus = async () => {
    try {
      const r = await adminFetch(`${BASE}/api/admin/products/sync/status`);
      if (!r.ok) return;
      const j = await r.json();
      const provs = j.providers ?? {};
      setSyncInfo(Object.keys(provs).map(k => ({
        key: k,
        label: provs[k]?.displayName ?? k,
        status: provs[k]?.lastSync ?? provs[k] ?? null,
      })));
    } catch { /* ignore */ }
  };
  useEffect(() => {
    loadSyncStatus();
    const t = setInterval(loadSyncStatus, 30000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const formatAgo = (iso: string) => {
    const sec = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
    if (sec < 60) return `منذ ${sec} ث`;
    const min = Math.floor(sec / 60);
    if (min < 60) return `منذ ${min} د`;
    const hr = Math.floor(min / 60);
    if (hr < 24) return `منذ ${hr} س`;
    return `منذ ${Math.floor(hr / 24)} يوم`;
  };

  const handleCreate = async () => {
    if (!form.name || !form.priceUsd) {
      toast({ title: 'حقول مطلوبة', description: 'الاسم والسعر مطلوبان', variant: 'destructive' });
      return;
    }
    try {
      await createProduct.mutateAsync({
        name: form.name,
        nameAr: form.nameAr || undefined,
        description: form.description || undefined,
        image: form.image || undefined,
        imageOverride: form.imageOverride || undefined,
        priceUsd: parseFloat(form.priceUsd),
        category: form.category,
        provider: 'manual',
        status: form.status,
        profitMargin: parseFloat(form.profitMargin) || 10,
        sortOrder: parseInt(form.sortOrder) || 0,
        requiredFields: form.requiredFields ? form.requiredFields.split(',').map(s => s.trim()) : [],
        customFields: formCustomFields,
        subGroup: form.subGroup || undefined,
      } as any);
      toast({ title: 'تمت الإضافة', description: `تم إضافة ${form.name}` });
      setShowAddModal(false);
      setForm(emptyForm);
      setFormCustomFields([]);
      refetch();
    } catch {
      toast({ title: 'خطأ', description: 'تعذر إضافة المنتج', variant: 'destructive' });
    }
  };

  const handleUpdate = async () => {
    if (!editingProduct) return;
    try {
      await updateProduct.mutateAsync({
        id: editingProduct.id,
        data: {
          name: editForm.name || undefined,
          nameAr: editForm.nameAr || undefined,
          description: editForm.description || undefined,
          imageOverride: editForm.imageOverride || undefined,
          priceUsd: editForm.priceUsd ? parseFloat(editForm.priceUsd) : undefined,
          profitMargin: editForm.profitMargin ? parseFloat(editForm.profitMargin) : undefined,
          category: editForm.category || undefined,
          status: editForm.status as 'active' | 'inactive',
          sortOrder: editForm.sortOrder !== '' ? parseInt(editForm.sortOrder) : undefined,
          subGroup: editForm.subGroup || null,
          autoApprove: editForm.autoApprove,
          customFields: editCustomFields,
        } as any,
      });
      toast({ title: 'تم التعديل' });
      setEditingProduct(null);
      refetch();
    } catch {
      toast({ title: 'خطأ', description: 'تعذر تعديل المنتج', variant: 'destructive' });
    }
  };

  const handleDuplicate = async (p: typeof products[0]) => {
    try {
      const cloned = await createProduct.mutateAsync({
        name: `${p.name} (نسخة)`,
        nameAr: (p as any).nameAr ? `${(p as any).nameAr} (نسخة)` : undefined,
        description: (p as any).description ?? undefined,
        image: p.image ?? undefined,
        imageOverride: (p as any).imageOverride ?? undefined,
        priceUsd: parseFloat(p.priceUsd?.toString() ?? '0'),
        category: p.category ?? 'mobile_games',
        provider: 'manual',
        status: 'inactive',
        profitMargin: parseFloat((p as any).profitMargin?.toString() ?? '10'),
        sortOrder: ((p as any).sortOrder ?? 0) + 1,
        requiredFields: Array.isArray((p as any).requiredFields) ? (p as any).requiredFields : [],
        customFields: Array.isArray((p as any).customFields) ? (p as any).customFields : [],
        subGroup: (p as any).subGroup ?? undefined,
      } as any);
      toast({ title: '✅ تم التكرار', description: `تم إنشاء نسخة من "${p.name}" — اضغط تعديل لتغيير السعر/التفاصيل` });
      await refetch();
      // Open the edit modal on the new clone so admin can adjust price/qty
      const newProd = (cloned as any) ?? { ...p, name: `${p.name} (نسخة)` };
      openEdit(newProd);
    } catch (err) {
      toast({ title: 'خطأ', description: 'تعذر تكرار المنتج', variant: 'destructive' });
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirm) return;
    try {
      await deleteProduct.mutateAsync({ id: deleteConfirm.id });
      toast({ title: 'تم الحذف', description: `تم حذف ${deleteConfirm.name}` });
      setDeleteConfirm(null);
      refetch();
    } catch {
      toast({ title: 'خطأ', description: 'تعذر حذف المنتج', variant: 'destructive' });
    }
  };

  const openEdit = (p: typeof products[0]) => {
    setEditingProduct({ id: p.id, name: p.name });
    setEditForm({
      name: p.name,
      nameAr: (p as any).nameAr ?? '',
      description: (p as any).description ?? '',
      imageOverride: (p as any).imageOverride ?? '',
      priceUsd: String(parseFloat(p.priceUsd?.toString() ?? '0')),
      profitMargin: String(parseFloat(p.profitMargin?.toString() ?? '10')),
      category: p.category ?? 'mobile_games',
      status: p.status ?? 'active',
      sortOrder: String((p as any).sortOrder ?? 0),
      subGroup: (p as any).subGroup ?? '',
      autoApprove: !!(p as any).autoApprove,
    });
    setEditCustomFields(Array.isArray((p as any).customFields) ? (p as any).customFields : []);
  };

  const displayImage = (p: typeof products[0]) => (p as any).imageOverride || p.image;

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="font-heading text-2xl font-bold">المنتجات</h1>
              <p className="text-muted-foreground text-sm mt-1">{total} منتج</p>
            </div>
            <div className="flex gap-3 flex-wrap">
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="search"
                  placeholder="بحث عن منتج..."
                  value={search}
                  onChange={e => { setSearch(e.target.value); setPage(1); clearSelection(); }}
                  className="pr-9 pl-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors"
                  dir="rtl"
                />
              </div>
              <select
                value={categoryFilter}
                onChange={e => { setCategoryFilter(e.target.value); setPage(1); clearSelection(); }}
                className="px-3 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
              >
                <option value="">كل الفئات</option>
                {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors"
              >
                <Plus size={14} /> إضافة منتج
              </button>
              <button
                onClick={handleSync}
                disabled={syncProducts.isPending}
                className="flex items-center gap-2 px-4 py-2.5 bg-secondary/15 text-secondary border border-secondary/30 rounded-xl text-sm font-semibold hover:bg-secondary/25 transition-colors"
              >
                {syncProducts.isPending ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
                مزامنة من API
              </button>
              <button
                onClick={() => setShowClearAllModal(true)}
                className="flex items-center gap-2 px-4 py-2.5 bg-red-500/10 text-red-400 border border-red-500/30 rounded-xl text-sm font-semibold hover:bg-red-500/20 transition-colors"
                title="حذف جميع المنتجات"
              >
                <Trash2 size={14} />
                حذف الكل
              </button>
              <a
                href="/api/admin/products/export-csv"
                onClick={(e) => {
                  e.preventDefault();
                  const tk = localStorage.getItem('elite_token');
                  fetch('/api/admin/products/export-csv', { headers: { Authorization: `Bearer ${tk}` } })
                    .then(r => r.blob())
                    .then(blob => {
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `products_${new Date().toISOString().split('T')[0]}.csv`;
                      a.click();
                      URL.revokeObjectURL(url);
                      toast({ title: '✅ تم تصدير المنتجات' });
                    })
                    .catch(() => toast({ title: 'فشل التصدير', variant: 'destructive' }));
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 rounded-xl text-sm font-semibold hover:bg-emerald-500/25 transition-colors cursor-pointer"
              >
                <Download size={14} /> تصدير CSV
              </a>
              <label className="flex items-center gap-2 px-4 py-2.5 bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 rounded-xl text-sm font-semibold hover:bg-cyan-500/25 transition-colors cursor-pointer">
                <Upload size={14} /> استيراد CSV
                <input
                  type="file"
                  accept=".csv,text/csv"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0]; if (!file) return;
                    const text = await file.text();
                    e.target.value = '';
                    try {
                      const res = await adminFetch('/api/admin/products/import-csv', { method: 'POST', body: JSON.stringify({ csv: text }) });
                      const j = await res.json();
                      if (!res.ok) throw new Error(j?.error || 'فشل الاستيراد');
                      toast({ title: '✅ تم الاستيراد', description: `محدّث: ${j.updated} | تخطّي: ${j.skipped}` });
                      if ((j.errors ?? []).length) console.warn('CSV import errors:', j.errors);
                      refetch();
                    } catch (err: any) {
                      toast({ title: 'فشل الاستيراد', description: err?.message, variant: 'destructive' });
                    }
                  }}
                />
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {syncInfo.map(({ key, label, status: s }) => {
              return (
                <div key={key} className="bg-card border border-border rounded-2xl px-4 py-3 flex items-center gap-3">
                  <div className={`w-2.5 h-2.5 rounded-full ${s ? (s.errors.length ? 'bg-amber-500' : 'bg-emerald-500') : 'bg-muted-foreground/40'}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-sm">{label}</span>
                      <span className="text-xs text-muted-foreground">
                        {s ? `${formatAgo(s.at)} • ${(s.durationMs/1000).toFixed(1)}ث` : 'لم تتم مزامنة بعد'}
                      </span>
                    </div>
                    {s && (
                      <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                        <span>📥 جلب: <b className="text-foreground">{s.fetched}</b></span>
                        <span>🆕 جديد: <b className="text-emerald-500">{s.created}</b></span>
                        <span>🔄 محدّث: <b className="text-blue-500">{s.updated}</b></span>
                        {s.skipped > 0 && <span>⏭ متجاهل: <b>{s.skipped}</b></span>}
                        {s.priceChanges > 0 && <span>💲 تغيّر السعر: <b className="text-orange-500">{s.priceChanges}</b></span>}
                        {s.errors.length > 0 && <span className="text-amber-500">⚠ {s.errors.length} خطأ</span>}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Sub-groups manager */}
          <div className="bg-card border border-border rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Tag size={14} className="text-primary" />
                <h3 className="text-sm font-bold">المجموعات الفرعية</h3>
                <span className="text-xs text-muted-foreground">({subGroupOptions.length})</span>
              </div>
              <button onClick={() => setShowSubGroupManager(s => !s)} className="text-xs text-primary hover:underline">
                {showSubGroupManager ? 'إخفاء' : 'إدارة'}
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {subGroupOptions.map(s => (
                <div key={s} className="group flex items-center gap-1 bg-background border border-border rounded-lg px-2 py-1">
                  <span className="text-xs font-medium">{s}</span>
                  {showSubGroupManager && (
                    <>
                      <button onClick={() => setRenamingSubGroup({ from: s, to: s })} className="p-0.5 hover:text-primary transition-colors" title="إعادة تسمية"><Pencil size={10} /></button>
                      <button onClick={() => removeSubGroup(s)} className="p-0.5 hover:text-destructive transition-colors" title="حذف"><X size={10} /></button>
                    </>
                  )}
                </div>
              ))}
            </div>
            {showSubGroupManager && (
              <div className="flex gap-2 mt-3">
                <input
                  value={newSubGroup}
                  onChange={e => setNewSubGroup(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') addSubGroup(); }}
                  placeholder="اسم مجموعة جديدة (مثل: شدات UC)"
                  className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                  dir="rtl"
                />
                <button onClick={addSubGroup} className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-xs font-semibold hover:bg-primary/90 transition-colors flex items-center gap-1">
                  <Plus size={12} /> إضافة
                </button>
              </div>
            )}
          </div>

          {selectedIds.size > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="sticky top-2 z-20 flex flex-wrap items-center gap-3 bg-primary/15 border border-primary/40 rounded-2xl px-4 py-3 backdrop-blur"
            >
              <span className="text-sm font-bold text-primary">{selectedIds.size} منتج محدد</span>
              <div className="flex gap-2 mr-auto flex-wrap">
                <button onClick={() => setShowBulkModal(true)} className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90">
                  <Percent size={12} /> تحديث السعر/الربح بالجملة
                </button>
                <button onClick={() => handleBulkAutoApprove(true)} disabled={bulkAutoBusy}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 font-semibold disabled:opacity-50">
                  ⚡ تفعيل التنفيذ التلقائي
                </button>
                <button onClick={() => handleBulkAutoApprove(false)} disabled={bulkAutoBusy}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl bg-muted text-foreground hover:bg-muted/70 font-semibold disabled:opacity-50">
                  🛡️ يحتاج موافقة
                </button>
                <button onClick={handleBulkDelete} disabled={bulkDeleteRunning}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl bg-destructive/15 text-destructive border border-destructive/30 hover:bg-destructive/25 font-semibold disabled:opacity-50">
                  {bulkDeleteRunning ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
                  حذف المحدد
                </button>
                <button onClick={clearSelection} className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl bg-muted text-foreground hover:bg-muted/70">
                  <X size={12} /> إلغاء التحديد
                </button>
              </div>
            </motion.div>
          )}

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {isLoading ? (
              <div className="py-12 text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : products.length === 0 ? (
              <div className="py-16 text-center">
                <Layers size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">لا توجد منتجات</p>
                <div className="flex gap-3 justify-center mt-4">
                  <button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors">
                    <Plus size={14} /> إضافة يدوي
                  </button>
                  <button onClick={handleSync} disabled={syncProducts.isPending} className="flex items-center gap-2 px-4 py-2 bg-secondary/15 text-secondary border border-secondary/30 rounded-xl text-sm font-semibold hover:bg-secondary/25 transition-colors">
                    {syncProducts.isPending ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
                    مزامنة API
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Desktop Table */}
                <div className="hidden lg:block overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-background/50">
                        <th className="text-right text-xs text-muted-foreground font-medium px-3 py-3 w-10">
                          <input
                            type="checkbox"
                            className="accent-primary cursor-pointer"
                            checked={products.length > 0 && products.every(p => selectedIds.has(p.id))}
                            onChange={e => {
                              setSelectedIds(prev => {
                                const next = new Set(prev);
                                if (e.target.checked) products.forEach(p => next.add(p.id));
                                else products.forEach(p => next.delete(p.id));
                                return next;
                              });
                            }}
                            title="تحديد منتجات الصفحة الحالية"
                          />
                        </th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المنتج</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الفئة</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المزوّد</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">السعر $</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الربح %</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الترتيب</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الحالة</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {products.map(product => (
                        <motion.tr key={product.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className={`hover:bg-background transition-colors ${selectedIds.has(product.id) ? 'bg-primary/5' : ''}`}>
                          <td className="px-3 py-3">
                            <input
                              type="checkbox"
                              className="accent-primary cursor-pointer"
                              checked={selectedIds.has(product.id)}
                              onChange={() => toggleSelect(product.id)}
                            />
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              {displayImage(product) ? (
                                <img src={displayImage(product)!} alt="" className="w-9 h-9 rounded-lg object-cover border border-border" />
                              ) : (
                                <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
                                  <ShoppingBag size={13} className="text-primary" />
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="text-sm font-medium truncate max-w-[180px]">{(product as any).nameAr || product.name}</p>
                                <div className="flex items-center gap-1 mt-0.5">
                                  {(product as any).isManual && <span className="text-[10px] bg-primary/10 text-primary px-1.5 rounded">يدوي</span>}
                                  {(product as any).salePriceUsd && (product as any).saleEndsAt && new Date((product as any).saleEndsAt).getTime() > Date.now() && (
                                    <span className="text-[10px] bg-amber-500/15 text-amber-400 px-1.5 rounded flex items-center gap-0.5"><Zap size={9} />تخفيض</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{CATEGORIES.find(c => c.value === product.category)?.label ?? product.category}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground capitalize whitespace-nowrap">{product.provider}</td>
                          <td className="px-4 py-3 text-sm font-bold text-primary whitespace-nowrap">${parseFloat(product.priceUsd?.toString() ?? '0').toFixed(3)}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{parseFloat(product.profitMargin?.toString() ?? '10').toFixed(0)}%</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{(product as any).sortOrder ?? 0}</td>
                          <td className="px-4 py-3"><StatusBadge status={product.status === 'active' ? 'active' : 'inactive'} size="sm" /></td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <button onClick={() => openEdit(product)} className="p-1.5 rounded-lg hover:bg-primary/10 text-primary transition-colors" title="تعديل"><Pencil size={13} /></button>
                              <Link href={`/admin/products/${product.id}/history`} className="p-1.5 rounded-lg hover:bg-cyan-500/10 text-cyan-400 transition-colors" title="سجل التغييرات"><History size={13} /></Link>
                              <button onClick={() => setFlashSaleProduct({ id: product.id, name: (product as any).nameAr || product.name, priceUsd: parseFloat(product.priceUsd?.toString() ?? '0'), salePriceUsd: (product as any).salePriceUsd ? parseFloat((product as any).salePriceUsd.toString()) : null, saleEndsAt: (product as any).saleEndsAt ?? null })} className="p-1.5 rounded-lg hover:bg-amber-500/10 text-amber-400 transition-colors" title="تخفيض سريع"><Zap size={13} /></button>
                              <button onClick={() => handleDuplicate(product)} disabled={createProduct.isPending} className="p-1.5 rounded-lg hover:bg-blue-500/10 text-blue-500 transition-colors disabled:opacity-50" title="تكرار"><Copy size={13} /></button>
                              <button onClick={() => setDeleteConfirm({ id: product.id, name: product.name })} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive transition-colors" title="حذف"><Trash2 size={13} /></button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile/Tablet Cards */}
                <div className="lg:hidden grid grid-cols-1 sm:grid-cols-2 gap-3 p-3" dir="rtl">
                  {products.map(product => (
                    <motion.div key={product.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                      className={`bg-background border rounded-2xl p-3 flex flex-col gap-3 transition-colors ${selectedIds.has(product.id) ? 'border-primary/60 bg-primary/5' : 'border-border hover:border-primary/40'}`}>
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          className="accent-primary cursor-pointer mt-1.5 shrink-0"
                          checked={selectedIds.has(product.id)}
                          onChange={() => toggleSelect(product.id)}
                        />
                        {displayImage(product) ? (
                          <img src={displayImage(product)!} alt="" className="w-14 h-14 rounded-xl object-cover border border-border shrink-0" />
                        ) : (
                          <div className="w-14 h-14 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                            <ShoppingBag size={20} className="text-primary" />
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start gap-2">
                            <p className="text-sm font-bold truncate flex-1">{(product as any).nameAr || product.name}</p>
                            <StatusBadge status={product.status === 'active' ? 'active' : 'inactive'} size="sm" />
                          </div>
                          <p className="text-[11px] text-muted-foreground truncate mt-0.5">{product.name}</p>
                          <div className="flex items-center gap-2 flex-wrap mt-1.5">
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                              {CATEGORIES.find(c => c.value === product.category)?.label ?? product.category}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/15 text-secondary capitalize">{product.provider}</span>
                            {(product as any).isManual && <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded">يدوي</span>}
                            {(product as any).subGroup && <span className="text-[10px] bg-purple-500/15 text-purple-300 px-1.5 py-0.5 rounded">{(product as any).subGroup}</span>}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center text-xs border-t border-border/40 pt-2">
                        <div>
                          <p className="text-[10px] text-muted-foreground">السعر</p>
                          <p className="font-bold text-primary">${parseFloat(product.priceUsd?.toString() ?? '0').toFixed(3)}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground">الربح</p>
                          <p className="font-bold text-emerald-400">{parseFloat(product.profitMargin?.toString() ?? '10').toFixed(0)}%</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground">الترتيب</p>
                          <p className="font-bold text-foreground/80">#{(product as any).sortOrder ?? 0}</p>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button onClick={() => openEdit(product)} className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-xl bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 transition-colors font-semibold">
                          <Pencil size={12} /> تعديل
                        </button>
                        <button onClick={() => setFlashSaleProduct({ id: product.id, name: (product as any).nameAr || product.name, priceUsd: parseFloat(product.priceUsd?.toString() ?? '0'), salePriceUsd: (product as any).salePriceUsd ? parseFloat((product as any).salePriceUsd.toString()) : null, saleEndsAt: (product as any).saleEndsAt ?? null })} className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition-colors" title="تخفيض سريع">
                          <Zap size={12} />
                        </button>
                        <button onClick={() => handleDuplicate(product)} disabled={createProduct.isPending} className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-xl bg-blue-500/10 text-blue-500 border border-blue-500/30 hover:bg-blue-500/20 transition-colors disabled:opacity-50" title="تكرار">
                          <Copy size={12} />
                        </button>
                        <button onClick={() => setDeleteConfirm({ id: product.id, name: product.name })} className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-xl bg-destructive/10 text-destructive border border-destructive/30 hover:bg-destructive/20 transition-colors">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </>
            )}
          </div>

          {total > 25 && (
            <div className="flex justify-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">السابق</button>
              <span className="px-4 py-2 text-sm text-muted-foreground">صفحة {page}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page * 25 >= total} className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">التالي</button>
            </div>
          )}
        </div>

        {/* Add Product Modal */}
        <AnimatePresence>
          {showAddModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setShowAddModal(false)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="font-heading text-lg font-bold">إضافة منتج جديد</h2>
                  <button onClick={() => setShowAddModal(false)} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الاسم بالعربية *</label>
                      <input value={form.nameAr} onChange={e => setForm(f => ({ ...f, nameAr: e.target.value }))} placeholder="شدات ببجي 60" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الاسم بالإنجليزية *</label>
                      <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="PUBG 60 UC" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">الوصف (اسم اللعبة/المجموعة)</label>
                    <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="PUBG Mobile" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">السعر (USD) *</label>
                      <input type="number" step="0.001" value={form.priceUsd} onChange={e => setForm(f => ({ ...f, priceUsd: e.target.value }))} placeholder="0.00" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">نسبة الربح (%)</label>
                      <input type="number" step="1" value={form.profitMargin} onChange={e => setForm(f => ({ ...f, profitMargin: e.target.value }))} placeholder="10" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الفئة</label>
                      <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50">
                        {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الحالة</label>
                      <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as 'active' | 'inactive' }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50">
                        <option value="active">مفعّل</option>
                        <option value="inactive">غير مفعّل</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">ترتيب العرض</label>
                      <input type="number" step="1" value={form.sortOrder} onChange={e => setForm(f => ({ ...f, sortOrder: e.target.value }))} placeholder="0" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الحقول المطلوبة (قديم)</label>
                      <input value={form.requiredFields} onChange={e => setForm(f => ({ ...f, requiredFields: e.target.value }))} placeholder="playerId, serverRegion" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <CustomFieldsEditor value={formCustomFields} onChange={setFormCustomFields} />
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">المجموعة الفرعية (شدات / عضويات / بطاقات...)</label>
                    <input value={form.subGroup} onChange={e => setForm(f => ({ ...f, subGroup: e.target.value }))} list="subgroup-options-add" placeholder="اختياري — مثال: شدات" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                    <datalist id="subgroup-options-add">
                      {subGroupOptions.map(s => <option key={s} value={s} />)}
                    </datalist>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {subGroupOptions.map(s => (
                        <button key={s} type="button" onClick={() => setForm(f => ({ ...f, subGroup: s }))} className={`px-2.5 py-1 rounded-lg text-xs border transition-colors ${form.subGroup === s ? 'bg-primary/20 border-primary/50 text-primary' : 'border-border bg-background hover:bg-muted'}`}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1.5"><ImageIcon size={12} /> صورة المنتج</label>
                    <div className="flex gap-2">
                      <input value={form.imageOverride || form.image} onChange={e => setForm(f => ({ ...f, imageOverride: e.target.value, image: '' }))} placeholder="https://... أو ارفع صورة" className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                      <label className="cursor-pointer px-3 py-2 bg-muted border border-border rounded-xl text-xs text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors flex items-center gap-1 shrink-0">
                        <ImageIcon size={12} /> رفع
                        <input type="file" accept="image/*" className="hidden" onChange={async e => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const fd = new FormData(); fd.append('image', file);
                          const r = await fetch(`${BASE}/api/admin/upload/image`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd });
                          if (r.ok) { const { url } = await r.json(); setForm(f => ({ ...f, imageOverride: url })); bumpImageVersion(); toast({ title: '✅ تم رفع الصورة' }); }
                          else { toast({ title: 'فشل رفع الصورة', variant: 'destructive' }); }
                        }} />
                      </label>
                    </div>
                    {(form.imageOverride || form.image) && (
                      <img src={form.imageOverride || form.image} alt="" className="mt-2 h-16 rounded-lg object-contain border border-border p-1 bg-background" onError={e => (e.currentTarget.style.display = 'none')} />
                    )}
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <button onClick={() => setShowAddModal(false)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={handleCreate} disabled={createProduct.isPending} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                    {createProduct.isPending ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                    إضافة المنتج
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Edit Product Modal */}
        <AnimatePresence>
          {editingProduct && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setEditingProduct(null)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="font-heading text-lg font-bold">تعديل المنتج</h2>
                  <button onClick={() => setEditingProduct(null)} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الاسم بالعربية</label>
                      <input value={editForm.nameAr} onChange={e => setEditForm(f => ({ ...f, nameAr: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الاسم بالإنجليزية</label>
                      <input value={editForm.name} onChange={e => setEditForm(f => ({ ...f, name: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">الوصف</label>
                    <input value={editForm.description} onChange={e => setEditForm(f => ({ ...f, description: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1.5"><ImageIcon size={12} /> صورة المنتج (اختياري — يُستبدل صورة API)</label>
                    <div className="flex gap-2">
                      <input value={editForm.imageOverride} onChange={e => setEditForm(f => ({ ...f, imageOverride: e.target.value }))} placeholder="https://... أو ارفع صورة" className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                      <label className="cursor-pointer px-3 py-2 bg-muted border border-border rounded-xl text-xs text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors flex items-center gap-1 shrink-0">
                        <ImageIcon size={12} /> رفع
                        <input type="file" accept="image/*" className="hidden" onChange={async e => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const fd = new FormData(); fd.append('image', file);
                          const r = await fetch(`${BASE}/api/admin/upload/image`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd });
                          if (r.ok) { const { url } = await r.json(); setEditForm(f => ({ ...f, imageOverride: url })); bumpImageVersion(); }
                        }} />
                      </label>
                    </div>
                    {editForm.imageOverride && (
                      <img src={editForm.imageOverride} alt="" className="mt-2 h-12 rounded-lg object-contain border border-border p-1 bg-background" onError={e => (e.currentTarget.style.display = 'none')} />
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">السعر (USD)</label>
                      <input type="number" step="0.001" value={editForm.priceUsd} onChange={e => setEditForm(f => ({ ...f, priceUsd: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">نسبة الربح (%)</label>
                      <input type="number" step="1" value={editForm.profitMargin} onChange={e => setEditForm(f => ({ ...f, profitMargin: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الفئة</label>
                      <select value={editForm.category} onChange={e => setEditForm(f => ({ ...f, category: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50">
                        {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الحالة</label>
                      <select value={editForm.status} onChange={e => setEditForm(f => ({ ...f, status: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50">
                        <option value="active">مفعّل</option>
                        <option value="inactive">غير مفعّل</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">ترتيب العرض</label>
                      <input type="number" value={editForm.sortOrder} onChange={e => setEditForm(f => ({ ...f, sortOrder: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">المجموعة الفرعية</label>
                    <input value={editForm.subGroup} onChange={e => setEditForm(f => ({ ...f, subGroup: e.target.value }))} list="subgroup-options-edit" placeholder="مثال: شدات / عضويات / بطاقات" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                    <datalist id="subgroup-options-edit">
                      {subGroupOptions.map(s => <option key={s} value={s} />)}
                    </datalist>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {subGroupOptions.map(s => (
                        <button key={s} type="button" onClick={() => setEditForm(f => ({ ...f, subGroup: s }))} className={`px-2.5 py-1 rounded-lg text-xs border transition-colors ${editForm.subGroup === s ? 'bg-primary/20 border-primary/50 text-primary' : 'border-border bg-background hover:bg-muted'}`}>
                          {s}
                        </button>
                      ))}
                      {editForm.subGroup && (
                        <button type="button" onClick={() => setEditForm(f => ({ ...f, subGroup: '' }))} className="px-2.5 py-1 rounded-lg text-xs border border-destructive/40 text-destructive hover:bg-destructive/10">
                          مسح
                        </button>
                      )}
                    </div>
                  </div>
                  <div className={`p-3 rounded-xl border ${editForm.autoApprove ? 'bg-amber-500/10 border-amber-500/40' : 'bg-background border-border'}`}>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editForm.autoApprove}
                        onChange={e => setEditForm(f => ({ ...f, autoApprove: e.target.checked }))}
                        className="w-4 h-4 mt-0.5 accent-amber-500"
                      />
                      <div className="flex-1">
                        <div className="text-sm font-bold flex items-center gap-2">
                          ⚡ التنفيذ التلقائي (بدون موافقة الأدمن)
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
                          {editForm.autoApprove
                            ? '🟡 الطلبات على هذا المنتج رح تنفّذ فوراً عند المزوّد بدون انتظار موافقتك. مناسب للمنتجات الموثوقة (مثل شدات API بسعر ثابت).'
                            : '🟢 الوضع الآمن: الطلبات تستنى موافقتك من صفحة الطلبات قبل ما تتنفذ.'}
                        </p>
                      </div>
                    </label>
                  </div>
                  <CustomFieldsEditor value={editCustomFields} onChange={setEditCustomFields} />
                </div>
                <div className="flex gap-3 mt-6">
                  <button onClick={() => setEditingProduct(null)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={handleUpdate} disabled={updateProduct.isPending} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                    {updateProduct.isPending ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                    حفظ التعديلات
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Delete Confirm Modal */}
        <AnimatePresence>
          {deleteConfirm && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setDeleteConfirm(null)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-sm shadow-2xl text-center">
                <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
                  <Trash2 size={20} className="text-destructive" />
                </div>
                <h2 className="font-heading text-lg font-bold mb-2">حذف المنتج؟</h2>
                <p className="text-muted-foreground text-sm mb-6">هل تريد حذف <strong>{deleteConfirm.name}</strong>؟ لا يمكن التراجع.</p>
                <div className="flex gap-3">
                  <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={handleDelete} disabled={deleteProduct.isPending} className="flex-1 py-2.5 bg-destructive text-destructive-foreground rounded-xl text-sm font-semibold hover:bg-destructive/90 transition-colors flex items-center justify-center gap-2">
                    {deleteProduct.isPending ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    حذف
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Bulk Update Modal */}
        <AnimatePresence>
          {showBulkModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setShowBulkModal(false)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-md shadow-2xl">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center"><Percent size={16} className="text-primary" /></div>
                    <h2 className="font-heading text-lg font-bold">تحديث بالجملة</h2>
                  </div>
                  <button onClick={() => setShowBulkModal(false)} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>
                <p className="text-xs text-muted-foreground mb-4">سيتم تطبيق التعديل على <strong className="text-primary">{selectedIds.size}</strong> منتج محدد.</p>
                <div className="grid grid-cols-2 gap-2 mb-4 p-1 bg-background/60 rounded-xl border border-border/60">
                  <button type="button" onClick={() => setBulkScope('price')} className={`py-2 rounded-lg text-xs font-semibold transition-colors ${bulkScope === 'price' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'}`}>💰 سعر / ربح</button>
                  <button type="button" onClick={() => setBulkScope('subgroup')} className={`py-2 rounded-lg text-xs font-semibold transition-colors ${bulkScope === 'subgroup' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'}`}>📁 نقل لمجموعة</button>
                </div>
                {bulkScope === 'subgroup' ? (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">المجموعة الفرعية الجديدة</label>
                      <input value={bulkSubGroupValue} onChange={e => setBulkSubGroupValue(e.target.value)} list="subgroup-options-bulk" placeholder="اكتب أو اختر — اتركه فارغًا لإزالة المجموعة" className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                      <datalist id="subgroup-options-bulk">
                        {subGroupOptions.map(s => <option key={s} value={s} />)}
                      </datalist>
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {subGroupOptions.map(s => (
                          <button key={s} type="button" onClick={() => setBulkSubGroupValue(s)} className={`px-2.5 py-1 rounded-lg text-xs border transition-colors ${bulkSubGroupValue === s ? 'bg-primary/20 border-primary/50 text-primary' : 'border-border bg-background hover:bg-muted'}`}>{s}</button>
                        ))}
                        <button type="button" onClick={() => setBulkSubGroupValue('')} className={`px-2.5 py-1 rounded-lg text-xs border transition-colors ${bulkSubGroupValue === '' ? 'bg-destructive/20 border-destructive/40 text-destructive' : 'border-border bg-background hover:bg-muted'}`}>— بدون</button>
                      </div>
                    </div>
                    <div className="bg-background/60 border border-border/60 rounded-xl p-3 text-xs text-muted-foreground leading-relaxed">
                      {bulkSubGroupValue ? `سيتم نقل ${selectedIds.size} منتج إلى مجموعة "${bulkSubGroupValue}".` : `سيتم إزالة ${selectedIds.size} منتج من أي مجموعة فرعية.`}
                    </div>
                    <div className="flex gap-3">
                      <button onClick={() => setShowBulkModal(false)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                      <button onClick={handleBulkSubGroup} disabled={bulkSubmitting} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">
                        {bulkSubmitting ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                        نقل
                      </button>
                    </div>
                  </div>
                ) : (
                <>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">الحقل</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button type="button" onClick={() => setBulkForm(f => ({ ...f, field: 'profitMargin' }))} className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${bulkForm.field === 'profitMargin' ? 'bg-primary text-primary-foreground border-primary' : 'bg-background border-border hover:bg-muted'}`}>نسبة الربح %</button>
                      <button type="button" onClick={() => setBulkForm(f => ({ ...f, field: 'priceUsd' }))} className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${bulkForm.field === 'priceUsd' ? 'bg-primary text-primary-foreground border-primary' : 'bg-background border-border hover:bg-muted'}`}>السعر $</button>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">العملية</label>
                    <div className="grid grid-cols-3 gap-2">
                      <button type="button" onClick={() => setBulkForm(f => ({ ...f, mode: 'increase_pct' }))} className={`px-2 py-2 rounded-xl text-xs font-semibold border transition-colors ${bulkForm.mode === 'increase_pct' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' : 'bg-background border-border hover:bg-muted'}`}>زيادة %</button>
                      <button type="button" onClick={() => setBulkForm(f => ({ ...f, mode: 'decrease_pct' }))} className={`px-2 py-2 rounded-xl text-xs font-semibold border transition-colors ${bulkForm.mode === 'decrease_pct' ? 'bg-amber-500/20 text-amber-300 border-amber-500/50' : 'bg-background border-border hover:bg-muted'}`}>خفض %</button>
                      <button type="button" onClick={() => setBulkForm(f => ({ ...f, mode: 'set' }))} className={`px-2 py-2 rounded-xl text-xs font-semibold border transition-colors ${bulkForm.mode === 'set' ? 'bg-blue-500/20 text-blue-300 border-blue-500/50' : 'bg-background border-border hover:bg-muted'}`}>تعيين</button>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">
                      {bulkForm.mode === 'set' ? (bulkForm.field === 'priceUsd' ? 'السعر الجديد ($)' : 'النسبة الجديدة (%)') : `النسبة المئوية (${bulkForm.mode === 'increase_pct' ? '+' : '-'} %)`}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={bulkForm.value}
                      onChange={e => setBulkForm(f => ({ ...f, value: e.target.value }))}
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                      placeholder="10"
                    />
                  </div>
                  <div className="bg-background/60 border border-border/60 rounded-xl p-3 text-xs text-muted-foreground leading-relaxed">
                    {bulkForm.mode === 'increase_pct' && `سيتم زيادة ${bulkForm.field === 'priceUsd' ? 'السعر' : 'نسبة الربح'} بمقدار ${bulkForm.value || 0}% لكل منتج محدد.`}
                    {bulkForm.mode === 'decrease_pct' && `سيتم تخفيض ${bulkForm.field === 'priceUsd' ? 'السعر' : 'نسبة الربح'} بمقدار ${bulkForm.value || 0}% لكل منتج محدد.`}
                    {bulkForm.mode === 'set' && `سيتم تعيين ${bulkForm.field === 'priceUsd' ? 'السعر' : 'نسبة الربح'} إلى ${bulkForm.value || 0}${bulkForm.field === 'priceUsd' ? '$' : '%'} لكل المنتجات المحددة.`}
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <button onClick={() => setShowBulkModal(false)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={handleBulkUpdate} disabled={bulkSubmitting} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">
                    {bulkSubmitting ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                    تطبيق
                  </button>
                </div>
                </>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Flash Sale Modal */}
        <AnimatePresence>
          {flashSaleProduct && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setFlashSaleProduct(null)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-md shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center"><Zap size={16} className="text-amber-400" /></div>
                    <h2 className="font-heading text-lg font-bold">تخفيض سريع</h2>
                  </div>
                  <button onClick={() => setFlashSaleProduct(null)} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>
                <p className="text-sm text-muted-foreground mb-4 truncate">المنتج: <strong className="text-foreground">{flashSaleProduct.name}</strong></p>

                {flashSaleProduct.salePriceUsd && flashSaleProduct.saleEndsAt && new Date(flashSaleProduct.saleEndsAt).getTime() > Date.now() && (
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 mb-4 text-xs text-amber-200">
                    <p className="flex items-center gap-1.5 font-semibold mb-1"><Tag size={12} /> تخفيض نشط حالياً</p>
                    <p>السعر بعد الخصم: <strong>${flashSaleProduct.salePriceUsd.toFixed(3)}</strong> (الأصلي ${flashSaleProduct.priceUsd.toFixed(3)})</p>
                    <p>ينتهي: {new Date(flashSaleProduct.saleEndsAt).toLocaleString('ar-EG')}</p>
                  </div>
                )}

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">نسبة الخصم (%)</label>
                      <input type="number" min="1" max="99" value={flashForm.discountPct} onChange={e => setFlashForm(f => ({ ...f, discountPct: e.target.value }))} className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-amber-500/50" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">المدة (ساعات)</label>
                      <input type="number" min="1" value={flashForm.durationHours} onChange={e => setFlashForm(f => ({ ...f, durationHours: e.target.value }))} className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-amber-500/50" />
                    </div>
                  </div>
                  <div className="bg-background/60 border border-border/60 rounded-xl p-3 text-xs text-muted-foreground">
                    {(() => {
                      const pct = parseFloat(flashForm.discountPct) || 0;
                      const newPrice = flashSaleProduct.priceUsd * (1 - pct / 100);
                      return <>السعر بعد الخصم: <strong className="text-amber-400">${newPrice.toFixed(3)}</strong> (الأصلي ${flashSaleProduct.priceUsd.toFixed(3)})</>;
                    })()}
                  </div>
                </div>

                <div className="flex gap-2 mt-6 flex-wrap">
                  {flashSaleProduct.salePriceUsd && (
                    <button onClick={handleClearFlashSale} disabled={flashSubmitting} className="px-3 py-2.5 border border-destructive/40 text-destructive rounded-xl text-xs font-semibold hover:bg-destructive/10 transition-colors flex items-center gap-1.5 disabled:opacity-50">
                      <X size={12} /> إلغاء التخفيض
                    </button>
                  )}
                  <button onClick={() => setFlashSaleProduct(null)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إغلاق</button>
                  <button onClick={handleSetFlashSale} disabled={flashSubmitting} className="flex-1 py-2.5 bg-amber-500 text-black rounded-xl text-sm font-bold hover:bg-amber-400 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">
                    {flashSubmitting ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
                    تفعيل
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* ── Clear All Products Danger Zone Modal ── */}
        <AnimatePresence>
          {showClearAllModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/70" onClick={() => setShowClearAllModal(false)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}
                className="relative bg-card border-2 border-red-500/40 rounded-2xl p-6 w-full max-w-md shadow-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
                    <Trash2 size={18} className="text-red-400" />
                  </div>
                  <div>
                    <h2 className="font-heading text-lg font-bold text-red-300">⚠️ حذف جميع المنتجات</h2>
                    <p className="text-xs text-white/50">هذا الإجراء لا يمكن التراجع عنه</p>
                  </div>
                  <button onClick={() => setShowClearAllModal(false)} className="mr-auto p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>

                <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-3 mb-4 text-sm text-red-300 space-y-1">
                  <p>• سيتم حذف <strong>جميع المنتجات</strong> من قاعدة البيانات</p>
                  <p>• الطلبات السابقة لن تتأثر</p>
                  <p>• يمكنك إعادة المزامنة بعد الحذف</p>
                </div>

                <div className="mb-4">
                  <label className="text-xs text-white/60 mb-2 block">اكتب <strong className="text-red-300">احذف الكل</strong> للتأكيد:</label>
                  <input
                    value={clearAllConfirmText}
                    onChange={e => setClearAllConfirmText(e.target.value)}
                    placeholder='اكتب "احذف الكل"'
                    className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm text-white focus:outline-none focus:border-red-500/50"
                    dir="rtl"
                  />
                </div>

                <div className="flex gap-3">
                  <button onClick={() => { setShowClearAllModal(false); setClearAllConfirmText(''); }}
                    className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">
                    إلغاء
                  </button>
                  <button
                    onClick={handleClearAllProducts}
                    disabled={clearAllRunning || clearAllConfirmText !== 'احذف الكل'}
                    className="flex-1 py-2.5 bg-red-500 text-white rounded-xl text-sm font-bold hover:bg-red-600 transition-colors disabled:opacity-40 flex items-center justify-center gap-2"
                  >
                    {clearAllRunning ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    حذف الكل نهائياً
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Sub-group Rename Modal */}
        <AnimatePresence>
          {renamingSubGroup && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setRenamingSubGroup(null)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-sm shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-heading text-base font-bold">إعادة تسمية المجموعة</h2>
                  <button onClick={() => setRenamingSubGroup(null)} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>
                <p className="text-xs text-muted-foreground mb-3">سيتم تعديل الاسم في القائمة وكل المنتجات الحالية المرتبطة بـ <strong className="text-foreground">"{renamingSubGroup.from}"</strong>.</p>
                <input
                  value={renamingSubGroup.to}
                  onChange={e => setRenamingSubGroup(r => r ? { ...r, to: e.target.value } : r)}
                  onKeyDown={e => { if (e.key === 'Enter') renameSubGroup(); }}
                  className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
                  dir="rtl"
                  autoFocus
                />
                <div className="flex gap-3 mt-5">
                  <button onClick={() => setRenamingSubGroup(null)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={renameSubGroup} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                    <Check size={14} /> حفظ
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
