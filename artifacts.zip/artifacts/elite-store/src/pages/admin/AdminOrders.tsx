import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useGetAdminOrders, useRetryOrder } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import { Package, RefreshCw, Download, CheckCircle2, XCircle, Send, X, CheckSquare, MessageSquare, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

const STATUS_LABELS: Record<string, string> = {
  '': 'جميع الطلبات',
  pending: 'قيد الانتظار',
  processing: 'جاري التنفيذ',
  completed: 'مكتمل',
  failed: 'فشل',
  refunded: 'مُسترد',
};

export default function AdminOrders() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [exporting, setExporting] = useState(false);
  const [approveModal, setApproveModal] = useState<{ id: string; productName: string } | null>(null);
  const [deliveryMessage, setDeliveryMessage] = useState('');
  const [approving, setApproving] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkRunning, setBulkRunning] = useState(false);
  const [tplModal, setTplModal] = useState<{ order: any } | null>(null);
  const [templates, setTemplates] = useState<Array<{ id: string; title: string; body: string }>>([]);
  const { toast } = useToast();

  const openTemplates = async (order: any) => {
    setTplModal({ order });
    if (templates.length === 0) {
      try {
        const r = await fetch(`${BASE}/api/admin/message-templates`, { headers: authHeaders() });
        const j = await r.json();
        setTemplates(j.templates ?? []);
      } catch { /* ignore */ }
    }
  };

  const renderTemplate = (body: string, order: any): string => {
    const orderNumber = order.orderNumber ? `#ORD-${String(order.orderNumber).padStart(5, '0')}` : order.id.slice(0, 8);
    const name = (order.userEmail || '').split('@')[0] || 'عزيزي';
    return body
      .replace(/\{name\}/g, name)
      .replace(/\{order\}/g, orderNumber)
      .replace(/\{product\}/g, order.productName || '')
      .replace(/\{price\}/g, parseFloat(order.totalPrice?.toString() ?? '0').toFixed(2))
      .replace(/\{playerId\}/g, order.playerId || '');
  };

  const copyText = async (text: string) => {
    try { await navigator.clipboard.writeText(text); toast({ title: '✅ تم النسخ' }); }
    catch { toast({ title: 'تعذّر النسخ', variant: 'destructive' }); }
  };

  const toggleId = (id: string) => setSelectedIds(s => {
    const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n;
  });
  const clearSelection = () => setSelectedIds(new Set());

  const runBulk = async (action: 'approve' | 'reject' | 'retry') => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm(`تأكيد ${action === 'approve' ? 'الموافقة على' : action === 'reject' ? 'رفض' : 'إعادة محاولة'} ${ids.length} طلب؟`)) return;
    setBulkRunning(true);
    try {
      const r = await fetch(`${BASE}/api/admin/orders/bulk-action`, {
        method: 'POST', headers: authHeaders(), body: JSON.stringify({ ids, action }),
      });
      const d = await r.json();
      toast({ title: `✅ نجح ${d.ok} ${d.fail ? `· فشل ${d.fail}` : ''}` });
      clearSelection();
      // Re-fetch list
      const refetchFn = (window as any).__adminOrdersRefetch;
      if (refetchFn) refetchFn();
    } catch { toast({ title: 'فشل التنفيذ الجماعي', variant: 'destructive' }); }
    finally { setBulkRunning(false); }
  };

  const { data, isLoading, refetch } = useGetAdminOrders({ page, limit: 25, status: status || undefined });
  React.useEffect(() => { (window as any).__adminOrdersRefetch = refetch; }, [refetch]);
  const retryOrder = useRetryOrder();
  const orders = data?.orders ?? [];
  const total = data?.total ?? 0;

  const handleRetry = async (id: string) => {
    try {
      await retryOrder.mutateAsync({ id });
      toast({ title: '⚡ تم إعادة المحاولة' });
      refetch();
    } catch {
      toast({ title: 'خطأ', description: 'فشل في إعادة المحاولة', variant: 'destructive' });
    }
  };

  const openApprove = (id: string, productName: string) => {
    setApproveModal({ id, productName });
    setDeliveryMessage('');
  };

  const submitApprove = async () => {
    if (!approveModal) return;
    setApproving(true);
    try {
      const res = await fetch(`${BASE}/api/admin/orders/${approveModal.id}/approve`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ deliveryMessage: deliveryMessage.trim() || undefined }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || data.message || 'فشل');
      }
      toast({
        title: deliveryMessage.trim() ? '✅ تم الإرسال للعميل' : '✅ تم تنفيذ الطلب',
        description: deliveryMessage.trim() ? 'سيظهر للعميل في الإشعارات.' : undefined,
      });
      setApproveModal(null);
      setDeliveryMessage('');
      refetch();
    } catch (e: any) {
      toast({ title: 'خطأ في الموافقة', description: e?.message ?? '', variant: 'destructive' });
    } finally {
      setApproving(false);
    }
  };

  const handleReject = async (id: string) => {
    const reason = prompt('سبب الرفض (اختياري):') ?? undefined;
    if (reason === null) return;
    if (!confirm('هل تريد رفض الطلب وإرجاع المبلغ للمستخدم؟')) return;
    try {
      const res = await fetch(`${BASE}/api/admin/orders/${id}/reject`, {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ reason: reason || undefined }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || data.message || 'فشل');
      }
      toast({ title: '❌ تم رفض الطلب وإرجاع الرصيد' });
      refetch();
    } catch (e: any) {
      toast({ title: 'خطأ في الرفض', description: e?.message ?? '', variant: 'destructive' });
    }
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const url = `${BASE}/api/admin/orders/export${status ? `?status=${status}` : ''}`;
      const res = await fetch(url, { headers: authHeaders() });
      if (!res.ok) throw new Error('فشل التصدير');
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `orders_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(a.href);
      toast({ title: '✅ تم تصدير الطلبات بنجاح' });
    } catch {
      toast({ title: 'خطأ في التصدير', variant: 'destructive' });
    } finally {
      setExporting(false);
    }
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="font-heading text-2xl font-bold">جميع الطلبات</h1>
              <p className="text-muted-foreground text-sm mt-1">{total} طلب إجمالاً</p>
            </div>
            <div className="flex items-center gap-2">
              <select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}
                className="px-3 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors" dir="rtl">
                {Object.entries(STATUS_LABELS).map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </select>
              <button onClick={handleExport} disabled={exporting}
                className="flex items-center gap-2 px-3 py-2.5 bg-green-500/10 text-green-400 border border-green-500/30 rounded-xl text-sm hover:bg-green-500/20 transition-colors disabled:opacity-50">
                <Download size={14} />
                {exporting ? 'جارٍ التصدير...' : 'تصدير CSV'}
              </button>
            </div>
          </div>

          {selectedIds.size > 0 && (
            <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3 bg-primary/10 border border-primary/30 rounded-2xl flex-wrap">
              <CheckSquare size={16} className="text-primary" />
              <span className="text-sm font-bold">{selectedIds.size} طلب محدد</span>
              <div className="ml-auto flex gap-2 flex-wrap">
                <button onClick={() => runBulk('approve')} disabled={bulkRunning}
                  className="px-3 py-1.5 text-xs rounded-lg bg-green-500/15 text-green-400 border border-green-500/30 hover:bg-green-500/25 disabled:opacity-50 font-bold">
                  <CheckCircle2 size={11} className="inline ml-1" /> موافقة على المحدد
                </button>
                <button onClick={() => runBulk('reject')} disabled={bulkRunning}
                  className="px-3 py-1.5 text-xs rounded-lg bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25 disabled:opacity-50 font-bold">
                  <XCircle size={11} className="inline ml-1" /> رفض المحدد
                </button>
                <button onClick={() => runBulk('retry')} disabled={bulkRunning}
                  className="px-3 py-1.5 text-xs rounded-lg bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 disabled:opacity-50 font-bold">
                  <RefreshCw size={11} className="inline ml-1" /> إعادة المحاولة
                </button>
                <button onClick={clearSelection} className="px-3 py-1.5 text-xs rounded-lg text-muted-foreground hover:bg-white/5">إلغاء التحديد</button>
              </div>
            </motion.div>
          )}

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {isLoading ? (
              <div className="py-12 text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : orders.length === 0 ? (
              <div className="py-16 text-center">
                <Package size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">لا توجد طلبات</p>
              </div>
            ) : (
              <>
                {/* Desktop Table */}
                <div className="hidden lg:block overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-background/50">
                        <th className="px-3 py-3 w-10">
                          <input type="checkbox"
                            checked={orders.length > 0 && orders.every(o => selectedIds.has(o.id))}
                            onChange={e => {
                              if (e.target.checked) setSelectedIds(new Set(orders.map(o => o.id)));
                              else clearSelection();
                            }}
                            className="w-4 h-4 accent-primary" />
                        </th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">رقم الطلب</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المنتج</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المستخدم</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">المبلغ</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">التاريخ</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">الحالة</th>
                        <th className="text-right text-xs text-muted-foreground font-medium px-4 py-3">إجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {orders.map(order => (
                        <motion.tr key={order.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background transition-colors">
                          <td className="px-3 py-3">
                            <input type="checkbox" checked={selectedIds.has(order.id)} onChange={() => toggleId(order.id)} className="w-4 h-4 accent-primary" />
                          </td>
                          <td className="px-4 py-3 text-xs font-mono text-muted-foreground whitespace-nowrap">
                            {(order as any).orderNumber ? `#ORD-${String((order as any).orderNumber).padStart(5, '0')}` : order.id.slice(0, 8)}
                          </td>
                          <td className="px-4 py-3 text-sm font-medium max-w-[220px]">
                            <div className="truncate">{order.productName}</div>
                            {((order as any).playerId || ((order as any).fieldValues && Object.keys((order as any).fieldValues).length > 0)) && (
                              <div className="mt-1 flex flex-wrap gap-1">
                                {(order as any).playerId && (
                                  <span className="inline-flex items-center text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/20 font-mono" title={(order as any).playerId}>
                                    ID: {String((order as any).playerId).slice(0, 20)}
                                  </span>
                                )}
                                {(order as any).fieldValues && Object.entries((order as any).fieldValues as Record<string, string>)
                                  .filter(([k, v]) => v && k !== 'playerId')
                                  .slice(0, 3)
                                  .map(([k, v]) => (
                                    <span key={k} className="inline-flex items-center text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border" title={`${k}: ${v}`}>
                                      {k}: {String(v).slice(0, 18)}
                                    </span>
                                  ))}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground max-w-[180px] truncate">#{order.userId}</td>
                          <td className="px-4 py-3 text-sm font-bold text-primary whitespace-nowrap">${parseFloat(order.totalPrice?.toString() ?? '0').toFixed(2)}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(order.createdAt).toLocaleDateString('en-GB')}</td>
                          <td className="px-4 py-3"><StatusBadge status={order.status} size="sm" /></td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {(order.status === 'processing' || order.status === 'pending') && (
                                <>
                                  <button onClick={() => openApprove(order.id, order.productName)} className="flex items-center gap-1 px-2 py-1 text-xs rounded-lg bg-green-500/10 text-green-400 border border-green-500/30 hover:bg-green-500/20 transition-colors">
                                    <CheckCircle2 size={11} /> موافقة
                                  </button>
                                  <button onClick={() => handleReject(order.id)} className="flex items-center gap-1 px-2 py-1 text-xs rounded-lg bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20 transition-colors">
                                    <XCircle size={11} /> رفض
                                  </button>
                                </>
                              )}
                              {order.status === 'failed' && (
                                <button onClick={() => handleRetry(order.id)} className="flex items-center gap-1 px-2 py-1 text-xs rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
                                  <RefreshCw size={11} /> إعادة
                                </button>
                              )}
                              <button onClick={() => openTemplates(order)} title="قوالب رسائل للعميل"
                                className="flex items-center gap-1 px-2 py-1 text-xs rounded-lg bg-blue-500/10 text-blue-300 border border-blue-500/30 hover:bg-blue-500/20 transition-colors">
                                <MessageSquare size={11} /> رسالة
                              </button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile/Tablet Cards */}
                <div className="lg:hidden divide-y divide-border">
                  {orders.map(order => (
                    <motion.div key={order.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="p-4 hover:bg-background/50 transition-colors">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-bold truncate">{order.productName}</p>
                          <p className="text-[11px] text-muted-foreground font-mono mt-0.5">
                            {(order as any).orderNumber ? `#ORD-${String((order as any).orderNumber).padStart(5, '0')}` : order.id.slice(0, 8)}
                          </p>
                          {((order as any).playerId || ((order as any).fieldValues && Object.keys((order as any).fieldValues).length > 0)) && (
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              {(order as any).playerId && (
                                <span className="inline-flex items-center text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/20 font-mono">
                                  ID: {String((order as any).playerId).slice(0, 22)}
                                </span>
                              )}
                              {(order as any).fieldValues && Object.entries((order as any).fieldValues as Record<string, string>)
                                .filter(([k, v]) => v && k !== 'playerId')
                                .slice(0, 4)
                                .map(([k, v]) => (
                                  <span key={k} className="inline-flex items-center text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border">
                                    {k}: {String(v).slice(0, 20)}
                                  </span>
                                ))}
                            </div>
                          )}
                        </div>
                        <StatusBadge status={order.status} size="sm" />
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-xs mb-3">
                        <div>
                          <span className="text-muted-foreground">المستخدم:</span>
                          <p className="text-foreground/90 truncate mt-0.5">#{order.userId}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">المبلغ:</span>
                          <p className="text-primary font-bold mt-0.5">${parseFloat(order.totalPrice?.toString() ?? '0').toFixed(2)}</p>
                        </div>
                        <div className="col-span-2">
                          <span className="text-muted-foreground">التاريخ:</span>
                          <span className="text-foreground/80 mr-1">{new Date(order.createdAt).toLocaleString('en-GB', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' })}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-border/40">
                        {(order.status === 'processing' || order.status === 'pending') && (
                          <>
                            <button onClick={() => openApprove(order.id, order.productName)} className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-green-500/15 text-green-400 border border-green-500/30 hover:bg-green-500/25 transition-colors font-semibold">
                              <CheckCircle2 size={12} /> موافقة
                            </button>
                            <button onClick={() => handleReject(order.id)} className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25 transition-colors font-semibold">
                              <XCircle size={12} /> رفض
                            </button>
                          </>
                        )}
                        {order.status === 'failed' && (
                          <button onClick={() => handleRetry(order.id)} className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 transition-colors font-semibold">
                            <RefreshCw size={12} /> إعادة المحاولة
                          </button>
                        )}
                        {!['processing', 'pending', 'failed'].includes(order.status) && (
                          <button onClick={() => openTemplates(order)} className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-blue-500/15 text-blue-300 border border-blue-500/30 hover:bg-blue-500/25 transition-colors font-semibold">
                            <MessageSquare size={12} /> رسالة للعميل
                          </button>
                        )}
                        {(order.status === 'processing' || order.status === 'pending' || order.status === 'failed') && (
                          <button onClick={() => openTemplates(order)} className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-lg bg-blue-500/15 text-blue-300 border border-blue-500/30 hover:bg-blue-500/25 transition-colors font-semibold">
                            <MessageSquare size={12} />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </>
            )}
          </div>

          {total > 25 && (
            <div className="flex justify-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">السابق</button>
              <span className="px-4 py-2 text-sm text-muted-foreground">صفحة {page}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page * 25 >= total}
                className="px-4 py-2 bg-card border border-border rounded-xl text-sm disabled:opacity-40">التالي</button>
            </div>
          )}
        </div>

        {/* Approve modal with delivery message */}
        {approveModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4" dir="rtl" onClick={() => !approving && setApproveModal(null)}>
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              onClick={e => e.stopPropagation()}
              className="bg-card border border-border w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl"
            >
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="min-w-0">
                  <h3 className="font-bold text-lg flex items-center gap-2"><CheckCircle2 size={18} className="text-green-400" /> موافقة على الطلب</h3>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{approveModal.productName}</p>
                </div>
                <button onClick={() => !approving && setApproveModal(null)} className="p-1.5 rounded-lg hover:bg-background text-muted-foreground" disabled={approving}>
                  <X size={18} />
                </button>
              </div>

              <label className="block text-sm font-semibold mb-2">
                رسالة للعميل (اختياري)
                <span className="block text-[11px] text-muted-foreground font-normal mt-0.5">
                  أدخل الكود / بيانات الحساب / معلومات التسليم. ستظهر للعميل في الإشعارات وصفحة الطلب.
                </span>
              </label>
              <textarea
                value={deliveryMessage}
                onChange={e => setDeliveryMessage(e.target.value)}
                placeholder="مثال:&#10;اسم المستخدم: ahminix_user&#10;كلمة المرور: 8sJk2L9p&#10;الكود: STEAM-XXXX-YYYY-ZZZZ"
                rows={6}
                className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors font-mono leading-relaxed resize-none"
                disabled={approving}
              />
              <p className="text-[11px] text-muted-foreground mt-2">
                💡 إذا تركت الحقل فارغاً وكان المنتج مرتبط بمزوّد API، سيتم تنفيذ الطلب تلقائياً عبر المزوّد.
              </p>

              <div className="flex items-center gap-2 mt-5">
                <button
                  onClick={() => !approving && setApproveModal(null)}
                  disabled={approving}
                  className="flex-1 px-4 py-2.5 rounded-xl border border-border bg-background hover:bg-background/70 text-sm font-semibold transition-colors"
                >
                  إلغاء
                </button>
                <button
                  onClick={submitApprove}
                  disabled={approving}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-green-500/20 text-green-300 border border-green-500/40 hover:bg-green-500/30 text-sm font-bold transition-colors disabled:opacity-60"
                >
                  {approving ? (
                    <span className="w-4 h-4 border-2 border-green-300 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send size={14} />
                  )}
                  {deliveryMessage.trim() ? 'موافقة وإرسال' : 'موافقة وتنفيذ'}
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* Templates modal */}
        {tplModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4" dir="rtl" onClick={() => setTplModal(null)}>
            <motion.div initial={{ opacity: 0, y: 40, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }}
              onClick={e => e.stopPropagation()}
              className="bg-card border border-border w-full sm:max-w-2xl rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="min-w-0">
                  <h3 className="font-bold text-lg flex items-center gap-2"><MessageSquare size={18} className="text-blue-400" /> قوالب رسائل العميل</h3>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{tplModal.order.productName} — {tplModal.order.userEmail}</p>
                </div>
                <button onClick={() => setTplModal(null)} className="p-1.5 rounded-lg hover:bg-background text-muted-foreground"><X size={18} /></button>
              </div>
              {templates.length === 0 ? (
                <div className="py-8 text-center text-sm text-muted-foreground">جارٍ التحميل...</div>
              ) : (
                <div className="space-y-3">
                  {templates.map(t => {
                    const text = renderTemplate(t.body, tplModal.order);
                    return (
                      <div key={t.id} className="bg-background border border-border rounded-xl p-3">
                        <div className="flex items-center justify-between mb-2 gap-2">
                          <div className="font-bold text-sm truncate">{t.title}</div>
                          <div className="flex gap-2 shrink-0">
                            <button onClick={() => copyText(text)} className="px-2.5 py-1 text-xs rounded-lg bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 flex items-center gap-1">
                              <Copy size={11} /> نسخ
                            </button>
                            <a href={`https://wa.me/?text=${encodeURIComponent(text)}`} target="_blank" rel="noopener noreferrer"
                              className="px-2.5 py-1 text-xs rounded-lg bg-green-500/15 text-green-300 border border-green-500/30 hover:bg-green-500/25 flex items-center gap-1">
                              واتساب
                            </a>
                            <a href={`https://t.me/share/url?url=${encodeURIComponent('Elite Store')}&text=${encodeURIComponent(text)}`} target="_blank" rel="noopener noreferrer"
                              className="px-2.5 py-1 text-xs rounded-lg bg-blue-500/15 text-blue-300 border border-blue-500/30 hover:bg-blue-500/25 flex items-center gap-1">
                              تيليغرام
                            </a>
                          </div>
                        </div>
                        <pre className="text-xs whitespace-pre-wrap text-foreground/85 leading-relaxed font-sans">{text}</pre>
                      </div>
                    );
                  })}
                </div>
              )}
              <p className="text-[11px] text-muted-foreground mt-4">💡 لتعديل القوالب: <span className="font-mono">PUT /api/admin/message-templates</span></p>
            </motion.div>
          </div>
        )}
      </DashboardLayout>
    </ProtectedRoute>
  );
}
