import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CreditCard, Plus, Pencil, Trash2, X, Check, GripVertical, Loader2, Image as ImageIcon, ChevronUp, ChevronDown } from 'lucide-react';

interface Detail { label: string; value: string }
interface PaymentMethod {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  emoji: string;
  color: string;
  imageUrl: string | null;
  details: Detail[];
  currency: string;
  isActive: boolean;
  sortOrder: number;
}

const emptyForm = {
  slug: '',
  nameAr: '',
  nameEn: '',
  emoji: '💳',
  color: '#6366f1',
  imageUrl: '',
  currency: 'SYP',
  isActive: true,
  details: [{ label: '', value: '' }] as Detail[],
};

const CURRENCIES = ['SYP', 'USD', 'EUR', 'USDT'];

export default function AdminPaymentMethods() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editingMethod, setEditingMethod] = useState<PaymentMethod | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<PaymentMethod | null>(null);
  const [form, setForm] = useState(emptyForm);

  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };

  const { data: methods = [], isLoading } = useQuery<PaymentMethod[]>({
    queryKey: ['admin-payment-methods'],
    queryFn: async () => {
      const res = await fetch('/api/admin/payment-methods', { headers });
      if (!res.ok) throw new Error('Failed to load');
      return res.json();
    },
  });

  const refetch = () => qc.invalidateQueries({ queryKey: ['admin-payment-methods'] });

  const createMethod = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch('/api/admin/payment-methods', {
        method: 'POST',
        headers,
        body: JSON.stringify({ ...data, details: data.details.filter(d => d.label && d.value) }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? 'Failed');
      return res.json();
    },
    onSuccess: () => { toast({ title: 'تمت الإضافة' }); refetch(); setShowModal(false); setForm(emptyForm); },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  const updateMethod = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: typeof form }) => {
      const res = await fetch(`/api/admin/payment-methods/${id}`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({ ...data, details: data.details.filter(d => d.label && d.value) }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? 'Failed');
      return res.json();
    },
    onSuccess: () => { toast({ title: 'تم التعديل' }); refetch(); setEditingMethod(null); setForm(emptyForm); },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  const deleteMethod = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/payment-methods/${id}`, { method: 'DELETE', headers });
      if (!res.ok) throw new Error('Failed');
    },
    onSuccess: () => { toast({ title: 'تم الحذف' }); refetch(); setDeleteConfirm(null); },
    onError: () => toast({ title: 'خطأ', description: 'تعذر الحذف', variant: 'destructive' }),
  });

  const moveMethod = useMutation({
    mutationFn: async (order: number[]) => {
      await fetch('/api/admin/payment-methods/reorder', {
        method: 'POST',
        headers,
        body: JSON.stringify({ order }),
      });
    },
    onSuccess: () => refetch(),
  });

  const openAdd = () => {
    setEditingMethod(null);
    setForm(emptyForm);
    setShowModal(true);
  };

  const openEdit = (m: PaymentMethod) => {
    setEditingMethod(m);
    setForm({
      slug: m.slug,
      nameAr: m.nameAr,
      nameEn: m.nameEn,
      emoji: m.emoji,
      color: m.color,
      imageUrl: m.imageUrl ?? '',
      currency: m.currency,
      isActive: m.isActive,
      details: m.details.length > 0 ? m.details : [{ label: '', value: '' }],
    });
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.slug || !form.nameAr || !form.nameEn) {
      toast({ title: 'حقول مطلوبة', description: 'الـ Slug والاسمان مطلوبان', variant: 'destructive' });
      return;
    }
    if (editingMethod) {
      updateMethod.mutate({ id: editingMethod.id, data: form });
    } else {
      createMethod.mutate(form);
    }
  };

  const addDetailRow = () => setForm(f => ({ ...f, details: [...f.details, { label: '', value: '' }] }));
  const removeDetailRow = (i: number) => setForm(f => ({ ...f, details: f.details.filter((_, idx) => idx !== i) }));
  const updateDetail = (i: number, key: 'label' | 'value', val: string) =>
    setForm(f => ({ ...f, details: f.details.map((d, idx) => idx === i ? { ...d, [key]: val } : d) }));

  const moveUp = (idx: number) => {
    if (idx === 0) return;
    const ids = methods.map(m => m.id);
    [ids[idx - 1], ids[idx]] = [ids[idx], ids[idx - 1]];
    moveMethod.mutate(ids);
  };

  const moveDown = (idx: number) => {
    if (idx === methods.length - 1) return;
    const ids = methods.map(m => m.id);
    [ids[idx], ids[idx + 1]] = [ids[idx + 1], ids[idx]];
    moveMethod.mutate(ids);
  };

  const isPending = createMethod.isPending || updateMethod.isPending;

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-heading text-2xl font-bold">طرق الدفع</h1>
              <p className="text-muted-foreground text-sm mt-1">{methods.length} طريقة دفع</p>
            </div>
            <button
              onClick={openAdd}
              className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors"
            >
              <Plus size={14} /> إضافة طريقة دفع
            </button>
          </div>

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {isLoading ? (
              <div className="py-12 text-center"><div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" /></div>
            ) : methods.length === 0 ? (
              <div className="py-16 text-center">
                <CreditCard size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">لا توجد طرق دفع</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {methods.map((method, idx) => (
                  <motion.div key={method.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-4 px-5 py-4">
                    <div className="flex flex-col gap-0.5">
                      <button onClick={() => moveUp(idx)} disabled={idx === 0} className="p-0.5 hover:bg-muted rounded disabled:opacity-30 transition-colors">
                        <ChevronUp size={12} />
                      </button>
                      <button onClick={() => moveDown(idx)} disabled={idx === methods.length - 1} className="p-0.5 hover:bg-muted rounded disabled:opacity-30 transition-colors">
                        <ChevronDown size={12} />
                      </button>
                    </div>
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ backgroundColor: method.color + '22', border: `1.5px solid ${method.color}55` }}>
                      {method.imageUrl ? (
                        <img src={method.imageUrl} alt="" className="w-7 h-7 object-contain rounded-lg" />
                      ) : (
                        <span>{method.emoji}</span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm">{method.nameAr}</p>
                        <span className="text-xs text-muted-foreground">({method.nameEn})</span>
                        {!method.isActive && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-muted text-muted-foreground">مخفي</span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{method.slug} · {method.currency}</p>
                      {method.details.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-0.5 truncate">
                          {method.details.map(d => `${d.label}: ${d.value}`).join(' · ')}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button onClick={() => openEdit(method)} className="p-1.5 rounded-lg hover:bg-primary/10 text-primary transition-colors">
                        <Pencil size={13} />
                      </button>
                      <button onClick={() => setDeleteConfirm(method)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive transition-colors">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Add/Edit Modal */}
        <AnimatePresence>
          {showModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => { setShowModal(false); setEditingMethod(null); }} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="font-heading text-lg font-bold">{editingMethod ? 'تعديل طريقة الدفع' : 'إضافة طريقة دفع جديدة'}</h2>
                  <button onClick={() => { setShowModal(false); setEditingMethod(null); }} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الاسم بالعربية *</label>
                      <input value={form.nameAr} onChange={e => setForm(f => ({ ...f, nameAr: e.target.value }))} placeholder="سيريتل كاش" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">الاسم بالإنجليزية *</label>
                      <input value={form.nameEn} onChange={e => setForm(f => ({ ...f, nameEn: e.target.value }))} placeholder="Syriatel Cash" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Slug (معرّف فريد) *</label>
                    <input value={form.slug} onChange={e => setForm(f => ({ ...f, slug: e.target.value.toLowerCase().replace(/\s+/g, '_') }))} placeholder="syriatel_cash" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 font-mono" />
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">رمز تعبيري</label>
                      <input value={form.emoji} onChange={e => setForm(f => ({ ...f, emoji: e.target.value }))} placeholder="💳" className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 text-center text-lg" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">اللون</label>
                      <div className="flex items-center gap-2">
                        <input type="color" value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} className="w-10 h-9 rounded-lg border border-border cursor-pointer bg-background p-0.5" />
                        <input value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} className="flex-1 px-2 py-2 bg-background border border-border rounded-xl text-xs focus:outline-none font-mono" />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">العملة</label>
                      <select value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))} className="w-full px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50">
                        {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">صورة طريقة الدفع (اختياري — تستبدل الرمز التعبيري)</label>
                    <div className="flex items-center gap-2">
                      <ImageIcon size={14} className="text-muted-foreground flex-shrink-0" />
                      <input value={form.imageUrl} onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))} placeholder="https://... أو ارفع صورة" className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" />
                      <label className="px-3 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/30 rounded-xl text-xs text-primary cursor-pointer transition-colors whitespace-nowrap font-bold">
                        📷 رفع
                        <input type="file" accept="image/*" className="hidden" onChange={async e => {
                          const file = e.target.files?.[0]; if (!file) return;
                          const fd = new FormData(); fd.append('image', file);
                          const tk = localStorage.getItem('elite_token');
                          try {
                            const r = await fetch('/api/admin/upload/image', { method: 'POST', headers: { Authorization: `Bearer ${tk}` }, body: fd });
                            if (!r.ok) throw new Error(await r.text());
                            const { url } = await r.json();
                            setForm(f => ({ ...f, imageUrl: url }));
                            toast({ title: '✅ تم رفع الصورة' });
                          } catch (err: any) {
                            toast({ title: 'فشل رفع الصورة', description: err.message, variant: 'destructive' });
                          } finally {
                            e.target.value = '';
                          }
                        }} />
                      </label>
                    </div>
                    {form.imageUrl && (
                      <img src={form.imageUrl} alt="" className="mt-2 h-14 rounded-lg object-contain border border-border p-1 bg-background" onError={e => (e.currentTarget.style.display = 'none')} />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs text-muted-foreground">تفاصيل (رقم المحفظة، العنوان...)</label>
                      <button type="button" onClick={addDetailRow} className="text-xs text-primary hover:underline">+ إضافة سطر</button>
                    </div>
                    <div className="space-y-2">
                      {form.details.map((d, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <input value={d.label} onChange={e => updateDetail(i, 'label', e.target.value)} placeholder="رقم المحفظة" className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50" dir="rtl" />
                          <input value={d.value} onChange={e => updateDetail(i, 'value', e.target.value)} placeholder="1122755750" className="flex-1 px-3 py-2 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 font-mono" />
                          {form.details.length > 1 && (
                            <button type="button" onClick={() => removeDetailRow(i)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive transition-colors">
                              <X size={12} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={() => setForm(f => ({ ...f, isActive: !f.isActive }))}
                      className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${form.isActive ? 'bg-primary' : 'bg-muted'}`}
                    >
                      <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.isActive ? 'translate-x-5' : 'translate-x-0.5'}`} />
                    </button>
                    <span className="text-sm">{form.isActive ? 'مفعّل (ظاهر للعملاء)' : 'مخفي (غير ظاهر)'}</span>
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <button onClick={() => { setShowModal(false); setEditingMethod(null); }} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={handleSave} disabled={isPending} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                    {isPending ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                    {editingMethod ? 'حفظ التعديلات' : 'إضافة'}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Delete Confirm */}
        <AnimatePresence>
          {deleteConfirm && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50" onClick={() => setDeleteConfirm(null)} />
              <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-sm shadow-2xl text-center">
                <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
                  <Trash2 size={20} className="text-destructive" />
                </div>
                <h2 className="font-heading text-lg font-bold mb-2">حذف طريقة الدفع؟</h2>
                <p className="text-muted-foreground text-sm mb-6">هل تريد حذف <strong>{deleteConfirm.nameAr}</strong>؟ لا يمكن التراجع عن هذا الإجراء.</p>
                <div className="flex gap-3">
                  <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">إلغاء</button>
                  <button onClick={() => deleteMethod.mutate(deleteConfirm.id)} disabled={deleteMethod.isPending} className="flex-1 py-2.5 bg-destructive text-destructive-foreground rounded-xl text-sm font-semibold hover:bg-destructive/90 transition-colors flex items-center justify-center gap-2">
                    {deleteMethod.isPending ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    حذف
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
