import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useQuery } from '@tanstack/react-query';
import { Trophy, Crown, Loader2, TrendingUp, Package, Users } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authFetch(path: string) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
}

const RANGES = [
  { key: 1, label: 'اليوم' },
  { key: 7, label: 'آخر أسبوع' },
  { key: 30, label: 'آخر شهر' },
  { key: 90, label: 'آخر 3 شهور' },
];

function fmtMoney(n: number) {
  return `$${(n ?? 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

function rankColor(i: number) {
  if (i === 0) return '#facc15';
  if (i === 1) return '#cbd5e1';
  if (i === 2) return '#f59e0b';
  return '#a855f7';
}

export default function AdminTopSelling() {
  const [range, setRange] = useState<number>(7);

  const { data, isLoading } = useQuery<any>({
    queryKey: ['admin-top-selling', range],
    queryFn: async () => {
      const res = await authFetch(`/api/admin/analytics?range=${range}`);
      if (!res.ok) throw new Error('Failed');
      return res.json();
    },
    refetchInterval: 60_000,
  });

  const topProducts: any[] = data?.topProducts ?? [];
  const topCustomers: any[] = data?.topCustomers ?? [];
  const summary = data?.summary ?? {};

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6 p-4 md:p-6" dir="rtl">
          <div className="flex flex-wrap items-center gap-3 justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-black flex items-center gap-2">
                <Trophy className="text-yellow-400" /> الأكثر مبيعاً
              </h1>
              <p className="text-sm text-muted-foreground mt-1">أفضل المنتجات والعملاء حسب الفترة الزمنية</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {RANGES.map((r) => (
                <button
                  key={r.key}
                  onClick={() => setRange(r.key)}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
                    range === r.key
                      ? 'bg-primary text-white shadow-lg shadow-primary/30'
                      : 'bg-card border border-border text-muted-foreground hover:text-white'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="animate-spin text-primary" size={32} />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { Icon: Package, label: 'الطلبات الناجحة', value: summary.completedOrders ?? 0, color: '#10b981' },
                  { Icon: TrendingUp, label: 'الإيرادات', value: fmtMoney(summary.totalRevenue ?? 0), color: '#a855f7' },
                  { Icon: Users, label: 'الإيداعات', value: summary.depositsCount ?? 0, color: '#22d3ee' },
                  { Icon: Crown, label: 'متوسط الطلب', value: fmtMoney(summary.avgOrderValue ?? 0), color: '#f59e0b' },
                ].map((s) => (
                  <div key={s.label} className="rounded-2xl p-4 border border-border bg-card">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-2" style={{ background: `${s.color}1f`, border: `1px solid ${s.color}55` }}>
                      <s.Icon size={18} style={{ color: s.color }} />
                    </div>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wider">{s.label}</p>
                    <p className="text-xl font-black mt-0.5 truncate">{s.value}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border bg-card p-5">
                  <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
                    <Package className="text-primary" /> أفضل المنتجات
                  </h2>
                  <div className="space-y-2">
                    {topProducts.length === 0 && <p className="text-sm text-muted-foreground py-6 text-center">لا توجد طلبات في هذه الفترة</p>}
                    {topProducts.map((p, i) => (
                      <div key={p.product_id} className="flex items-center gap-3 p-3 rounded-xl bg-background/40 border border-border/60">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center font-black text-sm shrink-0" style={{ background: `${rankColor(i)}25`, color: rankColor(i), border: `1px solid ${rankColor(i)}66` }}>
                          {i + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm truncate">{p.product_name}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{p.orders} طلب · {p.units} وحدة</p>
                        </div>
                        <p className="font-black text-sm text-success shrink-0">{fmtMoney(p.revenue)}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border bg-card p-5">
                  <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
                    <Crown className="text-yellow-400" /> أفضل العملاء
                  </h2>
                  <div className="space-y-2">
                    {topCustomers.length === 0 && <p className="text-sm text-muted-foreground py-6 text-center">لا يوجد عملاء في هذه الفترة</p>}
                    {topCustomers.map((c, i) => (
                      <div key={c.user_id} className="flex items-center gap-3 p-3 rounded-xl bg-background/40 border border-border/60">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center font-black text-sm shrink-0" style={{ background: `${rankColor(i)}25`, color: rankColor(i), border: `1px solid ${rankColor(i)}66` }}>
                          {i + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm truncate">{c.username ?? '—'}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{c.public_code ?? ''} · VIP {c.vip_level ?? 0} · {c.orders} طلب</p>
                        </div>
                        <p className="font-black text-sm text-primary shrink-0">{fmtMoney(c.spent)}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </div>
            </>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
