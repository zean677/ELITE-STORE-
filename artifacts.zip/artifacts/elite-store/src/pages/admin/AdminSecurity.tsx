import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Shield, AlertTriangle, Users, Key, LogOut, RefreshCw, Eye, EyeOff, Clock, Wifi } from 'lucide-react';
import { useToast } from '../../hooks/use-toast';
import { motion } from 'framer-motion';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

async function fetchSecurity() {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/security/overview`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error('Failed');
  return res.json();
}

async function logoutAllSessions(userId?: number) {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/sessions/all`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(userId ? { userId } : {}),
  });
  return res.json();
}

function fmtDate(iso: string) {
  return new Date(iso).toLocaleString('ar-SY', { dateStyle: 'short', timeStyle: 'short' });
}
function timeAgo(iso: string) {
  const ms = Date.now() - new Date(iso).getTime();
  const min = Math.floor(ms / 60000);
  if (min < 1) return 'الآن';
  if (min < 60) return `${min} د`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} س`;
  return `${Math.floor(hr / 24)} ي`;
}

export default function AdminSecurity() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [showEmails, setShowEmails] = useState(false);
  const { data, isLoading, refetch, isFetching } = useQuery({ queryKey: ['admin', 'security'], queryFn: fetchSecurity, staleTime: 30_000 });

  const logoutMut = useMutation({
    mutationFn: (userId?: number) => logoutAllSessions(userId),
    onSuccess: (r: any) => { toast({ title: '✅ تم', description: r.detail }); qc.invalidateQueries({ queryKey: ['admin', 'security'] }); },
    onError: () => toast({ title: '❌ خطأ', description: 'فشل تسجيل الخروج' }),
  });

  const riskLevel = (data?.failedLogins24h ?? 0) >= 10 ? 'high' : (data?.failedLogins24h ?? 0) >= 3 ? 'medium' : 'low';

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6 max-w-4xl mx-auto" dir="rtl">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-2xl font-bold">مركز الأمان</h1>
              <p className="text-sm text-muted-foreground mt-0.5">مراقبة الدخول والجلسات وتهديدات الأمان</p>
            </div>
            <button onClick={() => refetch()} className="p-2 rounded-xl border border-white/10 hover:bg-white/5">
              <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
            </button>
          </div>

          {/* Risk level banner */}
          {!isLoading && (
            <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
              className={`rounded-2xl border p-4 flex items-center gap-3 ${
                riskLevel === 'high' ? 'bg-red-500/10 border-red-500/30' :
                riskLevel === 'medium' ? 'bg-amber-500/10 border-amber-500/30' :
                'bg-emerald-500/10 border-emerald-500/20'
              }`}>
              <Shield size={20} className={riskLevel === 'high' ? 'text-red-400' : riskLevel === 'medium' ? 'text-amber-400' : 'text-emerald-400'} />
              <div>
                <div className="font-semibold text-sm">
                  {riskLevel === 'high' ? '🔴 مستوى خطر مرتفع' : riskLevel === 'medium' ? '🟡 يتطلب انتباهاً' : '🟢 النظام آمن'}
                </div>
                <div className="text-xs text-muted-foreground">
                  {data?.failedLogins24h ?? 0} محاولة دخول فاشلة خلال 24 ساعة
                  {(data?.suspiciousIps?.length ?? 0) > 0 && ` · ${data.suspiciousIps.length} IP مشبوه`}
                </div>
              </div>
            </motion.div>
          )}

          {/* Stats row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: AlertTriangle, label: 'فاشل (24س)', value: data?.failedLogins24h ?? 0, color: 'red' },
              { icon: AlertTriangle, label: 'فاشل (7 أيام)', value: data?.failedLogins7d ?? 0, color: 'amber' },
              { icon: Users, label: 'جلسات نشطة', value: data?.activeSessions ?? 0, color: 'blue' },
              { icon: Shield, label: 'IPs مشبوهة', value: data?.suspiciousIps?.length ?? 0, color: 'red' },
            ].map(item => (
              <div key={item.label} className="bg-card border border-border rounded-2xl p-4 text-center">
                <item.icon size={18} className={`text-${item.color}-400 mx-auto mb-2`} />
                <div className="text-2xl font-black">{String(item.value)}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{item.label}</div>
              </div>
            ))}
          </div>

          {/* Suspicious IPs */}
          {(data?.suspiciousIps?.length ?? 0) > 0 && (
            <div className="bg-card border border-red-500/30 rounded-2xl p-4">
              <h2 className="font-bold text-sm flex items-center gap-2 text-red-400 mb-3">
                <AlertTriangle size={16} /> عناوين IP مشبوهة (≥5 محاولات فاشلة في 24 ساعة)
              </h2>
              <div className="space-y-1.5">
                {data.suspiciousIps.map((ip: any) => (
                  <div key={ip.ip} className="flex items-center justify-between px-3 py-2 rounded-xl bg-red-500/5 border border-red-500/20 text-sm">
                    <span className="font-mono text-red-400">{ip.ip}</span>
                    <span className="text-xs font-bold bg-red-500/20 px-2 py-0.5 rounded-full">{ip.cnt} محاولة</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent failed logins */}
          <div className="bg-card border border-border rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-sm flex items-center gap-2">
                <Key size={16} className="text-amber-400" /> محاولات الدخول الفاشلة (24 ساعة)
              </h2>
              <button onClick={() => setShowEmails(!showEmails)} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                {showEmails ? <EyeOff size={12} /> : <Eye size={12} />}
                {showEmails ? 'إخفاء' : 'عرض'} اسم المستخدم
              </button>
            </div>
            {(data?.recentFailed?.length ?? 0) === 0 ? (
              <div className="py-6 text-center text-muted-foreground text-sm">لا توجد محاولات فاشلة ✅</div>
            ) : (
              <div className="space-y-1.5 max-h-56 overflow-y-auto">
                {data.recentFailed.map((f: any, i: number) => (
                  <div key={i} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs">
                    <span className="font-mono text-amber-400">{f.ip}</span>
                    {showEmails && <span className="text-muted-foreground flex-1 truncate">{f.username}</span>}
                    <span className="text-muted-foreground me-auto"><Clock size={10} className="inline me-0.5" />{timeAgo(f.createdAt)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent admin activity */}
          <div className="bg-card border border-border rounded-2xl p-4">
            <h2 className="font-bold text-sm flex items-center gap-2 mb-3">
              <Shield size={16} className="text-primary" /> آخر نشاط للأدمن
            </h2>
            {(data?.recentAdminActivity?.length ?? 0) === 0 ? (
              <div className="py-6 text-center text-muted-foreground text-sm">لا يوجد نشاط مسجّل</div>
            ) : (
              <div className="space-y-1.5">
                {data.recentAdminActivity.map((act: any, i: number) => (
                  <div key={i} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs">
                    <span className="font-semibold text-primary shrink-0">{act.adminUsername}</span>
                    <span className="px-1.5 py-0.5 rounded bg-white/10 font-mono">{act.action}</span>
                    <span className="text-muted-foreground">{act.entity}</span>
                    {act.ip && <span className="font-mono text-muted-foreground text-[10px] me-auto">{act.ip}</span>}
                    <span className="text-muted-foreground shrink-0">{timeAgo(act.createdAt)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Session management */}
          <div className="bg-card border border-border rounded-2xl p-4">
            <h2 className="font-bold text-sm flex items-center gap-2 mb-4">
              <Wifi size={16} className="text-primary" /> إدارة الجلسات
            </h2>
            <div className="flex flex-wrap gap-3">
              <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-3">
                <div className="text-2xl font-black">{data?.activeSessions ?? 0}</div>
                <div className="text-xs text-muted-foreground mt-0.5">جلسة نشطة في النظام</div>
              </div>
              <div className="flex flex-col gap-2 justify-center">
                <button
                  onClick={() => logoutMut.mutate(undefined)}
                  disabled={logoutMut.isPending}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm font-semibold hover:bg-red-500/20 disabled:opacity-50 transition-colors"
                >
                  <LogOut size={14} />
                  {logoutMut.isPending ? 'جاري...' : 'تسجيل خروج جميع الجلسات'}
                </button>
                <p className="text-xs text-muted-foreground">يبقي جلستك الحالية فقط ويُخرج الجميع</p>
              </div>
            </div>
          </div>

          {/* 2FA info */}
          <div className="bg-card border border-border rounded-2xl p-4">
            <h2 className="font-bold text-sm flex items-center gap-2 mb-3">
              <Key size={16} className="text-primary" /> المصادقة الثنائية (2FA)
            </h2>
            <p className="text-sm text-muted-foreground mb-3">
              2FA متاح لجميع المستخدمين من صفحة الأمان الشخصية. يُنصح إلزام الأدمن بتفعيله.
            </p>
            <a href={`${BASE}/security`} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary/15 border border-primary/30 text-primary text-sm font-semibold hover:bg-primary/25 transition-colors">
              <Key size={14} /> إدارة 2FA الخاص بك
            </a>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
