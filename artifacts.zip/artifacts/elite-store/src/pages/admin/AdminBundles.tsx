import React, { useEffect, useMemo, useState } from 'react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Gift, Plus, Trash2, Edit3, X, Save, Search, Star, Power } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = (json = false) => {
  const h: Record<string, string> = { Authorization: `Bearer ${localStorage.getItem('elite_token') || ''}` };
  if (json) h['Content-Type'] = 'application/json';
  return h;
};

interface Product { id: string; name: string; imageUrl?: string | null; priceUsd: number; status: string; }
interface BundleItem { id?: number; productId: string; qty: number; sortOrder?: number; product?: { id: string; name: string; imageUrl?: string | null; priceUsd: number; }; }
interface Bundle {
  id: number; name: string; nameAr?: string | null; description?: string | null; imageUrl?: string | null;
  bundlePriceUsd: number; status: string; badge?: string | null; sortOrder: number; isFeatured: boolean;
  startsAt?: string | null; endsAt?: string | null;
  items: BundleItem[]; originalTotalUsd: number; savingsUsd: number; savingsPercent: number;
}

const emptyForm = (): Partial<Bundle> & { items: BundleItem[] } => ({
  name: '', nameAr: '', description: '', imageUrl: '', bundlePriceUsd: 0, status: 'active',
  badge: '', sortOrder: 0, isFeatured: false, startsAt: '', endsAt: '', items: [],
});

export default function AdminBundles() {
  const [bundles, setBundles] = useState<Bundle[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<(Partial<Bundle> & { items: BundleItem[] }) | null>(null);
  const [search, setSearch] = useState('');
  const { toast } = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const [b, p] = await Promise.all([
        fetch(`${BASE}/api/admin/bundles`, { headers: headers() }).then(r => r.json()),
        fetch(`${BASE}/api/admin/products?limit=2000`, { headers: headers() }).then(r => r.json()),
      ]);
      setBundles(b.bundles || []);
      const list: any[] = p.products || p.items || [];
      setProducts(list.map((x: any) => ({ id: x.id, name: x.name, imageUrl: x.imageUrl, priceUsd: parseFloat(x.priceUsd ?? '0'), status: x.status })));
    } catch { toast({ title: 'فشل التحميل', variant: 'destructive' }); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const productMap = useMemo(() => new Map(products.map(p => [p.id, p])), [products]);
  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return products.slice(0, 50);
    return products.filter(p => p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q)).slice(0, 50);
  }, [products, search]);

  const addItem = (productId: string) => {
    if (!editing) return;
    if (editing.items.some(i => i.productId === productId)) { toast({ title: 'موجود مسبقاً' }); return; }
    setEditing({ ...editing, items: [...editing.items, { productId, qty: 1 }] });
  };
  const updateItemQty = (productId: string, qty: number) => {
    if (!editing) return;
    setEditing({ ...editing, items: editing.items.map(i => i.productId === productId ? { ...i, qty: Math.max(1, qty) } : i) });
  };
  const removeItem = (productId: string) => {
    if (!editing) return;
    setEditing({ ...editing, items: editing.items.filter(i => i.productId !== productId) });
  };

  const computedOriginal = useMemo(() => {
    if (!editing) return 0;
    return editing.items.reduce((s, i) => {
      const p = productMap.get(i.productId);
      return s + (p ? p.priceUsd * i.qty : 0);
    }, 0);
  }, [editing, productMap]);

  const save = async () => {
    if (!editing) return;
    if (!editing.name?.trim()) { toast({ title: 'الاسم الإنجليزي مطلوب', variant: 'destructive' }); return; }
    if (!editing.items.length) { toast({ title: 'أضف منتج واحد على الأقل', variant: 'destructive' }); return; }
    if (!editing.bundlePriceUsd || editing.bundlePriceUsd <= 0) { toast({ title: 'سعر الحزمة لازم > 0', variant: 'destructive' }); return; }
    const payload: any = {
      name: editing.name, nameAr: editing.nameAr || null, description: editing.description || null,
      imageUrl: editing.imageUrl || null, bundlePriceUsd: Number(editing.bundlePriceUsd),
      status: editing.status || 'active', badge: editing.badge || null,
      sortOrder: Number(editing.sortOrder) || 0, isFeatured: !!editing.isFeatured,
      startsAt: editing.startsAt || null, endsAt: editing.endsAt || null,
      items: editing.items.map((i, idx) => ({ productId: i.productId, qty: i.qty, sortOrder: idx })),
    };
    try {
      if (editing.id) {
        await fetch(`${BASE}/api/admin/bundles/${editing.id}`, { method: 'PUT', headers: headers(true), body: JSON.stringify(payload) });
        toast({ title: '✅ تم الحفظ' });
      } else {
        await fetch(`${BASE}/api/admin/bundles`, { method: 'POST', headers: headers(true), body: JSON.stringify(payload) });
        toast({ title: '🎁 تم إنشاء الحزمة' });
      }
      setEditing(null);
      await load();
    } catch { toast({ title: 'فشل الحفظ', variant: 'destructive' }); }
  };

  const remove = async (id: number, name: string) => {
    if (!confirm(`حذف الحزمة "${name}" نهائياً؟`)) return;
    try {
      await fetch(`${BASE}/api/admin/bundles/${id}`, { method: 'DELETE', headers: headers() });
      toast({ title: '🗑️ تم الحذف' });
      setBundles(bs => bs.filter(b => b.id !== id));
    } catch { toast({ title: 'فشل', variant: 'destructive' }); }
  };

  const toggleStatus = async (b: Bundle) => {
    const newStatus = b.status === 'active' ? 'inactive' : 'active';
    try {
      await fetch(`${BASE}/api/admin/bundles/${b.id}`, { method: 'PUT', headers: headers(true), body: JSON.stringify({ status: newStatus }) });
      setBundles(bs => bs.map(x => x.id === b.id ? { ...x, status: newStatus } : x));
    } catch { toast({ title: 'فشل', variant: 'destructive' }); }
  };

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-5" dir="rtl">
          <div className="flex flex-wrap items-center gap-3 justify-between">
            <div>
              <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
                <Gift className="text-primary" size={26} />
                الحزم والعروض
              </h1>
              <p className="text-muted-foreground text-sm mt-1">
                اجمع كم منتج بسعر مخصوم. الزبون يطلب الحزمة بضغطة وحدة.
              </p>
            </div>
            <button onClick={() => setEditing(emptyForm())}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground hover:opacity-90 font-semibold text-sm">
              <Plus size={16} /> حزمة جديدة
            </button>
          </div>

          {loading ? (
            <div className="text-center py-20 text-muted-foreground">جاري التحميل...</div>
          ) : bundles.length === 0 ? (
            <div className="text-center py-20 bg-card border border-border rounded-2xl">
              <Gift className="mx-auto mb-3 text-muted-foreground/30" size={48} />
              <p className="text-muted-foreground mb-3">ما عندك حزم. أنشئ أولى حزمك وزِد مبيعاتك.</p>
              <button onClick={() => setEditing(emptyForm())} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold text-sm">
                <Plus size={16} /> ابدأ الآن
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {bundles.map(b => (
                <div key={b.id} className="bg-card border border-border rounded-2xl p-4 flex flex-col gap-3">
                  <div className="flex gap-3">
                    {b.imageUrl ? (
                      <img src={b.imageUrl} alt={b.name} className="w-20 h-20 rounded-xl object-cover bg-muted" />
                    ) : (
                      <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-primary/20 to-purple-500/20 flex items-center justify-center">
                        <Gift size={32} className="text-primary" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-base truncate">{b.nameAr || b.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{b.items.length} منتج</div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-lg font-extrabold text-primary">${b.bundlePriceUsd.toFixed(2)}</span>
                        {b.savingsUsd > 0 && (
                          <span className="text-[10px] line-through text-muted-foreground">${b.originalTotalUsd.toFixed(2)}</span>
                        )}
                        {b.savingsPercent > 0 && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-success/15 text-success">-{b.savingsPercent}%</span>
                        )}
                      </div>
                      <div className="flex gap-1 mt-1.5 flex-wrap">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${b.status === 'active' ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
                          {b.status === 'active' ? 'فعّالة' : 'متوقفة'}
                        </span>
                        {b.isFeatured && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400">⭐ مميزة</span>}
                        {b.badge && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-primary/15 text-primary">{b.badge}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    <button onClick={() => setEditing({ ...b })}
                      className="flex-1 text-xs py-2 rounded-lg bg-muted hover:bg-muted/80 flex items-center justify-center gap-1">
                      <Edit3 size={12} /> تعديل
                    </button>
                    <button onClick={() => toggleStatus(b)}
                      className="flex-1 text-xs py-2 rounded-lg bg-amber-500/15 text-amber-400 border border-amber-500/30 hover:bg-amber-500/25 flex items-center justify-center gap-1">
                      <Power size={12} /> {b.status === 'active' ? 'إيقاف' : 'تفعيل'}
                    </button>
                    <button onClick={() => remove(b.id, b.nameAr || b.name)}
                      className="text-xs py-2 px-2.5 rounded-lg bg-destructive/15 text-destructive border border-destructive/30 hover:bg-destructive/25">
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {editing && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl" onClick={() => setEditing(null)}>
            <div className="bg-card border border-border rounded-2xl p-5 max-w-3xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading text-xl font-bold flex items-center gap-2">
                  <Gift className="text-primary" size={22} />
                  {editing.id ? 'تعديل حزمة' : 'حزمة جديدة'}
                </h2>
                <button onClick={() => setEditing(null)} className="p-2 rounded-lg hover:bg-muted"><X size={18} /></button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">الاسم بالعربي</span>
                  <input value={editing.nameAr || ''} onChange={(e) => setEditing({ ...editing, nameAr: e.target.value })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" placeholder="مثلاً: حزمة لاعب VIP" />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">الاسم بالإنجليزي *</span>
                  <input value={editing.name || ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" placeholder="VIP Player Bundle" />
                </label>
                <label className="text-xs md:col-span-2">
                  <span className="block mb-1 text-muted-foreground">وصف الحزمة</span>
                  <textarea value={editing.description || ''} onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                    rows={2} className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" placeholder="مزايا الحزمة..." />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">صورة (URL)</span>
                  <input value={editing.imageUrl || ''} onChange={(e) => setEditing({ ...editing, imageUrl: e.target.value })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" placeholder="https://..." />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">شارة (اختياري)</span>
                  <input value={editing.badge || ''} onChange={(e) => setEditing({ ...editing, badge: e.target.value })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" placeholder="🔥 الأكثر طلباً" />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">سعر الحزمة (USD) *</span>
                  <input type="number" step="0.01" value={editing.bundlePriceUsd ?? 0} onChange={(e) => setEditing({ ...editing, bundlePriceUsd: Number(e.target.value) })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm font-bold" />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">ترتيب العرض</span>
                  <input type="number" value={editing.sortOrder ?? 0} onChange={(e) => setEditing({ ...editing, sortOrder: Number(e.target.value) })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">يبدأ بـ (اختياري)</span>
                  <input type="datetime-local" value={editing.startsAt ? String(editing.startsAt).slice(0, 16) : ''} onChange={(e) => setEditing({ ...editing, startsAt: e.target.value })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" />
                </label>
                <label className="text-xs">
                  <span className="block mb-1 text-muted-foreground">ينتهي بـ (اختياري)</span>
                  <input type="datetime-local" value={editing.endsAt ? String(editing.endsAt).slice(0, 16) : ''} onChange={(e) => setEditing({ ...editing, endsAt: e.target.value })}
                    className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm" />
                </label>
                <label className="text-xs flex items-center gap-2 mt-1">
                  <input type="checkbox" checked={!!editing.isFeatured} onChange={(e) => setEditing({ ...editing, isFeatured: e.target.checked })} />
                  <Star size={14} className="text-amber-400" /> حزمة مميزة (تظهر بالأعلى)
                </label>
                <label className="text-xs flex items-center gap-2 mt-1">
                  <input type="checkbox" checked={editing.status === 'active'} onChange={(e) => setEditing({ ...editing, status: e.target.checked ? 'active' : 'inactive' })} />
                  <Power size={14} className="text-success" /> فعّالة (ظاهرة للزبائن)
                </label>
              </div>

              <div className="border-t border-border pt-4 mb-4">
                <h3 className="font-bold text-sm mb-2">منتجات الحزمة ({editing.items.length})</h3>
                {editing.items.length > 0 && (
                  <div className="space-y-1.5 mb-3">
                    {editing.items.map((it) => {
                      const p = productMap.get(it.productId);
                      return (
                        <div key={it.productId} className="flex items-center gap-2 bg-muted/40 rounded-lg p-2">
                          {p?.imageUrl ? <img src={p.imageUrl} className="w-10 h-10 rounded object-cover" alt="" /> : <div className="w-10 h-10 rounded bg-muted" />}
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-semibold truncate">{p?.name || it.productId}</div>
                            <div className="text-[10px] text-muted-foreground">${(p?.priceUsd ?? 0).toFixed(2)} × {it.qty} = ${((p?.priceUsd ?? 0) * it.qty).toFixed(2)}</div>
                          </div>
                          <input type="number" min={1} value={it.qty} onChange={(e) => updateItemQty(it.productId, Number(e.target.value))}
                            className="w-16 bg-background border border-border rounded px-2 py-1 text-xs text-center" />
                          <button onClick={() => removeItem(it.productId)} className="p-1.5 rounded bg-destructive/15 text-destructive hover:bg-destructive/25">
                            <X size={14} />
                          </button>
                        </div>
                      );
                    })}
                    <div className="flex justify-between items-center text-xs px-2 pt-1">
                      <span className="text-muted-foreground">السعر الأصلي:</span>
                      <span className="font-bold">${computedOriginal.toFixed(2)}</span>
                    </div>
                    {editing.bundlePriceUsd && Number(editing.bundlePriceUsd) > 0 && computedOriginal > Number(editing.bundlePriceUsd) && (
                      <div className="flex justify-between items-center text-xs px-2 text-success">
                        <span>التوفير:</span>
                        <span className="font-bold">${(computedOriginal - Number(editing.bundlePriceUsd)).toFixed(2)} ({Math.round(((computedOriginal - Number(editing.bundlePriceUsd)) / computedOriginal) * 100)}%)</span>
                      </div>
                    )}
                  </div>
                )}

                <div className="bg-background border border-border rounded-lg p-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Search size={14} className="text-muted-foreground" />
                    <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث عن منتج لإضافته..."
                      className="flex-1 bg-transparent text-sm outline-none" />
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {filteredProducts.map(p => (
                      <button key={p.id} onClick={() => addItem(p.id)} type="button"
                        className="w-full flex items-center gap-2 p-1.5 rounded hover:bg-muted text-right">
                        {p.imageUrl ? <img src={p.imageUrl} className="w-8 h-8 rounded object-cover" alt="" /> : <div className="w-8 h-8 rounded bg-muted" />}
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold truncate">{p.name}</div>
                          <div className="text-[10px] text-muted-foreground">${p.priceUsd.toFixed(2)}</div>
                        </div>
                        <Plus size={14} className="text-primary" />
                      </button>
                    ))}
                    {filteredProducts.length === 0 && <div className="text-xs text-center text-muted-foreground py-3">لا منتجات مطابقة</div>}
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button onClick={save} className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:opacity-90">
                  <Save size={16} /> {editing.id ? 'حفظ التعديلات' : 'إنشاء الحزمة'}
                </button>
                <button onClick={() => setEditing(null)} className="px-5 py-2.5 rounded-xl bg-muted hover:bg-muted/80 text-sm">إلغاء</button>
              </div>
            </div>
          </div>
        )}
      </DashboardLayout>
    </ProtectedRoute>
  );
}
