import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Bell, Send, Users, User, Megaphone, Tag, Info, AlertTriangle, Clock, CheckCircle2, Loader2, Trash2 } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

type NotifType = 'announcement' | 'offer' | 'info' | 'warning';

const TYPE_CONFIG: Record<NotifType, { label: string; icon: any; color: string; bg: string }> = {
  announcement: { label: 'إعلان عام', icon: Megaphone, color: 'text-primary', bg: 'bg-primary/15 border-primary/20' },
  offer:        { label: 'عرض خاص',  icon: Tag,      color: 'text-yellow-400', bg: 'bg-yellow-400/15 border-yellow-400/20' },
  info:         { label: 'معلومة',    icon: Info,     color: 'text-blue-400',   bg: 'bg-blue-400/15 border-blue-400/20' },
  warning:      { label: 'تنبيه',     icon: AlertTriangle, color: 'text-orange-400', bg: 'bg-orange-400/15 border-orange-400/20' },
};

function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'الآن';
  if (mins < 60) return `منذ ${mins} دقيقة`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `منذ ${hours} ساعة`;
  const days = Math.floor(hours / 24);
  return `منذ ${days} يوم`;
}

export default function AdminNotifications() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const [title, setTitle]       = useState('');
  const [message, setMessage]   = useState('');
  const [type, setType]         = useState<NotifType>('announcement');
  const [target, setTarget]     = useState<'all' | 'user'>('all');
  const [userId, setUserId]     = useState('');
  const [sent, setSent]         = useState<{ count: number; ts: Date } | null>(null);

  const { data: history = [], isLoading: histLoading } = useQuery({
    queryKey: ['admin-notif-history'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/admin/notifications/history?limit=30`, { headers: authHeaders() });
      if (!res.ok) throw new Error('failed');
      return res.json() as Promise<any[]>;
    },
    staleTime: 30_000,
  });

  const { data: users = [] } = useQuery({
    queryKey: ['admin-users-list'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/admin/users?limit=200&page=1`, { headers: authHeaders() });
      if (!res.ok) throw new Error('failed');
      const data = await res.json();
      return (data.users ?? []) as { id: number; username: string; email: string }[];
    },
    staleTime: 60_000,
  });

  const sendMutation = useMutation({
    mutationFn: async () => {
      const body: any = { title: title.trim(), message: message.trim(), type };
      if (target === 'user' && userId) body.targetUserId = parseInt(userId, 10);
      const res = await fetch(`${BASE}/api/admin/notifications/broadcast`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'خطأ في الإرسال');
      return data as { success: boolean; sent: number };
    },
    onSuccess: (data) => {
      setSent({ count: data.sent, ts: new Date() });
      setTitle('');
      setMessage('');
      qc.invalidateQueries({ queryKey: ['admin-notif-history'] });
      toast({ title: 'تم الإرسال', description: `تم إرسال الإشعار لـ ${data.sent} مستخدم` });
    },
    onError: (err: any) => {
      toast({ title: 'خطأ', description: err.message, variant: 'destructive' });
    },
  });

  const canSend = title.trim().length > 0 && message.trim().length > 0 && !(target === 'user' && !userId);

  const TypeIcon = TYPE_CONFIG[type].icon;

  const grouped = React.useMemo(() => {
    const map = new Map<string, { title: string; message: string; type: string; count: number; at: string; users: string[] }>();
    for (const n of history) {
      const key = `${n.title}||${n.message}||${n.type}||${n.createdAt}`;
      if (!map.has(key)) {
        map.set(key, { title: n.title, message: n.message, type: n.type, count: 0, at: n.createdAt, users: [] });
      }
      const entry = map.get(key)!;
      entry.count++;
      if (n.username) entry.users.push(n.username);
    }
    return Array.from(map.values());
  }, [history]);

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6" dir="rtl">

          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/20 flex items-center justify-center">
              <Bell size={18} className="text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-black">إشعارات العملاء</h1>
              <p className="text-xs text-muted-foreground">أرسل إعلانات وعروض لجميع المستخدمين أو لمستخدم بعينه</p>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
            className="bg-card border border-border rounded-2xl p-5 space-y-5">

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(Object.keys(TYPE_CONFIG) as NotifType[]).map(k => {
                const cfg = TYPE_CONFIG[k];
                const Icon = cfg.icon;
                return (
                  <button key={k} onClick={() => setType(k)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-sm font-semibold transition-all ${type === k ? cfg.bg + ' ' + cfg.color : 'border-border text-muted-foreground hover:border-border/80 hover:text-foreground'}`}>
                    <Icon size={15} />
                    {cfg.label}
                  </button>
                );
              })}
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <button onClick={() => setTarget('all')}
                className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm font-semibold transition-all ${target === 'all' ? 'bg-primary/15 border-primary/30 text-primary' : 'border-border text-muted-foreground hover:text-foreground'}`}>
                <Users size={16} />
                إرسال لجميع المستخدمين
                <span className="mr-auto text-xs opacity-70">({users.length})</span>
              </button>
              <button onClick={() => setTarget('user')}
                className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm font-semibold transition-all ${target === 'user' ? 'bg-primary/15 border-primary/30 text-primary' : 'border-border text-muted-foreground hover:text-foreground'}`}>
                <User size={16} />
                إرسال لمستخدم محدد
              </button>
            </div>

            <AnimatePresence>
              {target === 'user' && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                  <select value={userId} onChange={e => setUserId(e.target.value)}
                    className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30">
                    <option value="">-- اختر مستخدم --</option>
                    {users.map(u => (
                      <option key={u.id} value={u.id}>{u.username} ({u.email})</option>
                    ))}
                  </select>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-3">
              <div className="relative">
                <input
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="عنوان الإشعار"
                  maxLength={100}
                  className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[11px] text-muted-foreground">{title.length}/100</span>
              </div>
              <div className="relative">
                <textarea
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="نص الإشعار..."
                  rows={4}
                  maxLength={500}
                  className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground resize-none"
                />
                <span className="absolute left-3 bottom-3 text-[11px] text-muted-foreground">{message.length}/500</span>
              </div>
            </div>

            {title.trim() && message.trim() && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className={`border rounded-xl p-4 ${TYPE_CONFIG[type].bg}`}>
                <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-1.5">معاينة</p>
                <div className="flex items-start gap-2.5">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center border ${TYPE_CONFIG[type].bg}`}>
                    <TypeIcon size={14} className={TYPE_CONFIG[type].color} />
                  </div>
                  <div>
                    <p className="text-sm font-bold">{title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{message}</p>
                  </div>
                </div>
              </motion.div>
            )}

            <AnimatePresence>
              {sent && (
                <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="flex items-center gap-2 text-green-400 text-sm bg-green-400/10 border border-green-400/20 rounded-xl px-4 py-3">
                  <CheckCircle2 size={16} />
                  تم إرسال الإشعار لـ <strong>{sent.count}</strong> مستخدم بنجاح
                </motion.div>
              )}
            </AnimatePresence>

            <button
              onClick={() => sendMutation.mutate()}
              disabled={!canSend || sendMutation.isPending}
              className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-all text-sm">
              {sendMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              {sendMutation.isPending ? 'جارٍ الإرسال...' : 'إرسال الإشعار'}
            </button>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border flex items-center gap-2">
              <Clock size={15} className="text-muted-foreground" />
              <h2 className="font-bold text-sm">سجل الإشعارات المُرسَلة</h2>
            </div>

            {histLoading ? (
              <div className="flex items-center justify-center py-10">
                <Loader2 size={20} className="animate-spin text-muted-foreground" />
              </div>
            ) : grouped.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center gap-2">
                <Bell size={28} className="text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">لا توجد إشعارات مُرسَلة بعد</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {grouped.map((n, i) => {
                  const cfg = TYPE_CONFIG[n.type as NotifType] ?? TYPE_CONFIG.announcement;
                  const Icon = cfg.icon;
                  return (
                    <motion.div key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                      className="px-5 py-4 flex items-start gap-3 hover:bg-background/50 transition-colors">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center border shrink-0 mt-0.5 ${cfg.bg}`}>
                        <Icon size={14} className={cfg.color} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-bold">{n.title}</p>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                            <Users size={10} />
                            {n.count === 1 && n.users[0] ? n.users[0] : `${n.count} مستخدم`}
                          </span>
                          <span className="text-[11px] text-muted-foreground">{timeAgo(n.at)}</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </motion.div>

        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
