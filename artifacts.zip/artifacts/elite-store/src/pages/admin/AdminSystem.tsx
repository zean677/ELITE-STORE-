import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import {
  Activity, RefreshCw, CheckCircle2, XCircle, AlertTriangle, Database, Send,
  Cpu, HardDrive, Server, ShoppingBag, DollarSign, Clock, Zap, Wallet,
  Link2, Loader2, MessageCircle,
} from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

type Status = 'ok' | 'error' | 'not_configured';

interface SystemData {
  status: 'healthy' | 'degraded';
  timestamp: string;
  uptime: { seconds: number; human: string };
  database: { status: Status; latencyMs: number };
  telegram: { status: Status; configured: boolean; adminChatConfigured: boolean };
  providers: Record<string, { configured: boolean; balance: number | null; email: string | null; error: string | null }>;
  env: { jwtSecret: boolean; siteUrl: string; nodeEnv: string };
  orders: { last24h: number; last7d: number; pending: number; failed24h: number; revenue24h: number };
  memory: { usedMb: number; totalMb: number };
  load: { '1m': string; '5m': string; '15m': string };
  responseMs: number;
}

function StatusDot({ status }: { status: Status }) {
  if (status === 'ok') return <span className="inline-flex items-center gap-1.5 text-emerald-400 font-bold text-xs"><CheckCircle2 size={14} />متصل</span>;
  if (status === 'error') return <span className="inline-flex items-center gap-1.5 text-red-400 font-bold text-xs"><XCircle size={14} />خطأ</span>;
  return <span className="inline-flex items-center gap-1.5 text-amber-400 font-bold text-xs"><AlertTriangle size={14} />غير مهيّأ</span>;
}

function Card({ icon: Icon, title, children, color = 'primary' }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-2xl p-4 sm:p-5"
    >
      <div className="flex items-center gap-2.5 mb-3">
        <div className={`w-9 h-9 rounded-xl bg-${color}/15 border border-${color}/20 flex items-center justify-center`}>
          <Icon size={16} className={`text-${color}`} />
        </div>
        <h3 className="font-black text-foreground text-sm">{title}</h3>
      </div>
      {children}
    </motion.div>
  );
}

function Row({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5 text-xs border-b border-border/40 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-bold text-foreground ${mono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}

interface WebhookInfo {
  url?: string;
  pending_update_count?: number;
  last_error_date?: number;
  last_error_message?: string;
  ip_address?: string;
  max_connections?: number;
}

export default function AdminSystem() {
  const [data, setData] = useState<SystemData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastFetch, setLastFetch] = useState<Date | null>(null);
  const [webhook, setWebhook] = useState<WebhookInfo | null>(null);
  const [webhookLoading, setWebhookLoading] = useState(false);
  const [webhookAction, setWebhookAction] = useState<string | null>(null);
  const [webhookMsg, setWebhookMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const authHeaders = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token')}` });

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/system`, { headers: authHeaders() });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
      setLastFetch(new Date());
    } catch (e: any) {
      setError(e.message ?? 'فشل الاتصال');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchWebhook = useCallback(async () => {
    setWebhookLoading(true);
    try {
      const res = await fetch(`${BASE}/api/admin/telegram/webhook-info`, { headers: authHeaders() });
      const json = await res.json();
      if (json.ok) setWebhook(json.info ?? {});
    } catch {} finally { setWebhookLoading(false); }
  }, []);

  const rebindWebhook = async () => {
    setWebhookAction('rebind'); setWebhookMsg(null);
    try {
      const res = await fetch(`${BASE}/api/admin/telegram/set-webhook`, { method: 'POST', headers: authHeaders() });
      const json = await res.json();
      if (json.ok) {
        setWebhook(json.info ?? {});
        setWebhookMsg({ type: 'ok', text: 'تم إعادة ربط الويبهوك بنجاح ✓' });
      } else throw new Error(json.error ?? 'فشل');
    } catch (e: any) {
      setWebhookMsg({ type: 'err', text: e.message ?? 'فشل إعادة الربط' });
    } finally { setWebhookAction(null); setTimeout(() => setWebhookMsg(null), 5000); }
  };

  const sendTest = async () => {
    setWebhookAction('test'); setWebhookMsg(null);
    try {
      const res = await fetch(`${BASE}/api/admin/telegram/test`, { method: 'POST', headers: authHeaders() });
      const json = await res.json();
      setWebhookMsg({ type: json.ok ? 'ok' : 'err', text: json.message ?? (json.ok ? 'تم الإرسال' : 'فشل الإرسال') });
    } catch (e: any) {
      setWebhookMsg({ type: 'err', text: e.message ?? 'فشل الإرسال' });
    } finally { setWebhookAction(null); setTimeout(() => setWebhookMsg(null), 5000); }
  };

  useEffect(() => { fetchData(); fetchWebhook(); }, [fetchData, fetchWebhook]);
  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(fetchData, 15000);
    return () => clearInterval(id);
  }, [autoRefresh, fetchData]);

  const overallHealthy = data?.status === 'healthy';

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-5 pb-8">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl sm:text-3xl font-black flex items-center gap-2">
                <Activity className="text-primary" size={26} />
                حالة النظام
              </h1>
              <p className="text-xs text-muted-foreground mt-1">
                {lastFetch ? `آخر تحديث: ${lastFetch.toLocaleTimeString('ar-EG')}` : 'لم يتم التحديث بعد'}
                {data && ` • استجابة في ${data.responseMs}ms`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
                <input type="checkbox" checked={autoRefresh} onChange={e => setAutoRefresh(e.target.checked)}
                  className="w-4 h-4 accent-primary" />
                تحديث تلقائي (15s)
              </label>
              <button onClick={fetchData} disabled={loading}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-white font-bold rounded-xl hover:bg-primary/90 disabled:opacity-50 text-sm">
                <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
                تحديث
              </button>
            </div>
          </div>

          {/* Big status banner */}
          {data && (
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`rounded-3xl p-5 border ${
                overallHealthy
                  ? 'bg-emerald-500/10 border-emerald-500/30'
                  : 'bg-red-500/10 border-red-500/30'
              }`}
            >
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  {overallHealthy ? (
                    <CheckCircle2 className="text-emerald-400" size={32} />
                  ) : (
                    <XCircle className="text-red-400" size={32} />
                  )}
                  <div>
                    <h2 className={`text-xl font-black ${overallHealthy ? 'text-emerald-300' : 'text-red-300'}`}>
                      {overallHealthy ? 'جميع الأنظمة تعمل بكفاءة' : 'يوجد مشاكل في النظام'}
                    </h2>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      الخادم يعمل منذ {data.uptime.human}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-3 text-xs">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <Database size={13} /> DB: <StatusDot status={data.database.status} />
                  </span>
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <Send size={13} /> Telegram: <StatusDot status={data.telegram.status} />
                  </span>
                </div>
              </div>
            </motion.div>
          )}

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-4 text-sm text-red-300">
              <AlertTriangle className="inline ml-2" size={16} />
              فشل تحميل بيانات النظام: {error}
            </div>
          )}

          {data && (
            <>
              {/* Today's orders quick stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  className="bg-gradient-to-br from-primary/15 to-primary/5 border border-primary/30 rounded-2xl p-4">
                  <ShoppingBag className="text-primary mb-2" size={18} />
                  <p className="text-xs text-muted-foreground">طلبات آخر 24 ساعة</p>
                  <p className="text-2xl font-black mt-1">{data.orders.last24h}</p>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.05 } }}
                  className="bg-gradient-to-br from-emerald-500/15 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-4">
                  <DollarSign className="text-emerald-400 mb-2" size={18} />
                  <p className="text-xs text-muted-foreground">إيرادات اليوم</p>
                  <p className="text-2xl font-black mt-1 text-emerald-300">${data.orders.revenue24h.toFixed(2)}</p>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.1 } }}
                  className="bg-gradient-to-br from-amber-500/15 to-amber-500/5 border border-amber-500/30 rounded-2xl p-4">
                  <Clock className="text-amber-400 mb-2" size={18} />
                  <p className="text-xs text-muted-foreground">طلبات معلّقة</p>
                  <p className="text-2xl font-black mt-1 text-amber-300">{data.orders.pending}</p>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.15 } }}
                  className={`bg-gradient-to-br ${data.orders.failed24h > 0 ? 'from-red-500/15 to-red-500/5 border-red-500/30' : 'from-card to-card border-border'} border rounded-2xl p-4`}>
                  <XCircle className={`mb-2 ${data.orders.failed24h > 0 ? 'text-red-400' : 'text-muted-foreground'}`} size={18} />
                  <p className="text-xs text-muted-foreground">فشل اليوم</p>
                  <p className={`text-2xl font-black mt-1 ${data.orders.failed24h > 0 ? 'text-red-300' : ''}`}>{data.orders.failed24h}</p>
                </motion.div>
              </div>

              {/* Telegram Webhook details */}
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gradient-to-br from-sky-500/10 to-primary/5 border border-sky-500/30 rounded-2xl p-4 sm:p-5"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center">
                      <Link2 size={16} className="text-sky-400" />
                    </div>
                    <div>
                      <h3 className="font-black text-sm">تفاصيل ويبهوك Telegram</h3>
                      <p className="text-[11px] text-muted-foreground">اتصال البوت المباشر مع Telegram</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={fetchWebhook} disabled={webhookLoading}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-card border border-border rounded-xl text-xs font-bold hover:bg-muted disabled:opacity-50">
                      <RefreshCw size={12} className={webhookLoading ? 'animate-spin' : ''} />
                      تحديث
                    </button>
                    <button onClick={sendTest} disabled={webhookAction !== null}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-500/15 border border-violet-500/40 text-violet-300 rounded-xl text-xs font-bold hover:bg-violet-500/25 disabled:opacity-50">
                      {webhookAction === 'test' ? <Loader2 size={12} className="animate-spin" /> : <MessageCircle size={12} />}
                      إرسال رسالة اختبار
                    </button>
                    <button onClick={rebindWebhook} disabled={webhookAction !== null}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-xl text-xs font-bold hover:bg-primary/90 disabled:opacity-50">
                      {webhookAction === 'rebind' ? <Loader2 size={12} className="animate-spin" /> : <Link2 size={12} />}
                      إعادة ربط الويبهوك
                    </button>
                  </div>
                </div>

                {webhookMsg && (
                  <div className={`mb-3 px-3 py-2 rounded-xl text-xs font-bold ${
                    webhookMsg.type === 'ok' ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      : 'bg-red-500/15 text-red-300 border border-red-500/30'
                  }`}>
                    {webhookMsg.text}
                  </div>
                )}

                {webhook ? (
                  <div className="space-y-2">
                    <div className="bg-background/60 rounded-xl p-3 border border-border/40">
                      <p className="text-[10px] text-muted-foreground mb-1">رابط الويبهوك الحالي</p>
                      <p className="font-mono text-[11px] break-all text-sky-300">
                        {webhook.url || <span className="text-amber-400">لا يوجد ويبهوك مسجّل</span>}
                      </p>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div className="bg-background/60 rounded-xl p-2.5 border border-border/40">
                        <p className="text-[10px] text-muted-foreground">تحديثات معلّقة</p>
                        <p className={`text-lg font-black ${(webhook.pending_update_count ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                          {webhook.pending_update_count ?? 0}
                        </p>
                      </div>
                      <div className="bg-background/60 rounded-xl p-2.5 border border-border/40">
                        <p className="text-[10px] text-muted-foreground">عنوان IP</p>
                        <p className="font-mono text-xs font-bold mt-0.5">{webhook.ip_address || '—'}</p>
                      </div>
                      <div className="bg-background/60 rounded-xl p-2.5 border border-border/40">
                        <p className="text-[10px] text-muted-foreground">أقصى اتصالات</p>
                        <p className="text-lg font-black mt-0.5">{webhook.max_connections ?? '—'}</p>
                      </div>
                      <div className="bg-background/60 rounded-xl p-2.5 border border-border/40">
                        <p className="text-[10px] text-muted-foreground">آخر خطأ</p>
                        <p className="text-xs font-bold mt-0.5">
                          {webhook.last_error_date
                            ? new Date(webhook.last_error_date * 1000).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })
                            : <span className="text-emerald-400">لا يوجد ✓</span>}
                        </p>
                      </div>
                    </div>
                    {webhook.last_error_message && (
                      <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-2.5 text-[11px] text-red-300">
                        <span className="font-bold">رسالة الخطأ الأخيرة: </span>
                        {webhook.last_error_message}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground text-xs">
                    {webhookLoading ? 'جاري التحميل...' : 'اضغط "تحديث" لجلب معلومات الويبهوك'}
                  </div>
                )}
              </motion.div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Telegram Bot */}
                <Card icon={Send} title="بوت Telegram" color="primary">
                  <Row label="حالة الاتصال" value={<StatusDot status={data.telegram.status} />} />
                  <Row label="توكن البوت" value={data.telegram.configured ? '✓ مهيّأ' : '✗ غير مهيّأ'} />
                  <Row label="معرّف المسؤول" value={data.telegram.adminChatConfigured ? '✓ مهيّأ' : '✗ غير مهيّأ'} />
                  {data.telegram.status === 'error' && (
                    <p className="mt-2 text-[11px] text-red-300 bg-red-500/10 rounded-lg p-2">
                      البوت غير قادر على الاتصال بـ Telegram. تحقّق من صحة التوكن.
                    </p>
                  )}
                </Card>

                {/* Database */}
                <Card icon={Database} title="قاعدة البيانات" color="emerald-500">
                  <Row label="حالة الاتصال" value={<StatusDot status={data.database.status} />} />
                  <Row label="زمن الاستجابة" value={<span className={data.database.latencyMs > 100 ? 'text-amber-400' : 'text-emerald-400'}>{data.database.latencyMs}ms</span>} />
                  <Row label="بيئة التشغيل" value={data.env.nodeEnv} />
                  <Row label="JWT Secret" value={data.env.jwtSecret ? '✓ مهيّأ' : '✗ مفقود'} />
                </Card>

                {/* Providers */}
                <Card icon={Wallet} title="مزوّدو الخدمة" color="violet-500">
                  {Object.entries(data.providers).map(([name, p]) => (
                    <div key={name} className="py-2 border-b border-border/40 last:border-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-xs uppercase">{name}</span>
                        <div className="flex items-center gap-2">
                          {p.configured ? (
                            p.error ? <span className="text-red-400 text-[11px] font-bold">خطأ</span>
                              : <span className="text-emerald-400 text-[11px] font-bold">${(p.balance ?? 0).toFixed(2)}</span>
                          ) : <span className="text-amber-400 text-[11px] font-bold">غير مهيّأ</span>}
                          <button
                            onClick={async () => {
                              const tk = localStorage.getItem('elite_token');
                              const res = await fetch(`/api/admin/providers/test`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tk}` },
                                body: JSON.stringify({ provider: name }),
                              });
                              const j = await res.json();
                              alert(j.ok
                                ? `✅ ${name}: نجح الاتصال (${j.latencyMs}ms)\nالرصيد: $${j.balance ?? '-'}`
                                : `❌ ${name}: فشل\n${j.error || 'خطأ غير معروف'}`);
                              fetchData();
                            }}
                            className="px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-[10px] font-bold hover:bg-cyan-500/30"
                          >
                            اختبار الآن
                          </button>
                        </div>
                      </div>
                      {p.email && <p className="text-[10px] text-muted-foreground mt-0.5">{p.email}</p>}
                      {p.error && <p className="text-[10px] text-red-300 mt-0.5">{p.error}</p>}
                    </div>
                  ))}
                </Card>

                {/* Server */}
                <Card icon={Server} title="الخادم" color="cyan-500">
                  <Row label="مدة التشغيل" value={data.uptime.human} />
                  <Row
                    label="استخدام الذاكرة"
                    value={
                      <span>
                        {data.memory.usedMb} / {data.memory.totalMb} MB
                      </span>
                    }
                  />
                  <Row label="الحمل (1m)" value={data.load['1m']} mono />
                  <Row label="الحمل (5m)" value={data.load['5m']} mono />
                  <Row label="رابط الموقع" value={<span className="text-[11px]">{data.env.siteUrl}</span>} />
                </Card>

                {/* Orders week */}
                <Card icon={ShoppingBag} title="إحصائيات الطلبات" color="primary">
                  <Row label="آخر 24 ساعة" value={data.orders.last24h} />
                  <Row label="آخر 7 أيام" value={data.orders.last7d} />
                  <Row label="معلّقة الآن" value={<span className={data.orders.pending > 5 ? 'text-amber-400' : ''}>{data.orders.pending}</span>} />
                  <Row label="فاشلة (24س)" value={<span className={data.orders.failed24h > 0 ? 'text-red-400' : ''}>{data.orders.failed24h}</span>} />
                  <Row label="إيرادات اليوم" value={`$${data.orders.revenue24h.toFixed(2)}`} />
                </Card>

                {/* Performance */}
                <Card icon={Zap} title="الأداء" color="amber-500">
                  <Row label="استجابة API" value={<span className={data.responseMs > 500 ? 'text-amber-400' : 'text-emerald-400'}>{data.responseMs}ms</span>} />
                  <Row label="استعلام DB" value={`${data.database.latencyMs}ms`} />
                  <Row label="استخدام الذاكرة" value={`${Math.round((data.memory.usedMb / data.memory.totalMb) * 100)}%`} />
                  <Row label="آخر فحص" value={new Date(data.timestamp).toLocaleTimeString('ar-EG')} />
                </Card>
              </div>
            </>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
