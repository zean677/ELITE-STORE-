import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { useGetAdminDashboard, useGetAdminOrders } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import { useAdminWs } from '@/hooks/use-admin-ws';
import {
  Users, Package, CreditCard, TrendingUp, ChevronRight, RefreshCw, Layers,
  Tag, DollarSign, AlertTriangle, Wifi, WifiOff, Zap, BarChart3, ShieldCheck,
  Activity, Clock, TrendingDown, MessageCircle,
} from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const fadeUp = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0, transition: { duration: 0.35 } } };

function StatCard({ icon: Icon, label, value, sub, color, live }: { icon: any; label: string; value: string; sub?: string; color: string; live?: boolean }) {
  return (
    <motion.div variants={fadeUp} className="bg-card border border-border rounded-2xl p-5 relative overflow-hidden">
      {live && (
        <span className="absolute top-3 left-3 flex items-center gap-1">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
          </span>
        </span>
      )}
      <div className={`w-10 h-10 rounded-xl bg-${color}/15 border border-${color}/20 flex items-center justify-center mb-3`}>
        <Icon size={18} className={`text-${color}`} />
      </div>
      <p className="text-muted-foreground text-xs font-medium">{label}</p>
      <p className="text-2xl font-black mt-1">{value}</p>
      {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
    </motion.div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-xl px-4 py-3 shadow-xl">
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className="text-sm font-bold text-primary">${parseFloat(payload[0]?.value ?? 0).toFixed(2)}</p>
      <p className="text-xs text-muted-foreground">{payload[1]?.value ?? 0} طلب</p>
    </div>
  );
};

export default function AdminDashboard() {
  const { data: stats } = useGetAdminDashboard();
  const { data: recentOrdersData } = useGetAdminOrders({ limit: 10, page: 1 });
  const recentOrders = recentOrdersData?.orders ?? [];

  // WebSocket live data
  const { status: wsStatus, items: wsItems } = useAdminWs({ enabled: true });
  const [liveOrderCount, setLiveOrderCount] = useState(0);
  const [liveRevenue, setLiveRevenue] = useState(0);
  const [liveFeed, setLiveFeed] = useState<Array<{ type: string; text: string; ts: number }>>([]);
  const prevWsItems = useRef(0);

  useEffect(() => {
    if (wsItems.length > prevWsItems.current) {
      const newItems = wsItems.slice(0, wsItems.length - prevWsItems.current);
      newItems.forEach(item => {
        if (item.type === 'new_order') {
          setLiveOrderCount(c => c + 1);
          setLiveFeed(f => [{ type: 'order', text: item.body, ts: item.ts }, ...f].slice(0, 8));
        }
        if (item.type === 'order_completed') {
          setLiveFeed(f => [{ type: 'completed', text: item.body, ts: item.ts }, ...f].slice(0, 8));
        }
        if (item.type === 'order_failed') {
          setLiveFeed(f => [{ type: 'failed', text: item.body, ts: item.ts }, ...f].slice(0, 8));
        }
      });
    }
    prevWsItems.current = wsItems.length;
  }, [wsItems]);

  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('30d');
  const [urgent, setUrgent] = React.useState<any>(null);
  const [sypRate, setSypRate] = React.useState(13000);

  React.useEffect(() => {
    const load = () => {
      const token = localStorage.getItem('elite_token');
      fetch(`${BASE}/api/admin/dashboard/urgent`, { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.ok ? r.json() : null).then(setUrgent).catch(() => {});
      fetch(`${BASE}/api/settings`)
        .then(r => r.ok ? r.json() : null)
        .then(s => { if (s?.syp_rate) setSypRate(parseFloat(s.syp_rate)); })
        .catch(() => {});
    };
    load(); const i = setInterval(load, 60000); return () => clearInterval(i);
  }, []);

  const urgentTotal = urgent ? (urgent.stalePendingOrders + urgent.pendingPayments + urgent.failedOrdersToday) : 0;
  const [chartData, setChartData] = React.useState<any[]>([]);
  const [loadingChart, setLoadingChart] = React.useState(false);

  const fetchChart = React.useCallback(async (p: string) => {
    setLoadingChart(true);
    try {
      const token = localStorage.getItem('elite_token');
      const res = await fetch(`${BASE}/api/admin/revenue-chart?period=${p}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setChartData(data.map((d: any) => ({
          date: new Date(d.date).toLocaleDateString('en-GB', { month: 'short', day: 'numeric' }),
          revenue: d.revenue,
          orders: d.orders,
        })));
      }
    } finally {
      setLoadingChart(false);
    }
  }, []);

  React.useEffect(() => { fetchChart(period); }, [period, fetchChart]);

  const totalRevenue = parseFloat(stats?.totalRevenue?.toString() ?? '0');
  const todayRevenue = parseFloat(stats?.revenueToday?.toString() ?? '0');
  const revenueSyp = Math.round(totalRevenue * sypRate).toLocaleString('ar-SY');
  const todaySyp = Math.round(todayRevenue * sypRate).toLocaleString('ar-SY');

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-8">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="font-heading text-2xl font-bold">لوحة الإدارة الذكية</h1>
              <p className="text-muted-foreground text-sm mt-1">مراقبة وإدارة المتجر بشكل لحظي</p>
            </div>
            <div className="flex items-center gap-2">
              {/* WS Status */}
              <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                wsStatus === 'connected' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' :
                wsStatus === 'connecting' ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' :
                'bg-red-500/10 border-red-500/30 text-red-400'
              }`}>
                {wsStatus === 'connected' ? <Wifi size={11} /> : <WifiOff size={11} />}
                {wsStatus === 'connected' ? 'مباشر' : wsStatus === 'connecting' ? 'يتصل...' : 'منقطع'}
              </span>
              <span className="px-3 py-1.5 bg-primary/15 text-primary text-xs font-semibold rounded-full border border-primary/20">Admin Panel</span>
            </div>
          </div>

          {urgentTotal > 0 && (
            <Link href="/admin/control"
              className="flex items-center gap-3 p-4 rounded-2xl border-2 border-red-500/40 bg-red-500/10 hover:bg-red-500/15 transition">
              <AlertTriangle size={20} className="text-red-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm">تحتاج اهتمامك الآن: {urgentTotal} عنصر عاجل</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {urgent.stalePendingOrders} طلب معلّق · {urgent.pendingPayments} إيداع · {urgent.failedOrdersToday} فاشل اليوم
                </p>
              </div>
              <ChevronRight size={16} className="text-muted-foreground" />
            </Link>
          )}

          {/* Live session stats bar */}
          {wsStatus === 'connected' && (liveOrderCount > 0 || liveFeed.length > 0) && (
            <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4 flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2 text-emerald-400">
                <Activity size={16} />
                <span className="text-sm font-bold">نشاط مباشر هذه الجلسة</span>
              </div>
              {liveOrderCount > 0 && (
                <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 text-xs font-bold">
                  <Zap size={11} /> {liveOrderCount} طلب جديد
                </span>
              )}
              {liveFeed[0] && (
                <span className="text-xs text-muted-foreground truncate max-w-xs">{liveFeed[0].text}</span>
              )}
            </motion.div>
          )}

          {/* Stats grid */}
          <motion.div initial="initial" animate="animate" className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            <StatCard icon={Users} label="إجمالي المستخدمين" value={String(stats?.totalUsers ?? 0)} color="primary" />
            <StatCard icon={Package} label="إجمالي الطلبات" value={String(stats?.totalOrders ?? 0)} sub={`${(stats as any)?.pendingOrders ?? 0} قيد المعالجة`} color="secondary" />
            <StatCard icon={Layers} label="المنتجات النشطة" value={String((stats as any)?.totalProducts ?? 0)} color="accent" />
            <StatCard icon={CreditCard} label="مدفوعات معلّقة" value={String(stats?.pendingPayments ?? 0)} color="accent" />
            <StatCard
              icon={TrendingUp}
              label="الإيرادات (USD)"
              value={`$${totalRevenue.toFixed(2)}`}
              sub={`اليوم: $${todayRevenue.toFixed(2)}`}
              color="success"
              live={wsStatus === 'connected'}
            />
            <StatCard
              icon={DollarSign}
              label="الإيرادات (SYP)"
              value={`${revenueSyp} ل.س`}
              sub={`اليوم: ${todaySyp} ل.س`}
              color="success"
            />
          </motion.div>

          {/* Revenue Chart */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="font-heading font-bold">مخطط الإيرادات</h2>
                <p className="text-xs text-muted-foreground mt-0.5">الإيرادات من الطلبات المكتملة</p>
              </div>
              <div className="flex gap-1.5 items-center">
                {loadingChart && <RefreshCw size={12} className="animate-spin text-muted-foreground" />}
                {(['7d', '30d', '90d'] as const).map(p => (
                  <button
                    key={p}
                    onClick={() => setPeriod(p)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${period === p ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}
                  >
                    {p === '7d' ? '7 أيام' : p === '30d' ? '30 يوم' : '90 يوم'}
                  </button>
                ))}
              </div>
            </div>
            {chartData.length === 0 ? (
              <div className="h-48 flex items-center justify-center">
                <p className="text-muted-foreground text-sm">لا توجد بيانات بعد — قم بإضافة طلبات لترى المخطط</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6C5CE7" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#6C5CE7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.4)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.4)' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="revenue" stroke="#6C5CE7" strokeWidth={2} fill="url(#revGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Recent Orders */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-bold">آخر الطلبات</h2>
                <Link href="/admin/orders" className="text-primary text-sm flex items-center gap-1 hover:underline">عرض الكل <ChevronRight size={14} /></Link>
              </div>
              <div className="bg-card border border-border rounded-2xl overflow-hidden">
                {recentOrders.length === 0 ? (
                  <div className="py-12 text-center">
                    <Package size={32} className="mx-auto text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground text-sm">لا توجد طلبات بعد</p>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {recentOrders.map(order => (
                      <div key={order.id} className="flex items-center justify-between p-4 hover:bg-background transition-colors">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">{order.productName}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">#{order.userId} · {new Date(order.createdAt).toLocaleDateString('en-GB')}</p>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-sm font-bold text-primary">${parseFloat(order.totalPrice?.toString() ?? '0').toFixed(2)}</span>
                          <StatusBadge status={order.status} size="sm" />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Links + Top Products + Live Feed */}
            <div className="space-y-4">
              {/* Live feed */}
              {liveFeed.length > 0 && (
                <div>
                  <h2 className="font-heading font-bold mb-3 flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
                    </span>
                    أحداث مباشرة
                  </h2>
                  <div className="space-y-1.5">
                    {liveFeed.slice(0, 4).map((ev, i) => (
                      <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                        className={`p-2.5 rounded-xl border text-xs ${
                          ev.type === 'completed' ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' :
                          ev.type === 'failed' ? 'bg-red-500/5 border-red-500/20 text-red-400' :
                          'bg-primary/5 border-primary/20 text-primary'
                        }`}>
                        {ev.text}
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              <h2 className="font-heading font-bold">روابط سريعة</h2>
              <div className="space-y-2">
                {[
                  { href: '/admin/payments', label: 'مراجعة المدفوعات', sub: `${stats?.pendingPayments ?? 0} معلّق`, icon: CreditCard },
                  { href: '/admin/orders', label: 'إدارة الطلبات', sub: `${(stats as any)?.pendingOrders ?? 0} قيد المعالجة`, icon: Package },
                  { href: '/admin/users', label: 'إدارة المستخدمين', sub: `${stats?.totalUsers ?? 0} مجموع`, icon: Users },
                  { href: '/admin/financial', label: '💰 التحكم المالي', sub: 'أرباح حقيقية + ذروة', icon: BarChart3 },
                  { href: '/admin/order-queue', label: '⚡ قائمة انتظار الطلبات', sub: 'مراقبة لحظية + تنبيهات', icon: Zap },
                  { href: '/admin/support', label: '💬 تذاكر الدعم', sub: 'الرد على استفسارات العملاء', icon: MessageCircle },
                  { href: '/admin/monitoring', label: '🔭 مركز المراقبة', sub: 'صحة النظام المباشرة', icon: Activity },
                  { href: '/admin/automation', label: '🤖 مركز الأتمتة', sub: 'إعدادات الأتمتة', icon: Zap },
                  { href: '/admin/security', label: '🔒 مركز الأمان', sub: 'محاولات الدخول والجلسات', icon: ShieldCheck },
                  { href: '/admin/store-editor', label: '🎨 محرر المتجر', sub: 'ألوان وأقسام وتخطيط', icon: Layers },
                  { href: '/admin/category-card-builder', label: '🗂️ محرر كروت الأقسام', sub: 'شكل وتخطيط كروت الأقسام', icon: Layers },
                  { href: '/admin/bundles', label: '🎁 الحزم والعروض', sub: 'باقات بسعر مخصوم', icon: Tag },
                  { href: '/admin/settings', label: 'الإعدادات', sub: 'مفاتيح API والإعلانات', icon: CreditCard },
                ].map(item => {
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href} className="flex items-center gap-3 w-full bg-card border border-border rounded-xl p-3.5 hover:border-primary/40 hover:bg-background transition-all">
                      <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                        <Icon size={14} className="text-primary" />
                      </div>
                      <div className="text-left min-w-0 flex-1">
                        <p className="text-xs font-semibold">{item.label}</p>
                        <p className="text-xs text-muted-foreground">{item.sub}</p>
                      </div>
                      <ChevronRight size={12} className="text-muted-foreground" />
                    </Link>
                  );
                })}
              </div>

              {/* Top Products */}
              {(stats?.topProducts?.length ?? 0) > 0 && (
                <div>
                  <h2 className="font-heading font-bold mt-5 mb-3">أكثر المنتجات مبيعاً</h2>
                  <div className="space-y-2">
                    {(stats?.topProducts ?? []).slice(0, 5).map((p: any, i: number) => (
                      <div key={p.productId} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
                        <span className="text-xs font-black text-primary w-5 shrink-0">#{i + 1}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold truncate">{p.productName}</p>
                          <p className="text-xs text-muted-foreground">{p.orderCount} طلب · ${parseFloat(p.revenue).toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
