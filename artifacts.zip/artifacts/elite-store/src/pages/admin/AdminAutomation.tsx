import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Zap, RefreshCw, CheckCircle, Clock, DollarSign, Shield, AlertTriangle, Info, Save } from 'lucide-react';
import { useToast } from '../../hooks/use-toast';
import { motion } from 'framer-motion';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

async function fetchAutomation() {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/automation/config`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error('Failed');
  return res.json() as Promise<Record<string, string>>;
}

async function saveAutomation(config: Record<string, string>) {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/automation/config`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  return res.json();
}

interface ToggleRuleProps {
  label: string;
  description: string;
  icon: React.ElementType;
  value: boolean;
  onChange: (v: boolean) => void;
  badge?: string;
  badgeColor?: string;
}

function ToggleRule({ label, description, icon: Icon, value, onChange, badge, badgeColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' }: ToggleRuleProps) {
  return (
    <div className="flex items-start justify-between gap-4 p-4 rounded-2xl border border-white/10 bg-white/5">
      <div className="flex items-start gap-3">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${value ? 'bg-emerald-500/15 text-emerald-400' : 'bg-white/10 text-muted-foreground'}`}>
          <Icon size={16} />
        </div>
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-sm">{label}</span>
            {badge && <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold ${badgeColor}`}>{badge}</span>}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{description}</p>
        </div>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`relative shrink-0 w-11 h-6 rounded-full transition-colors ${value ? 'bg-emerald-500' : 'bg-white/20'}`}
      >
        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${value ? 'right-0.5' : 'left-0.5'}`} />
      </button>
    </div>
  );
}

export default function AdminAutomation() {
  const { toast } = useToast();
  const { data, isLoading } = useQuery({ queryKey: ['admin', 'automation'], queryFn: fetchAutomation, staleTime: 60_000 });

  const [config, setConfig] = useState<Record<string, string>>({});
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (data) { setConfig({ ...data }); setDirty(false); }
  }, [data]);

  const setVal = (key: string, value: string) => {
    setConfig(prev => ({ ...prev, [key]: value }));
    setDirty(true);
  };
  const setBool = (key: string, v: boolean) => setVal(key, v ? 'true' : 'false');
  const bool = (key: string) => config[key] !== 'false';
  const num = (key: string, def: number) => parseInt(config[key] ?? String(def), 10);

  const saveMut = useMutation({
    mutationFn: () => saveAutomation(config),
    onSuccess: () => { toast({ title: '✅ تم الحفظ', description: 'إعدادات الأتمتة محدّثة' }); setDirty(false); },
    onError: () => toast({ title: '❌ خطأ', description: 'فشل الحفظ' }),
  });

  const RULES = [
    {
      key: 'auto_retry_failed_orders',
      label: 'إعادة محاولة الطلبات الفاشلة',
      description: 'عند فشل طلب بسبب خطأ مؤقت، يتم إعادة المحاولة تلقائياً حتى 3 مرات قبل التراجع.',
      icon: RefreshCw,
      badge: 'يعمل كل دقيقة',
    },
    {
      key: 'auto_stop_loss_products',
      label: 'إيقاف المنتجات الخاسرة تلقائياً',
      description: 'إذا أصبح سعر البيع أقل من تكلفة المزود، يتم إيقاف المنتج تلقائياً لحماية الأرباح.',
      icon: Shield,
      badge: 'حماية الربح',
      badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    },
    {
      key: 'auto_hide_unavailable_products',
      label: 'إخفاء المنتجات غير المتاحة',
      description: 'عند مزامنة المنتجات، إذا حُذف منتج من المزود، يتم إخفاؤه تلقائياً من المتجر.',
      icon: AlertTriangle,
    },
    {
      key: 'sync_on_startup',
      label: 'مزامنة المنتجات عند بدء الخادم',
      description: 'عند إعادة تشغيل الخادم، يتم مزامنة قائمة المنتجات من المزود تلقائياً.',
      icon: Zap,
    },
  ];

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6 max-w-3xl mx-auto" dir="rtl">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2"><Zap size={24} className="text-amber-400" /> مركز الأتمتة</h1>
              <p className="text-sm text-muted-foreground mt-0.5">تكوين قواعد الأتمتة والجداول الزمنية</p>
            </div>
            {dirty && (
              <motion.button
                initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                onClick={() => saveMut.mutate()}
                disabled={saveMut.isPending}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white font-semibold text-sm hover:opacity-90 disabled:opacity-50 transition-opacity"
              >
                <Save size={14} />
                {saveMut.isPending ? 'جاري الحفظ...' : 'حفظ التغييرات'}
              </motion.button>
            )}
          </div>

           {/* Saved automation state — only settings backed by this page are shown here. */}
           <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
             <div className="flex items-center gap-2 mb-3">
               <CheckCircle size={15} className="text-emerald-400" />
               <span className="text-sm font-semibold">حالة الإعدادات المحفوظة</span>
             </div>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
               {[
                 ['إعادة محاولة الطلبات الفاشلة', 'auto_retry_failed_orders'],
                 ['حماية الأسعار من الخسارة', 'auto_stop_loss_products'],
                 ['إخفاء المنتجات غير المتاحة', 'auto_hide_unavailable_products'],
                 ['المزامنة عند بدء الخادم', 'sync_on_startup'],
               ].map(([label, key]) => (
                 <div key={key} className="flex items-center gap-2 text-xs rounded-xl border border-white/10 px-3 py-2">
                   <span className={`w-2 h-2 rounded-full ${bool(key) ? 'bg-emerald-400' : 'bg-gray-500'}`} />
                   <span className="font-medium flex-1">{label}</span>
                   <span className="text-muted-foreground">{bool(key) ? 'مفعّل' : 'متوقف'}</span>
                 </div>
               ))}
             </div>
           </div>

          {/* Toggle rules */}
          {isLoading ? (
            <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-20 rounded-2xl bg-white/5 border border-white/10 animate-pulse" />)}</div>
          ) : (
            <div className="space-y-3">
              {RULES.map(rule => (
                <ToggleRule
                  key={rule.key}
                  label={rule.label}
                  description={rule.description}
                  icon={rule.icon}
                  value={bool(rule.key)}
                  onChange={v => setBool(rule.key, v)}
                  badge={rule.badge}
                  badgeColor={rule.badgeColor}
                />
              ))}
            </div>
          )}

          {/* Numeric settings */}
          <div className="space-y-4">
            <h2 className="font-bold text-sm flex items-center gap-2"><Clock size={14} className="text-primary" /> إعدادات الجداول الزمنية</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl border border-white/10 bg-white/5">
                <label className="text-sm font-semibold flex items-center gap-2 mb-2">
                  <RefreshCw size={14} className="text-primary" /> فترة مزامنة الأسعار (دقيقة)
                </label>
                <input
                  type="number"
                  min={5}
                  max={1440}
                  value={num('price_sync_interval_minutes', 60)}
                  onChange={e => setVal('price_sync_interval_minutes', e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-background border border-white/10 text-sm focus:outline-none focus:border-primary/50"
                />
                <p className="text-xs text-muted-foreground mt-1">الحد الأدنى: 5 دقائق · الافتراضي: 60 دقيقة</p>
              </div>
              <div className="p-4 rounded-2xl border border-white/10 bg-white/5">
                <label className="text-sm font-semibold flex items-center gap-2 mb-2">
                  <DollarSign size={14} className="text-amber-400" /> حد تنبيه رصيد المزود (ل.س)
                </label>
                <input
                  type="number"
                  min={0}
                  value={num('low_balance_threshold_syp', 50000)}
                  onChange={e => setVal('low_balance_threshold_syp', e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-background border border-white/10 text-sm focus:outline-none focus:border-primary/50"
                />
                <p className="text-xs text-muted-foreground mt-1">يرسل تنبيه تيليجرام عند انخفاض الرصيد تحت هذا الحد</p>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-xs text-muted-foreground flex items-start gap-2">
            <Info size={14} className="shrink-0 mt-0.5 text-blue-400" />
            <div>
              قواعد الأتمتة تعمل على الخادم مباشرةً — التغييرات تُطبَّق على الدورة التالية.
              لا حاجة لإعادة تشغيل الخادم.
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
