import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import {
  MessageCircle, Send, ChevronRight, Clock, CheckCircle2,
  Loader2, RefreshCw, User, X, AlertTriangle, ArrowRight, Package, Filter,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

type TicketStatus = 'open' | 'in_progress' | 'closed';
type Priority = 'low' | 'medium' | 'high' | 'urgent';

interface AdminTicket {
  id: number;
  subject: string;
  status: TicketStatus;
  priority: Priority;
  orderId: string | null;
  userId: number;
  userName: string | null;
  userEmail: string | null;
  messageCount: number;
  createdAt: string;
  updatedAt: string;
  closedAt: string | null;
}

interface Message {
  id: number;
  ticketId: number;
  userId: number;
  body: string;
  isAdmin: string;
  createdAt: string;
}

const STATUS_CFG: Record<TicketStatus, { label: string; color: string; bg: string; border: string; icon: React.ElementType }> = {
  open:        { label: 'مفتوحة',        color: 'text-blue-400',    bg: 'bg-blue-500/10',    border: 'border-blue-500/30',    icon: MessageCircle },
  in_progress: { label: 'قيد المراجعة', color: 'text-yellow-400',  bg: 'bg-yellow-500/10',  border: 'border-yellow-500/30',  icon: Clock },
  closed:      { label: 'مغلقة',         color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', icon: CheckCircle2 },
};

const PRIORITY_CFG: Record<Priority, { label: string; color: string }> = {
  low:    { label: 'منخفض', color: 'text-muted-foreground' },
  medium: { label: 'متوسط', color: 'text-blue-400' },
  high:   { label: 'عالي',  color: 'text-orange-400' },
  urgent: { label: 'عاجل 🔴', color: 'text-red-400' },
};

function elapsed(d: string) {
  const s = Math.floor((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 60) return 'الآن';
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}د`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}س`;
  return `${Math.floor(h / 24)}ي`;
}

function TicketChat({ ticket, onBack, onStatusChange }: {
  ticket: AdminTicket;
  onBack: () => void;
  onStatusChange: () => void;
}) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [msg, setMsg] = useState('');
  const [sending, setSending] = useState(false);
  const [updating, setUpdating] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data, isFetching, refetch } = useQuery<{ ticket: AdminTicket; messages: Message[] }>({
    queryKey: ['admin-ticket', ticket.id],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/support/tickets/${ticket.id}`, { headers: authHeaders() });
      if (!r.ok) throw new Error();
      return r.json();
    },
    refetchInterval: 6_000,
    staleTime: 3_000,
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [data?.messages]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!msg.trim() || sending) return;
    setSending(true);
    try {
      const r = await fetch(`${BASE}/api/support/tickets/${ticket.id}/messages`, {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ body: msg }),
      });
      if (!r.ok) throw new Error();
      setMsg('');
      refetch();
      qc.invalidateQueries({ queryKey: ['admin-support-tickets'] });
    } catch {
      toast({ title: 'خطأ', description: 'تعذّر الإرسال', variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  async function updateStatus(status: TicketStatus) {
    setUpdating(true);
    try {
      const r = await fetch(`${BASE}/api/admin/support/tickets/${ticket.id}`, {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ status }),
      });
      if (!r.ok) throw new Error();
      refetch();
      onStatusChange();
      toast({ title: status === 'closed' ? '✅ التذكرة مغلقة' : '🔄 تم تحديث الحالة', duration: 2000 });
    } catch {
      toast({ title: 'خطأ', description: 'تعذّر التحديث', variant: 'destructive' });
    } finally {
      setUpdating(false);
    }
  }

  const cur = (data?.ticket as AdminTicket | undefined) ?? ticket;
  const scfg = STATUS_CFG[cur.status];
  const SIcon = scfg.icon;
  const isClosed = cur.status === 'closed';

  return (
    <div className="flex flex-col h-[calc(100vh-180px)]" dir="rtl">
      {/* Header */}
      <div className="flex items-start gap-3 mb-3 pb-3 border-b border-border">
        <button onClick={onBack} className="p-2 rounded-xl hover:bg-card border border-border text-muted-foreground mt-0.5">
          <ArrowRight size={15} />
        </button>
        <div className="flex-1 min-w-0">
          <p className="font-black text-sm truncate">{cur.subject}</p>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span className={`flex items-center gap-1 text-[10px] font-bold ${scfg.color}`}>
              <SIcon size={10} />{scfg.label}
            </span>
            <span className="text-[10px] text-muted-foreground">·</span>
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <User size={9} />{cur.userName ?? cur.userEmail ?? `#${cur.userId}`}
            </span>
            {cur.orderId && (
              <>
                <span className="text-[10px] text-muted-foreground">·</span>
                <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <Package size={9} />{cur.orderId}
                </span>
              </>
            )}
            {isFetching && <RefreshCw size={9} className="animate-spin text-muted-foreground" />}
          </div>
        </div>
        {/* Status Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          {cur.status !== 'in_progress' && !isClosed && (
            <button onClick={() => updateStatus('in_progress')} disabled={updating}
              className="px-2.5 py-1.5 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-[10px] font-bold hover:bg-yellow-500/20 transition-colors disabled:opacity-50"
            >قيد المراجعة</button>
          )}
          {!isClosed ? (
            <button onClick={() => updateStatus('closed')} disabled={updating}
              className="px-2.5 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold hover:bg-emerald-500/20 transition-colors disabled:opacity-50"
            >إغلاق ✓</button>
          ) : (
            <button onClick={() => updateStatus('open')} disabled={updating}
              className="px-2.5 py-1.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-bold hover:bg-blue-500/20 transition-colors disabled:opacity-50"
            >إعادة فتح</button>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 pb-2">
        {data?.messages.map(m => {
          const isAdm = m.isAdmin === 'true';
          return (
            <motion.div key={m.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
              className={`flex ${isAdm ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] ${isAdm ? 'bg-primary/10 border-primary/20' : 'bg-card border-border'} border rounded-2xl px-3.5 py-2.5`}>
                {!isAdm && (
                  <p className="text-[10px] font-black text-muted-foreground mb-1 flex items-center gap-1">
                    <User size={9} />{cur.userName ?? cur.userEmail ?? `مستخدم #${cur.userId}`}
                  </p>
                )}
                {isAdm && <p className="text-[10px] font-black text-primary mb-1">⚡ الإدارة</p>}
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.body}</p>
                <p className="text-[9px] text-muted-foreground mt-1 text-end">{elapsed(m.createdAt)}</p>
              </div>
            </motion.div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Reply input */}
      <form onSubmit={send} className="flex items-end gap-2 mt-3 pt-3 border-t border-border">
        <textarea
          value={msg} onChange={e => setMsg(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(e as any); } }}
          className="flex-1 bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:border-primary outline-none resize-none min-h-[44px] max-h-[120px] transition-colors"
          placeholder="رد كمسؤول... (Enter للإرسال)"
          rows={1}
        />
        <button type="submit" disabled={sending || !msg.trim()}
          className="p-3 rounded-xl bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-40"
        >
          {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
        </button>
      </form>
    </div>
  );
}

const FILTER_OPTIONS: { label: string; value: string }[] = [
  { label: 'الكل', value: 'all' },
  { label: 'مفتوحة', value: 'open' },
  { label: 'قيد المراجعة', value: 'in_progress' },
  { label: 'مغلقة', value: 'closed' },
];

export default function AdminSupportPage() {
  const [filter, setFilter] = useState('open');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const qc = useQueryClient();

  const { data, isLoading, isFetching, refetch } = useQuery<{ tickets: AdminTicket[] }>({
    queryKey: ['admin-support-tickets', filter],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/admin/support/tickets?status=${filter}`, { headers: authHeaders() });
      if (!r.ok) throw new Error();
      return r.json();
    },
    refetchInterval: 10_000,
    staleTime: 5_000,
  });

  const { data: statsData } = useQuery<{ stats: Record<string, number> }>({
    queryKey: ['admin-support-stats'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/admin/support/stats`, { headers: authHeaders() });
      return r.json();
    },
    refetchInterval: 15_000,
  });

  const selectedTicket = data?.tickets.find(t => t.id === selectedId);

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div dir="rtl">
          {selectedTicket ? (
            <TicketChat
              ticket={selectedTicket}
              onBack={() => setSelectedId(null)}
              onStatusChange={() => {
                qc.invalidateQueries({ queryKey: ['admin-support-tickets'] });
                qc.invalidateQueries({ queryKey: ['admin-support-stats'] });
                qc.invalidateQueries({ queryKey: ['admin-ticket', selectedId] });
              }}
            />
          ) : (
            <>
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-xl font-black flex items-center gap-2">
                    <MessageCircle size={20} className="text-primary" />
                    إدارة تذاكر الدعم
                  </h1>
                  <p className="text-xs text-muted-foreground mt-0.5">تحديث كل 10 ثواني</p>
                </div>
                <button onClick={() => refetch()} disabled={isFetching}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-primary/10 border border-primary/30 text-primary text-xs font-bold hover:bg-primary/20 transition-colors disabled:opacity-50"
                >
                  <RefreshCw size={12} className={isFetching ? 'animate-spin' : ''} />تحديث
                </button>
              </div>

              {/* Stats bar */}
              {statsData && (
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {(['open', 'in_progress', 'closed'] as TicketStatus[]).map(s => {
                    const cfg = STATUS_CFG[s];
                    const Icon = cfg.icon;
                    return (
                      <button key={s} onClick={() => setFilter(s)}
                        className={`rounded-xl border p-2.5 flex items-center gap-2.5 transition-all ${filter === s ? `${cfg.bg} ${cfg.border}` : 'bg-card border-border hover:border-primary/30'}`}
                      >
                        <Icon size={15} className={cfg.color} />
                        <div className="text-right">
                          <p className={`text-xl font-black ${cfg.color}`}>{statsData.stats[s] ?? 0}</p>
                          <p className="text-[9px] text-muted-foreground">{cfg.label}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Filter tabs */}
              <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
                <Filter size={13} className="text-muted-foreground shrink-0" />
                {FILTER_OPTIONS.map(f => (
                  <button key={f.value} onClick={() => setFilter(f.value)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${filter === f.value ? 'bg-primary text-white' : 'bg-card border border-border text-muted-foreground hover:border-primary/40'}`}
                  >{f.label}</button>
                ))}
              </div>

              {/* Tickets list */}
              {isLoading ? (
                <div className="flex justify-center py-16"><Loader2 className="animate-spin text-primary" size={32} /></div>
              ) : !data?.tickets.length ? (
                <div className="flex flex-col items-center justify-center py-20 gap-3 text-center">
                  <AlertTriangle size={32} className="text-muted-foreground/30" />
                  <p className="text-sm text-muted-foreground">لا توجد تذاكر</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {data.tickets.map((t, i) => {
                    const scfg = STATUS_CFG[t.status];
                    const SIcon = scfg.icon;
                    const pcfg = PRIORITY_CFG[t.priority];
                    return (
                      <motion.button key={t.id}
                        initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.03 }}
                        onClick={() => setSelectedId(t.id)}
                        className="w-full text-right bg-card border border-border rounded-2xl p-4 hover:border-primary/40 hover:bg-primary/5 transition-all group flex items-center gap-3"
                      >
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${scfg.bg} ${scfg.border} border`}>
                          <SIcon size={16} className={scfg.color} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-sm truncate flex-1">{t.subject}</p>
                            <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md ${scfg.bg} ${scfg.color} border ${scfg.border} shrink-0`}>
                              {t.messageCount} رسالة
                            </span>
                          </div>
                          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                            <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                              <User size={9} />{t.userName ?? t.userEmail ?? `#${t.userId}`}
                            </span>
                            <span className="text-[10px] text-muted-foreground">·</span>
                            <span className={`text-[10px] font-bold ${pcfg.color}`}>{pcfg.label}</span>
                            <span className="text-[10px] text-muted-foreground">·</span>
                            <span className="text-[10px] text-muted-foreground">{elapsed(t.updatedAt)}</span>
                            {t.orderId && (
                              <>
                                <span className="text-[10px] text-muted-foreground">·</span>
                                <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                                  <Package size={9} />{t.orderId}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                        <ChevronRight size={14} className="text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                      </motion.button>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
