import { useState, useEffect, useRef } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Palette, Layout, Save, RefreshCw, Eye, EyeOff, Check, ChevronUp, ChevronDown, Layers } from 'lucide-react';
import { useToast } from '../../hooks/use-toast';
import { motion } from 'framer-motion';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

async function fetchAppearance() {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/store-appearance`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error('Failed');
  return res.json() as Promise<Record<string, string>>;
}

async function saveAppearance(config: Record<string, string>) {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/store-appearance`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  return res.json();
}

async function fetchHomeSections() {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/home-sections`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) return [];
  const data = await res.json();
  return data.sections ?? data ?? [];
}

async function saveHomeSections(sections: any[]) {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/home-sections`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ sections }),
  });
  return res.json();
}

const PRESET_THEMES = [
  { name: 'Elite (افتراضي)', primary: '#6C5CE7', accent: '#FD79A8', bg: '#0f0e17' },
  { name: 'Ocean Blue', primary: '#0984e3', accent: '#00cec9', bg: '#0a0f1e' },
  { name: 'Emerald', primary: '#00b894', accent: '#fdcb6e', bg: '#0a1a10' },
  { name: 'Sunset', primary: '#e17055', accent: '#ffeaa7', bg: '#1a0f0a' },
  { name: 'Midnight', primary: '#a29bfe', accent: '#fd79a8', bg: '#080812' },
  { name: 'Rose Gold', primary: '#e84393', accent: '#fdcb6e', bg: '#1a0a12' },
];

const RADIUS_OPTIONS = [
  { label: 'مربع', value: '4' },
  { label: 'دائري خفيف', value: '8' },
  { label: 'دائري (افتراضي)', value: '16' },
  { label: 'دائري كامل', value: '24' },
];

export default function AdminStoreEditor() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [showPreview, setShowPreview] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [activeTab, setActiveTab] = useState<'colors' | 'layout' | 'sections'>('colors');
  const previewRef = useRef<HTMLIFrameElement>(null);

  const { data: appearance } = useQuery({ queryKey: ['admin', 'appearance'], queryFn: fetchAppearance, staleTime: 60_000 });
  const { data: sections, isLoading: sectionsLoading } = useQuery({ queryKey: ['admin', 'home-sections'], queryFn: fetchHomeSections, staleTime: 30_000 });

  const [config, setConfig] = useState<Record<string, string>>({
    store_primary_color: '#6C5CE7',
    store_accent_color: '#FD79A8',
    store_bg_color: '#0f0e17',
    store_card_radius: '16',
    store_font: 'inherit',
    store_logo_text: 'Elite Store',
  });
  const [localSections, setLocalSections] = useState<any[]>([]);

  useEffect(() => { if (appearance) { setConfig({ ...appearance }); setDirty(false); } }, [appearance]);
  useEffect(() => { if (sections) setLocalSections([...sections]); }, [sections]);

  const setVal = (key: string, value: string) => { setConfig(prev => ({ ...prev, [key]: value })); setDirty(true); };

  const saveMut = useMutation({
    mutationFn: async () => {
      await saveAppearance(config);
      await saveHomeSections(localSections);
    },
    onSuccess: () => {
      toast({ title: '✅ تم الحفظ', description: 'تغييرات المتجر محفوظة' });
      setDirty(false);
      qc.invalidateQueries({ queryKey: ['admin', 'appearance'] });
      qc.invalidateQueries({ queryKey: ['admin', 'home-sections'] });
    },
    onError: () => toast({ title: '❌ خطأ', description: 'فشل الحفظ' }),
  });

  const moveSection = (idx: number, dir: -1 | 1) => {
    const newS = [...localSections];
    const target = idx + dir;
    if (target < 0 || target >= newS.length) return;
    [newS[idx], newS[target]] = [newS[target], newS[idx]];
    setLocalSections(newS);
    setDirty(true);
  };

  const toggleSection = (idx: number) => {
    const newS = [...localSections];
    newS[idx] = { ...newS[idx], enabled: !newS[idx].enabled };
    setLocalSections(newS);
    setDirty(true);
  };

  // Apply preview CSS vars to iframe
  useEffect(() => {
    if (!showPreview || !previewRef.current) return;
    const style = `
      :root {
        --primary: ${config.store_primary_color};
        --accent: ${config.store_accent_color};
        --background: ${config.store_bg_color};
        --radius: ${config.store_card_radius}px;
      }
    `;
    try {
      const doc = previewRef.current.contentDocument;
      if (doc) {
        let el = doc.getElementById('__preview_vars');
        if (!el) { el = doc.createElement('style'); el.id = '__preview_vars'; doc.head.appendChild(el); }
        el.textContent = style;
      }
    } catch {}
  }, [config, showPreview]);

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6 max-w-4xl mx-auto" dir="rtl">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2"><Palette size={24} className="text-primary" /> محرر المتجر المباشر</h1>
              <p className="text-sm text-muted-foreground mt-0.5">تخصيص مظهر المتجر وترتيب الأقسام بدون كود</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowPreview(!showPreview)}
                className="flex items-center gap-2 px-3 py-2 rounded-xl border border-white/10 text-sm hover:bg-white/5 transition-colors"
              >
                {showPreview ? <EyeOff size={14} /> : <Eye size={14} />}
                {showPreview ? 'إخفاء المعاينة' : 'معاينة'}
              </button>
              {dirty && (
                <motion.button
                  initial={{ scale: 0.9 }} animate={{ scale: 1 }}
                  onClick={() => saveMut.mutate()}
                  disabled={saveMut.isPending}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white text-sm font-semibold hover:opacity-90 disabled:opacity-50"
                >
                  <Save size={14} />
                  {saveMut.isPending ? 'حفظ...' : 'حفظ التغييرات'}
                </motion.button>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white/5 border border-white/10 rounded-2xl p-1.5">
            {([['colors', 'الألوان والمظهر', Palette], ['layout', 'شكل البطاقات', Layers], ['sections', 'ترتيب الأقسام', Layout]] as const).map(([t, label, Icon]) => (
              <button
                key={t}
                onClick={() => setActiveTab(t)}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm font-semibold transition-all ${activeTab === t ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}
              >
                <Icon size={14} />{label}
              </button>
            ))}
          </div>

          {/* Colors tab */}
          {activeTab === 'colors' && (
            <div className="space-y-5">
              {/* Preset themes */}
              <div>
                <h2 className="font-semibold text-sm mb-3">ثيمات جاهزة</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {PRESET_THEMES.map(theme => (
                    <button
                      key={theme.name}
                      onClick={() => {
                        setVal('store_primary_color', theme.primary);
                        setVal('store_accent_color', theme.accent);
                        setVal('store_bg_color', theme.bg);
                      }}
                      className={`flex items-center gap-2.5 p-3 rounded-xl border text-sm transition-all hover:border-white/30 ${
                        config.store_primary_color === theme.primary ? 'border-white/40 bg-white/10' : 'border-white/10 bg-white/5'
                      }`}
                    >
                      <div className="flex gap-1 shrink-0">
                        {[theme.primary, theme.accent, theme.bg].map((c, i) => (
                          <div key={i} className="w-4 h-4 rounded-full border border-white/20" style={{ background: c }} />
                        ))}
                      </div>
                      <span className="font-medium truncate">{theme.name}</span>
                      {config.store_primary_color === theme.primary && <Check size={12} className="text-primary ms-auto shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom colors */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { key: 'store_primary_color', label: 'اللون الرئيسي', hint: 'الأزرار والروابط' },
                  { key: 'store_accent_color', label: 'اللون المكمّل', hint: 'الشارات والتأثيرات' },
                  { key: 'store_bg_color', label: 'لون الخلفية', hint: 'خلفية الصفحات' },
                ].map(item => (
                  <div key={item.key} className="p-4 rounded-2xl border border-white/10 bg-white/5">
                    <label className="text-sm font-semibold mb-1 block">{item.label}</label>
                    <p className="text-xs text-muted-foreground mb-3">{item.hint}</p>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={config[item.key] ?? '#6C5CE7'}
                        onChange={e => setVal(item.key, e.target.value)}
                        className="w-10 h-10 rounded-xl border border-white/20 cursor-pointer bg-transparent"
                      />
                      <input
                        type="text"
                        value={config[item.key] ?? ''}
                        onChange={e => setVal(item.key, e.target.value)}
                        className="flex-1 px-3 py-2 rounded-xl bg-background border border-white/10 text-sm font-mono focus:outline-none focus:border-primary/50"
                        placeholder="#000000"
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Logo text */}
              <div className="p-4 rounded-2xl border border-white/10 bg-white/5">
                <label className="text-sm font-semibold mb-1 block">اسم المتجر في الشعار</label>
                <input
                  type="text"
                  value={config.store_logo_text ?? 'Elite Store'}
                  onChange={e => setVal('store_logo_text', e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-background border border-white/10 text-sm focus:outline-none focus:border-primary/50"
                />
              </div>
            </div>
          )}

          {/* Layout / card radius tab */}
          {activeTab === 'layout' && (
            <div className="space-y-5">
              <div>
                <h2 className="font-semibold text-sm mb-3">شكل زوايا البطاقات</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {RADIUS_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => setVal('store_card_radius', opt.value)}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all ${config.store_card_radius === opt.value ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-white/5 hover:border-white/30'}`}
                    >
                      <div className="w-10 h-8 border-2 border-current mx-auto mb-2" style={{ borderRadius: `${opt.value}px` }} />
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="font-semibold text-sm mb-3">شكل بطاقات المنتجات</h2>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'default', label: 'كلاسيك', desc: 'صورة + اسم + سعر' },
                    { value: 'compact', label: 'مضغوط', desc: 'حجم أصغر، كثافة أعلى' },
                    { value: 'wide', label: 'عريض', desc: 'صورة كبيرة أفقية' },
                  ].map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => {
                        setVal('product_card_style', opt.value);
                        // Also save this to existing product_card_style setting
                        fetch(`${BASE}/api/admin/settings`, {
                          method: 'PUT',
                          headers: { Authorization: `Bearer ${localStorage.getItem('elite_token')}`, 'Content-Type': 'application/json' },
                          body: JSON.stringify({ product_card_style: opt.value }),
                        }).catch(() => {});
                      }}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all text-center ${config.product_card_style === opt.value ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-white/5 hover:border-white/30'}`}
                    >
                      <div className="font-semibold mb-0.5">{opt.label}</div>
                      <div className="text-xs text-muted-foreground">{opt.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Sections tab */}
          {activeTab === 'sections' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold text-sm">ترتيب أقسام الصفحة الرئيسية</h2>
                <p className="text-xs text-muted-foreground">اسحب أو استخدم الأسهم للترتيب</p>
              </div>
              {sectionsLoading ? (
                <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-14 rounded-xl bg-white/5 animate-pulse" />)}</div>
              ) : localSections.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground text-sm">لا توجد أقسام — أضف منتجات لتظهر الأقسام</div>
              ) : (
                <div className="space-y-2">
                  {localSections.map((sec: any, idx: number) => (
                    <motion.div
                      key={sec.id ?? idx}
                      layout
                      className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-all ${sec.enabled !== false ? 'border-white/15 bg-white/5' : 'border-white/5 bg-white/[0.02] opacity-60'}`}
                    >
                      <div className="flex flex-col gap-0.5 shrink-0">
                        <button onClick={() => moveSection(idx, -1)} disabled={idx === 0} className="p-0.5 hover:text-primary disabled:opacity-20 transition-colors">
                          <ChevronUp size={14} />
                        </button>
                        <button onClick={() => moveSection(idx, 1)} disabled={idx === localSections.length - 1} className="p-0.5 hover:text-primary disabled:opacity-20 transition-colors">
                          <ChevronDown size={14} />
                        </button>
                      </div>
                      <span className="w-6 h-6 rounded-lg bg-white/10 text-xs font-bold flex items-center justify-center shrink-0">{idx + 1}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{sec.label ?? sec.title ?? sec.type ?? 'قسم'}</div>
                        {sec.type && <div className="text-xs text-muted-foreground">{sec.type}</div>}
                      </div>
                      <button
                        onClick={() => toggleSection(idx)}
                        className={`shrink-0 text-xs px-2.5 py-1 rounded-lg font-medium transition-colors ${sec.enabled !== false ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' : 'bg-white/10 text-muted-foreground border border-white/10'}`}
                      >
                        {sec.enabled !== false ? 'ظاهر' : 'مخفي'}
                      </button>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Live Preview */}
          {showPreview && (
            <div className="rounded-2xl border border-white/15 overflow-hidden bg-black">
              <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-white/5">
                <span className="text-xs text-muted-foreground">معاينة مباشرة — التغييرات تظهر بعد الحفظ</span>
                <span className="flex gap-1.5">
                  {['bg-red-400', 'bg-amber-400', 'bg-emerald-400'].map(c => <span key={c} className={`w-3 h-3 rounded-full ${c}`} />)}
                </span>
              </div>
              <iframe
                ref={previewRef}
                src={`${BASE}/`}
                className="w-full"
                style={{ height: '500px', border: 'none' }}
                title="Store Preview"
              />
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
