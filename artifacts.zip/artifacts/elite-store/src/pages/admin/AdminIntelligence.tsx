import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Minus, DollarSign, ShoppingBag, Users, Zap, Activity, Award, Clock } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function authFetch(path: string) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} }).then(r => r.json());
}

function DeltaChip({ pct }: { pct: number }) {
  if (pct > 0) return (
    <span className="flex items-center gap-0.5 text-emerald-400 text-[10px] font-bold">
      <TrendingUp size={11} /> +{pct}%
    </span>
  );
  if (pct < 0) return (
    <span className="flex items-center gap-0.5 text-red-400 text-[10px] font-bold">
      <TrendingDown size={11} /> {pct}%
    </span>
  );
  return <span className="flex items-center gap-0.5 text-gray-400 text-[10px]"><Minus size={11} /> 0%</span>;
}

function KpiCard({ label, thisWeek, lastWeek, pct, icon, fmt }: { label: string; thisWeek: number; lastWeek: number; pct: number; icon: React.ReactNode; fmt: (v: number) => string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/3 p-4">
      <div className="flex items-start justify-between mb-2">
        <p className="text-gray-400 text-xs">{label}</p>
        {icon}
      </div>
      <p className="text-white text-xl font-black mb-0.5">{fmt(thisWeek)}</p>
      <div className="flex items-center gap-1.5">
        <DeltaChip pct={pct} />
        <span className="text-gray-600 text-[10px]">vs الأسبوع الماضي ({fmt(lastWeek)})</span>
      </div>
    </div>
  );
}

// Hour labels in Arabic
const HOUR_LABELS = ['12ص','1ص','2ص','3ص','4ص','5ص','6ص','7ص','8ص','9ص','10ص','11ص','12م','1م','2م','3م','4م','5م','6م','7م','8م','9م','10م','11م'];

export default function AdminIntelligence() {
  const { data, isLoading } = useQuery({
    queryKey: ['admin-intelligence'],
    queryFn: () => authFetch('/api/admin/analytics/intelligence'),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  if (isLoading) return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );

  const tw = data?.thisWeek ?? {};
  const lw = data?.lastWeek ?? {};
  const ch = data?.change ?? {};
  const daily: any[] = (data?.daily ?? []).map((r: any) => ({
    name: new Date(r.day).toLocaleDateString('ar', { weekday: 'short' }),
    revenue: parseFloat(r.revenue ?? '0'),
    orders: Number(r.orders ?? 0),
  }));
  const topProducts: any[] = data?.topProducts ?? [];
  const hourData: any[] = Array.from({ length: 24 }, (_, i) => {
    const found = (data?.hourHeatmap ?? []).find((h: any) => Number(h.hour) === i);
    return { hour: HOUR_LABELS[i], orders: Number(found?.orders ?? 0) };
  });
  const maxHourOrders = Math.max(...hourData.map(h => h.orders), 1);

  const fmt$ = (v: number) => `$${v.toFixed(2)}`;
  const fmtN = (v: number) => String(Math.round(v));

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="p-4 max-w-2xl mx-auto pb-10" dir="rtl">
          <div className="mb-6">
            <h1 className="text-white text-xl font-black flex items-center gap-2">
              <Zap size={20} className="text-amber-400" /> ذكاء الإيرادات
            </h1>
            <p className="text-gray-400 text-xs mt-0.5">مقارنة هذا الأسبوع vs الأسبوع الماضي + توقعات</p>
          </div>

          {/* KPI grid */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <KpiCard label="الإيرادات" thisWeek={tw.revenue ?? 0} lastWeek={lw.revenue ?? 0} pct={ch.revenuePct ?? 0} fmt={fmt$}
              icon={<DollarSign size={18} className="text-emerald-400" />} />
            <KpiCard label="الطلبات" thisWeek={tw.orders ?? 0} lastWeek={lw.orders ?? 0} pct={ch.ordersPct ?? 0} fmt={fmtN}
              icon={<ShoppingBag size={18} className="text-blue-400" />} />
            <KpiCard label="مستخدمون جدد" thisWeek={tw.newUsers ?? 0} lastWeek={lw.newUsers ?? 0} pct={ch.newUsersPct ?? 0} fmt={fmtN}
              icon={<Users size={18} className="text-violet-400" />} />
            <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4">
              <p className="text-gray-400 text-xs mb-2 flex items-center gap-1"><Activity size={12} /> توقع الأسبوع القادم</p>
              <p className="text-white text-xl font-black">{fmt$(data?.forecast7 ?? 0)}</p>
              <p className="text-gray-500 text-[10px] mt-0.5">بناءً على متوسط 14 يوم</p>
            </div>
          </div>

          {/* Daily revenue chart (14 days) */}
          {daily.length > 0 && (
            <div className="rounded-2xl border border-white/10 bg-white/3 p-4 mb-5">
              <p className="text-white font-bold text-sm mb-4 flex items-center gap-2">
                <TrendingUp size={15} className="text-emerald-400" /> الإيرادات اليومية (14 يوم)
              </p>
              <ResponsiveContainer width="100%" height={140}>
                <AreaChart data={daily} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#6b7280', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: 8, fontSize: 11 }}
                    formatter={(v: any) => [`$${parseFloat(v).toFixed(2)}`, 'الإيرادات']}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="url(#revGrad)" strokeWidth={2} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Top products */}
          {topProducts.length > 0 && (
            <div className="rounded-2xl border border-white/10 bg-white/3 p-4 mb-5">
              <p className="text-white font-bold text-sm mb-4 flex items-center gap-2">
                <Award size={15} className="text-amber-400" /> أفضل المنتجات هذا الأسبوع
              </p>
              <div className="flex flex-col gap-2">
                {topProducts.map((p: any, i: number) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black ${i === 0 ? 'bg-amber-500 text-black' : i === 1 ? 'bg-gray-400 text-black' : i === 2 ? 'bg-orange-700 text-white' : 'bg-white/10 text-gray-400'}`}>{i + 1}</span>
                    <p className="flex-1 text-white text-xs truncate">{p.name ?? p.id}</p>
                    <p className="text-emerald-400 text-xs font-bold">${parseFloat(p.revenue).toFixed(0)}</p>
                    <p className="text-gray-500 text-[10px]">{p.orders} طلب</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Hour heatmap */}
          <div className="rounded-2xl border border-white/10 bg-white/3 p-4">
            <p className="text-white font-bold text-sm mb-4 flex items-center gap-2">
              <Clock size={15} className="text-violet-400" /> أفضل ساعات البيع (30 يوم)
            </p>
            <div className="flex gap-0.5 items-end h-16">
              {hourData.map((h, i) => {
                const intensity = h.orders / maxHourOrders;
                return (
                  <div key={i} title={`${h.hour}: ${h.orders} طلب`}
                    className="flex-1 rounded-sm transition-all cursor-pointer hover:opacity-80"
                    style={{
                      height: `${Math.max(4, intensity * 100)}%`,
                      background: intensity > 0.7 ? '#8b5cf6' : intensity > 0.4 ? '#6d28d9' : intensity > 0.1 ? '#4c1d95' : '#1f1f3a',
                    }}
                  />
                );
              })}
            </div>
            <div className="flex justify-between mt-1">
              <span className="text-gray-600 text-[8px]">12ص</span>
              <span className="text-gray-600 text-[8px]">12م</span>
              <span className="text-gray-600 text-[8px]">11م</span>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
