import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import {
  RefreshCw, Clock, CheckCircle2, XCircle, Loader2,
  AlertTriangle, Zap, Volume2, VolumeX, Package, RotateCcw,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
function authHeaders() {
  const token = localStorage.getItem('elite_token');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

type OrderStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'refunded';

interface QueueOrder {
  id: string;
  orderNumber: number;
  productName: string;
  qty: number;
  playerId: string | null;
  totalPrice: string;
  status: OrderStatus;
  retryCount: number;
  lastDispatchError: string | null;
  providerOrderId: string | null;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface QueueData {
  orders: QueueOrder[];
  byStatus: Record<OrderStatus, QueueOrder[]>;
  counts: Record<OrderStatus, number>;
  generatedAt: string;
}

const STATUS_CONFIG: Record<OrderStatus, { label: string; color: string; icon: React.ElementType; bg: string; border: string }> = {
  pending:    { label: 'قيد الانتظار',  color: 'text-yellow-400',  icon: Clock,         bg: 'bg-yellow-500/10',  border: 'border-yellow-500/30' },
  processing: { label: 'جاري التنفيذ',  color: 'text-blue-400',    icon: Loader2,       bg: 'bg-blue-500/10',    border: 'border-blue-500/30' },
  completed:  { label: 'مكتمل',          color: 'text-emerald-400', icon: CheckCircle2,  bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' },
  failed:     { label: 'فشل',            color: 'text-red-400',     icon: XCircle,       bg: 'bg-red-500/10',     border: 'border-red-500/30' },
  refunded:   { label: 'مُسترد',         color: 'text-purple-400',  icon: RotateCcw,     bg: 'bg-purple-500/10',  border: 'border-purple-500/30' },
};

function elapsed(date: string): string {
  const ms = Date.now() - new Date(date).getTime();
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}ث`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}د`;
  const h = Math.floor(m / 60);
  return `${h}س ${m % 60}د`;
}

function OrderCard({ order, seen }: { order: QueueOrder; seen: boolean }) {
  const cfg = STATUS_CONFIG[order.status] ?? STATUS_CONFIG.pending;
  const Icon = cfg.icon;
  const isNew = !seen;
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.94, y: -10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ type: 'spring', stiffness: 300, damping: 28 }}
      className={`relative rounded-xl border p-3 ${cfg.bg} ${cfg.border} ${isNew ? 'ring-2 ring-primary/60 ring-offset-1 ring-offset-background' : ''}`}
    >
      {isNew && (
        <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-primary" />
        </span>
      )}
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <p className="text-xs font-black text-foreground line-clamp-1 flex-1">{order.productName}</p>
        <span className={`text-[10px] font-bold ${cfg.color} shrink-0`}>#{order.orderNumber}</span>
      </div>
      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
        <span>{order.playerId ? `ID: ${order.playerId.slice(0, 14)}` : '—'}</span>
        <span className="font-bold text-foreground">${parseFloat(order.totalPrice).toFixed(2)}</span>
      </div>
      {order.lastDispatchError && order.status === 'failed' && (
        <p className="mt-1.5 text-[9px] text-red-400 line-clamp-2 bg-red-500/10 rounded px-1.5 py-1">
          {order.lastDispatchError}
        </p>
      )}
      <div className="flex items-center justify-between mt-2">
        <div className={`flex items-center gap-1 ${cfg.color}`}>
          <Icon size={10} className={order.status === 'processing' ? 'animate-spin' : ''} />
          <span className="text-[10px] font-semibold">{cfg.label}</span>
        </div>
        <span className="text-[10px] text-muted-foreground">{elapsed(order.createdAt)} مضى</span>
      </div>
      {order.retryCount > 0 && (
        <div className="mt-1 flex items-center gap-1 text-[9px] text-orange-400">
          <RotateCcw size={8} />
          <span>{order.retryCount} محاولة إعادة</span>
        </div>
      )}
    </motion.div>
  );
}

const ACTIVE_COLUMNS: OrderStatus[] = ['pending', 'processing', 'completed', 'failed'];

export default function AdminOrderQueuePage() {
  const { toast } = useToast();
  const [soundOn, setSoundOn] = useState(true);
  const [seenIds, setSeenIds] = useState<Set<string>>(new Set());
  const prevCountRef = useRef<Record<string, number>>({});
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playAlert = useCallback((type: 'new' | 'complete') => {
    if (!soundOn) return;
    try {
      if (!audioCtxRef.current) audioCtxRef.current = new AudioContext();
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      if (type === 'new') {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1100, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.3);
      } else {
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(900, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.4);
      }
    } catch { /* silent */ }
  }, [soundOn]);

  const { data, isLoading, isFetching, refetch, dataUpdatedAt } = useQuery<QueueData>({
    queryKey: ['admin-order-queue'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/admin/order-queue`, { headers: authHeaders() });
      if (!r.ok) throw new Error('Unauthorized');
      return r.json();
    },
    refetchInterval: 6_000,
    staleTime: 3_000,
  });

  useEffect(() => {
    if (!data) return;
    const prev = prevCountRef.current;
    const cur = data.counts;

    if (Object.keys(prev).length > 0) {
      const newPending = (cur.pending ?? 0) > (prev.pending ?? 0);
      const newCompleted = (cur.completed ?? 0) > (prev.completed ?? 0);

      if (newPending) {
        playAlert('new');
        toast({ title: '🛒 طلب جديد وصل!', description: 'يوجد طلب جديد قيد الانتظار', duration: 3000 });
      } else if (newCompleted) {
        playAlert('complete');
      }
    }

    const fresh = new Set<string>();
    const now = Date.now();
    for (const o of data.orders) {
      if (now - new Date(o.createdAt).getTime() < 30_000) fresh.add(o.id);
    }
    setSeenIds(prev => {
      const next = new Set(prev);
      for (const id of fresh) next.add(id);
      return next;
    });

    prevCountRef.current = cur;
  }, [data, playAlert, toast]);

  const lastUpdate = dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString('ar-SY') : '—';

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="min-h-screen" dir="rtl">
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div>
              <h1 className="text-xl font-black text-foreground flex items-center gap-2">
                <Zap size={20} className="text-primary" />
                قائمة انتظار الطلبات
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                تحديث كل 6 ثواني · آخر تحديث: {lastUpdate}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSoundOn(s => !s)}
                className={`p-2 rounded-lg border transition-colors ${soundOn ? 'bg-primary/10 border-primary/30 text-primary' : 'bg-card border-border text-muted-foreground'}`}
                title={soundOn ? 'كتم الصوت' : 'تفعيل الصوت'}
              >
                {soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </button>
              <button
                onClick={() => refetch()}
                disabled={isFetching}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-primary/10 border border-primary/30 text-primary text-xs font-bold hover:bg-primary/20 transition-colors disabled:opacity-50"
              >
                <RefreshCw size={13} className={isFetching ? 'animate-spin' : ''} />
                تحديث
              </button>
              <Link href="/admin/orders" className="px-3 py-2 rounded-lg bg-card border border-border text-xs font-bold text-foreground hover:border-primary/40 transition-colors">
                عرض كل الطلبات
              </Link>
            </div>
          </div>

          {/* Summary bar */}
          {data && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
              {ACTIVE_COLUMNS.map(s => {
                const cfg = STATUS_CONFIG[s];
                const Icon = cfg.icon;
                return (
                  <div key={s} className={`rounded-xl border p-3 ${cfg.bg} ${cfg.border} flex items-center gap-3`}>
                    <Icon size={18} className={`${cfg.color} ${s === 'processing' ? 'animate-spin' : ''} shrink-0`} />
                    <div>
                      <p className={`text-2xl font-black ${cfg.color}`}>{data.counts[s] ?? 0}</p>
                      <p className="text-[10px] text-muted-foreground">{cfg.label}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {isLoading ? (
            <div className="flex items-center justify-center py-24">
              <Loader2 className="animate-spin text-primary" size={36} />
            </div>
          ) : data ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              {ACTIVE_COLUMNS.map(status => {
                const cfg = STATUS_CONFIG[status];
                const Icon = cfg.icon;
                const orders = data.byStatus[status] ?? [];
                return (
                  <div key={status} className="flex flex-col gap-2">
                    {/* Column header */}
                    <div className={`flex items-center gap-2 rounded-xl border p-2.5 ${cfg.bg} ${cfg.border}`}>
                      <Icon size={14} className={`${cfg.color} ${status === 'processing' ? 'animate-spin' : ''}`} />
                      <span className={`text-xs font-black ${cfg.color}`}>{cfg.label}</span>
                      <span className={`mr-auto text-xs font-black px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.border} border ${cfg.color}`}>
                        {orders.length}
                      </span>
                    </div>

                    {/* Order cards */}
                    <div className="flex flex-col gap-2 min-h-[120px]">
                      <AnimatePresence mode="popLayout">
                        {orders.length === 0 ? (
                          <motion.div
                            key="empty"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="flex flex-col items-center justify-center py-8 text-muted-foreground/40 gap-2"
                          >
                            <Package size={28} />
                            <p className="text-xs">لا توجد طلبات</p>
                          </motion.div>
                        ) : (
                          orders.map(order => (
                            <OrderCard
                              key={order.id}
                              order={order}
                              seen={seenIds.has(order.id)}
                            />
                          ))
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-24 gap-3 text-muted-foreground">
              <AlertTriangle size={36} className="opacity-30" />
              <p className="text-sm">تعذّر تحميل البيانات</p>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
