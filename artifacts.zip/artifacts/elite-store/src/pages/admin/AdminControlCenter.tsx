import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { AlertTriangle, Clock, CreditCard, XCircle, RefreshCw, Power, AlertCircle, Wallet, ChevronRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem('elite_token')}`, 'Content-Type': 'application/json' });

export default function AdminControlCenter() {
  const [urgent, setUrgent] = useState<any>(null);
  const [maintenance, setMaintenance] = useState({ enabled: false, message: '' });
  const [savingMaint, setSavingMaint] = useState(false);
  const { toast } = useToast();

  const reload = async () => {
    const [u, m] = await Promise.all([
      fetch(`${BASE}/api/admin/dashboard/urgent`, { headers: headers() }).then(r => r.json()),
      fetch(`${BASE}/api/admin/maintenance`, { headers: headers() }).then(r => r.json()),
    ]);
    setUrgent(u); setMaintenance({ enabled: !!m.enabled, message: m.message || '' });
  };
  useEffect(() => { reload(); const i = setInterval(reload, 30000); return () => clearInterval(i); }, []);

  const saveMaintenance = async () => {
    setSavingMaint(true);
    try {
      await fetch(`${BASE}/api/admin/maintenance`, { method: 'POST', headers: headers(), body: JSON.stringify(maintenance) });
      toast({ title: maintenance.enabled ? '🚧 تم تفعيل وضع الصيانة' : '✅ تم إيقاف وضع الصيانة' });
    } catch { toast({ title: 'فشل الحفظ', variant: 'destructive' }); }
    finally { setSavingMaint(false); }
  };

  const items = urgent ? [
    { key: 'stalePending', label: 'طلبات معلّقة أكثر من ساعة', value: urgent.stalePendingOrders, color: '#f59e0b', icon: Clock, href: '/admin/orders?status=processing' },
    { key: 'pendingPayments', label: 'إيداعات تنتظر الموافقة', value: urgent.pendingPayments, color: '#3b82f6', icon: CreditCard, href: '/admin/payments' },
    { key: 'failedToday', label: 'طلبات فشلت اليوم', value: urgent.failedOrdersToday, color: '#ef4444', icon: XCircle, href: '/admin/orders?status=failed' },
    { key: 'lowBal', label: 'عملاء برصيد أقل من $1', value: urgent.lowBalanceCustomers, color: '#a855f7', icon: Wallet, href: '/admin/users' },
    { key: 'retried', label: 'طلبات أعيدت محاولتها اليوم', value: urgent.ordersRetriedToday, color: '#06b6d4', icon: RefreshCw, href: '/admin/orders' },
  ] : [];

  const totalUrgent = urgent ? (urgent.stalePendingOrders + urgent.pendingPayments + urgent.failedOrdersToday) : 0;

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6" dir="rtl">
          <div>
            <h1 className="font-heading text-2xl font-bold">مركز التحكم السريع</h1>
            <p className="text-muted-foreground text-sm mt-1">نظرة فورية على ما يحتاج تدخلك الآن</p>
          </div>

          {/* Urgent Issues */}
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl p-5 border-2"
            style={{ background: totalUrgent > 0 ? 'rgba(239,68,68,0.06)' : 'rgba(34,197,94,0.05)',
                     borderColor: totalUrgent > 0 ? 'rgba(239,68,68,0.3)' : 'rgba(34,197,94,0.25)' }}>
            <div className="flex items-center gap-3 mb-4">
              {totalUrgent > 0
                ? <AlertTriangle size={22} className="text-red-400" />
                : <AlertCircle size={22} className="text-green-400" />}
              <div>
                <h2 className="font-bold">{totalUrgent > 0 ? 'مشاكل تحتاج تدخل عاجل' : 'كل شيء على ما يرام'}</h2>
                <p className="text-xs text-muted-foreground">
                  {totalUrgent > 0 ? `${totalUrgent} عنصر يحتاج اهتمامك` : 'لا توجد مشاكل عاجلة حالياً'}
                </p>
              </div>
              <button onClick={reload} className="ml-auto p-2 rounded-lg hover:bg-white/5"><RefreshCw size={14} /></button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {items.map(it => {
                const Icon = it.icon;
                return (
                  <Link key={it.key} href={it.href}
                    className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:border-primary/40 transition">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${it.color}20`, color: it.color }}>
                      <Icon size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-2xl font-black" style={{ color: it.value > 0 ? it.color : 'inherit' }}>{it.value}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{it.label}</p>
                    </div>
                    <ChevronRight size={14} className="text-muted-foreground shrink-0" />
                  </Link>
                );
              })}
            </div>
          </motion.div>

          {/* Maintenance Mode */}
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: maintenance.enabled ? 'rgba(245,158,11,0.18)' : 'rgba(34,197,94,0.15)',
                         color: maintenance.enabled ? '#f59e0b' : '#22c55e' }}>
                <Power size={18} />
              </div>
              <div>
                <h2 className="font-bold">وضع الصيانة</h2>
                <p className="text-xs text-muted-foreground">يمنع استقبال طلبات جديدة ويعرض رسالة للعملاء</p>
              </div>
              <label className="ml-auto inline-flex items-center cursor-pointer gap-2">
                <input type="checkbox" className="sr-only peer" checked={maintenance.enabled}
                  onChange={e => setMaintenance(m => ({ ...m, enabled: e.target.checked }))} />
                <div className="w-12 h-7 bg-muted rounded-full relative peer-checked:bg-amber-500/80 transition">
                  <div className="absolute top-0.5 left-0.5 bg-white w-6 h-6 rounded-full transition peer-checked:translate-x-5 rtl:peer-checked:-translate-x-5" />
                </div>
                <span className="text-xs font-bold">{maintenance.enabled ? 'مفعّل' : 'معطّل'}</span>
              </label>
            </div>
            <textarea
              value={maintenance.message}
              onChange={e => setMaintenance(m => ({ ...m, message: e.target.value }))}
              rows={3} maxLength={500}
              placeholder="الرسالة التي ستظهر للعملاء عند محاولة شراء"
              className="w-full px-3 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50"
            />
            <div className="flex justify-end mt-3">
              <button onClick={saveMaintenance} disabled={savingMaint}
                className="px-4 py-2 rounded-xl text-sm font-bold text-white disabled:opacity-50"
                style={{ background: maintenance.enabled ? 'linear-gradient(135deg,#f59e0b,#ef4444)' : 'linear-gradient(135deg,#6C5CE7,#a29bfe)' }}>
                {savingMaint ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
              </button>
            </div>
          </motion.div>

          {/* Quick actions */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { href: '/admin/staff', label: 'الموظفون والصلاحيات', icon: '👥' },
              { href: '/admin/scheduled', label: 'الإشعارات المجدولة', icon: '🕒' },
              { href: '/admin/top-selling', label: 'الأكثر مبيعاً', icon: '⭐' },
              { href: '/admin/provider-errors', label: 'أخطاء المزوّدين', icon: '⚠️' },
            ].map(a => (
              <Link key={a.href} href={a.href}
                className="flex items-center gap-3 p-4 bg-card border border-border rounded-2xl hover:border-primary/40 transition">
                <span className="text-2xl">{a.icon}</span>
                <span className="text-sm font-semibold">{a.label}</span>
                <ChevronRight size={14} className="ml-auto text-muted-foreground" />
              </Link>
            ))}
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
