import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { DollarSign, TrendingUp, TrendingDown, Users, Clock, ShoppingCart, RefreshCw, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

async function fetchFinancial() {
  const token = localStorage.getItem('elite_token');
  const res = await fetch(`${BASE}/api/admin/financial/summary`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error('Failed');
  return res.json();
}

function fmt(n: number, decimals = 2) { return n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }); }
function fmtSyp(n: number) { return n.toLocaleString('ar-SY') + ' ل.س'; }

const HOURS = Array.from({ length: 24 }, (_, i) => i);
function formatHour(h: number) {
  if (h === 0) return '12م';
  if (h < 12) return `${h}ص`;
  if (h === 12) return '12ظ';
  return `${h - 12}م`;
}

function StatCard({ icon: Icon, label, value, sub, color, growth }: { icon: any; label: string; value: string; sub?: string; color: string; growth?: number }) {
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className={`rounded-2xl border p-4 bg-card border-${color}/20`}>
      <div className={`w-9 h-9 rounded-xl bg-${color}/15 border border-${color}/20 flex items-center justify-center mb-3`}>
        <Icon size={16} className={`text-${color}`} />
      </div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-xl font-black mt-0.5">{value}</p>
      {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
      {growth !== undefined && (
        <p className={`text-xs mt-1 font-semibold flex items-center gap-1 ${growth >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
          {growth >= 0 ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
          {growth >= 0 ? '+' : ''}{fmt(growth, 1)}% مقارنة بـ 30 يوم سابق
        </p>
      )}
    </motion.div>
  );
}

const CustomTooltipUsd = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-xl px-3 py-2 text-xs shadow-xl">
      <p className="text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }} className="font-bold">{p.name}: ${fmt(p.value)}</p>
      ))}
    </div>
  );
};

export default function AdminFinancial() {
  const [view, setView] = useState<'usd' | 'syp'>('usd');
  const { data, isLoading, refetch, isFetching } = useQuery({ queryKey: ['admin', 'financial'], queryFn: fetchFinancial, staleTime: 120_000 });

  const peakMap: Record<number, number> = {};
  (data?.peakHours ?? []).forEach((p: any) => { peakMap[p.hour] = p.cnt; });
  const maxPeak = Math.max(1, ...Object.values(peakMap) as number[]);
  const topHour = data?.peakHours?.[0]?.hour;

  return (
    <ProtectedRoute adminOnly>
      <DashboardLayout>
        <div className="space-y-6 max-w-5xl mx-auto" dir="rtl">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-2xl font-bold">لوحة التحكم المالي</h1>
              <p className="text-sm text-muted-foreground mt-0.5">آخر 30 يوم — الأرباح الحقيقية بعد خصم تكلفة المزود</p>
            </div>
            <div className="flex gap-2 items-center">
              <div className="flex rounded-xl border border-white/10 overflow-hidden">
                {(['usd', 'syp'] as const).map(v => (
                  <button key={v} onClick={() => setView(v)} className={`px-3 py-1.5 text-xs font-semibold transition-colors ${view === v ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}>
                    {v === 'usd' ? '$ دولار' : 'ل.س ليرة'}
                  </button>
                ))}
              </div>
              <button onClick={() => refetch()} className="p-2 rounded-xl border border-white/10 hover:bg-white/5 transition-colors">
                <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
              </button>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[...Array(4)].map((_, i) => <div key={i} className="h-28 rounded-2xl bg-white/5 border border-white/10 animate-pulse" />)}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <StatCard icon={TrendingUp} label="إجمالي الإيرادات" color="primary"
                  value={view === 'usd' ? `$${fmt(data?.revenue30d ?? 0)}` : fmtSyp(data?.revenueSyp30d ?? 0)}
                  growth={data?.revenueGrowthPct} />
                <StatCard icon={DollarSign} label="صافي الربح الحقيقي" color="success"
                  value={view === 'usd' ? `$${fmt(data?.netProfit30d ?? 0)}` : fmtSyp(data?.netProfitSyp30d ?? 0)}
                  sub={`تكلفة: ${view === 'usd' ? '$' + fmt(data?.cost30d ?? 0) : fmtSyp(Math.round((data?.cost30d ?? 0) * (data?.sypRate ?? 13000)))}`} />
                <StatCard icon={ShoppingCart} label="متوسط قيمة الطلب" color="secondary"
                  value={view === 'usd' ? `$${fmt(data?.avgOrderValue ?? 0)}` : fmtSyp(Math.round((data?.avgOrderValue ?? 0) * (data?.sypRate ?? 13000)))}
                  sub={`${data?.orderCount30d ?? 0} طلب مكتمل`} />
                <StatCard icon={Users} label="معدل تحويل العملاء" color="accent"
                  value={`${data?.conversionRate ?? 0}%`}
                  sub={`${data?.activeUsers30d ?? 0} / ${data?.totalUsers ?? 0} عميل`} />
              </div>

              {/* Net Profit Chart */}
              <div className="bg-card border border-border rounded-2xl p-5">
                <h2 className="font-bold mb-1">مخطط الربح اليومي (30 يوم)</h2>
                <p className="text-xs text-muted-foreground mb-4">الإيرادات مقابل التكلفة مقابل صافي الربح</p>
                {(data?.daily?.length ?? 0) === 0 ? (
                  <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">لا توجد بيانات بعد</div>
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <AreaChart data={data?.daily?.map((d: any) => ({
                      date: d.date?.slice(5),
                      إيرادات: view === 'usd' ? +d.revenue.toFixed(2) : Math.round(d.revenue * (data?.sypRate ?? 13000)),
                      ربح: view === 'usd' ? +d.netProfit.toFixed(2) : Math.round(d.netProfit * (data?.sypRate ?? 13000)),
                      تكلفة: view === 'usd' ? +d.cost.toFixed(2) : Math.round(d.cost * (data?.sypRate ?? 13000)),
                    })) ?? []} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="revG" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6C5CE7" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#6C5CE7" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="profG" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#00cec9" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#00cec9" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="date" tick={{ fontSize: 9, fill: 'rgba(255,255,255,0.4)' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: 'rgba(255,255,255,0.4)' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltipUsd />} />
                      <Area type="monotone" dataKey="إيرادات" stroke="#6C5CE7" strokeWidth={2} fill="url(#revG)" />
                      <Area type="monotone" dataKey="ربح" stroke="#00cec9" strokeWidth={2} fill="url(#profG)" />
                      <Area type="monotone" dataKey="تكلفة" stroke="#fd79a8" strokeWidth={1.5} fill="none" strokeDasharray="4 2" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>

              {/* Peak Hours Heatmap */}
              <div className="bg-card border border-border rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Clock size={16} className="text-primary" />
                  <h2 className="font-bold">أوقات الذروة</h2>
                  {topHour !== undefined && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 text-xs font-bold border border-amber-500/20">
                      ذروة: {formatHour(topHour)}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-12 gap-1">
                  {HOURS.map(h => {
                    const cnt = peakMap[h] ?? 0;
                    const intensity = maxPeak > 0 ? cnt / maxPeak : 0;
                    return (
                      <div key={h} className="flex flex-col items-center gap-0.5">
                        <div
                          className="w-full rounded-sm transition-all"
                          style={{
                            height: '32px',
                            background: intensity > 0
                              ? `rgba(108, 92, 231, ${0.15 + intensity * 0.85})`
                              : 'rgba(255,255,255,0.05)',
                          }}
                          title={`${formatHour(h)}: ${cnt} طلب`}
                        />
                        <span className="text-[9px] text-muted-foreground">{h % 6 === 0 ? formatHour(h) : ''}</span>
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-muted-foreground mt-2">الأعمدة الأغمق = أكثر الطلبات (من الطلبات المكتملة آخر 30 يوم)</p>
              </div>

              {/* Summary footer */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: 'سعر صرف الدولار', value: `${(data?.sypRate ?? 13000).toLocaleString()} ل.س` },
                  { label: 'إجمالي الطلبات', value: String(data?.orderCount30d ?? 0) },
                  { label: 'معدل النمو', value: `${data?.revenueGrowthPct ?? 0 >= 0 ? '+' : ''}${fmt(data?.revenueGrowthPct ?? 0, 1)}%` },
                  { label: 'المستخدمون النشطون', value: `${data?.activeUsers30d ?? 0} / ${data?.totalUsers ?? 0}` },
                ].map(item => (
                  <div key={item.label} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
                    <div className="text-base font-bold">{item.value}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{item.label}</div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
