import React, { useEffect, useRef, useState } from 'react';
import { Link, useRoute, useSearch } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { useGetOrder } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import { useToast } from '@/hooks/use-toast';
import { useCurrency } from '@/hooks/use-currency';
import {
  CheckCircle2, Loader2, PackageSearch,
  RefreshCw, Wallet, Clock, XCircle, ShoppingBag, Share2
} from 'lucide-react';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function LivePulse() {
  return (
    <span className="relative flex h-2.5 w-2.5">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" />
    </span>
  );
}

// Confetti particle
function Particle({ x, y, color, delay }: { x: number; y: number; color: string; delay: number }) {
  return (
    <motion.div
      style={{ position: 'absolute', left: `${x}%`, top: 0, width: 8, height: 8, borderRadius: 2, background: color, zIndex: 0 }}
      initial={{ y: -10, opacity: 1, rotate: 0 }}
      animate={{ y: y, opacity: 0, rotate: Math.random() * 360 }}
      transition={{ duration: 1.4, delay, ease: 'easeOut' }}
    />
  );
}

function SuccessConfetti() {
  const particles = React.useMemo(() => Array.from({ length: 18 }, (_, i) => ({
    x: Math.random() * 100,
    y: Math.random() * 200 + 80,
    color: ['#6C5CE7', '#00b894', '#fdcb6e', '#e17055', '#74b9ff', '#a29bfe'][i % 6],
    delay: Math.random() * 0.5,
  })), []);

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {particles.map((p, i) => <Particle key={i} {...p} />)}
    </div>
  );
}

export default function OrderResult() {
  const [successMatch, successParams] = useRoute('/orders/:id/success');
  const [failedMatch, failedParams] = useRoute('/orders/:id/failed');
  const searchStr = useSearch();
  const { toast } = useToast();
  const { formatPrice } = useCurrency();
  const queryClient = useQueryClient();
  const [showConfetti, setShowConfetti] = useState(false);

  const id = successParams?.id || failedParams?.id || '';
  const isSuccessRoute = Boolean(successMatch);
  const reason = new URLSearchParams(searchStr).get('reason');
  const isUuid = UUID_RE.test(id);

  const resolvedRef = useRef(false);

  const { data: order, isLoading } = useGetOrder(id, {
    query: {
      enabled: isUuid,
      refetchInterval: (query: any) => {
        const status = (query.state.data as any)?.status;
        if (status === 'completed' || status === 'failed') return false;
        return 3500;
      },
    } as any,
  });

  useEffect(() => {
    if (!order || resolvedRef.current) return;
    const status = order.status;

    if (status === 'completed') {
      resolvedRef.current = true;
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 2000);
      queryClient.invalidateQueries({ queryKey: ['/api/wallet'] });
      queryClient.invalidateQueries({ queryKey: ['/api/me'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      toast({ title: '✅ تم تنفيذ الطلب بنجاح', description: order.productName ?? '' });
    } else if (status === 'failed') {
      resolvedRef.current = true;
      queryClient.invalidateQueries({ queryKey: ['/api/wallet'] });
      queryClient.invalidateQueries({ queryKey: ['/api/me'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      toast({ title: '❌ فشل الطلب — تم إرجاع الرصيد', description: order.productName ?? '', variant: 'destructive' });
    }
  }, [order?.status, order?.productName, queryClient, toast]);

  const isProcessing = order?.status === 'processing' || order?.status === 'pending';
  const isOrderCompleted = order?.status === 'completed';
  const isOrderFailed = order?.status === 'failed';

  const showSuccess = isOrderCompleted || (isSuccessRoute && !isOrderFailed);
  const showFailed = isOrderFailed || (!isSuccessRoute && !isOrderCompleted);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: 'Elite Store', text: `اشتريت ${order?.productName ?? 'منتجاً'} من Elite Store!`, url: window.location.origin });
    }
  };

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-xl mx-auto py-8 px-4" dir="rtl">
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="relative bg-card border border-border rounded-3xl p-7 text-center overflow-hidden"
          >
            {showConfetti && <SuccessConfetti />}

            {/* Glow background */}
            <div className="absolute inset-0 pointer-events-none" style={{
              background: showSuccess && !isProcessing
                ? 'radial-gradient(ellipse at 50% 0%, rgba(0,184,148,0.07) 0%, transparent 65%)'
                : isOrderFailed
                ? 'radial-gradient(ellipse at 50% 0%, rgba(225,112,85,0.07) 0%, transparent 65%)'
                : 'radial-gradient(ellipse at 50% 0%, rgba(245,158,11,0.07) 0%, transparent 65%)',
            }} />

            {/* Status Icon */}
            <AnimatePresence mode="wait">
              {isProcessing || (!order && isLoading) ? (
                <motion.div key="processing" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.8, opacity: 0 }}
                  className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-5 relative"
                  style={{ background: 'rgba(245,158,11,0.12)', border: '2px solid rgba(245,158,11,0.25)' }}>
                  <Clock size={40} className="text-amber-400" />
                  <span className="absolute inset-0 rounded-full animate-ping border-2 border-amber-400/15" />
                </motion.div>
              ) : showSuccess ? (
                <motion.div key="success" initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-5"
                  style={{ background: 'rgba(0,184,148,0.12)', border: '2px solid rgba(0,184,148,0.25)' }}>
                  <CheckCircle2 size={44} className="text-green-400" />
                </motion.div>
              ) : (
                <motion.div key="failed" initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-5"
                  style={{ background: 'rgba(225,112,85,0.12)', border: '2px solid rgba(225,112,85,0.25)' }}>
                  <XCircle size={44} className="text-red-400" />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Title */}
            <h1 className="font-heading text-2xl font-black mb-2">
              {isProcessing || (!order && isLoading)
                ? 'جاري معالجة الطلب...'
                : showSuccess ? 'تم تنفيذ الطلب بنجاح ✅'
                : 'لم يتم تنفيذ الطلب ❌'}
            </h1>

            <p className="text-muted-foreground text-sm leading-7">
              {isProcessing || (!order && isLoading)
                ? 'يتم إرسال الطلب للمزود. الحالة تتحدث تلقائياً — لا تحديث الصفحة.'
                : showSuccess ? 'تم تنفيذ طلبك بنجاح. يمكنك مراجعة تفاصيل الطلب في أي وقت.'
                : reason || 'فشل تنفيذ الطلب. تم إرجاع المبلغ كاملاً إلى محفظتك تلقائياً.'}
            </p>

            {/* Refund notice on failure */}
            <AnimatePresence>
              {showFailed && !isProcessing && (
                <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="mt-4 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
                  style={{ background: 'rgba(0,184,148,0.1)', border: '1px solid rgba(0,184,148,0.25)', color: '#00b894' }}>
                  <Wallet size={14} />
                  تم إرجاع الرصيد إلى محفظتك
                </motion.div>
              )}
            </AnimatePresence>

            {/* Live indicator */}
            <AnimatePresence>
              {isProcessing && (
                <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="flex items-center justify-center gap-2 mt-4 text-amber-400">
                  <LivePulse />
                  <span className="text-xs font-semibold">متابعة مباشرة...</span>
                  <Loader2 size={13} className="animate-spin" />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Order Details */}
            {isLoading && isUuid && !order ? (
              <div className="mt-6 flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Loader2 size={16} className="animate-spin" />
                تحميل تفاصيل الطلب...
              </div>
            ) : order ? (
              <motion.div layout className="mt-6 bg-background border border-border rounded-2xl p-4 text-right space-y-3">
                <div className="flex justify-between gap-4">
                  <span className="text-muted-foreground text-sm">رقم الطلب</span>
                  <span className="font-mono text-xs font-bold text-primary">
                    {(order as any).orderNumber
                      ? `#ORD-${String((order as any).orderNumber).padStart(5, '0')}`
                      : `#${order.id.slice(0, 8).toUpperCase()}`}
                  </span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-muted-foreground text-sm">المنتج</span>
                  <span className="font-bold text-sm text-end">{order.productName}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-muted-foreground text-sm">الكمية</span>
                  <span className="font-semibold text-sm">× {order.qty}</span>
                </div>
                <div className="flex justify-between gap-4 items-center">
                  <span className="text-muted-foreground text-sm">الحالة</span>
                  <div className="flex items-center gap-2">
                    {isProcessing && <LivePulse />}
                    <StatusBadge status={order.status} size="sm" />
                  </div>
                </div>
                <div className="pt-2 border-t border-border flex justify-between gap-4 items-center">
                  <span className="text-muted-foreground text-sm font-semibold">الإجمالي المدفوع</span>
                  <span className="font-black text-lg text-primary">
                    {formatPrice(Number(order.totalPrice))}
                  </span>
                </div>
              </motion.div>
            ) : null}

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3 mt-6">
              <Link href="/orders"
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-primary text-white font-bold text-sm transition-all active:scale-95 col-span-2"
                style={{ boxShadow: '0 4px 20px rgba(108,92,231,0.35)' }}>
                <PackageSearch size={16} />
                عرض طلباتي
              </Link>
              {order?.productId && (
                <Link href={`/products/${order.productId}`}
                  className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-background border border-border font-bold text-sm active:scale-95 hover:bg-card transition-all">
                  <ShoppingBag size={16} />
                  إعادة الطلب
                </Link>
              )}
              <Link href="/wallet"
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-background border border-border font-bold text-sm active:scale-95 hover:bg-card transition-all">
                <Wallet size={16} />
                المحفظة
              </Link>
              {isOrderCompleted && typeof navigator?.share === 'function' && (
                <button onClick={handleShare}
                  className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-background border border-border font-bold text-sm active:scale-95 hover:bg-card transition-all col-span-2">
                  <Share2 size={16} />
                  مشاركة
                </button>
              )}
            </div>

          </motion.div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
