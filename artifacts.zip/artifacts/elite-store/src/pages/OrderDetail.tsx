import React from 'react';
import { Link, useRoute } from 'wouter';
import { motion } from 'framer-motion';
import { useGetOrder } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import {
  ArrowRight, ArrowLeft, Package, Clock, CheckCircle2, XCircle,
  Copy, Gift, Tag, User, Hash, Calendar, RefreshCw, Loader2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useSettings } from '@/hooks/use-settings';
import { useLanguage } from '@/i18n';
import { useCurrency } from '@/hooks/use-currency';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function fmtOrderNum(n: number | null | undefined) {
  return n ? `#ORD-${String(n).padStart(5, '0')}` : '';
}

function Row({ icon, label, value, mono = false, highlight = false }: {
  icon: React.ReactNode; label: string; value: React.ReactNode; mono?: boolean; highlight?: boolean;
}) {
  return (
    <div className={`flex items-start gap-3 py-3 border-b border-border last:border-0 ${highlight ? 'bg-primary/5 -mx-5 px-5 rounded-xl' : ''}`}>
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
        <div className={`text-sm font-semibold break-all ${mono ? 'font-mono' : ''} ${highlight ? 'text-primary' : ''}`}>
          {value}
        </div>
      </div>
    </div>
  );
}

export default function OrderDetail() {
  const [, params] = useRoute('/orders/:id');
  const id = params?.id ?? '';
  const isUuid = UUID_RE.test(id);
  const { toast } = useToast();
  const { sypRate: SYP_RATE } = useSettings();
  const { lang, dir } = useLanguage();
  const { formatPrice } = useCurrency();
  const ArrowBack = dir === 'rtl' ? ArrowLeft : ArrowRight;

  const { data: order, isLoading } = useGetOrder(id, {
    query: {
      enabled: isUuid,
      refetchInterval: (q: any) => {
        const status = (q.state.data as any)?.status;
        return status === 'completed' || status === 'failed' ? false : 4000;
      },
    } as any,
  });

  function copyCode(code: string) {
    navigator.clipboard.writeText(code).then(() => {
      toast({ title: lang === 'ar' ? '✅ تم النسخ' : '✅ Copied', description: code.slice(0, 30) });
    });
  }

  const isProcessing = order?.status === 'processing' || order?.status === 'pending';
  const isCompleted = order?.status === 'completed';
  const isFailed = order?.status === 'failed';

  const totalUsd = parseFloat((order as any)?.totalPrice?.toString() ?? '0');
  const totalSyp = totalUsd * SYP_RATE;
  const originalUsd = parseFloat((order as any)?.originalPrice?.toString() ?? '0');
  const promoDiscount = parseFloat((order as any)?.promoDiscount?.toString() ?? '0');

  const statusColor = isCompleted
    ? 'text-green-400'
    : isFailed
    ? 'text-red-400'
    : 'text-amber-400';

  const statusBg = isCompleted
    ? 'rgba(34,197,94,0.12)'
    : isFailed
    ? 'rgba(239,68,68,0.12)'
    : 'rgba(245,158,11,0.12)';

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-lg mx-auto py-6 px-4" dir={dir}>

          {/* Back */}
          <Link href="/orders" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-5 transition-colors">
            <ArrowBack size={15} />
            {lang === 'ar' ? 'كل الطلبات' : 'All Orders'}
          </Link>

          {isLoading ? (
            <div className="flex flex-col items-center gap-3 py-20 text-muted-foreground">
              <Loader2 size={32} className="animate-spin text-primary" />
              <p className="text-sm">{lang === 'ar' ? 'جاري تحميل الطلب...' : 'Loading order...'}</p>
            </div>
          ) : !order ? (
            <div className="flex flex-col items-center gap-3 py-20 text-muted-foreground">
              <Package size={40} />
              <p>{lang === 'ar' ? 'الطلب غير موجود' : 'Order not found'}</p>
              <Link href="/orders" className="text-sm text-primary underline">
                {lang === 'ar' ? 'العودة للطلبات' : 'Back to orders'}
              </Link>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >

              {/* Status Card */}
              <div
                className="rounded-2xl p-5 flex items-center gap-4"
                style={{ background: statusBg, border: `1px solid ${isCompleted ? 'rgba(34,197,94,0.2)' : isFailed ? 'rgba(239,68,68,0.2)' : 'rgba(245,158,11,0.2)'}` }}
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: statusBg }}>
                  {isProcessing ? (
                    <RefreshCw size={22} className="animate-spin text-amber-400" />
                  ) : isCompleted ? (
                    <CheckCircle2 size={22} className="text-green-400" />
                  ) : (
                    <XCircle size={22} className="text-red-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`font-bold text-base ${statusColor}`}>
                    {isProcessing
                      ? (lang === 'ar' ? 'جاري تنفيذ الطلب...' : 'Processing...')
                      : isCompleted
                      ? (lang === 'ar' ? 'تم تنفيذ الطلب بنجاح' : 'Order Completed')
                      : (lang === 'ar' ? 'فشل تنفيذ الطلب' : 'Order Failed')}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5 font-mono">
                    {fmtOrderNum((order as any).orderNumber)}
                  </p>
                </div>
                <StatusBadge status={order.status} size="sm" />
              </div>

              {/* Delivered Code — highlighted if present */}
              {(order as any).deliveredCode && isCompleted && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-green-500/10 border border-green-500/25 rounded-2xl p-5"
                >
                  <p className="text-xs text-green-400 font-semibold mb-2">
                    {lang === 'ar' ? '🎁 كود التفعيل / الرمز المُسلَّم' : '🎁 Delivered Code'}
                  </p>
                  <div className="flex items-center gap-3">
                    <code className="flex-1 text-sm font-mono bg-black/20 rounded-lg px-3 py-2 break-all text-green-300">
                      {(order as any).deliveredCode}
                    </code>
                    <button
                      onClick={() => copyCode((order as any).deliveredCode)}
                      className="shrink-0 w-9 h-9 rounded-lg bg-green-500/20 hover:bg-green-500/30 flex items-center justify-center transition-colors"
                    >
                      <Copy size={15} className="text-green-400" />
                    </button>
                  </div>
                </motion.div>
              )}

              {/* Details Card */}
              <div className="bg-card border border-border rounded-2xl p-5">
                <h2 className="text-sm font-bold mb-4 text-muted-foreground uppercase tracking-wide">
                  {lang === 'ar' ? 'تفاصيل الطلب' : 'Order Details'}
                </h2>

                <Row
                  icon={<Package size={14} className="text-primary" />}
                  label={lang === 'ar' ? 'المنتج' : 'Product'}
                  value={order.productName}
                />

                <Row
                  icon={<Hash size={14} className="text-primary" />}
                  label={lang === 'ar' ? 'رقم الطلب' : 'Order Number'}
                  value={fmtOrderNum((order as any).orderNumber) || order.id.slice(0, 8)}
                  mono
                />

                {(order as any).playerId && (
                  <Row
                    icon={<User size={14} className="text-primary" />}
                    label={lang === 'ar' ? 'معرف اللاعب / Player ID' : 'Player ID'}
                    value={(order as any).playerId}
                    mono
                  />
                )}

                {(order as any).fieldValues && typeof (order as any).fieldValues === 'object' &&
                  Object.entries((order as any).fieldValues as Record<string, string>)
                    .filter(([k, v]) => v && k !== 'playerId')
                    .map(([k, v]) => (
                      <Row
                        key={k}
                        icon={<User size={14} className="text-primary" />}
                        label={k}
                        value={String(v)}
                        mono
                      />
                    ))
                }

                <Row
                  icon={<Package size={14} className="text-primary" />}
                  label={lang === 'ar' ? 'الكمية' : 'Quantity'}
                  value={`x${order.qty}`}
                />

                <Row
                  icon={<Calendar size={14} className="text-primary" />}
                  label={lang === 'ar' ? 'تاريخ الطلب' : 'Order Date'}
                  value={new Date(order.createdAt).toLocaleString('en-GB')}
                />

                {(order as any).completedAt && isCompleted && (() => {
                  const start = new Date(order.createdAt).getTime();
                  const end = new Date((order as any).completedAt).getTime();
                  const ms = Math.max(0, end - start);
                  const fmtDuration = (totalMs: number) => {
                    const sec = Math.round(totalMs / 1000);
                    if (lang === 'ar') {
                      if (sec < 60) return `${sec} ثانية`;
                      const m = Math.floor(sec / 60);
                      const s = sec % 60;
                      if (m < 60) return s ? `${m} دقيقة و ${s} ثانية` : `${m} دقيقة`;
                      const h = Math.floor(m / 60);
                      const mm = m % 60;
                      if (h < 24) return mm ? `${h} ساعة و ${mm} دقيقة` : `${h} ساعة`;
                      const d = Math.floor(h / 24);
                      const hh = h % 24;
                      return hh ? `${d} يوم و ${hh} ساعة` : `${d} يوم`;
                    }
                    if (sec < 60) return `${sec}s`;
                    const m = Math.floor(sec / 60);
                    const s = sec % 60;
                    if (m < 60) return s ? `${m}m ${s}s` : `${m}m`;
                    const h = Math.floor(m / 60);
                    const mm = m % 60;
                    if (h < 24) return mm ? `${h}h ${mm}m` : `${h}h`;
                    const d = Math.floor(h / 24);
                    const hh = h % 24;
                    return hh ? `${d}d ${hh}h` : `${d}d`;
                  };
                  return (
                    <Row
                      icon={<Clock size={14} className="text-green-400" />}
                      label={lang === 'ar' ? '⏱ مدة التنفيذ الفعلية' : '⏱ Actual Processing Time'}
                      value={<span className="text-green-400">{fmtDuration(ms)}</span>}
                    />
                  );
                })()}

                {(order as any).giftToEmail && (
                  <Row
                    icon={<Gift size={14} className="text-amber-400" />}
                    label={lang === 'ar' ? 'هدية إلى' : 'Gift To'}
                    value={(order as any).giftToEmail}
                    mono
                  />
                )}

                {promoDiscount > 0 && (
                  <Row
                    icon={<Tag size={14} className="text-green-400" />}
                    label={lang === 'ar' ? 'خصم كود الترويج' : 'Promo Discount'}
                    value={`-${(promoDiscount * 100).toFixed(0)}%`}
                  />
                )}

                {/* Pricing */}
                <div className="mt-4 pt-4 border-t border-border space-y-2">
                  {originalUsd > 0 && originalUsd !== totalUsd && (
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>{lang === 'ar' ? 'السعر قبل الخصم' : 'Original Price'}</span>
                      <span className="line-through">{originalUsd.toFixed(2)} $</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{lang === 'ar' ? 'المبلغ المدفوع' : 'Total Paid'}</span>
                    <div className="text-end">
                      {(() => {
                        const paidAmount = parseFloat((order as any)?.paidAmount?.toString() ?? '');
                        const paidCurrency = (order as any)?.paidCurrency as string | undefined;
                        if (Number.isFinite(paidAmount) && paidCurrency) {
                          const suffix = paidCurrency === 'SYP' ? 'ل.س' : paidCurrency === 'EUR' ? '€' : '$';
                          const formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: paidCurrency === 'SYP' ? 0 : 2 }).format(paidAmount);
                          return (
                            <>
                              <p className="text-base font-bold text-primary">
                                {paidCurrency === 'EUR' || paidCurrency === 'USD' ? `${suffix}${formatted}` : `${formatted} ${suffix}`}
                              </p>
                              <p className="text-[10px] text-muted-foreground mt-0.5">
                                {lang === 'ar' ? 'القيمة المخصومة من المحفظة وقت الشراء' : 'Locked at checkout'}
                              </p>
                            </>
                          );
                        }
                        return (
                          <>
                            <p className="text-base font-bold text-primary">{formatPrice(totalUsd)}</p>
                            <p className="text-xs text-muted-foreground">{totalSyp.toLocaleString('en-US', { maximumFractionDigits: 0 })} ل.س</p>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                </div>
              </div>

              {/* Failed message */}
              {isFailed && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 text-sm text-red-300">
                  {lang === 'ar'
                    ? 'فشل تنفيذ الطلب. إذا تم خصم أي مبلغ من محفظتك، تم إرجاعه تلقائياً.'
                    : 'Order failed. Any deducted balance has been automatically refunded to your wallet.'}
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3">
                <Link
                  href="/orders"
                  className="flex-1 h-10 rounded-xl bg-muted hover:bg-muted/80 flex items-center justify-center text-sm font-medium transition-colors"
                >
                  {lang === 'ar' ? 'كل الطلبات' : 'All Orders'}
                </Link>
                <Link
                  href="/products"
                  className="flex-1 h-10 rounded-xl bg-primary/15 hover:bg-primary/25 text-primary flex items-center justify-center text-sm font-medium transition-colors"
                >
                  {lang === 'ar' ? 'تسوّق مجدداً' : 'Shop Again'}
                </Link>
              </div>

            </motion.div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
