import React, { useEffect, useState } from 'react';
import { useParams, useLocation, Link } from 'wouter';
import { PublicLayout as Layout } from '@/components/Layout';
import { Gift, ArrowLeft, ShoppingBag, Check, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

interface BundleItem {
  productId: string; qty: number;
  product?: { id: string; name: string; imageUrl?: string | null; priceUsd: number; status: string; requiredFields?: string[] } | null;
}
interface Bundle {
  id: number; name: string; nameAr?: string | null; description?: string | null; imageUrl?: string | null;
  bundlePriceUsd: number; badge?: string | null; items: BundleItem[];
  originalTotalUsd: number; savingsUsd: number; savingsPercent: number;
}

export default function BundleDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [bundle, setBundle] = useState<Bundle | null>(null);
  const [loading, setLoading] = useState(true);
  const [playerIds, setPlayerIds] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetch(`${BASE}/api/bundles/${id}`).then(r => r.ok ? r.json() : null).then(setBundle).finally(() => setLoading(false));
  }, [id]);

  const itemsRequiringId = (bundle?.items || []).filter(i => {
    const r = i.product?.requiredFields || [];
    return r.includes('playerId') || r.includes('email');
  });

  const order = async () => {
    if (!user) { navigate(`/login?redirect=/bundles/${id}`); return; }
    if (!bundle) return;
    for (const it of itemsRequiringId) {
      if (!playerIds[it.productId]?.trim()) {
        toast({ title: 'حقل مفقود', description: `يرجى إدخال المعرف لـ ${it.product?.name}`, variant: 'destructive' });
        return;
      }
    }
    if (!confirm(`تأكيد شراء حزمة "${bundle.nameAr || bundle.name}" بسعر $${bundle.bundlePriceUsd.toFixed(2)}؟`)) return;
    setSubmitting(true);
    try {
      const r = await fetch(`${BASE}/api/bundles/${bundle.id}/order`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('elite_token') || ''}` },
        body: JSON.stringify({ playerIds }),
      });
      const j = await r.json();
      if (!r.ok) {
        toast({ title: 'فشل الطلب', description: j.message || j.error || '', variant: 'destructive' });
        return;
      }
      toast({ title: '🎁 تم استلام طلب الحزمة', description: `${j.orders?.length || 0} منتج قيد المعالجة` });
      navigate('/orders');
    } catch (e: any) {
      toast({ title: 'فشل الطلب', description: String(e?.message || e), variant: 'destructive' });
    } finally { setSubmitting(false); }
  };

  if (loading) return <Layout><div className="text-center py-20 text-muted-foreground">جاري التحميل...</div></Layout>;
  if (!bundle) return <Layout><div className="text-center py-20"><AlertCircle className="mx-auto text-destructive mb-3" size={48} /><p>الحزمة غير موجودة</p><Link href="/bundles" className="text-primary text-sm mt-3 inline-block">عودة للحزم</Link></div></Layout>;

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 max-w-3xl" dir="rtl">
        <Link href="/bundles" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary mb-4">
          <ArrowLeft size={14} /> كل الحزم
        </Link>

        <div className="bg-card border border-border rounded-3xl overflow-hidden mb-5">
          <div className="relative h-48 md:h-64 bg-gradient-to-br from-primary/30 via-purple-500/20 to-pink-500/20">
            {bundle.imageUrl ? (
              <img src={bundle.imageUrl} alt={bundle.nameAr || bundle.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Gift size={96} className="text-primary/60" />
              </div>
            )}
            {bundle.savingsPercent > 0 && (
              <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-success text-white font-extrabold shadow-lg">
                وفّر {bundle.savingsPercent}%
              </div>
            )}
          </div>
          <div className="p-5">
            <h1 className="font-heading text-2xl md:text-3xl font-extrabold mb-2">{bundle.nameAr || bundle.name}</h1>
            {bundle.description && <p className="text-sm text-muted-foreground mb-4">{bundle.description}</p>}
            <div className="flex items-end gap-3 mb-4 pb-4 border-b border-border">
              <span className="text-4xl font-extrabold text-primary">${bundle.bundlePriceUsd.toFixed(2)}</span>
              {bundle.savingsUsd > 0 && (
                <>
                  <span className="text-lg line-through text-muted-foreground mb-1">${bundle.originalTotalUsd.toFixed(2)}</span>
                  <span className="text-sm font-bold text-success mb-1">وفّر ${bundle.savingsUsd.toFixed(2)}</span>
                </>
              )}
            </div>

            <h2 className="font-bold text-sm mb-2">يشمل ({bundle.items.length} منتج):</h2>
            <div className="space-y-2 mb-5">
              {bundle.items.map(it => (
                <div key={it.productId} className="flex items-center gap-3 bg-muted/40 rounded-xl p-3">
                  {it.product?.imageUrl ? (
                    <img src={it.product.imageUrl} alt="" className="w-12 h-12 rounded-lg object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center"><Check size={20} className="text-primary" /></div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold truncate">{it.product?.name || it.productId}</div>
                    <div className="text-[11px] text-muted-foreground">الكمية: {it.qty} • سعر مفرد: ${it.product?.priceUsd?.toFixed(2) ?? '0.00'}</div>
                  </div>
                </div>
              ))}
            </div>

            {itemsRequiringId.length > 0 && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 mb-4">
                <p className="text-xs font-bold text-amber-400 mb-2 flex items-center gap-1">
                  <AlertCircle size={14} /> أدخل المعرفات المطلوبة:
                </p>
                <div className="space-y-2">
                  {itemsRequiringId.map(it => (
                    <div key={it.productId}>
                      <label className="text-[11px] text-muted-foreground block mb-1">{it.product?.name}</label>
                      <input
                        value={playerIds[it.productId] || ''}
                        onChange={(e) => setPlayerIds({ ...playerIds, [it.productId]: e.target.value })}
                        placeholder="معرف اللاعب / الإيميل"
                        className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button onClick={order} disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-2 py-3.5 rounded-xl bg-primary text-primary-foreground font-extrabold text-base hover:opacity-90 disabled:opacity-50 shadow-lg shadow-primary/20">
              <ShoppingBag size={18} />
              {submitting ? 'جارٍ المعالجة...' : `اطلب الحزمة الآن — $${bundle.bundlePriceUsd.toFixed(2)}`}
            </button>
            <p className="text-[10px] text-muted-foreground text-center mt-2">
              سيتم خصم المبلغ من رصيدك وإنشاء طلب لكل منتج بالحزمة
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}
