import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { useGetOrders } from '@workspace/api-client-react';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { StatusBadge } from '@/components/StatusBadge';
import { useLanguage } from '@/i18n';
import { Package, Search, RefreshCw, Wifi, CheckCircle2, XCircle, RotateCcw, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { useSettings } from '@/hooks/use-settings';
import { useOrderPolling } from '@/hooks/use-order-polling';
import { useToast } from '@/hooks/use-toast';
import { useCurrency } from '@/hooks/use-currency';

const STATUS_TABS = [
  { key: '', labelAr: 'الكل', labelEn: 'All' },
  { key: 'completed', labelAr: 'مكتمل', labelEn: 'Completed' },
  { key: 'processing', labelAr: 'جاري', labelEn: 'Processing' },
  { key: 'pending', labelAr: 'انتظار', labelEn: 'Pending' },
  { key: 'failed', labelAr: 'فشل', labelEn: 'Failed' },
];

function LiveDot() {
  return (
    <span className="relative flex h-2 w-2 shrink-0">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
      <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500" />
    </span>
  );
}

export default function Orders() {
  const { lang, dir } = useLanguage();
  const [, navigate] = useLocation();
  const { sypRate: SYP_RATE } = useSettings();
  const { formatPrice } = useCurrency();
  const { toast } = useToast();
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [fromDate, setFromDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().slice(0, 10);
  });
  const [toDate, setToDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  });
  const [showDateFilter, setShowDateFilter] = useState(false);

  const { data, isLoading, refetch, isFetching } = useGetOrders({
    page: 1,
    limit: 100,
    status: status || undefined,
  });

  const allOrders = data?.orders ?? [];

  // Real-time polling for processing orders
  useOrderPolling(allOrders.map(o => ({ id: o.id, status: o.status })));

  // Detect status transitions and toast notifications
  const prevStatusesRef = useRef<Record<string, string>>({});
  useEffect(() => {
    for (const order of allOrders) {
      const prev = prevStatusesRef.current[order.id];
      if (prev && prev !== order.status) {
        if (order.status === 'completed') {
          toast({
            title: lang === 'ar' ? '✅ تم تنفيذ الطلب' : '✅ Order Completed',
            description: order.productName ?? '',
          });
        } else if (order.status === 'failed') {
          toast({
            title: lang === 'ar' ? '❌ فشل الطلب — تم إرجاع الرصيد' : '❌ Order Failed — Balance Refunded',
            description: order.productName ?? '',
            variant: 'destructive',
          });
        }
      }
      prevStatusesRef.current[order.id] = order.status;
    }
  }, [allOrders, lang, toast]);

  const filtered = allOrders.filter(order => {
    if (search) {
      const s = search.toLowerCase();
      if (
        !order.productName?.toLowerCase().includes(s) &&
        !order.id?.toLowerCase().includes(s)
      ) return false;
    }
    if (fromDate) {
      const orderDate = new Date(order.createdAt).toISOString().slice(0, 10);
      if (orderDate < fromDate) return false;
    }
    if (toDate) {
      const orderDate = new Date(order.createdAt).toISOString().slice(0, 10);
      if (orderDate > toDate) return false;
    }
    return true;
  });

  const totalSYP = filtered.reduce(
    (s, o) => s + parseFloat(o.totalPrice?.toString() ?? '0') * SYP_RATE,
    0,
  );

  const processingCount = allOrders.filter(o => o.status === 'processing').length;
  const getCounts = (key: string) =>
    allOrders.filter(o => (!key ? true : o.status === key)).length;

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-3 sm:space-y-4 max-w-5xl mx-auto w-full min-w-0 overflow-x-hidden px-2 sm:px-4 pt-2 sm:pt-4" dir={dir}>

          {/* Header */}
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <h1 className="font-heading text-xl sm:text-2xl font-bold truncate">
                {lang === 'ar' ? 'طلباتي' : 'My Orders'}
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {lang === 'ar' ? `${allOrders.length} طلب` : `${allOrders.length} orders`}
              </p>
            </div>
            <button
              onClick={() => refetch()}
              disabled={isFetching}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-border bg-card hover:bg-muted transition-all active:scale-95 shrink-0"
            >
              <RefreshCw size={12} className={isFetching ? 'animate-spin' : ''} />
              {lang === 'ar' ? 'تحديث' : 'Refresh'}
            </button>
          </div>

          {/* Live Tracker Banner */}
          <AnimatePresence>
            {processingCount > 0 && (
              <motion.div
                key="live-banner"
                initial={{ opacity: 0, y: -8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.97 }}
                className="flex items-center gap-3 px-4 py-3 rounded-2xl border"
                style={{
                  background: 'linear-gradient(135deg, rgba(245,158,11,0.12), rgba(234,179,8,0.06))',
                  borderColor: 'rgba(245,158,11,0.3)',
                }}
              >
                <LiveDot />
                <Wifi size={14} className="text-amber-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-amber-400">
                    {lang === 'ar'
                      ? `${processingCount} طلب قيد التنفيذ — متابعة تلقائية`
                      : `${processingCount} order${processingCount > 1 ? 's' : ''} processing — live tracking`}
                  </p>
                  <p className="text-[10px] text-amber-400/70 mt-0.5">
                    {lang === 'ar'
                      ? 'الحالة والرصيد يتحدثان تلقائياً دون تحديث الصفحة'
                      : 'Status & wallet update automatically without refresh'}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Search + Date Filters — date collapses on mobile */}
          <div className="bg-card border border-border rounded-2xl p-2 sm:p-3 space-y-2 min-w-0">
            <div className="flex gap-2 min-w-0">
              {/* Search */}
              <div className="relative flex-1 min-w-0">
                <Search size={14} className={`absolute top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none ${dir === 'rtl' ? 'right-3' : 'left-3'}`} />
                <input
                  type="text"
                  value={searchInput}
                  onChange={e => { setSearchInput(e.target.value); setSearch(e.target.value); }}
                  placeholder={lang === 'ar' ? 'بحث بالمنتج أو الرقم...' : 'Search...'}
                  className={`w-full min-w-0 bg-background border border-border rounded-xl py-2 sm:py-2.5 text-sm focus:outline-none focus:border-primary/50 transition-colors ${dir === 'rtl' ? 'pr-9 pl-3 text-right' : 'pl-9 pr-3 text-left'}`}
                />
              </div>
              <button
                type="button"
                onClick={() => setShowDateFilter(v => !v)}
                className={`shrink-0 flex items-center gap-1.5 px-3 rounded-xl text-xs font-semibold border transition-colors ${showDateFilter ? 'bg-primary/15 border-primary/40 text-primary' : 'bg-background border-border text-muted-foreground hover:bg-muted'}`}
                aria-expanded={showDateFilter}
              >
                <SlidersHorizontal size={13} />
                <span className="hidden sm:inline">{lang === 'ar' ? 'تاريخ' : 'Date'}</span>
                <ChevronDown size={12} className={`transition-transform ${showDateFilter ? 'rotate-180' : ''}`} />
              </button>
            </div>
            <AnimatePresence initial={false}>
              {showDateFilter && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="grid grid-cols-2 gap-1.5 sm:gap-2 min-w-0 pt-1">
                    <div className="min-w-0">
                      <label className="block text-[10px] text-muted-foreground mb-1 px-0.5">
                        {lang === 'ar' ? 'من' : 'From'}
                      </label>
                      <input
                        type="date"
                        value={fromDate}
                        onChange={e => setFromDate(e.target.value)}
                        className="w-full min-w-0 bg-background border border-border rounded-xl px-2 py-1.5 sm:py-2 text-[11px] sm:text-xs focus:outline-none focus:border-primary/50"
                      />
                    </div>
                    <div className="min-w-0">
                      <label className="block text-[10px] text-muted-foreground mb-1 px-0.5">
                        {lang === 'ar' ? 'إلى' : 'To'}
                      </label>
                      <input
                        type="date"
                        value={toDate}
                        onChange={e => setToDate(e.target.value)}
                        className="w-full min-w-0 bg-background border border-border rounded-xl px-2 py-1.5 sm:py-2 text-[11px] sm:text-xs focus:outline-none focus:border-primary/50"
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Status Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none -mx-1 px-1">
            {STATUS_TABS.map(tab => {
              const count = getCounts(tab.key);
              const active = status === tab.key;
              const isProcessingTab = tab.key === 'processing';
              return (
                <button
                  key={tab.key}
                  onClick={() => setStatus(tab.key)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap border shrink-0 ${
                    active
                      ? 'bg-primary/15 border-primary/40 text-primary'
                      : 'bg-card border-border text-muted-foreground hover:border-border/80'
                  }`}
                >
                  {isProcessingTab && count > 0 && <LiveDot />}
                  {lang === 'ar' ? tab.labelAr : tab.labelEn}
                  <span
                    className={`w-5 h-5 rounded-full text-xs flex items-center justify-center font-bold ${
                      active ? 'bg-primary text-white' : 'bg-border text-muted-foreground'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Total */}
          {filtered.length > 0 && (
            <div className="flex justify-end">
              <div className="px-4 py-2 bg-card border border-border rounded-xl text-sm font-bold">
                {lang === 'ar' ? 'الإجمالي' : 'Total'}: {formatPrice(totalSYP / SYP_RATE)}
              </div>
            </div>
          )}

          {/* Orders List */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {isLoading ? (
              <div className="divide-y divide-border">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 animate-pulse">
                    <div className="w-10 h-10 bg-muted rounded-xl" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-muted rounded w-1/3" />
                      <div className="h-3 bg-muted rounded w-1/4" />
                    </div>
                    <div className="h-6 w-16 bg-muted rounded-full" />
                  </div>
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="py-16 text-center">
                <Package size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground text-sm">
                  {lang === 'ar'
                    ? 'لا يوجد طلبات ضمن النطاق الحالي.'
                    : 'No orders found in the selected period.'}
                </p>
                <Link
                  href="/"
                  className="inline-block mt-4 px-4 py-2 bg-primary/15 text-primary text-sm font-medium rounded-xl"
                >
                  {lang === 'ar' ? 'تصفح المنتجات' : 'Browse Products'}
                </Link>
              </div>
            ) : (
              <div className="divide-y divide-border">
                <AnimatePresence initial={false}>
                  {filtered.map((order, idx) => {
                    const isProcessing = order.status === 'processing';
                    const isCompleted = order.status === 'completed';
                    const isFailed = order.status === 'failed';

                    return (
                      <motion.div
                        key={order.id}
                        layout
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.03 }}
                        className={`flex items-center gap-2 sm:gap-4 p-2.5 sm:p-4 transition-colors cursor-pointer group min-w-0 ${
                          isProcessing ? 'bg-amber-500/5' : 'hover:bg-muted/40'
                        }`}
                        onClick={() => navigate(`/orders/${order.id}`)}
                      >
                        {/* Status Icon */}
                        <div
                          className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shrink-0 relative"
                          style={{
                            background: isProcessing
                              ? 'rgba(245,158,11,0.15)'
                              : isCompleted
                              ? 'rgba(34,197,94,0.15)'
                              : isFailed
                              ? 'rgba(239,68,68,0.15)'
                              : 'rgba(108,92,231,0.15)',
                          }}
                        >
                          {isProcessing ? (
                            <RefreshCw size={16} className="animate-spin text-amber-400" />
                          ) : isCompleted ? (
                            <CheckCircle2 size={16} className="text-green-400" />
                          ) : isFailed ? (
                            <XCircle size={16} className="text-red-400" />
                          ) : (
                            <Package size={16} className="text-primary" />
                          )}
                          {isProcessing && (
                            <span className="absolute inset-0 rounded-xl animate-ping border border-amber-400/30" />
                          )}
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="text-[13px] sm:text-sm font-semibold truncate">{order.productName}</p>
                            {isProcessing && <LiveDot />}
                          </div>
                          <div className="flex items-center gap-1.5 text-[10.5px] sm:text-xs text-muted-foreground mt-0.5 flex-wrap">
                            <span className="bg-muted/60 px-1.5 py-0.5 rounded text-foreground/80 font-medium">x{order.qty}</span>
                            <span>{new Date(order.createdAt).toLocaleDateString('en-GB')}</span>
                            <span className="hidden xs:inline font-mono text-muted-foreground/70 truncate">
                              {(order as any).orderNumber
                                ? `#${String((order as any).orderNumber).padStart(5, '0')}`
                                : `#${order.id.slice(0, 6)}`}
                            </span>
                          </div>
                          {isProcessing && (
                            <p className="text-[10px] text-amber-400 mt-0.5 font-medium">
                              {lang === 'ar' ? 'جاري التنفيذ...' : 'Processing...'}
                            </p>
                          )}
                        </div>

                        {/* Price + Status + Reorder — fixed width column for clean alignment */}
                        <div className="flex flex-col items-end gap-1.5 shrink-0 min-w-[78px] sm:min-w-[110px]">
                          <span className="text-[13px] sm:text-sm font-bold text-primary whitespace-nowrap leading-none">
                            {formatPrice(parseFloat(order.totalPrice?.toString() ?? '0'))}
                          </span>
                          <StatusBadge status={order.status} size="sm" />
                          {order.productId && (
                            <Link
                              href={`/products/${order.productId}`}
                              onClick={(e) => e.stopPropagation()}
                              className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary transition-colors px-1.5 py-0.5 rounded-md hover:bg-primary/10 leading-none"
                              title={lang === 'ar' ? 'إعادة الطلب' : 'Reorder'}
                            >
                              <RotateCcw size={10} />
                              <span className="hidden sm:inline">{lang === 'ar' ? 'أعد الطلب' : 'Reorder'}</span>
                            </Link>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>

        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
