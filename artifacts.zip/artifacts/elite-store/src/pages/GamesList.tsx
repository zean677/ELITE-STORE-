import React, { useState, useMemo, useEffect } from 'react';
import { Link, useSearch, useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { useGetCategories } from '@workspace/api-client-react';
import { useQuery } from '@tanstack/react-query';
import { PublicLayout } from '@/components/Layout';
import { useLanguage } from '@/i18n';
import { Search, ChevronRight, ChevronLeft, Zap, Star } from 'lucide-react';
import { getBrandInfo } from '@/lib/product-images';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
const API_BASE = import.meta.env.BASE_URL || '';

const CATEGORY_META: Record<string, { nameAr: string; nameEn: string; icon: string; accent: string }> = {
  mobile_games: { nameAr: 'ألعاب الهاتف',     nameEn: 'Mobile Games',  icon: '', accent: '#8b5cf6' },
  pc_games:     { nameAr: 'ألعاب الكمبيوتر',  nameEn: 'PC Games',      icon: '', accent: '#3b82f6' },
  gift_cards:   { nameAr: 'بطاقات الهدايا',   nameEn: 'Gift Cards',    icon: '', accent: '#f59e0b' },
  services:     { nameAr: 'الخدمات الرقمية',  nameEn: 'Services',      icon: '', accent: '#10b981' },
  general:      { nameAr: 'خدمات متنوعة',     nameEn: 'General',       icon: '', accent: '#f43f5e' },
};

type FeaturedGame = {
  id: string; nameAr: string; nameEn: string; color: string; emoji: string; imageUrl?: string;
  category: string; keywords: string[]; sortOrder: number; isActive: boolean;
};

function matchesKeywords(label: string, keywords: string[]) {
  if (!keywords?.length) return false;
  const l = label.toLowerCase();
  return keywords.some(k => k && l.includes(k.toLowerCase()));
}

function GameCard({ game, category, index }: {
  game: { label: string; count: number; image?: string | null; category: string };
  category: string;
  index: number;
}) {
  const { lang } = useLanguage();
  const brand = getBrandInfo(game.label, game.label, category, API_BASE);
  const [imgOk, setImgOk] = React.useState(true);
  const href = `/products?category=${encodeURIComponent(category)}&game=${encodeURIComponent(game.label)}`;
  const packageCount = game.count ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.025, type: 'spring', stiffness: 280, damping: 22 }}
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
    >
      <Link href={href}>
        <div
          className="relative rounded-2xl overflow-hidden cursor-pointer group"
          style={{
            background: `linear-gradient(160deg, ${brand.color}22 0%, #0d1117 60%)`,
            border: `1.5px solid ${brand.color}35`,
            boxShadow: `0 2px 20px ${brand.color}15`,
          }}
        >
          <div
            className="absolute inset-x-0 top-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            style={{ background: `linear-gradient(90deg, transparent, ${brand.color}80, transparent)` }}
          />
          <div
            className="relative flex items-center justify-center overflow-hidden"
            style={{
              height: 140,
              background: `linear-gradient(160deg, ${brand.color}30 0%, ${brand.color}08 50%, transparent 100%)`,
            }}
          >
            <div
              className="absolute inset-0 opacity-40"
              style={{ background: `radial-gradient(ellipse 80% 60% at 50% 50%, ${brand.color}30, transparent)` }}
            />
            <div className="relative z-10 w-full h-full overflow-hidden px-4 py-4 flex flex-col justify-between">
              <div
                className="absolute inset-0"
                style={{
                  background: `
                    radial-gradient(circle at 20% 20%, ${brand.color}80, transparent 28%),
                    radial-gradient(circle at 85% 15%, rgba(255,255,255,0.18), transparent 22%),
                    linear-gradient(135deg, ${brand.color}55, rgba(8,12,26,0.92) 58%, ${brand.color}24)
                  `,
                }}
              />
              <div className="absolute inset-0 opacity-25 bg-[linear-gradient(135deg,transparent_0_40%,rgba(255,255,255,.18)_40%_41%,transparent_41%_100%)]" />
              <div className="relative z-10 flex items-start justify-end gap-2">
                <span className="w-7 h-7 rounded-full flex items-center justify-center text-white/70" style={{ background: 'rgba(0,0,0,0.25)' }}>⚡</span>
              </div>
              <div
                className="relative z-10 self-center flex items-center justify-center rounded-3xl font-black text-white shadow-2xl"
                style={{
                  width: 74, height: 74,
                  background: `linear-gradient(145deg, rgba(255,255,255,0.20), ${brand.color}dd)`,
                  boxShadow: `0 12px 34px ${brand.color}70, inset 0 0 0 1px rgba(255,255,255,0.20)`,
                  fontSize: brand.label.length <= 2 ? 28 : brand.label.length <= 3 ? 22 : 16,
                  letterSpacing: '-0.5px',
                }}
              >
                {brand.label}
              </div>
              <div className="relative z-10">
                <p className="text-[11px] font-black text-white leading-tight line-clamp-2 drop-shadow" dir="auto">{game.label}</p>
                <p className="text-[9px] text-white/55 mt-0.5">{lang === 'ar' ? 'واجهة رسمية للخدمة' : 'Official service cover'}</p>
              </div>
            </div>
            <div
              className="absolute top-2.5 right-2.5 flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold z-20 backdrop-blur-sm"
              style={{ background: 'rgba(0,0,0,0.55)', border: `1px solid ${brand.color}40`, color: brand.color }}
            >
              <Zap size={8} />{packageCount}
            </div>
            <div
              className="absolute top-2.5 left-2.5 flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-semibold z-20 backdrop-blur-sm"
              style={{ background: 'rgba(0,0,0,0.55)', border: '1px solid rgba(255,255,255,0.10)' }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-white/80">{lang === 'ar' ? 'متاح' : 'Live'}</span>
            </div>
          </div>
          <div
            className="px-3 py-2.5 flex items-center justify-between gap-2"
            style={{ background: `linear-gradient(0deg, rgba(0,0,0,0.6), rgba(0,0,0,0.1))` }}
          >
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-sm leading-tight text-white line-clamp-1 group-hover:text-white/90" dir="auto" title={game.label}>{game.label}</h3>
              <p className="text-[10px] mt-0.5 font-medium" style={{ color: brand.color }}>
                {lang === 'ar' ? `${packageCount} باقة` : `${packageCount} packages`}
              </p>
            </div>
            <div
              className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center transition-transform duration-200 group-hover:translate-x-0.5"
              style={{ background: `${brand.color}20`, border: `1px solid ${brand.color}40` }}
            >
              <ChevronLeft size={13} style={{ color: brand.color }} />
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

function FeaturedGameCard({ gameGroup, label, labelAr, totalCount, color, emoji, imageUrl, category, index }: {
  gameGroup: string; label: string; labelAr: string; totalCount: number;
  color: string; emoji: string; imageUrl?: string; category: string; index: number;
}) {
  const { lang } = useLanguage();
  const href = `/products?category=${encodeURIComponent(category)}&game_group=${gameGroup}`;
  const displayName = lang === 'ar' ? labelAr : label;
  const brand = getBrandInfo(label, label, category, API_BASE);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, type: 'spring', stiffness: 260, damping: 20 }}
      whileHover={{ y: -6, scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
    >
      <Link href={href}>
        <div
          className="relative rounded-2xl overflow-hidden cursor-pointer group"
          style={{
            background: `linear-gradient(160deg, ${color}35 0%, #0d1117 70%)`,
            border: `2px solid ${color}55`,
            boxShadow: `0 4px 30px ${color}25`,
            minHeight: 170,
          }}
        >
          <div
            className="absolute inset-x-0 top-0 h-0.5 opacity-80"
            style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }}
          />
          <div
            className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-full text-[9px] font-black uppercase tracking-widest z-20"
            style={{ background: `${color}30`, color, border: `1px solid ${color}60` }}
          >
            <Star size={7} fill="currentColor" />
            {lang === 'ar' ? 'الأكثر طلباً' : 'Top Game'}
          </div>
          <div
            className="relative h-36 flex items-center justify-center overflow-hidden"
            style={{ background: `linear-gradient(160deg, ${color}40 0%, ${color}10 50%, transparent 100%)` }}
          >
            <div
              className="absolute inset-0"
              style={{
                background: `radial-gradient(circle at 30% 40%, ${color}50, transparent 50%),
                             radial-gradient(circle at 80% 20%, rgba(255,255,255,0.12), transparent 30%)`,
              }}
            />
            <div
              className="relative z-10 flex items-center justify-center rounded-3xl font-black text-white shadow-2xl overflow-hidden"
              style={{
                width: 90, height: 90,
                background: `linear-gradient(145deg, rgba(255,255,255,0.25), ${color}ee)`,
                boxShadow: `0 16px 40px ${color}80, inset 0 0 0 1.5px rgba(255,255,255,0.25)`,
                fontSize: 32,
              }}
            >
              {imageUrl ? (
                <img src={imageUrl} alt={displayName} className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).replaceWith(Object.assign(document.createElement('span'), { textContent: emoji, style: 'font-size:32px' })); }} />
              ) : (
                emoji
              )}
            </div>
            <div
              className="absolute top-2.5 right-2.5 flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold z-20 backdrop-blur-sm"
              style={{ background: 'rgba(0,0,0,0.55)', border: `1px solid ${color}40`, color }}
            >
              <Zap size={8} />{totalCount}
            </div>
            <div
              className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-semibold z-20 backdrop-blur-sm"
              style={{ background: 'rgba(0,0,0,0.55)', border: '1px solid rgba(255,255,255,0.10)' }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-white/80">{lang === 'ar' ? 'متاح' : 'Live'}</span>
            </div>
          </div>
          <div
            className="px-3 py-2.5 flex items-center justify-between gap-2"
            style={{ background: `linear-gradient(0deg, rgba(0,0,0,0.7), rgba(0,0,0,0.15))` }}
          >
            <div className="min-w-0 flex-1">
              <h3 className="font-black text-base leading-tight text-white group-hover:text-white/90" dir="auto">{displayName}</h3>
              <p className="text-[10px] mt-0.5 font-medium" style={{ color }}>
                {lang === 'ar' ? `${totalCount} باقة متاحة` : `${totalCount} packages`}
              </p>
            </div>
            <div
              className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: `${color}25`, border: `1.5px solid ${color}50` }}
            >
              <ChevronLeft size={14} style={{ color }} />
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export default function GamesList() {
  const searchStr = useSearch();
  const [, navigate] = useLocation();
  const urlParams = useMemo(() => new URLSearchParams(searchStr), [searchStr]);
  const { lang } = useLanguage();

  const [activeCategory, setActiveCategory] = useState(() => urlParams.get('category') || 'mobile_games');
  const [search, setSearch] = useState('');

  useEffect(() => {
    const cat = urlParams.get('category') || 'mobile_games';
    setActiveCategory(cat);
    setSearch(urlParams.get('q') || '');
  }, [searchStr]);

  const { data: categoriesData } = useGetCategories();

  const { data: featuredGames = [] } = useQuery({
    queryKey: ['featured-games'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/featured-games`);
      if (!res.ok) return [] as FeaturedGame[];
      const j = await res.json();
      return ((j.items as FeaturedGame[]) || [])
        .filter(g => g.isActive !== false)
        .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    },
    staleTime: 5 * 60 * 1000,
  });

  const { data: gamesData = [], isLoading } = useQuery({
    queryKey: ['category-games', activeCategory, search],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (activeCategory) params.set('category', activeCategory);
      if (search.trim()) params.set('search', search.trim());
      params.set('limit', '1000');
      const res = await fetch(`${BASE}/api/products/games?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to load games');
      return res.json() as Promise<{ label: string; count: number; image?: string | null; category: string }[]>;
    },
    staleTime: 5 * 60 * 1000,
  });

  const activeFeatured = useMemo(
    () => featuredGames.filter(f => f.category === activeCategory),
    [featuredGames, activeCategory]
  );

  const { featuredCounts, otherGames } = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const f of activeFeatured) counts[f.id] = 0;
    const other: typeof gamesData = [];
    for (const g of gamesData) {
      if (!g.label?.trim()) continue;
      const matched = activeFeatured.find(f => matchesKeywords(g.label, f.keywords));
      if (matched) counts[matched.id] = (counts[matched.id] ?? 0) + (g.count ?? 0);
      else other.push(g);
    }
    return { featuredCounts: counts, otherGames: other };
  }, [gamesData, activeFeatured]);

  const showFeatured = activeFeatured.length > 0 && !search;
  const visibleFeatured = activeFeatured.filter(f => (featuredCounts[f.id] ?? 0) > 0);

  const games = useMemo(() => {
    if (showFeatured) return otherGames.filter(g => g.label?.trim());
    return gamesData.filter(g => g.label?.trim());
  }, [gamesData, otherGames, showFeatured]);

  const catMeta = CATEGORY_META[activeCategory] ?? CATEGORY_META.mobile_games;
  const catNameFromAPI = categoriesData?.find(c => c.id === activeCategory);
  const catName = lang === 'ar'
    ? (catNameFromAPI?.nameAr ?? catMeta.nameAr)
    : (catNameFromAPI?.name ?? catMeta.nameEn);

  // Build tabs list from API categories (fallback to known meta keys)
  const tabs = useMemo(() => {
    const list: { id: string; nameAr: string; nameEn: string; icon: string; accent: string }[] = [];
    const seen = new Set<string>();
    if (categoriesData?.length) {
      for (const c of categoriesData) {
        const key = String(c.id);
        if (seen.has(key)) continue;
        seen.add(key);
        const meta = CATEGORY_META[key];
        list.push({
          id: key,
          nameAr: c.nameAr || meta?.nameAr || c.name || key,
          nameEn: c.name || meta?.nameEn || key,
          icon: meta?.icon || '🛒',
          accent: meta?.accent || '#8b5cf6',
        });
      }
    }
    // Ensure core categories always present
    for (const k of Object.keys(CATEGORY_META)) {
      if (!seen.has(k)) {
        seen.add(k);
        list.push({ id: k, ...CATEGORY_META[k] });
      }
    }
    return list;
  }, [categoriesData]);

  const switchTab = (id: string) => {
    setActiveCategory(id);
    setSearch('');
    const params = new URLSearchParams();
    params.set('category', id);
    navigate(`/games?${params.toString()}`);
  };

  return (
    <PublicLayout>
      <div className="max-w-2xl mx-auto px-3 py-5 md:max-w-4xl lg:max-w-6xl">

        {(catNameFromAPI as any)?.bannerImage ? (
          <div
            className="mb-5 rounded-2xl relative overflow-hidden h-40 sm:h-48 flex items-end"
            style={{ border: `1px solid ${catMeta.accent}25` }}
            dir={lang === 'ar' ? 'rtl' : 'ltr'}
          >
            <img src={(catNameFromAPI as any).bannerImage} alt={catName} loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: `linear-gradient(0deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.35) 60%, rgba(0,0,0,0.1) 100%)` }} />
            <div className="relative w-full p-4">
              <h1 className="font-black text-2xl text-white leading-tight drop-shadow-lg">
                {(catNameFromAPI as any).bannerTitle || catName}
              </h1>
              <p className="text-xs text-white/80 mt-1 drop-shadow">
                {(catNameFromAPI as any).bannerSubtitle ||
                  (lang === 'ar'
                    ? `${gamesData.length} لعبة وخدمة • اضغط لعرض الباقات`
                    : `${gamesData.length} titles • Tap to view packages`)}
              </p>
            </div>
          </div>
        ) : (
          <div
            className="mb-5 rounded-2xl px-4 py-4 relative overflow-hidden flex items-center gap-3"
            style={{
              background: `linear-gradient(135deg, ${catMeta.accent}18 0%, rgba(13,17,23,0.9) 100%)`,
              border: `1px solid ${catMeta.accent}25`,
            }}
            dir={lang === 'ar' ? 'rtl' : 'ltr'}
          >
            <div
              className="w-2 h-11 rounded-full flex-shrink-0"
              style={{ background: catMeta.accent }}
            />
            <div>
              <h1 className="font-black text-xl text-white leading-none">{catName}</h1>
              <p className="text-xs text-white/50 mt-1">
                {isLoading
                  ? (lang === 'ar' ? 'جارٍ التحميل...' : 'Loading...')
                  : lang === 'ar'
                    ? `${gamesData.length} لعبة وخدمة • اضغط لعرض الباقات`
                    : `${gamesData.length} titles • Tap to view packages`}
              </p>
            </div>
          </div>
        )}

        <div className="relative mb-5">
          <Search
            size={15}
            className="absolute top-1/2 -translate-y-1/2 text-white/30 pointer-events-none"
            style={{ [lang === 'ar' ? 'right' : 'left']: 14 }}
          />
          <input
            type="search"
            placeholder={lang === 'ar' ? 'ابحث عن لعبة أو خدمة...' : 'Search a game or service...'}
            value={search}
            onChange={e => setSearch(e.target.value)}
            dir={lang === 'ar' ? 'rtl' : 'ltr'}
            className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/20 transition-colors"
            style={{ paddingRight: lang === 'ar' ? 42 : 16, paddingLeft: lang === 'ar' ? 16 : 42 }}
          />
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="rounded-2xl overflow-hidden animate-pulse" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="bg-white/5" style={{ height: 140 }} />
                <div className="p-3 space-y-2">
                  <div className="h-3.5 bg-white/10 rounded-lg w-3/4" />
                  <div className="h-2.5 bg-white/05 rounded-lg w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            <div>
              {showFeatured && visibleFeatured.length > 0 && (
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                    <Star size={14} className="text-yellow-400" fill="currentColor" />
                    <span className="text-sm font-bold text-white/80">
                      {lang === 'ar' ? 'الألعاب المميزة' : 'Featured Games'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {visibleFeatured.map((f, i) => (
                      <FeaturedGameCard
                        key={f.id}
                        gameGroup={f.id}
                        label={f.nameEn || f.nameAr}
                        labelAr={f.nameAr || f.nameEn}
                        totalCount={featuredCounts[f.id] ?? 0}
                        color={f.color}
                        emoji={f.emoji}
                        imageUrl={f.imageUrl}
                        category={activeCategory}
                        index={i}
                      />
                    ))}
                  </div>
                </div>
              )}

              {games.length === 0 && !showFeatured ? (
                <div className="flex flex-col items-center justify-center py-24 text-center">
                  <div className="text-5xl mb-4">🔍</div>
                  <p className="text-white/50 text-base font-medium">
                    {search
                      ? (lang === 'ar' ? `لا نتائج لـ "${search}"` : `No results for "${search}"`)
                      : (lang === 'ar' ? 'لا توجد عناصر' : 'Nothing here yet')}
                  </p>
                  {search && (
                    <button
                      onClick={() => setSearch('')}
                      className="mt-3 text-xs font-semibold px-4 py-2 rounded-xl transition-colors hover:bg-white/10"
                      style={{ color: catMeta.accent }}
                    >
                      {lang === 'ar' ? 'مسح البحث' : 'Clear search'}
                    </button>
                  )}
                </div>
              ) : games.length > 0 ? (
                <div>
                  {showFeatured && visibleFeatured.length > 0 && (
                    <div className="flex items-center gap-2 mb-3" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                      <span className="text-sm font-bold text-white/60">
                        {lang === 'ar' ? 'جميع الألعاب' : 'All Games'}
                      </span>
                    </div>
                  )}
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {games.map((game, i) => (
                      <GameCard key={game.label} game={game} category={activeCategory} index={i} />
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          </AnimatePresence>
        )}
      </div>
    </PublicLayout>
  );
}
