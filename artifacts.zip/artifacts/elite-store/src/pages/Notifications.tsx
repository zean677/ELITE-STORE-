import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useGetNotifications, useMarkNotificationRead, getGetNotificationsQueryKey, customFetch } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useLanguage } from '@/i18n';
import { Bell, CheckCircle, Package, Wallet, AlertCircle, BellRing, BellOff } from 'lucide-react';
import { isPushSupported, getCurrentSubscription, subscribePush, unsubscribePush, sendTestPush } from '@/lib/push';
import { useToast } from '@/hooks/use-toast';

const typeConfig: Record<string, { icon: any; color: string }> = {
  order_completed: { icon: Package, color: 'text-success' },
  payment_approved: { icon: Wallet, color: 'text-secondary' },
  balance_updated: { icon: Wallet, color: 'text-primary' },
  order_failed: { icon: AlertCircle, color: 'text-destructive' },
};

function PushToggle() {
  const [supported] = React.useState(isPushSupported());
  const [enabled, setEnabled] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    if (!supported) return;
    getCurrentSubscription().then((s) => setEnabled(!!s));
  }, [supported]);

  if (!supported) return null;

  const enable = async () => {
    setBusy(true);
    const r = await subscribePush();
    setBusy(false);
    if (r.ok) {
      setEnabled(true);
      toast({ title: '✅ تم تفعيل إشعارات المتصفح' });
      sendTestPush();
    } else {
      toast({ title: '⚠️ ' + (r.reason || 'فشل التفعيل'), variant: 'destructive' });
    }
  };
  const disable = async () => {
    setBusy(true);
    await unsubscribePush();
    setBusy(false);
    setEnabled(false);
    toast({ title: 'تم إيقاف إشعارات المتصفح' });
  };

  return (
    <div className={`p-4 rounded-2xl border ${enabled ? 'bg-success/10 border-success/30' : 'bg-primary/5 border-primary/30'} flex items-center gap-3 mb-4`}>
      {enabled ? <BellRing className="text-success shrink-0" size={22} /> : <Bell className="text-primary shrink-0" size={22} />}
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold">{enabled ? 'إشعارات المتصفح مفعّلة' : 'فعّل إشعارات المتصفح'}</div>
        <div className="text-[11px] text-muted-foreground mt-0.5">
          {enabled ? 'بنوصلك إشعار حتى لو مغلق التطبيق' : 'احصل على إشعار فوري لما يكتمل طلبك أو ينزل خصم'}
        </div>
      </div>
      <button
        onClick={enabled ? disable : enable}
        disabled={busy}
        className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap ${enabled ? 'bg-muted hover:bg-muted/80' : 'bg-primary text-primary-foreground hover:bg-primary/90'} disabled:opacity-50`}
      >
        {busy ? '...' : enabled ? <><BellOff size={14} className="inline ml-1" />إيقاف</> : 'تفعيل'}
      </button>
    </div>
  );
}

export default function Notifications() {
  const { t, lang, dir } = useLanguage();
  const queryClient = useQueryClient();
  const { data: notifications, refetch } = useGetNotifications();
  const markRead = useMarkNotificationRead();

  const invalidateBadge = () => {
    queryClient.invalidateQueries({ queryKey: getGetNotificationsQueryKey() });
  };

  // Auto-mark all as read when the user opens the notifications page
  useEffect(() => {
    if (!notifications || notifications.length === 0) return;
    const hasUnread = notifications.some((n: any) => !n.isRead);
    if (!hasUnread) return;
    (async () => {
      try {
        await customFetch('/api/notifications/read-all', { method: 'POST' });
      } catch {}
      invalidateBadge();
      refetch();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notifications?.length]);

  const handleMarkRead = async (id: number) => {
    await markRead.mutateAsync({ id });
    invalidateBadge();
    refetch();
  };

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-6" dir={dir}>
          <div>
            <h1 className="font-heading text-2xl font-bold">{t('notifications')}</h1>
            <p className="text-muted-foreground text-sm mt-1">
              {(notifications ?? []).filter(n => !n.isRead).length}{' '}
              {lang === 'ar' ? 'غير مقروء' : 'unread'}
            </p>
          </div>

          <PushToggle />

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {!notifications || notifications.length === 0 ? (
              <div className="py-16 text-center">
                <Bell size={40} className="mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">{lang === 'ar' ? 'لا توجد إشعارات بعد' : 'No notifications yet'}</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {notifications.map(n => {
                  const cfg = typeConfig[n.type] ?? { icon: Bell, color: 'text-muted-foreground' };
                  const Icon = cfg.icon;
                  return (
                    <motion.div key={n.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className={`flex items-start gap-4 p-4 hover:bg-background transition-colors ${!n.isRead ? 'bg-primary/5' : ''}`}>
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${!n.isRead ? 'bg-primary/15 border border-primary/20' : 'bg-card border border-border'}`}>
                        <Icon size={16} className={cfg.color} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium ${!n.isRead ? 'text-foreground' : 'text-muted-foreground'}`}>{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{n.message}</p>
                        <p className="text-xs text-muted-foreground/60 mt-1">{new Date(n.createdAt).toLocaleString()}</p>
                      </div>
                      {!n.isRead && (
                        <button onClick={() => handleMarkRead(n.id)} className="shrink-0 p-1.5 rounded-lg hover:bg-card transition-colors text-muted-foreground hover:text-primary" title={lang === 'ar' ? 'تعليم كمقروء' : 'Mark as read'}>
                          <CheckCircle size={16} />
                        </button>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
