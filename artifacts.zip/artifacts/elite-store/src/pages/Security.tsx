import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  ShieldCheck, Key, LogOut, Lock, Smartphone,
  Eye, EyeOff, CheckCircle2, AlertTriangle, ChevronRight,
  Loader2, RefreshCw, Fingerprint, Bell, Wallet, QrCode, ShieldOff
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useLanguage } from '@/i18n';
import { PublicLayout } from '@/components/Layout';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

function authFetch2(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  const base = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';
  return fetch(`${base}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function SectionHeader({ icon: Icon, title, subtitle, color }: { icon: any; title: string; subtitle: string; color: string }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <div className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0" style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div>
        <h2 className="font-bold text-sm text-white">{title}</h2>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </div>
    </div>
  );
}

function Card({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.35 }}
      className="rounded-2xl border border-white/8 p-5"
      style={{ background: 'rgba(255,255,255,0.03)' }}
    >
      {children}
    </motion.div>
  );
}

export default function Security() {
  const { user, logout } = useAuth();
  const { lang, dir } = useLanguage();
  const { toast } = useToast();

  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [changingPwd, setChangingPwd] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [twoFaToken, setTwoFaToken] = useState('');
  const [twoFaStep, setTwoFaStep] = useState<'idle' | 'setup' | 'disable'>('idle');
  const [twoFaSetupData, setTwoFaSetupData] = useState<{ secret: string; qrCode: string } | null>(null);
  const [twoFaLoading, setTwoFaLoading] = useState(false);
  const queryClient = useQueryClient();

  const { data: twoFaStatus } = useQuery({
    queryKey: ['2fa-status'],
    enabled: !!user,
    queryFn: async () => {
      const res = await authFetch2('GET', '/api/auth/2fa/status');
      if (!res.ok) return { enabled: false };
      return res.json();
    },
    staleTime: 30_000,
  });

  const is2FaEnabled = twoFaStatus?.enabled ?? false;

  const handleSetup2Fa = async () => {
    setTwoFaLoading(true);
    try {
      const res = await authFetch2('GET', '/api/auth/2fa/setup');
      const data = await res.json();
      if (data.enabled) {
        toast({ title: lang === 'ar' ? '2FA مفعّل بالفعل' : '2FA already enabled' });
        queryClient.invalidateQueries({ queryKey: ['2fa-status'] });
        return;
      }
      setTwoFaSetupData({ secret: data.secret, qrCode: data.qrCode });
      setTwoFaStep('setup');
    } catch { toast({ title: lang === 'ar' ? 'خطأ في الإعداد' : 'Setup error', variant: 'destructive' }); }
    finally { setTwoFaLoading(false); }
  };

  const handleVerify2Fa = async () => {
    if (twoFaToken.length !== 6) return;
    setTwoFaLoading(true);
    try {
      const res = await authFetch2('POST', '/api/auth/2fa/verify', { token: twoFaToken });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast({ title: lang === 'ar' ? 'تم تفعيل 2FA ✓' : '2FA enabled ✓' });
      setTwoFaStep('idle'); setTwoFaToken(''); setTwoFaSetupData(null);
      queryClient.invalidateQueries({ queryKey: ['2fa-status'] });
    } catch (e: any) { toast({ title: e.message, variant: 'destructive' }); }
    finally { setTwoFaLoading(false); }
  };

  const handleDisable2Fa = async () => {
    if (twoFaToken.length !== 6) return;
    setTwoFaLoading(true);
    try {
      const res = await authFetch2('POST', '/api/auth/2fa/disable', { token: twoFaToken });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast({ title: lang === 'ar' ? 'تم إلغاء 2FA' : '2FA disabled' });
      setTwoFaStep('idle'); setTwoFaToken('');
      queryClient.invalidateQueries({ queryKey: ['2fa-status'] });
    } catch (e: any) { toast({ title: e.message, variant: 'destructive' }); }
    finally { setTwoFaLoading(false); }
  };

  const strengthScore = (pwd: string) => {
    let s = 0;
    if (pwd.length >= 8) s++;
    if (/[A-Z]/.test(pwd)) s++;
    if (/[0-9]/.test(pwd)) s++;
    if (/[^A-Za-z0-9]/.test(pwd)) s++;
    return s;
  };

  const strength = strengthScore(newPwd);
  const strengthLabel = ['ضعيف', 'مقبول', 'جيد', 'قوي', 'ممتاز'][strength] ?? '';
  const strengthColor = ['#ef4444', '#f97316', '#f59e0b', '#22c55e', '#10b981'][strength] ?? '#6b7280';

  const handleChangePassword = async () => {
    if (!currentPwd || !newPwd || !confirmPwd) {
      toast({ title: 'خطأ', description: 'يرجى تعبئة جميع الحقول', variant: 'destructive' });
      return;
    }
    if (newPwd !== confirmPwd) {
      toast({ title: 'خطأ', description: 'كلمة المرور الجديدة وتأكيدها غير متطابقتين', variant: 'destructive' });
      return;
    }
    if (newPwd.length < 8) {
      toast({ title: 'خطأ', description: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل', variant: 'destructive' });
      return;
    }
    setChangingPwd(true);
    try {
      const token = localStorage.getItem('elite_token');
      const res = await fetch(`${BASE}/api/auth/change-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ currentPassword: currentPwd, newPassword: newPwd }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message ?? 'فشل تغيير كلمة المرور');
      toast({ title: '✅ تم بنجاح', description: 'تم تغيير كلمة المرور بنجاح' });
      setCurrentPwd(''); setNewPwd(''); setConfirmPwd('');
    } catch (err: any) {
      toast({ title: 'فشل', description: err.message, variant: 'destructive' });
    } finally {
      setChangingPwd(false);
    }
  };

  const handleLogoutAllDevices = async () => {
    setLoggingOut(true);
    await new Promise(r => setTimeout(r, 800));
    toast({ title: '✅ تم تسجيل الخروج', description: 'تم تسجيل الخروج من جميع الأجهزة' });
    logout();
    setLoggingOut(false);
  };

  return (
    <PublicLayout>
      <div className="max-w-lg mx-auto px-4 py-6" dir="rtl">

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)', boxShadow: '0 8px 24px rgba(108,92,231,0.4)' }}>
              <ShieldCheck size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-black text-white">حماية الحساب</h1>
              <p className="text-xs text-muted-foreground">إدارة أمان حسابك ورصيدك</p>
            </div>
          </div>
        </motion.div>

        {!user && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl p-6 text-center border border-yellow-500/20" style={{ background: 'rgba(245,158,11,0.08)' }}>
            <AlertTriangle size={32} className="text-yellow-400 mx-auto mb-3" />
            <p className="font-bold text-yellow-400 mb-1">يجب تسجيل الدخول</p>
            <p className="text-sm text-muted-foreground">سجّل دخولك للوصول إلى إعدادات الأمان</p>
          </motion.div>
        )}

        {user && (
          <div className="space-y-4">

            {/* ── تغيير كلمة المرور ── */}
            <Card delay={0.05}>
              <SectionHeader icon={Key} title="تغيير كلمة المرور" subtitle="غيّر كلمة مرورك بشكل دوري لحماية حسابك" color="#6C5CE7" />
              <div className="space-y-3">

                {/* Current Password */}
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">كلمة المرور الحالية</label>
                  <div className="relative">
                    <input
                      type={showCurrent ? 'text' : 'password'}
                      value={currentPwd}
                      onChange={e => setCurrentPwd(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pr-4 pl-10 py-2.5 rounded-xl text-sm border border-white/10 bg-white/5 focus:outline-none focus:border-primary/50 transition-colors"
                    />
                    <button onClick={() => setShowCurrent(s => !s)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      {showCurrent ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {/* New Password */}
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">كلمة المرور الجديدة</label>
                  <div className="relative">
                    <input
                      type={showNew ? 'text' : 'password'}
                      value={newPwd}
                      onChange={e => setNewPwd(e.target.value)}
                      placeholder="8 أحرف على الأقل"
                      className="w-full pr-4 pl-10 py-2.5 rounded-xl text-sm border border-white/10 bg-white/5 focus:outline-none focus:border-primary/50 transition-colors"
                    />
                    <button onClick={() => setShowNew(s => !s)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      {showNew ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                  {newPwd && (
                    <div className="mt-2 space-y-1">
                      <div className="flex gap-1">
                        {[0,1,2,3].map(i => (
                          <div key={i} className="h-1 flex-1 rounded-full transition-all duration-300" style={{ background: i < strength ? strengthColor : 'rgba(255,255,255,0.1)' }} />
                        ))}
                      </div>
                      <p className="text-xs" style={{ color: strengthColor }}>قوة كلمة المرور: {strengthLabel}</p>
                    </div>
                  )}
                </div>

                {/* Confirm Password */}
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">تأكيد كلمة المرور الجديدة</label>
                  <div className="relative">
                    <input
                      type={showConfirm ? 'text' : 'password'}
                      value={confirmPwd}
                      onChange={e => setConfirmPwd(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pr-4 pl-10 py-2.5 rounded-xl text-sm border border-white/10 bg-white/5 focus:outline-none focus:border-primary/50 transition-colors"
                    />
                    <button onClick={() => setShowConfirm(s => !s)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      {showConfirm ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                    {confirmPwd && (
                      <div className="absolute left-10 top-1/2 -translate-y-1/2">
                        {confirmPwd === newPwd
                          ? <CheckCircle2 size={14} className="text-green-400" />
                          : <AlertTriangle size={14} className="text-red-400" />}
                      </div>
                    )}
                  </div>
                </div>

                <button
                  onClick={handleChangePassword}
                  disabled={changingPwd}
                  className="w-full py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90 active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-60"
                  style={{ background: 'linear-gradient(135deg, #6C5CE7, #8B5CF6)', boxShadow: '0 4px 16px rgba(108,92,231,0.35)' }}
                >
                  {changingPwd ? <Loader2 size={15} className="animate-spin" /> : <Key size={15} />}
                  {changingPwd ? 'جاري التحديث...' : 'تغيير كلمة المرور'}
                </button>
              </div>
            </Card>

            {/* ── التحقق الثنائي ── */}
            <Card delay={0.1}>
              <SectionHeader icon={Fingerprint} title="التحقق الثنائي (2FA)" subtitle="طبقة حماية إضافية لحسابك" color="#22c55e" />
              <div className="flex items-center justify-between p-3 rounded-xl border border-white/8" style={{ background: 'rgba(34,197,94,0.06)' }}>
                <div className="flex items-center gap-3">
                  <Smartphone size={18} className="text-green-400" />
                  <div>
                    <p className="text-sm font-semibold">رمز OTP عبر واتساب</p>
                    <p className="text-xs text-muted-foreground">يُرسل رمز تحقق عند كل دخول</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold" style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>قريباً</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3 text-center">سيتم تفعيل هذه الميزة قريباً</p>
            </Card>

            {/* ── سجل الدخول والأجهزة ── */}
            <Card delay={0.13}>
              <SectionHeader icon={Smartphone} title="سجل الدخول والأجهزة" subtitle="شاهد من وين دخل لحسابك واطرد الأجهزة المشبوهة" color="#a855f7" />
              <a
                href={`${BASE}/login-history`}
                className="flex items-center justify-between p-3 rounded-xl border border-white/8 hover:bg-white/5 transition"
              >
                <div className="flex items-center gap-3">
                  <Fingerprint size={18} className="text-purple-400" />
                  <div>
                    <p className="text-sm font-semibold">عرض الجلسات النشطة</p>
                    <p className="text-xs text-muted-foreground">آخر دخول، عناوين IP، المتصفح، طرد الأجهزة</p>
                  </div>
                </div>
                <ChevronRight size={16} className="text-muted-foreground" />
              </a>
            </Card>

            {/* ── إشعارات الأمان ── */}
            <Card delay={0.15}>
              <SectionHeader icon={Bell} title="إشعارات الأمان" subtitle="ابقَ على اطلاع بنشاط حسابك" color="#3b82f6" />
              <div className="space-y-2.5">
                {[
                  { label: 'إشعار عند تسجيل الدخول من جهاز جديد', enabled: true },
                  { label: 'إشعار عند تغيير كلمة المرور', enabled: true },
                  { label: 'إشعار عند كل معاملة مالية', enabled: true },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-2.5 rounded-xl border border-white/8">
                    <span className="text-xs font-medium">{item.label}</span>
                    <div className="w-9 h-5 rounded-full flex items-center transition-all" style={{ background: item.enabled ? '#3b82f6' : 'rgba(255,255,255,0.1)', justifyContent: item.enabled ? 'flex-end' : 'flex-start', padding: '2px' }}>
                      <div className="w-4 h-4 rounded-full bg-white shadow" />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* ── حماية الرصيد ── */}
            <Card delay={0.2}>
              <SectionHeader icon={Wallet} title="حماية الرصيد" subtitle="أضف طبقة حماية إضافية على رصيدك" color="#f59e0b" />
              <div className="space-y-2.5">
                <div className="flex items-center justify-between p-3 rounded-xl border border-white/8">
                  <div className="flex items-center gap-3">
                    <Lock size={16} className="text-yellow-400" />
                    <div>
                      <p className="text-sm font-semibold">قفل الرصيد</p>
                      <p className="text-xs text-muted-foreground">تأكيد بكلمة مرور قبل كل شراء</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold" style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>قريباً</span>
                </div>
              </div>
            </Card>

            {/* ── معلومات الجلسة ── */}
            <Card delay={0.25}>
              <SectionHeader icon={Smartphone} title="الجلسة الحالية" subtitle="معلومات جلستك النشطة" color="#a855f7" />
              <div className="space-y-2">
                {[
                  { label: 'الحساب', value: user.username },
                  { label: 'البريد الإلكتروني', value: user.email },
                  { label: 'صلاحية الجلسة', value: '7 أيام' },
                  { label: 'وقت الدخول', value: localStorage.getItem('elite_login_at') ? new Date(parseInt(localStorage.getItem('elite_login_at')!)).toLocaleString('en-GB') : 'غير محدد' },
                ].map((row, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg border border-white/6">
                    <span className="text-xs text-muted-foreground">{row.label}</span>
                    <span className="text-xs font-semibold truncate max-w-[60%] text-right">{row.value}</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* ── التحقق بخطوتين 2FA ── */}
            <Card delay={0.25}>
              <SectionHeader
                icon={Smartphone}
                title={lang === 'ar' ? 'التحقق بخطوتين (2FA)' : 'Two-Factor Authentication'}
                subtitle={lang === 'ar' ? 'أضف طبقة حماية إضافية لحسابك باستخدام تطبيق المصادقة' : 'Add an extra layer of protection with an authenticator app'}
                color="#8b5cf6"
              />

              {twoFaStep === 'idle' && (
                <div className="space-y-3">
                  <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border ${is2FaEnabled ? 'border-emerald-500/30 bg-emerald-500/10' : 'border-white/10 bg-white/5'}`}>
                    {is2FaEnabled ? <CheckCircle2 size={15} className="text-emerald-400" /> : <ShieldOff size={15} className="text-muted-foreground" />}
                    <span className="text-sm">{is2FaEnabled ? (lang === 'ar' ? '2FA مفعّل ✓' : '2FA Enabled ✓') : (lang === 'ar' ? '2FA غير مفعّل' : '2FA Disabled')}</span>
                  </div>
                  {is2FaEnabled ? (
                    <button onClick={() => setTwoFaStep('disable')} className="w-full py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all hover:opacity-90" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: '#ef4444' }}>
                      <ShieldOff size={14} />{lang === 'ar' ? 'إلغاء تفعيل 2FA' : 'Disable 2FA'}
                    </button>
                  ) : (
                    <button onClick={handleSetup2Fa} disabled={twoFaLoading} className="w-full py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all hover:opacity-90 disabled:opacity-60" style={{ background: 'rgba(139,92,246,0.12)', border: '1px solid rgba(139,92,246,0.3)', color: '#8b5cf6' }}>
                      {twoFaLoading ? <Loader2 size={14} className="animate-spin" /> : <QrCode size={14} />}
                      {lang === 'ar' ? 'إعداد 2FA' : 'Set up 2FA'}
                    </button>
                  )}
                </div>
              )}

              {twoFaStep === 'setup' && twoFaSetupData && (
                <div className="space-y-4">
                  <p className="text-xs text-muted-foreground">{lang === 'ar' ? '1. افتح تطبيق Google Authenticator أو Authy وامسح رمز QR' : '1. Open Google Authenticator or Authy and scan the QR code'}</p>
                  <div className="flex justify-center">
                    <img src={twoFaSetupData.qrCode} alt="QR Code" className="w-40 h-40 rounded-xl border border-border p-1 bg-white" />
                  </div>
                  <p className="text-xs text-muted-foreground text-center">{lang === 'ar' ? 'أو أدخل السر يدوياً:' : 'Or enter the secret manually:'}</p>
                  <div className="font-mono text-xs bg-background border border-border rounded-xl px-3 py-2 text-center break-all text-muted-foreground">{twoFaSetupData.secret}</div>
                  <p className="text-xs text-muted-foreground">{lang === 'ar' ? '2. أدخل الرمز المكوّن من 6 أرقام من التطبيق:' : '2. Enter the 6-digit code from the app:'}</p>
                  <input
                    type="text" inputMode="numeric" maxLength={6} value={twoFaToken}
                    onChange={e => setTwoFaToken(e.target.value.replace(/\D/g, ''))}
                    placeholder="000000"
                    className="w-full px-4 py-3 bg-background border border-border rounded-xl text-center font-mono text-xl tracking-widest focus:outline-none focus:border-purple-500/50"
                  />
                  <div className="flex gap-2">
                    <button onClick={() => { setTwoFaStep('idle'); setTwoFaToken(''); setTwoFaSetupData(null); }} className="flex-1 py-2.5 rounded-xl text-sm border border-border text-muted-foreground hover:text-foreground transition-colors">
                      {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                    </button>
                    <button onClick={handleVerify2Fa} disabled={twoFaToken.length !== 6 || twoFaLoading} className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2" style={{ background: 'linear-gradient(135deg, #8b5cf6, #6d28d9)' }}>
                      {twoFaLoading ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                      {lang === 'ar' ? 'تفعيل' : 'Enable'}
                    </button>
                  </div>
                </div>
              )}

              {twoFaStep === 'disable' && (
                <div className="space-y-4">
                  <div className="flex items-start gap-2 p-3 rounded-xl border border-red-500/20 bg-red-500/6">
                    <AlertTriangle size={15} className="text-red-400 mt-0.5 shrink-0" />
                    <p className="text-xs text-muted-foreground">{lang === 'ar' ? 'ستصبح حسابك أقل أماناً بدون 2FA. أدخل الرمز من تطبيق المصادقة للتأكيد.' : 'Your account will be less secure without 2FA. Enter the code from your authenticator app to confirm.'}</p>
                  </div>
                  <input
                    type="text" inputMode="numeric" maxLength={6} value={twoFaToken}
                    onChange={e => setTwoFaToken(e.target.value.replace(/\D/g, ''))}
                    placeholder="000000"
                    className="w-full px-4 py-3 bg-background border border-border rounded-xl text-center font-mono text-xl tracking-widest focus:outline-none focus:border-red-500/50"
                  />
                  <div className="flex gap-2">
                    <button onClick={() => { setTwoFaStep('idle'); setTwoFaToken(''); }} className="flex-1 py-2.5 rounded-xl text-sm border border-border text-muted-foreground hover:text-foreground transition-colors">
                      {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                    </button>
                    <button onClick={handleDisable2Fa} disabled={twoFaToken.length !== 6 || twoFaLoading} className="flex-1 py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2" style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)', color: '#ef4444' }}>
                      {twoFaLoading ? <Loader2 size={14} className="animate-spin" /> : <ShieldOff size={14} />}
                      {lang === 'ar' ? 'إلغاء تفعيل' : 'Disable'}
                    </button>
                  </div>
                </div>
              )}
            </Card>

            {/* ── تسجيل الخروج من كل الأجهزة ── */}
            <Card delay={0.3}>
              <SectionHeader icon={LogOut} title="إدارة الأجهزة" subtitle="تحكم في الأجهزة المتصلة بحسابك" color="#ef4444" />
              <div className="p-3 rounded-xl border border-red-500/20 mb-4" style={{ background: 'rgba(239,68,68,0.06)' }}>
                <div className="flex items-start gap-2.5">
                  <AlertTriangle size={16} className="text-red-400 mt-0.5 shrink-0" />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    تسجيل الخروج من جميع الأجهزة سيُنهي جميع الجلسات النشطة وسيحتاج إلى إعادة تسجيل الدخول
                  </p>
                </div>
              </div>
              <button
                onClick={handleLogoutAllDevices}
                disabled={loggingOut}
                className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-90 active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-60"
                style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', color: '#ef4444' }}
              >
                {loggingOut ? <Loader2 size={15} className="animate-spin" /> : <LogOut size={15} />}
                {loggingOut ? 'جاري الخروج...' : 'تسجيل الخروج من جميع الأجهزة'}
              </button>
            </Card>

          </div>
        )}
      </div>
    </PublicLayout>
  );
}
