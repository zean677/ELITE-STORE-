import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { CheckCircle, AlertTriangle, XCircle, RefreshCw, Zap, Bot, ShoppingCart, Clock } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

type ServiceStatus = 'operational' | 'degraded' | 'down';

interface StatusData {
  generatedAt: string;
  services: {
    api: { status: ServiceStatus; label: string };
    provider: { status: ServiceStatus; label: string; detail: string };
    telegram: { status: ServiceStatus; label: string; detail: string };
  };
  orders24h: {
    total: number;
    completed: number;
    failed: number;
    pending: number;
    successRate: number;
  };
}

function StatusBadge({ status }: { status: ServiceStatus }) {
  if (status === 'operational') return (
    <span className="flex items-center gap-1.5 text-emerald-400 text-sm font-bold">
      <CheckCircle size={15} /> يعمل بشكل طبيعي
    </span>
  );
  if (status === 'degraded') return (
    <span className="flex items-center gap-1.5 text-yellow-400 text-sm font-bold">
      <AlertTriangle size={15} /> أداء منخفض
    </span>
  );
  return (
    <span className="flex items-center gap-1.5 text-red-400 text-sm font-bold">
      <XCircle size={15} /> متوقف
    </span>
  );
}

function StatusDot({ status }: { status: ServiceStatus }) {
  const color = status === 'operational' ? 'bg-emerald-400' : status === 'degraded' ? 'bg-yellow-400' : 'bg-red-400';
  return (
    <span className="relative flex h-3 w-3 shrink-0">
      <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-60 ${color}`} />
      <span className={`relative inline-flex rounded-full h-3 w-3 ${color}`} />
    </span>
  );
}

function overallStatus(services: StatusData['services']): ServiceStatus {
  const vals = Object.values(services).map(s => s.status);
  if (vals.every(v => v === 'operational')) return 'operational';
  if (vals.some(v => v === 'down')) return 'down';
  return 'degraded';
}

const SERVICE_ICONS: Record<string, React.ElementType> = {
  api: Zap,
  provider: ShoppingCart,
  telegram: Bot,
};

export default function StatusPage() {
  const { data, isLoading, isFetching, refetch, dataUpdatedAt } = useQuery<StatusData>({
    queryKey: ['public-status'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/status`);
      if (!r.ok) throw new Error('Failed');
      return r.json();
    },
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const overall = data ? overallStatus(data.services) : null;
  const lastUpdated = dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString('ar-SY') : null;

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <div className="border-b border-border bg-card/50">
        <div className="max-w-2xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-black text-foreground">حالة النظام</h1>
              <p className="text-sm text-muted-foreground mt-0.5">System Status</p>
            </div>
            <button
              onClick={() => refetch()}
              disabled={isFetching}
              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 text-primary text-sm font-semibold hover:bg-primary/20 transition-colors disabled:opacity-50"
            >
              <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
              تحديث
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          </div>
        ) : data ? (
          <>
            {/* Overall status banner */}
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`rounded-2xl p-5 border flex items-center gap-4 ${
                overall === 'operational'
                  ? 'bg-emerald-500/10 border-emerald-500/30'
                  : overall === 'degraded'
                  ? 'bg-yellow-500/10 border-yellow-500/30'
                  : 'bg-red-500/10 border-red-500/30'
              }`}
            >
              <StatusDot status={overall!} />
              <div>
                <p className="font-black text-base text-foreground">
                  {overall === 'operational'
                    ? '✅ جميع الأنظمة تعمل بشكل طبيعي'
                    : overall === 'degraded'
                    ? '⚠️ بعض الخدمات تعمل بأداء منخفض'
                    : '❌ يوجد خدمات متوقفة'}
                </p>
                {lastUpdated && (
                  <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                    <Clock size={10} /> آخر تحديث: {lastUpdated}
                  </p>
                )}
              </div>
            </motion.div>

            {/* Services */}
            <div className="space-y-2">
              <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wide px-1">الخدمات</h2>
              {Object.entries(data.services).map(([key, svc], i) => {
                const Icon = SERVICE_ICONS[key] ?? Zap;
                return (
                  <motion.div
                    key={key}
                    initial={{ opacity: 0, x: 16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="bg-card border border-border rounded-xl p-4 flex items-center gap-4"
                  >
                    <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Icon size={16} className="text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-foreground">{svc.label}</p>
                      {'detail' in svc && <p className="text-xs text-muted-foreground">{(svc as any).detail}</p>}
                    </div>
                    <StatusBadge status={svc.status} />
                  </motion.div>
                );
              })}
            </div>

            {/* Orders 24h */}
            <div className="space-y-2">
              <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wide px-1">إحصائيات آخر 24 ساعة</h2>
              <div className="bg-card border border-border rounded-xl p-5">
                {/* Success rate bar */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-foreground">نسبة نجاح الطلبات</span>
                    <span className={`text-xl font-black ${
                      data.orders24h.successRate >= 90 ? 'text-emerald-400'
                      : data.orders24h.successRate >= 70 ? 'text-yellow-400'
                      : 'text-red-400'
                    }`}>{data.orders24h.successRate}%</span>
                  </div>
                  <div className="h-2 bg-background rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${data.orders24h.successRate}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className={`h-full rounded-full ${
                        data.orders24h.successRate >= 90 ? 'bg-emerald-400'
                        : data.orders24h.successRate >= 70 ? 'bg-yellow-400'
                        : 'bg-red-400'
                      }`}
                    />
                  </div>
                </div>
                {/* Stats grid */}
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { label: 'إجمالي', value: data.orders24h.total, color: 'text-foreground' },
                    { label: 'مكتمل', value: data.orders24h.completed, color: 'text-emerald-400' },
                    { label: 'قيد المعالجة', value: data.orders24h.pending, color: 'text-blue-400' },
                    { label: 'فاشل', value: data.orders24h.failed, color: 'text-red-400' },
                  ].map(stat => (
                    <div key={stat.label} className="text-center bg-background rounded-lg p-2">
                      <p className={`text-xl font-black ${stat.color}`}>{stat.value}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <p className="text-center text-xs text-muted-foreground py-2">
              يتم تحديث هذه الصفحة تلقائياً كل 60 ثانية
            </p>
          </>
        ) : (
          <div className="text-center py-20 text-muted-foreground">
            <XCircle size={40} className="mx-auto mb-3 opacity-30" />
            <p>تعذّر تحميل البيانات</p>
          </div>
        )}
      </div>
    </div>
  );
}
