import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PublicLayout } from '@/components/Layout';
import { useLanguage } from '@/i18n';
import { ChevronDown, HelpCircle } from 'lucide-react';

const faqs = [
  {
    q: { ar: 'كيف يتم شحن الطلب؟', en: 'How is the order delivered?' },
    a: { ar: 'يتم تنفيذ الطلب تلقائياً فور دفع الرصيد وتأكيد الطلب، عادةً في أقل من دقيقة.', en: 'Orders are fulfilled automatically upon payment confirmation, usually within a minute.' },
  },
  {
    q: { ar: 'ما طرق الدفع المتاحة؟', en: 'What payment methods are available?' },
    a: { ar: 'ندعم الدفع بالليرة السورية (SYP) عبر طرق دفع متعددة، والدولار الأمريكي (USD) والـ USDT. يمكنك رؤية جميع الطرق المتاحة في صفحة الإيداع.', en: 'We support SYP, USD, and USDT payments. View all available methods on the deposit page.' },
  },
  {
    q: { ar: 'ما الذي أحتاجه لشحن حسابي؟', en: 'What do I need to recharge my account?' },
    a: { ar: 'تحتاج فقط إلى معرّف اللاعب (Player ID) الخاص باللعبة. بعض الألعاب قد تتطلب Zone ID أو بريد إلكتروني.', en: 'You only need your Player ID. Some games may require a Zone ID or email.' },
  },
  {
    q: { ar: 'ماذا يحدث إذا فشل الطلب؟', en: 'What happens if an order fails?' },
    a: { ar: 'في حالة فشل تنفيذ الطلب لأي سبب، يتم إرجاع المبلغ كاملاً إلى محفظتك تلقائياً وبشكل فوري دون الحاجة للتواصل مع الدعم.', en: 'If an order fails for any reason, the full amount is automatically and instantly refunded to your wallet.' },
  },
  {
    q: { ar: 'كيف يعمل نظام VIP؟', en: 'How does the VIP system work?' },
    a: { ar: 'كلما زاد إجمالي مشترياتك، ترتفع درجتك في نظام VIP. الدرجات الأعلى تمنحك خصومات تلقائية على جميع الطلبات. الدرجات: برونزي، فضي، ذهبي، بلاتيني، ألماسي.', en: 'Your VIP level increases with total purchases. Higher levels grant automatic discounts. Levels: Bronze, Silver, Gold, Platinum, Diamond.' },
  },
  {
    q: { ar: 'هل يمكنني استخدام كود خصم؟', en: 'Can I use a discount code?' },
    a: { ar: 'نعم! أدخل كود الخصم في صفحة تفاصيل المنتج قبل إتمام الشراء. يمكن متابعة العروض والأكواد عبر قناتنا على تيليغرام.', en: 'Yes! Enter the promo code on the product page before purchasing. Follow our Telegram channel for deals.' },
  },
  {
    q: { ar: 'كيف أتواصل مع الدعم؟', en: 'How do I contact support?' },
    a: { ar: 'يمكنك التواصل معنا عبر صفحة الدعم في التطبيق، أو مباشرةً عبر تيليغرام للرد السريع. فريق الدعم متاح 24/7.', en: 'Contact us via the in-app support page or directly on Telegram for quick responses. Support is available 24/7.' },
  },
  {
    q: { ar: 'هل المتجر آمن؟', en: 'Is the store safe?' },
    a: { ar: 'نعم. جميع المعاملات مشفرة، ولا نحتفظ ببيانات حساسة. جميع المنتجات تأتي من موردين معتمدين ومرخصين.', en: 'Yes. All transactions are encrypted. We never store sensitive data. All products come from authorized suppliers.' },
  },
  {
    q: { ar: 'كيف أضيف رصيداً إلى محفظتي؟', en: 'How do I add balance to my wallet?' },
    a: { ar: 'اذهب إلى صفحة الإيداع، اختر طريقة الدفع المناسبة، وأرسل الرصيد. بعد تأكيد الأدمن يُضاف الرصيد فوراً.', en: 'Go to the deposit page, select a payment method, and send payment. After admin confirmation, balance is added instantly.' },
  },
  {
    q: { ar: 'هل التطبيق متاح على الجوال؟', en: 'Is the app available on mobile?' },
    a: { ar: 'يمكنك تثبيت المتجر كتطبيق على جهازك (PWA) من خلال متصفح الجوال. فقط افتح الموقع ثم أضفه إلى الشاشة الرئيسية.', en: 'You can install the store as an app (PWA) on your mobile. Open the site in your browser and add it to your home screen.' },
  },
];

function FAQItem({ q, a, lang }: { q: { ar: string; en: string }; a: { ar: string; en: string }; lang: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-border rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between p-5 text-start hover:bg-white/5 transition-colors"
        dir={lang === 'ar' ? 'rtl' : 'ltr'}
      >
        <span className="font-semibold text-sm leading-relaxed">{lang === 'ar' ? q.ar : q.en}</span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }} className="shrink-0 ms-3">
          <ChevronDown size={16} className="text-primary" />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            style={{ overflow: 'hidden' }}
          >
            <p
              className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed"
              dir={lang === 'ar' ? 'rtl' : 'ltr'}
            >
              {lang === 'ar' ? a.ar : a.en}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQ() {
  const { lang } = useLanguage();

  return (
    <PublicLayout>
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-primary/15 border border-primary/20 flex items-center justify-center mx-auto mb-4">
            <HelpCircle size={28} className="text-primary" />
          </div>
          <h1 className="font-heading text-3xl font-black mb-2">
            {lang === 'ar' ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}
          </h1>
          <p className="text-muted-foreground text-sm">
            {lang === 'ar' ? 'إجابات على أكثر الأسئلة شيوعاً' : 'Answers to the most common questions'}
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <FAQItem key={i} q={faq.q} a={faq.a} lang={lang} />
          ))}
        </div>

        <div className="mt-10 p-6 rounded-2xl text-center" style={{ background: 'linear-gradient(135deg, rgba(108,92,231,0.1), rgba(108,92,231,0.05))', border: '1px solid rgba(108,92,231,0.2)' }}>
          <p className="text-sm text-muted-foreground mb-3">
            {lang === 'ar' ? 'لم تجد إجابتك؟ تواصل مع فريق الدعم' : "Didn't find your answer? Contact support"}
          </p>
          <a href="/support" className="inline-flex items-center gap-2 px-6 py-2.5 bg-primary text-white rounded-xl text-sm font-bold hover:bg-primary/90 transition-colors">
            {lang === 'ar' ? 'تواصل مع الدعم' : 'Contact Support'}
          </a>
        </div>
      </div>
    </PublicLayout>
  );
}
