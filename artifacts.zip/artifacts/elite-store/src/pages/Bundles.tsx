import React, { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { PublicLayout as Layout } from '@/components/Layout';
import { Gift, Sparkles, ShoppingBag } from 'lucide-react';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

interface Bundle {
  id: number; name: string; nameAr?: string | null; description?: string | null; imageUrl?: string | null;
  bundlePriceUsd: number; badge?: string | null; isFeatured: boolean;
  items: Array<{ productId: string; qty: number; product?: { name: string; imageUrl?: string | null } | null }>;
  originalTotalUsd: number; savingsUsd: number; savingsPercent: number;
}

export default function Bundles() {
  const [bundles, setBundles] = useState<Bundle[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch(`${BASE}/api/bundles`).then(r => r.json()).then(j => setBundles(j.bundles || [])).finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-6xl" dir="rtl">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/15 text-primary text-xs font-bold mb-3">
            <Sparkles size={14} /> عروض حصرية
          </div>
          <h1 className="font-heading text-3xl md:text-4xl font-extrabold mb-2">حزم وعروض اليوم</h1>
          <p className="text-muted-foreground text-sm md:text-base">وفّر أكثر — اطلب أكثر من منتج بسعر مخصوم بضغطة وحدة</p>
        </div>

        {loading ? (
          <div className="text-center py-20 text-muted-foreground">جاري التحميل...</div>
        ) : bundles.length === 0 ? (
          <div className="text-center py-20 bg-card border border-border rounded-2xl">
            <Gift className="mx-auto mb-3 text-muted-foreground/30" size={56} />
            <p className="text-muted-foreground">لا توجد حزم متاحة حالياً. عُد قريباً 🎁</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {bundles.map(b => (
              <Link key={b.id} href={`/bundles/${b.id}`}>
                <div className="group bg-card border border-border hover:border-primary/60 rounded-2xl overflow-hidden cursor-pointer transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10">
                  <div className="relative h-40 bg-gradient-to-br from-primary/30 via-purple-500/20 to-pink-500/20">
                    {b.imageUrl ? (
                      <img src={b.imageUrl} alt={b.nameAr || b.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Gift size={64} className="text-primary/60" />
                      </div>
                    )}
                    {b.savingsPercent > 0 && (
                      <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-success text-white text-xs font-extrabold shadow-lg">
                        وفّر {b.savingsPercent}%
                      </div>
                    )}
                    {b.badge && (
                      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-amber-500 text-white text-xs font-bold shadow-lg">
                        {b.badge}
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-1 line-clamp-1">{b.nameAr || b.name}</h3>
                    {b.description && <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{b.description}</p>}
                    <div className="flex items-end gap-2 mb-3">
                      <span className="text-2xl font-extrabold text-primary">${b.bundlePriceUsd.toFixed(2)}</span>
                      {b.savingsUsd > 0 && <span className="text-sm line-through text-muted-foreground mb-0.5">${b.originalTotalUsd.toFixed(2)}</span>}
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">{b.items.length} منتج</span>
                      <span className="inline-flex items-center gap-1 text-primary font-bold group-hover:gap-2 transition-all">
                        <ShoppingBag size={14} /> اطلب الآن
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
