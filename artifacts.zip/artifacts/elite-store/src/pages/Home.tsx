import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { PublicLayout } from '@/components/Layout';
import { useLanguage } from '@/i18n';
import { useQuery } from '@tanstack/react-query';
import { Search, Zap, Shield, ShieldCheck, Clock, ChevronLeft, Star, Pencil, LayoutGrid, Gift, Sparkles, Tag } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

const TELEGRAM_CHANNEL = 'https://t.me/elitestore_sy';
const TELEGRAM_SUPPORT = 'https://t.me/+963931670388';
const WHATSAPP_GROUP = 'https://chat.whatsapp.com/DmATlEZYLFgHbWuo4HOVay';

const CATEGORY_ROUTE_OVERRIDES: Record<string, string> = {
  games: '/games?category=mobile_games',
  mobile_games: '/games?category=mobile_games',
  pc_games: '/games?category=pc_games',
  apps: '/games?category=services',
  social: '/games?category=services',
  telecom: '/games?category=general',
  gift_cards: '/games?category=gift_cards',
  crypto: '/games?category=general',
  ai: '/games?category=services',
  subscriptions: '/games?category=services',
  design: '/games?category=services',
  accounts: '/games?category=general',
  wholesale: '/games?category=general',
  services: '/games?category=services',
  general: '/games?category=general',
};

function normalizeCategoryHref(cat: { id?: string | number; href?: string }) {
  const id = String(cat.id ?? '');
  if (CATEGORY_ROUTE_OVERRIDES[id]) return CATEGORY_ROUTE_OVERRIDES[id];
  const href = cat.href ?? '';
  if (href.includes('/products?category=services/products') || href.includes('q=telecomq=') || href.includes('q=cryptoq=') || href.includes('q=numbersq=') || href.includes('q=accountsq=')) {
    return CATEGORY_ROUTE_OVERRIDES.general;
  }
  if (href.startsWith('/products?category=')) {
    return href.replace('/products?category=', '/games?category=');
  }
  if (href === '/products') return '/games?category=mobile_games';
  return href || '/games?category=mobile_games';
}

// ─── Static fallback categories (used if API fails) ──────────
const CATEGORIES_FALLBACK = [
  {
    id: 'games',
    nameAr: 'الألعاب',
    nameEn: 'Games',
    href: '/games?category=mobile_games',
    color: '#7c3aed',
    bg: 'linear-gradient(145deg, #1a0040, #2d0080)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=pubg.com&sz=64', label: 'PUBG', bg: '#f59e0b' },
      { img: 'https://www.google.com/s2/favicons?domain=garena.com&sz=64', label: 'FF', bg: '#f97316' },
      { img: 'https://www.google.com/s2/favicons?domain=mobilelegends.com&sz=64', label: 'ML', bg: '#dc2626' },
      { img: 'https://www.google.com/s2/favicons?domain=clash.com&sz=64', label: 'CoC', bg: '#3b82f6' },
    ],
  },
  {
    id: 'apps',
    nameAr: 'التطبيقات',
    nameEn: 'Apps',
    href: '/games?category=services',
    color: '#22c55e',
    bg: 'linear-gradient(145deg, #002010, #004020)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=netflix.com&sz=64', label: 'Netflix', bg: '#e50914' },
      { img: 'https://www.google.com/s2/favicons?domain=spotify.com&sz=64', label: 'Spotify', bg: '#1db954' },
      { img: 'https://www.google.com/s2/favicons?domain=youtube.com&sz=64', label: 'YouTube', bg: '#ff0000' },
      { img: 'https://www.google.com/s2/favicons?domain=chat.openai.com&sz=64', label: 'ChatGPT', bg: '#10a37f' },
    ],
  },
  {
    id: 'social',
    nameAr: 'السوشيال ميديا',
    nameEn: 'Social Media',
    href: '/games?category=services',
    color: '#3b82f6',
    bg: 'linear-gradient(145deg, #001030, #002060)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=telegram.org&sz=64', label: 'TG', bg: '#2aabee' },
      { img: 'https://www.google.com/s2/favicons?domain=facebook.com&sz=64', label: 'FB', bg: '#1877f2' },
      { img: 'https://www.google.com/s2/favicons?domain=tiktok.com&sz=64', label: 'TT', bg: '#000000' },
      { img: 'https://www.google.com/s2/favicons?domain=instagram.com&sz=64', label: 'IG', bg: '#e1306c' },
    ],
  },
  {
    id: 'telecom',
    nameAr: 'الرصيد والاتصالات',
    nameEn: 'Telecom',
    href: '/games?category=general',
    color: '#ef4444',
    bg: 'linear-gradient(145deg, #200010, #400020)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=syriatel.com.sy&sz=64', label: 'Syriatel', bg: '#dc2626' },
      { img: 'https://www.google.com/s2/favicons?domain=mtn.sy&sz=64', label: 'MTN', bg: '#f59e0b' },
      { img: 'https://www.google.com/s2/favicons?domain=zain.com&sz=64', label: 'Zain', bg: '#a855f7' },
      { img: 'https://www.google.com/s2/favicons?domain=vodafone.com&sz=64', label: 'VF', bg: '#ef4444' },
    ],
  },
  {
    id: 'gift_cards',
    nameAr: 'البطاقات',
    nameEn: 'Gift Cards',
    href: '/games?category=gift_cards',
    color: '#f59e0b',
    bg: 'linear-gradient(145deg, #201000, #402000)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=play.google.com&sz=64', label: 'Google', bg: '#4285f4' },
      { img: 'https://www.google.com/s2/favicons?domain=apple.com&sz=64', label: 'iTunes', bg: '#fc3158' },
      { img: 'https://www.google.com/s2/favicons?domain=amazon.com&sz=64', label: 'Amazon', bg: '#ff9900' },
      { img: 'https://www.google.com/s2/favicons?domain=playstation.com&sz=64', label: 'PSN', bg: '#00439c' },
    ],
  },
  {
    id: 'crypto',
    nameAr: 'العملات الرقمية',
    nameEn: 'Crypto',
    href: '/games?category=general',
    color: '#f59e0b',
    bg: 'linear-gradient(145deg, #201500, #403000)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=tether.to&sz=64', label: 'USDT', bg: '#26a17b' },
      { img: 'https://www.google.com/s2/favicons?domain=binance.com&sz=64', label: 'BNB', bg: '#f3ba2f' },
      { img: 'https://www.google.com/s2/favicons?domain=payeer.com&sz=64', label: 'Payeer', bg: '#1e88e5' },
      { img: 'https://www.google.com/s2/favicons?domain=perfectmoney.com&sz=64', label: 'PM', bg: '#c62828' },
    ],
  },
  {
    id: 'pc_games',
    nameAr: 'ألعاب الكمبيوتر',
    nameEn: 'PC Games',
    href: '/games?category=pc_games',
    color: '#06b6d4',
    bg: 'linear-gradient(145deg, #001520, #002d40)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=store.steampowered.com&sz=64', label: 'Steam', bg: '#1b2838' },
      { img: 'https://www.google.com/s2/favicons?domain=playvalorant.com&sz=64', label: 'Valorant', bg: '#ef4444' },
      { img: 'https://www.google.com/s2/favicons?domain=leagueoflegends.com&sz=64', label: 'LoL', bg: '#c89b3c' },
      { img: 'https://www.google.com/s2/favicons?domain=xbox.com&sz=64', label: 'Xbox', bg: '#107c10' },
    ],
  },
  {
    id: 'ai',
    nameAr: 'الذكاء الاصطناعي',
    nameEn: 'AI Tools',
    href: '/games?category=services',
    color: '#a78bfa',
    bg: 'linear-gradient(145deg, #100020, #200040)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=chat.openai.com&sz=64', label: 'ChatGPT', bg: '#10a37f' },
      { img: 'https://www.google.com/s2/favicons?domain=midjourney.com&sz=64', label: 'MJ', bg: '#000000' },
      { img: 'https://www.google.com/s2/favicons?domain=gemini.google.com&sz=64', label: 'Gemini', bg: '#4285f4' },
      { img: 'https://www.google.com/s2/favicons?domain=claude.ai&sz=64', label: 'Claude', bg: '#d97706' },
    ],
  },
  {
    id: 'subscriptions',
    nameAr: 'الاشتراكات',
    nameEn: 'Subscriptions',
    href: '/games?category=services',
    color: '#8b5cf6',
    bg: 'linear-gradient(145deg, #0f0020, #1f0040)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=netflix.com&sz=64', label: 'Netflix', bg: '#e50914' },
      { img: 'https://www.google.com/s2/favicons?domain=spotify.com&sz=64', label: 'Spotify', bg: '#1db954' },
      { img: 'https://www.google.com/s2/favicons?domain=canva.com&sz=64', label: 'Canva', bg: '#00c4cc' },
      { img: 'https://www.google.com/s2/favicons?domain=adobe.com&sz=64', label: 'Adobe', bg: '#ff0000' },
    ],
  },
  {
    id: 'design',
    nameAr: 'برامج التصميم',
    nameEn: 'Design Tools',
    href: '/games?category=services',
    color: '#f472b6',
    bg: 'linear-gradient(145deg, #200010, #3f0020)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=canva.com&sz=64', label: 'Canva', bg: '#00c4cc' },
      { img: 'https://www.google.com/s2/favicons?domain=adobe.com&sz=64', label: 'Adobe', bg: '#ff0000' },
      { img: 'https://www.google.com/s2/favicons?domain=figma.com&sz=64', label: 'Figma', bg: '#f24e1e' },
      { img: 'https://www.google.com/s2/favicons?domain=capcut.com&sz=64', label: 'CapCut', bg: '#000000' },
    ],
  },
  {
    id: 'accounts',
    nameAr: 'الأرقام والتفعيل',
    nameEn: 'Numbers & Activation',
    href: '/games?category=general',
    color: '#34d399',
    bg: 'linear-gradient(145deg, #001510, #003020)',
    icons: [
      { img: 'https://www.google.com/s2/favicons?domain=whatsapp.com&sz=64', label: 'WA', bg: '#25d366' },
      { img: 'https://www.google.com/s2/favicons?domain=telegram.org&sz=64', label: 'TG', bg: '#2aabee' },
      { img: 'https://www.google.com/s2/favicons?domain=snapchat.com&sz=64', label: 'SC', bg: '#fffc00' },
      { img: 'https://www.google.com/s2/favicons?domain=twitter.com&sz=64', label: 'X', bg: '#000000' },
    ],
  },
];

// ─── WhatsApp Group Popup ─────────────────────────────────────
function TelegramPopup() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const dismissed = sessionStorage.getItem('wa_popup_dismissed');
    if (!dismissed) {
      const t = setTimeout(() => setOpen(true), 1200);
      return () => clearTimeout(t);
    }
    return undefined;
  }, []);

  const dismiss = () => {
    sessionStorage.setItem('wa_popup_dismissed', '1');
    setOpen(false);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}
          onClick={dismiss}
        >
          <motion.div
            initial={{ scale: 0.85, y: 40, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.85, y: 40, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            onClick={e => e.stopPropagation()}
            className="relative w-full max-w-sm rounded-3xl overflow-hidden"
            style={{ background: '#111827', border: '1px solid rgba(37,211,102,0.3)', boxShadow: '0 0 60px rgba(37,211,102,0.2)' }}
          >
            <div className="relative h-44 flex items-center justify-center overflow-hidden"
              style={{ background: 'linear-gradient(135deg, #128C7E 0%, #25D366 50%, #5DF08A 100%)' }}>
              <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 30% 50%, rgba(255,255,255,0.08) 0%, transparent 60%)' }} />
              <div className="text-center z-10 px-6">
                <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-3"
                  style={{ background: 'rgba(255,255,255,0.15)', border: '2px solid rgba(255,255,255,0.3)' }}>
                  <svg viewBox="0 0 24 24" fill="white" className="w-11 h-11">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                  </svg>
                </div>
                <p className="text-white font-black text-lg">انضم لمجتمع الواتساب الآن!</p>
                <p className="text-white/85 text-sm">أخبار الموقع وعروض مميزة</p>
              </div>
            </div>
            <div className="p-6 text-center" dir="rtl">
              <div className="flex items-center gap-2 justify-center mb-2">
                <span className="text-red-500 text-lg">🔴</span>
                <h3 className="font-black text-white text-lg">ملاحظة مهمة !!</h3>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed mb-2">
                يرجى الانضمام الى{' '}
                <a href={WHATSAPP_GROUP} target="_blank" rel="noopener noreferrer" className="text-emerald-400 font-bold underline">مجتمع الواتساب</a>
              </p>
              <p className="text-gray-400 text-sm mb-4">لمتابعة أخبار وتحديثات الموقع :</p>
              <a href={WHATSAPP_GROUP} target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl font-black text-white text-base mb-3 transition-all hover:scale-[1.02] active:scale-95"
                style={{ background: 'linear-gradient(135deg, #25D366, #128C7E)' }}>
                ➡️ اضغط هنا للانضمام ⬅️
              </a>
              <button onClick={dismiss}
                className="w-full py-3 rounded-2xl font-bold text-gray-800 text-base transition-all hover:opacity-90 active:scale-95"
                style={{ background: '#fbbf24' }}>
                إغلاق
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Category display type ─────────────────────────────────────
type CatDisplay = {
  id: string | number;
  nameAr: string;
  nameEn: string;
  href: string;
  color: string;
  bg: string;
  icons: { img: string; label: string; bg: string }[];
};

function apiToCat(c: any): CatDisplay {
  return {
    id: c.id,
    nameAr: c.nameAr,
    nameEn: c.nameEn,
    href: normalizeCategoryHref(c),
    color: c.color,
    bg: c.bgGradient,
    icons: [
      { img: c.icon1 || '', label: c.iconLabel1 || '', bg: c.color },
      { img: c.icon2 || '', label: c.iconLabel2 || '', bg: c.color },
      { img: c.icon3 || '', label: c.iconLabel3 || '', bg: c.color },
      { img: c.icon4 || '', label: c.iconLabel4 || '', bg: c.color },
    ],
  };
}

// ─── Category Card Config ──────────────────────────────────────
type CatCardConfig = {
  layout: 'grid' | 'single' | 'minimal';
  iconStyle: 'rounded' | 'circle' | 'square';
  iconSize: 'sm' | 'md' | 'lg';
  hoverEffect: 'scale' | 'lift' | 'glow' | 'none';
  showEnLabel: boolean;
  showVipBadge: boolean;
  cardRadius: number;
  borderGlow: boolean;
  nameSize: 'xs' | 'sm' | 'md';
};

const DEFAULT_CAT_CONFIG: CatCardConfig = {
  layout: 'grid', iconStyle: 'rounded', iconSize: 'md',
  hoverEffect: 'scale', showEnLabel: true, showVipBadge: true,
  cardRadius: 16, borderGlow: false, nameSize: 'sm',
};

function useCatCardConfig(): CatCardConfig {
  const { data } = useQuery<CatCardConfig>({
    queryKey: ['cat-card-config'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/settings`);
      if (!r.ok) return DEFAULT_CAT_CONFIG;
      const d = await r.json();
      if (!d.category_card_style) return DEFAULT_CAT_CONFIG;
      try { return { ...DEFAULT_CAT_CONFIG, ...JSON.parse(d.category_card_style) }; }
      catch { return DEFAULT_CAT_CONFIG; }
    },
    staleTime: 5 * 60_000,
  });
  return data ?? DEFAULT_CAT_CONFIG;
}

// ─── Category Card ─────────────────────────────────────────────
function CategoryCard({ cat, index, cfg }: { cat: CatDisplay; index: number; cfg: CatCardConfig }) {
  const [imgErrors, setImgErrors] = useState<Set<number>>(new Set());
  const { user } = useAuth();
  const userVipLevel = (user as any)?.vipLevel ?? 0;
  const isVip = userVipLevel >= 1;

  const iconSizePx = cfg.iconSize === 'sm' ? 28 : cfg.iconSize === 'lg' ? 44 : 36;
  const iconSizeCls = cfg.iconSize === 'sm' ? 'w-7 h-7' : cfg.iconSize === 'lg' ? 'w-11 h-11' : 'w-9 h-9';
  const iconBr = cfg.iconStyle === 'circle' ? 9999 : cfg.iconStyle === 'square' ? 6 : 14;
  const nameSizeCls = cfg.nameSize === 'xs' ? 'text-[10px]' : cfg.nameSize === 'md' ? 'text-sm' : 'text-[12px]';
  const borderColor = `${cat.color}${cfg.borderGlow ? '80' : '40'}`;
  const shadow = cfg.borderGlow
    ? `0 0 18px ${cat.color}40, 0 4px 20px ${cat.color}18`
    : `0 4px 20px ${cat.color}18`;
  const hoverProps = cfg.hoverEffect === 'scale' ? { scale: 1.04, y: -4 }
    : cfg.hoverEffect === 'lift' ? { y: -6 }
    : cfg.hoverEffect === 'glow' ? { scale: 1.02 }
    : {};

  const displayIcons = cfg.layout === 'single' ? [cat.icons[0]] : cat.icons;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, type: 'spring', stiffness: 300, damping: 25 }}
      whileHover={hoverProps}
      whileTap={{ scale: 0.96 }}
    >
      <Link href={cat.href} className="block">
        <div
          className="relative overflow-hidden shine-card"
          style={{
            background: cat.bg,
            border: `1px solid ${borderColor}`,
            boxShadow: shadow,
            borderRadius: cfg.cardRadius,
            minHeight: cfg.layout === 'minimal' ? 52 : 148,
          }}
        >
          {/* VIP badge */}
          {cfg.showVipBadge && isVip && (
            <div className="absolute top-2 right-2 z-10">
              <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full"
                style={{ background: 'rgba(0,0,0,0.55)', border: '1px solid rgba(255,215,0,0.5)' }}
                title={`خصم VIP ${userVipLevel} مفعّل لك`}>
                <Star size={9} className="text-yellow-400" fill="#facc15" />
                <span className="text-[9px] font-black text-yellow-400">VIP {userVipLevel}</span>
              </div>
            </div>
          )}

          {/* Minimal layout */}
          {cfg.layout === 'minimal' ? (
            <div className="flex items-center gap-2.5 p-3">
              <div className="flex items-center justify-center overflow-hidden shrink-0"
                style={{ width: iconSizePx, height: iconSizePx, borderRadius: iconBr, background: `${cat.icons[0]?.bg ?? cat.color}22`, border: `1px solid ${cat.icons[0]?.bg ?? cat.color}33` }}>
                {cat.icons[0]?.img && !imgErrors.has(0) ? (
                  <img src={cat.icons[0].img} alt={cat.icons[0].label} className={`${iconSizeCls} object-contain`} onError={() => setImgErrors(s => new Set([...s, 0]))} />
                ) : (
                  <span className="text-[10px] font-black text-white/60">{(cat.icons[0]?.label ?? cat.nameAr).slice(0, 2)}</span>
                )}
              </div>
              <p className={`${nameSizeCls} font-black text-white`}>{cat.nameAr}</p>
            </div>
          ) : cfg.layout === 'single' ? (
            <>
              <div className="p-3 pb-1.5 flex justify-center">
                <div className="flex items-center justify-center overflow-hidden"
                  style={{ width: iconSizePx * 2, height: iconSizePx * 2, borderRadius: iconBr, background: `${displayIcons[0]?.bg ?? cat.color}22`, border: `1px solid ${displayIcons[0]?.bg ?? cat.color}33` }}>
                  {displayIcons[0]?.img && !imgErrors.has(0) ? (
                    <img src={displayIcons[0].img} alt={displayIcons[0].label} style={{ width: iconSizePx * 1.4, height: iconSizePx * 1.4 }} className="object-contain" onError={() => setImgErrors(s => new Set([...s, 0]))} />
                  ) : (
                    <span className="text-base font-black text-white/60">{(displayIcons[0]?.label ?? '').slice(0, 2)}</span>
                  )}
                </div>
              </div>
              <div className="w-full text-center py-2.5 px-2"
                style={{ background: `linear-gradient(0deg, ${cat.color}33 0%, transparent 100%)`, borderTop: `1px solid ${cat.color}30` }}>
                <p className={`${nameSizeCls} font-black text-white leading-none`}>{cat.nameAr}</p>
                {cfg.showEnLabel && <p className="text-[9px] text-white/45 mt-1">{cat.nameEn}</p>}
              </div>
            </>
          ) : (
            <>
              {/* Grid 2×2 icons */}
              <div className="p-3 pb-1.5">
                <div className="grid grid-cols-2 gap-2">
                  {cat.icons.map((icon, i) => (
                    <div key={i} className="aspect-square flex items-center justify-center overflow-hidden"
                      style={{ borderRadius: iconBr, background: `${icon.bg}22`, border: `1px solid ${icon.bg}33` }}>
                      {!imgErrors.has(i) ? (
                        <img src={icon.img} alt={icon.label} className={`${iconSizeCls} object-contain`}
                          onError={() => setImgErrors(s => new Set([...s, i]))} />
                      ) : (
                        <span className="text-xs font-black text-white/60">{icon.label.slice(0, 2)}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              {/* Name strip */}
              <div className="w-full text-center py-2.5 px-2"
                style={{ background: `linear-gradient(0deg, ${cat.color}33 0%, transparent 100%)`, borderTop: `1px solid ${cat.color}30` }}>
                <p className={`${nameSizeCls} font-black text-white leading-none`}>{cat.nameAr}</p>
                {cfg.showEnLabel && <p className="text-[9px] text-white/45 mt-1">{cat.nameEn}</p>}
              </div>
            </>
          )}
        </div>
      </Link>
    </motion.div>
  );
}

// ─── Hero Banner Slider ───────────────────────────────────────
const HERO_SLIDES = [
  {
    id: 0,
    bg: 'linear-gradient(135deg, #0d0025 0%, #1e0060 40%, #0a0a2e 100%)',
    glow1: '#6C5CE7',
    glow2: '#a29bfe',
    accentColor: '#6C5CE7',
    badgeText: '🎮 متجر Elite Store',
    title: 'أفضل أسعار\nالألعاب الرقمية',
    subtitle: 'شحن فوري · ضمان كامل · خدمة 24/7',
    ctaText: 'تصفح المنتجات',
    ctaHref: '/games?category=mobile_games',
    ctaSecondary: 'اشحن الآن',
    ctaSecondaryHref: '/games?category=mobile_games',
    emoji: '🎮',
    particles: ['#6C5CE7', '#a29bfe', '#00CEC9', '#6C5CE7', '#a29bfe', '#fff'],
    badge2: '🏆 الأفضل سعراً',
    icon: '🕹️',
    barColors: ['#6C5CE7', '#a29bfe', '#7c3aed', '#8b5cf6', '#6C5CE7'],
  },
  {
    id: 1,
    bg: 'linear-gradient(135deg, #001a00 0%, #003d00 40%, #001200 100%)',
    glow1: '#22c55e',
    glow2: '#86efac',
    accentColor: '#22c55e',
    badgeText: '⚡ تسليم فوري',
    title: 'تسليم آني\nبعد الدفع مباشرة',
    subtitle: 'أكثر من 100 منتج رقمي متاح الآن',
    ctaText: 'بطاقات الهدايا',
    ctaHref: '/games?category=gift_cards',
    ctaSecondary: 'الاشتراكات',
    ctaSecondaryHref: '/games?category=services',
    emoji: '⚡',
    particles: ['#22c55e', '#86efac', '#4ade80', '#22c55e', '#16a34a', '#fff'],
    badge2: '✅ ضمان استرداد',
    icon: '🚀',
    barColors: ['#22c55e', '#16a34a', '#4ade80', '#86efac', '#22c55e'],
  },
  {
    id: 2,
    bg: 'linear-gradient(135deg, #001020 0%, #002060 40%, #000d1a 100%)',
    glow1: '#3b82f6',
    glow2: '#93c5fd',
    accentColor: '#3b82f6',
    badgeText: '🔒 دفع آمن 100%',
    title: 'دفع مضمون\nبطرق متعددة',
    subtitle: 'Syriatel Cash · Sham Cash · وأكثر',
    ctaText: 'اشحن رصيدك',
    ctaHref: '/deposit',
    ctaSecondary: 'إنشاء حساب',
    ctaSecondaryHref: '/register',
    emoji: '🔒',
    particles: ['#3b82f6', '#93c5fd', '#60a5fa', '#3b82f6', '#1d4ed8', '#fff'],
    badge2: '💳 دفع مرن',
    icon: '🛡️',
    barColors: ['#3b82f6', '#1d4ed8', '#60a5fa', '#93c5fd', '#3b82f6'],
  },
];

function HeroBanner() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [direction, setDirection] = useState(1);
  const [paused, setPaused] = useState(false);

  const { data: apiBanners } = useQuery({
    queryKey: ['home-banners'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/banners`);
      if (!r.ok) return [];
      return r.json() as Promise<any[]>;
    },
    staleTime: 60_000,
  });

  const slides = (apiBanners && apiBanners.length > 0)
    ? apiBanners.map((b, i) => ({
        id: b.id ?? i,
        bg: b.bgGradient,
        glow1: b.glow1,
        glow2: b.glow2,
        accentColor: b.accentColor,
        badgeText: b.badgeText,
        title: b.title,
        subtitle: b.subtitle,
        ctaText: b.ctaText,
        ctaHref: b.ctaHref || '/games?category=mobile_games',
        ctaSecondary: b.ctaSecondaryText,
        ctaSecondaryHref: b.ctaSecondaryHref || '/games?category=mobile_games',
        emoji: b.emoji,
        particles: [b.accentColor, b.glow2, b.glow1, b.accentColor, b.glow2, '#fff'],
        badge2: b.badge2Text,
        icon: b.icon,
        iconEnabled: b.iconEnabled === true,
        barColors: [b.accentColor, b.glow1, b.glow2, b.accentColor, b.glow2],
      }))
    : HERO_SLIDES;

  const goTo = (idx: number) => {
    setDirection(idx > activeSlide ? 1 : -1);
    setActiveSlide(idx);
  };

  useEffect(() => {
    if (activeSlide >= slides.length) setActiveSlide(0);
  }, [slides.length, activeSlide]);

  useEffect(() => {
    if (paused) return;
    const timer = setInterval(() => {
      setDirection(1);
      setActiveSlide(prev => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [paused, slides.length]);

  const slide = slides[Math.min(activeSlide, slides.length - 1)] || HERO_SLIDES[0];

  return (
    <div
      className="relative w-full rounded-3xl overflow-hidden mb-5"
      style={{ minHeight: 220, height: 220 }}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Slide background */}
      <AnimatePresence mode="wait" custom={direction}>
        <motion.div
          key={`bg-${slide.id}`}
          className="absolute inset-0"
          style={{ background: slide.bg }}
          custom={direction}
          initial={{ opacity: 0, x: direction * 60 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: direction * -60 }}
          transition={{ duration: 0.45, ease: 'easeInOut' }}
        />
      </AnimatePresence>

      {/* Slide counter */}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold text-white/60"
        style={{ background: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(4px)' }}>
        {activeSlide + 1}/{slides.length}
      </div>

      {/* Border glow */}
      <div className="absolute inset-0 rounded-3xl pointer-events-none"
        style={{ border: `1px solid ${slide.accentColor}40`, boxShadow: `0 0 80px ${slide.accentColor}18, inset 0 0 40px ${slide.accentColor}06` }} />

      {/* Glow circles */}
      <motion.div
        key={`g1-${slide.id}`}
        className="absolute -right-16 -top-16 w-72 h-72 rounded-full pointer-events-none"
        style={{ background: `radial-gradient(circle, ${slide.glow1}50, transparent 70%)` }}
        animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      <motion.div
        key={`g2-${slide.id}`}
        className="absolute -left-10 -bottom-10 w-48 h-48 rounded-full pointer-events-none"
        style={{ background: `radial-gradient(circle, ${slide.glow2}40, transparent 70%)` }}
        animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 4, repeat: Infinity, delay: 0.5 }}
      />

      {/* Floating particles */}
      {slide.particles.map((color, i) => (
        <motion.div
          key={`p-${slide.id}-${i}`}
          className="absolute rounded-full pointer-events-none"
          style={{
            background: color,
            width: i % 3 === 0 ? 6 : i % 3 === 1 ? 4 : 3,
            height: i % 3 === 0 ? 6 : i % 3 === 1 ? 4 : 3,
            top: `${10 + i * 14}%`,
            left: `${8 + i * 12}%`,
            filter: 'blur(0.5px)',
          }}
          animate={{
            opacity: [0.2, 0.9, 0.2],
            scale: [1, 1.8, 1],
            y: [0, -8, 0],
          }}
          transition={{ duration: 2 + i * 0.4, repeat: Infinity, delay: i * 0.18 }}
        />
      ))}

      {/* Scanline overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.5) 2px, rgba(255,255,255,0.5) 3px)', backgroundSize: '100% 4px' }} />

      {/* Main Content */}
      <div className="relative z-10 flex flex-col justify-between h-full" style={{ minHeight: 200, padding: '18px 16px 16px' }} dir="rtl">
        {/* Top badges row */}
        <div className="flex items-center justify-between mb-3">
          <AnimatePresence mode="wait">
            <motion.div
              key={`badge-${slide.id}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black text-white"
              style={{ background: `${slide.accentColor}30`, border: `1px solid ${slide.accentColor}50`, backdropFilter: 'blur(8px)' }}
            >
              {slide.badgeText}
            </motion.div>
          </AnimatePresence>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold text-white/80"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}>
            {slide.badge2}
          </div>
        </div>

        {/* Title */}
        <div className="mb-3">
          <AnimatePresence mode="wait">
            <motion.h1
              key={`title-${slide.id}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.45, delay: 0.05 }}
              className="font-black text-white text-2xl leading-tight mb-1.5"
              style={{ textShadow: `0 0 40px ${slide.accentColor}60`, whiteSpace: 'pre-line' }}
            >
              {slide.title}
            </motion.h1>
          </AnimatePresence>
          <AnimatePresence mode="wait">
            <motion.p
              key={`sub-${slide.id}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4, delay: 0.1 }}
              className="text-xs font-medium"
              style={{ color: `${slide.accentColor}cc` }}
            >
              {slide.subtitle}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* CTA buttons + dots */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AnimatePresence mode="wait">
              <motion.a
                key={`cta-${slide.id}`}
                href={`${BASE}${slide.ctaHref}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.35, delay: 0.15 }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-black text-white transition-all hover:scale-105 active:scale-95"
                style={{ background: `linear-gradient(135deg, ${slide.accentColor}, ${slide.glow2})`, boxShadow: `0 4px 20px ${slide.accentColor}50` }}
              >
                <Zap size={11} />
                {slide.ctaText}
              </motion.a>
            </AnimatePresence>
            <motion.a
              href={`${BASE}${slide.ctaSecondaryHref}`}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold text-white/80 transition-all hover:text-white active:scale-95"
              style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)' }}
            >
              {slide.ctaSecondary}
            </motion.a>
          </div>

          {/* Dots indicator */}
          <div className="flex items-center gap-1.5">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i)}
                className="transition-all duration-300 rounded-full"
                style={{
                  width: i === activeSlide ? 22 : 7,
                  height: 7,
                  background: i === activeSlide ? slide.accentColor : 'rgba(255,255,255,0.25)',
                  boxShadow: i === activeSlide ? `0 0 10px ${slide.accentColor}80` : 'none',
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Decorative icon — bottom-left corner, opt-in per banner */}
      {(slide as any).iconEnabled && (
        <div className="absolute bottom-3 left-3 z-20 pointer-events-none">
          <AnimatePresence mode="wait">
            <motion.div
              key={`icon-${slide.id}`}
              initial={{ scale: 0, rotate: -20 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
              style={{ background: `${slide.accentColor}22`, border: `1px solid ${slide.accentColor}40`, backdropFilter: 'blur(10px)' }}
            >
              {slide.icon}
            </motion.div>
          </AnimatePresence>
        </div>
      )}

      {/* Right side decorative bars */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col items-center gap-2 pointer-events-none">
        <div className="flex items-end gap-0.5 h-10">
          {slide.barColors.map((color, i) => (
            <motion.div
              key={`bar-${slide.id}-${i}`}
              className="w-2.5 rounded-t-sm"
              style={{ background: color }}
              initial={{ scaleY: 0, originY: 1 }}
              animate={{ scaleY: 1 }}
              transition={{ delay: i * 0.08, type: 'spring', stiffness: 250 }}
              custom={i}
            >
              <motion.div
                className="w-full h-full rounded-t-sm"
                style={{ background: `linear-gradient(to top, ${color}ff, ${color}44)`, height: `${35 + i * 8}%` }}
                animate={{ height: [`${35 + i * 8}%`, `${50 + i * 8}%`, `${35 + i * 8}%`] }}
                transition={{ duration: 1.5 + i * 0.2, repeat: Infinity, delay: i * 0.1 }}
              />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Bottom Elite Store label */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2">
        <div className="flex items-center gap-1 px-2 py-0.5 rounded-full"
          style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,255,255,0.1)', backdropFilter: 'blur(8px)' }}>
          <Zap size={8} style={{ color: slide.accentColor }} />
          <span className="text-[9px] font-black text-white/70">Elite Store</span>
        </div>
      </div>
    </div>
  );
}

// ─── Search Bar ───────────────────────────────────────────────
function SearchBar() {
  const [q, setQ] = useState('');

  const go = () => {
    if (q.trim()) window.location.href = `${BASE}/games?category=mobile_games&q=${encodeURIComponent(q.trim())}`;
  };

  return (
    <div className="relative mb-5 flex items-center gap-2">
      <div className="flex-1 relative">
        <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
          <Search size={15} className="text-gray-500" />
        </div>
        <input
          value={q}
          onChange={e => setQ(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && go()}
          placeholder="ابحث عن منتج أو لعبة..."
          dir="rtl"
          className="w-full py-3 pr-9 pl-4 rounded-2xl text-sm text-white placeholder-gray-500 outline-none transition-all"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            backdropFilter: 'blur(10px)',
          }}
          onFocus={e => { e.currentTarget.style.border = '1px solid rgba(108,92,231,0.5)'; e.currentTarget.style.boxShadow = '0 0 20px rgba(108,92,231,0.1)'; }}
          onBlur={e => { e.currentTarget.style.border = '1px solid rgba(255,255,255,0.1)'; e.currentTarget.style.boxShadow = 'none'; }}
        />
      </div>
      <button
        onClick={go}
        className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all active:scale-90"
        style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)', boxShadow: '0 4px 15px rgba(108,92,231,0.4)' }}
      >
        <Search size={16} className="text-white" />
      </button>
    </div>
  );
}

// ─── Stats Bar (Trust-focused, no live counters) ───────────
function StatsBar() {
  const { data: statsData } = useQuery<{ count: number }>({
    queryKey: ['products-count'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/products/count`);
      if (!res.ok) return { count: 0 };
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });
  const productCount = statsData?.count ?? 0;
  const productLabel = productCount >= 1000
    ? `+${Math.floor(productCount / 1000)}K`
    : productCount > 0 ? `+${productCount}` : '—';
  const stats = [
    { icon: '⚡', label: 'تسليم فوري', value: '24/7' },
    { icon: '🛡️', label: 'ضمان كامل', value: '100%' },
    { icon: '✅', label: 'عملية ناجحة', value: '+10K' },
    { icon: '🛍️', label: 'منتج متاح', value: productLabel },
  ];
  return (
    <div className="grid grid-cols-4 gap-2 mb-5">
      {stats.map((s, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 + i * 0.05 }}
          className="flex flex-col items-center py-3 px-1 rounded-xl text-center"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <span className="text-lg leading-none mb-1">{s.icon}</span>
          <span className="text-white font-black text-sm leading-none">{s.value}</span>
          <span className="text-gray-500 text-[9px] mt-0.5">{s.label}</span>
        </motion.div>
      ))}
    </div>
  );
}

function NoticePanel() {
  return (
    <div className="mb-3 rounded-xl px-3 py-2 flex items-center gap-2" dir="rtl" style={{ background: 'linear-gradient(135deg, rgba(37,211,102,0.12), rgba(18,140,126,0.06))', border: '1px solid rgba(37,211,102,0.18)' }}>
      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse shrink-0" />
      <p className="flex-1 min-w-0 text-[11px] text-gray-300 truncate">
        <span className="font-bold text-white">ملاحظة:</span> انضم لمجتمع الواتساب لمتابعة العروض والأخبار
      </p>
      <a href={WHATSAPP_GROUP} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold text-white shrink-0 transition-transform active:scale-95" style={{ background: 'linear-gradient(135deg, #25D366, #128C7E)' }}>
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z"/>
        </svg>
        انضم
      </a>
    </div>
  );
}

// ─── Admin Quick Edit Bar (only visible to admins) ────────────
function AdminQuickBar() {
  const { user } = useAuth();
  if (user?.role !== 'admin') return null;
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2 p-3 rounded-2xl border" dir="rtl"
      style={{ background: 'linear-gradient(135deg, rgba(108,92,231,0.12), rgba(0,206,201,0.06))', borderColor: 'rgba(108,92,231,0.3)' }}>
      <span className="text-xs font-bold text-primary mr-1">⚙️ وضع الإدارة:</span>
      <Link href="/admin/categories"
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 transition-colors">
        <LayoutGrid size={12} /> ترتيب وتعديل الأقسام
      </Link>
      <Link href="/admin/products"
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 transition-colors">
        <Pencil size={12} /> تعديل المنتجات والأسعار
      </Link>
      <Link href="/admin/orders"
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30 hover:bg-amber-500/25 transition-colors">
        ⏳ الطلبات قيد المراجعة
      </Link>
    </div>
  );
}

// ─── Hook: home sections config ───────────────────────────────
function useHomeSections() {
  const { data } = useQuery<{ sections: { id: string; enabled: boolean }[] }>({
    queryKey: ['home-sections'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/home-sections`);
      if (!r.ok) return { sections: [] };
      return r.json();
    },
    staleTime: 60_000,
  });
  const sections = data?.sections ?? [];
  const isEnabled = (id: string) => {
    const sec = sections.find(s => s.id === id);
    return sec === undefined ? true : sec.enabled;
  };
  return { isEnabled };
}

// ─── Quick Discount (Flash Sale) ─────────────────────────────
// ─── Live countdown hook (updates every second) ───────────────────────────────
function useCountdown(target: string | null) {
  const [now, setNow] = React.useState(Date.now);
  useEffect(() => {
    if (!target) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [target]);
  const ms = target ? Math.max(0, new Date(target).getTime() - now) : 0;
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1_000);
  return { h, m, s, expired: ms === 0 };
}

// ─── Individual flash sale card (isolated re-render) ─────────────────────────
function FlashCard({ p }: { p: any }) {
  const { h, m, s, expired } = useCountdown(p.saleEndsAt);
  if (expired) return null;
  const urgent = h === 0 && m < 10;
  return (
    <Link href={`/products/${p.id}`} className="shrink-0 w-36">
      <div className="relative rounded-2xl overflow-hidden border border-orange-500/25 bg-gradient-to-br from-orange-500/10 via-red-500/5 to-transparent hover:border-orange-400/50 transition-colors hover:-translate-y-0.5 cursor-pointer" style={{ willChange: 'auto' }}>
        {p.discountPct > 0 && (
          <div className="absolute top-1.5 right-1.5 z-10 px-1.5 py-0.5 rounded-md bg-red-500 text-white text-[9px] font-extrabold shadow">
            -{p.discountPct}%
          </div>
        )}
        <div className="h-20 bg-gradient-to-br from-orange-600/20 to-red-700/20 flex items-center justify-center overflow-hidden">
          {p.imageUrl ? (
            <img src={p.imageUrl} alt={p.nameAr || p.name} loading="lazy" className="w-full h-full object-cover" />
          ) : (
            <Tag size={28} className="text-orange-400/60" />
          )}
        </div>
        <div className="p-2">
          <h3 className="font-bold text-[11px] text-white line-clamp-1 mb-1">{p.nameAr || p.name}</h3>
          <div className="flex items-center gap-1.5 mb-1">
            <span className="text-sm font-extrabold text-orange-400">${Number(p.salePriceUsd).toFixed(2)}</span>
            <span className="text-[10px] line-through text-white/40">${Number(p.priceUsd).toFixed(2)}</span>
          </div>
          <div className={`flex items-center gap-1 text-[9px] font-mono font-bold ${urgent ? 'text-red-400' : 'text-orange-300/80'}`}>
            <Clock size={8} />
            {h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
            {urgent && <span className="text-red-400 animate-pulse">!</span>}
          </div>
        </div>
      </div>
    </Link>
  );
}

function QuickDiscount() {
  const { data, isLoading } = useQuery<any[]>({
    queryKey: ['flash-sales'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/products/flash-sales`);
      if (!r.ok) return [];
      return r.json();
    },
    staleTime: 2 * 60 * 1000,
    refetchInterval: 5 * 60 * 1000,
  });
  const products = data ?? [];
  if (isLoading || products.length === 0) return null;

  return (
    <div className="mb-6" dir="rtl">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-white font-black text-base flex items-center gap-2">
          <Tag size={18} className="text-orange-400" />
          خصم سريع
          <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded-full bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold">
            ⚡ محدود
          </span>
        </h2>
        <Link href="/games" className="flex items-center gap-1 text-orange-400 text-xs font-bold hover:text-orange-300 transition-colors">
          عرض الكل <ChevronLeft size={13} />
        </Link>
      </div>
      <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-hide">
        {products.slice(0, 8).map(p => <FlashCard key={p.id} p={p} />)}
      </div>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────
function FeaturedBundles() {
  const { data } = useQuery<{ bundles: any[] }>({
    queryKey: ['featured-bundles'],
    queryFn: async () => {
      const r = await fetch(`${BASE}/api/bundles`);
      if (!r.ok) return { bundles: [] };
      return r.json();
    },
    staleTime: 5 * 60 * 1000,
  });
  const all = data?.bundles ?? [];
  const featured = all.filter(b => b.isFeatured);
  const list = (featured.length > 0 ? featured : all).slice(0, 6);
  if (list.length === 0) return null;
  return (
    <div className="mb-6" dir="rtl">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-white font-black text-base flex items-center gap-2">
          <Gift size={18} className="text-pink-400" />
          عروض وحزم مميزة
          <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold">
            <Sparkles size={9} /> وفّر
          </span>
        </h2>
        <Link href="/bundles" className="flex items-center gap-1 text-pink-400 text-xs font-bold hover:text-pink-300 transition-colors">
          كل الحزم <ChevronLeft size={13} />
        </Link>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-2.5">
        {list.map(b => (
          <Link key={b.id} href={`/bundles/${b.id}`}>
            <div className="group relative rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-indigo-500/10 hover:border-pink-400/60 transition-all hover:-translate-y-0.5 cursor-pointer h-full flex flex-col">
              <div className="relative h-24 sm:h-28 bg-gradient-to-br from-pink-600/30 to-purple-700/30 overflow-hidden">
                {b.imageUrl ? (
                  <img src={b.imageUrl} alt={b.nameAr || b.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Gift size={36} className="text-pink-400/70" />
                  </div>
                )}
                {b.savingsPercent > 0 && (
                  <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-success text-white text-[9px] font-extrabold shadow">
                    -{b.savingsPercent}%
                  </div>
                )}
                {b.badge && (
                  <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-amber-500/95 text-white text-[9px] font-bold shadow">
                    {b.badge}
                  </div>
                )}
              </div>
              <div className="p-2 flex flex-col flex-1">
                <h3 className="font-bold text-xs text-white line-clamp-1 mb-1">{b.nameAr || b.name}</h3>
                <div className="text-[9px] text-white/50 mb-1.5">{b.items?.length ?? 0} منتج</div>
                <div className="flex items-end gap-1.5 mt-auto">
                  <span className="text-base font-extrabold text-pink-400">${Number(b.bundlePriceUsd).toFixed(2)}</span>
                  {b.savingsUsd > 0 && (
                    <span className="text-[9px] line-through text-white/40 mb-0.5">${Number(b.originalTotalUsd).toFixed(2)}</span>
                  )}
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  const { lang } = useLanguage();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { isEnabled } = useHomeSections();
  const catCfg = useCatCardConfig();

  const { data: dbCats } = useQuery({
    queryKey: ['public-db-categories'],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/categories`);
      if (!res.ok) return null;
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) return null;
      return data as any[];
    },
    staleTime: 5 * 60 * 1000,
  });

  const EXCLUDED_CATEGORIES = ['wholesale', 'other_stores', 'other', 'متاجر_أخرى'];
  const displayCats: CatDisplay[] = dbCats && dbCats.length > 0
    ? dbCats.filter(c => !EXCLUDED_CATEGORIES.includes(String(c.id ?? ''))).map(apiToCat)
    : CATEGORIES_FALLBACK as unknown as CatDisplay[];

  return (
    <PublicLayout>
      <TelegramPopup />
      <div className="max-w-6xl mx-auto px-3 sm:px-4 pt-3 pb-24">

        <AdminQuickBar />

        {/* Hero */}
        <HeroBanner />

        <NoticePanel />

        {/* Search */}
        <SearchBar />

        {/* Stats */}
        <StatsBar />

        {/* Featured Bundles — controlled by admin home-sections toggle */}
        {isEnabled('featured_bundles') && <FeaturedBundles />}

        {/* Quick Discount (Flash Sales) — controlled by admin home-sections toggle */}
        {isEnabled('quick_discount') && <QuickDiscount />}

        {/* Categories header */}
        <div className="flex items-center justify-between mb-3" dir="rtl">
          <h2 className="text-white font-black text-base">تصفح الأقسام</h2>
          <Link href="/games?category=mobile_games" className="flex items-center gap-1 text-purple-400 text-xs font-bold hover:text-purple-300 transition-colors">
            عرض الكل <ChevronLeft size={13} />
          </Link>
        </div>

        {/* 3-column category grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 mb-6">
          {displayCats.map((cat, i) => (
            <div key={cat.id} className="relative">
              <CategoryCard cat={cat} index={i} cfg={catCfg} />
              {isAdmin && (
                <Link
                  href={`/admin/categories?edit=${cat.id}`}
                  onClick={(e) => e.stopPropagation()}
                  className="absolute top-2 left-2 z-20 w-7 h-7 rounded-full flex items-center justify-center shadow-lg transition-transform hover:scale-110 active:scale-95"
                  style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', border: '1px solid rgba(108,92,231,0.5)' }}
                  title="تعديل القسم"
                >
                  <Pencil size={11} className="text-primary" />
                </Link>
              )}
            </div>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <Link href="/games?category=mobile_games"
            className="flex items-center justify-center gap-2 py-4 rounded-2xl font-bold text-white text-sm transition-all hover:scale-[1.02] active:scale-95"
            style={{ background: 'linear-gradient(135deg, #6C5CE7, #a29bfe)', boxShadow: '0 4px 20px #6C5CE750' }}>
            <Zap size={15} /> تصفح الألعاب
          </Link>
          <a href={TELEGRAM_SUPPORT} target="_blank" rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-4 rounded-2xl font-bold text-white text-sm transition-all hover:scale-[1.02] active:scale-95"
            style={{ background: 'linear-gradient(135deg, #2AABEE, #1E96D0)', boxShadow: '0 4px 20px #2AABEE50' }}>
            <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4 -rotate-12">
              <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
            </svg>
            تواصل عبر تيليغرام
          </a>
        </div>

        {/* Feature badges */}
        <div className="flex flex-wrap gap-2 justify-center">
          {['🔒 دفع آمن', '⚡ تسليم فوري', '💬 دعم 24/7', '🔄 استرجاع مضمون', '💎 جودة عالية'].map((badge, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 + i * 0.08 }}
              className="text-xs px-3 py-1.5 rounded-full font-semibold"
              style={{
                background: 'rgba(108,92,231,0.1)',
                border: '1px solid rgba(108,92,231,0.25)',
                color: '#a29bfe',
              }}
            >
              {badge}
            </motion.span>
          ))}
        </div>
      </div>
    </PublicLayout>
  );
}
