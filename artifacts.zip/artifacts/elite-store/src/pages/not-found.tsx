import { Link } from "wouter";
import { motion } from "framer-motion";
import { AlertCircle, Home, ShoppingBag } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background px-4 py-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md text-center"
      >
        <div className="relative mx-auto mb-6 w-24 h-24 rounded-3xl bg-gradient-to-br from-red-500/20 to-amber-500/20 border border-red-500/30 flex items-center justify-center">
          <AlertCircle className="text-red-400" size={44} />
          <div className="absolute -top-2 -right-2 w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center">
            <span className="text-xl font-black text-red-400">404</span>
          </div>
        </div>

        <h1 className="text-3xl font-black text-foreground mb-2">
          الصفحة غير موجودة
        </h1>
        <p className="text-sm text-muted-foreground mb-8 leading-relaxed">
          الرابط الذي تحاول الوصول إليه غير صحيح أو تم نقله.
          <br />
          ربما تبحث عن منتج مختلف أو صفحة تم تحديث رابطها.
        </p>

        <div className="grid grid-cols-2 gap-3">
          <Link href="/" className="flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white font-bold rounded-2xl hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
            <Home size={16} />
            الرئيسية
          </Link>
          <Link href="/products" className="flex items-center justify-center gap-2 px-4 py-3 bg-card border border-border text-foreground font-bold rounded-2xl hover:bg-muted transition-all">
            <ShoppingBag size={16} />
            المنتجات
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
