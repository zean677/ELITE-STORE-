import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PublicLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { Star, Gift, Coins, Loader2, Check, Lock, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function api(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

function RewardsContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [confirming, setConfirming] = useState<any | null>(null);

  const { data: rewards = [], isLoading } = useQuery<any[]>({
    queryKey: ['loyalty-rewards-public'],
    queryFn: async () => (await api('GET', '/api/loyalty/rewards')).json(),
  });

  const { data: loyalty } = useQuery<any>({
    queryKey: ['loyalty-me'],
    queryFn: async () => (await api('GET', '/api/loyalty')).json(),
  });

  const myPoints = loyalty?.points ?? 0;

  const redeemMut = useMutation({
    mutationFn: async (id: number) => {
      const res = await api('POST', `/api/loyalty/rewards/${id}/redeem`, {});
      const data = await res.json();
      if (!res.ok) throw new Error(data.message ?? 'فشل الاستبدال');
      return data;
    },
    onSuccess: (d) => {
      toast({ title: '🎉 تم الاستبدال بنجاح!', description: d.message });
      setConfirming(null);
      qc.invalidateQueries({ queryKey: ['loyalty-rewards-public'] });
      qc.invalidateQueries({ queryKey: ['loyalty-me'] });
      qc.invalidateQueries({ queryKey: ['user'] });
    },
    onError: (e: any) => toast({ title: '❌ تعذّر الاستبدال', description: e.message, variant: 'destructive' }),
  });

  return (
    <div dir="rtl" className="max-w-6xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-yellow-500/20 via-orange-500/15 to-pink-500/20 border border-yellow-500/30 rounded-3xl p-5 lg:p-6 relative overflow-hidden">
        <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full bg-yellow-500/20 blur-3xl" />
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg shadow-yellow-500/40">
              <Gift size={28} className="text-white" />
            </div>
            <div>
              <h1 className="font-heading text-2xl lg:text-3xl font-black">متجر المكافآت</h1>
              <p className="text-xs text-muted-foreground mt-0.5">استبدل نقاط الولاء بمكافآت حصرية</p>
            </div>
          </div>
          <div className="bg-card/70 backdrop-blur border border-yellow-500/40 rounded-2xl px-5 py-3 flex items-center gap-3">
            <Star size={20} className="text-yellow-400" fill="currentColor" />
            <div>
              <p className="text-[11px] text-muted-foreground">رصيدك</p>
              <p className="font-black text-2xl text-yellow-400 leading-none">{myPoints.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="flex justify-center py-16"><Loader2 size={28} className="animate-spin text-primary" /></div>
      ) : rewards.length === 0 ? (
        <div className="text-center py-16 bg-card border border-dashed border-border rounded-3xl">
          <Gift size={48} className="mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground">لا توجد مكافآت متاحة حالياً. تابعنا قريباً!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rewards.map((r: any) => {
            const canAfford = myPoints >= r.pointsCost;
            const inStock = r.stock == null || r.stock > 0;
            const disabled = !canAfford || !inStock;
            const progress = Math.min(100, Math.round((myPoints / r.pointsCost) * 100));

            return (
              <motion.div key={r.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                className="relative bg-card border border-border rounded-3xl p-5 overflow-hidden group hover:border-yellow-500/40 transition-all"
                style={{ boxShadow: canAfford ? `0 0 0 1px ${r.accentColor}40` : undefined }}>
                <div className="absolute -top-10 -left-10 w-32 h-32 rounded-full opacity-10 blur-2xl" style={{ background: r.accentColor }} />

                <div className="relative">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl shrink-0"
                      style={{ background: `${r.accentColor}25`, border: `1px solid ${r.accentColor}50` }}>
                      {r.emoji}
                    </div>
                    <div className="text-left">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">السعر</p>
                      <p className="font-black text-xl text-yellow-400 leading-none">{r.pointsCost.toLocaleString()}</p>
                      <p className="text-[10px] text-muted-foreground">نقطة</p>
                    </div>
                  </div>

                  <h3 className="font-heading font-bold text-base mb-1">{r.nameAr}</h3>
                  {r.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{r.description}</p>}

                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    {r.value != null && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-semibold">
                        قيمة ${parseFloat(r.value).toFixed(2)}
                      </span>
                    )}
                    {r.stock != null && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${r.stock > 0 ? 'bg-blue-500/15 text-blue-400' : 'bg-red-500/15 text-red-400'}`}>
                        {r.stock > 0 ? `متبقي ${r.stock}` : 'نفدت الكمية'}
                      </span>
                    )}
                    {r.redeemedCount > 0 && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                        🔥 استُبدلت {r.redeemedCount}× 
                      </span>
                    )}
                  </div>

                  {!canAfford && (
                    <div className="mb-3">
                      <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                        <span>تقدّمك</span>
                        <span className="font-semibold">{progress}%</span>
                      </div>
                      <div className="h-1.5 bg-background rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${progress}%` }}
                          className="h-full bg-gradient-to-r from-yellow-500 to-orange-500" />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1">تحتاج {(r.pointsCost - myPoints).toLocaleString()} نقطة إضافية</p>
                    </div>
                  )}

                  <button disabled={disabled} onClick={() => setConfirming(r)}
                    className={`w-full py-2.5 rounded-xl font-bold text-sm transition-all ${disabled ? 'bg-muted text-muted-foreground cursor-not-allowed' : 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white shadow-lg shadow-yellow-500/30 hover:scale-[1.02]'}`}>
                    {!inStock ? '❌ نفدت الكمية' : !canAfford ? <><Lock size={13} className="inline ml-1" /> نقاط غير كافية</> : <><Gift size={13} className="inline ml-1" /> استبدل الآن</>}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* How to earn more */}
      <div className="bg-card border border-border rounded-2xl p-5">
        <h3 className="font-heading font-bold mb-3 flex items-center gap-2">
          <Coins size={16} className="text-yellow-400" /> كيف أربح نقاط أكثر؟
        </h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2"><Check size={14} className="text-emerald-400 mt-0.5 shrink-0" /> اربح <span className="text-yellow-400 font-bold mx-1">{loyalty?.pointsPerUsdEarned ?? 1} نقطة</span> عن كل $1 تشتريه</li>
          <li className="flex items-start gap-2"><Check size={14} className="text-emerald-400 mt-0.5 shrink-0" /> ارتقِ لـ VIP أعلى للحصول على نقاط مضاعفة (قريباً)</li>
          <li className="flex items-start gap-2"><Check size={14} className="text-emerald-400 mt-0.5 shrink-0" /> تابع منحات الإدارة الموسمية في رمضان والأعياد</li>
        </ul>
        <Link href="/products" className="inline-block mt-4 px-4 py-2 rounded-xl bg-primary/15 text-primary text-sm font-semibold hover:bg-primary/25">
          🛍️ تصفّح المنتجات
        </Link>
      </div>

      {/* Confirm modal */}
      <AnimatePresence>
        {confirming && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => !redeemMut.isPending && setConfirming(null)}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
              onClick={e => e.stopPropagation()}
              className="bg-card border border-border rounded-3xl w-full max-w-sm overflow-hidden">
              <div className="p-6 text-center">
                <div className="w-20 h-20 mx-auto rounded-3xl flex items-center justify-center text-5xl mb-4"
                  style={{ background: `${confirming.accentColor}25`, border: `2px solid ${confirming.accentColor}` }}>
                  {confirming.emoji}
                </div>
                <h3 className="font-heading font-black text-lg mb-1">{confirming.nameAr}</h3>
                {confirming.description && <p className="text-xs text-muted-foreground mb-4">{confirming.description}</p>}

                <div className="bg-background/50 rounded-2xl p-4 my-4">
                  <p className="text-xs text-muted-foreground">سيتم خصم</p>
                  <p className="font-black text-3xl text-yellow-400">{confirming.pointsCost.toLocaleString()} نقطة</p>
                  <p className="text-[11px] text-muted-foreground mt-1">رصيدك بعد الاستبدال: {(myPoints - confirming.pointsCost).toLocaleString()} نقطة</p>
                </div>

                <div className="flex gap-2">
                  <button disabled={redeemMut.isPending} onClick={() => setConfirming(null)}
                    className="flex-1 py-2.5 rounded-xl bg-muted text-muted-foreground font-semibold text-sm">
                    إلغاء
                  </button>
                  <button disabled={redeemMut.isPending} onClick={() => redeemMut.mutate(confirming.id)}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold text-sm disabled:opacity-50">
                    {redeemMut.isPending ? <Loader2 size={14} className="inline animate-spin" /> : '✓ تأكيد'}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function LoyaltyRewards() {
  return (
    <ProtectedRoute>
      <PublicLayout>
        <RewardsContent />
      </PublicLayout>
    </ProtectedRoute>
  );
}
