import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PublicLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Bell, BellOff, Loader2, Trash2, TrendingDown, CheckCircle2, ArrowDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

function api(method: string, path: string, body?: unknown) {
  const token = localStorage.getItem('elite_token');
  return fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

function PriceAlertsContent() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: alerts = [], isLoading } = useQuery<any[]>({
    queryKey: ['price-alerts'],
    queryFn: async () => (await api('GET', '/api/price-alerts')).json(),
  });

  const delMut = useMutation({
    mutationFn: async (id: number) => api('DELETE', `/api/price-alerts/${id}`),
    onSuccess: () => {
      toast({ title: 'تم الحذف' });
      qc.invalidateQueries({ queryKey: ['price-alerts'] });
    },
  });

  const active = alerts.filter(a => a.isActive);
  const triggered = alerts.filter(a => !a.isActive && a.triggeredAt);

  return (
    <div dir="rtl" className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-500/15 via-cyan-500/10 to-emerald-500/15 border border-blue-500/30 rounded-3xl p-5 lg:p-6 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-cyan-500/20 blur-3xl" />
        <div className="relative flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/40">
            <Bell size={26} className="text-white" />
          </div>
          <div>
            <h1 className="font-heading text-2xl lg:text-3xl font-black">تنبيهات الأسعار</h1>
            <p className="text-xs text-muted-foreground mt-0.5">احصل على إشعار فوري عند انخفاض أسعار منتجاتك المفضلة</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-card border border-border rounded-2xl p-4 text-center">
          <p className="text-[10px] text-muted-foreground uppercase">نشطة</p>
          <p className="text-2xl font-black text-blue-400 mt-1">{active.length}</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4 text-center">
          <p className="text-[10px] text-muted-foreground uppercase">تم تفعيلها</p>
          <p className="text-2xl font-black text-emerald-400 mt-1">{triggered.length}</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4 text-center">
          <p className="text-[10px] text-muted-foreground uppercase">الحد الأقصى</p>
          <p className="text-2xl font-black text-muted-foreground mt-1">25</p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><Loader2 size={28} className="animate-spin text-primary" /></div>
      ) : alerts.length === 0 ? (
        <div className="text-center py-16 bg-card border border-dashed border-border rounded-3xl">
          <Bell size={48} className="mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground mb-4">ليس لديك أي تنبيهات سعر بعد</p>
          <Link href="/products" className="inline-block px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm">
            🛍️ تصفّح المنتجات
          </Link>
        </div>
      ) : (
        <>
          {active.length > 0 && (
            <section>
              <h2 className="font-heading font-bold text-sm text-muted-foreground mb-3 flex items-center gap-2">
                <Bell size={14} /> النشطة ({active.length})
              </h2>
              <div className="space-y-3">
                <AnimatePresence>
                  {active.map(a => {
                    const cur = parseFloat(a.currentPriceUsd ?? a.priceWhenCreated);
                    const target = parseFloat(a.targetPriceUsd);
                    const original = parseFloat(a.priceWhenCreated);
                    const distancePct = original > target ? Math.round(((original - cur) / (original - target)) * 100) : 0;
                    const progress = Math.min(100, Math.max(0, distancePct));
                    return (
                      <motion.div key={a.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }}
                        className="bg-card border border-border rounded-2xl p-4 hover:border-blue-500/40 transition-colors">
                        <div className="flex items-start gap-3">
                          {a.productImage ? (
                            <img src={a.productImage} alt="" className="w-14 h-14 rounded-xl object-cover bg-background" />
                          ) : (
                            <div className="w-14 h-14 rounded-xl bg-blue-500/10 flex items-center justify-center text-2xl">🎮</div>
                          )}
                          <div className="flex-1 min-w-0">
                            <Link href={`/products/${encodeURIComponent(a.productId)}`}>
                              <p className="font-bold text-sm truncate hover:text-primary cursor-pointer">{a.productName}</p>
                            </Link>
                            <div className="flex items-center gap-3 mt-1 text-xs">
                              <span className="text-muted-foreground">السعر الآن: <span className="font-bold text-foreground">${cur.toFixed(2)}</span></span>
                              <span className="text-muted-foreground">الهدف: <span className="font-bold text-blue-400">${target.toFixed(2)}</span></span>
                            </div>

                            <div className="mt-2.5">
                              <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                                <span>التقدم</span>
                                <span className="font-bold">{progress}%</span>
                              </div>
                              <div className="h-1.5 bg-background rounded-full overflow-hidden">
                                <motion.div initial={{ width: 0 }} animate={{ width: `${progress}%` }}
                                  className="h-full bg-gradient-to-r from-blue-500 to-cyan-400" />
                              </div>
                            </div>
                          </div>
                          <button onClick={() => delMut.mutate(a.id)} disabled={delMut.isPending}
                            className="shrink-0 p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </section>
          )}

          {triggered.length > 0 && (
            <section>
              <h2 className="font-heading font-bold text-sm text-emerald-400 mb-3 flex items-center gap-2">
                <CheckCircle2 size={14} /> تم تفعيلها 🎉 ({triggered.length})
              </h2>
              <div className="space-y-2">
                {triggered.map(a => {
                  const triggered = parseFloat(a.triggeredPriceUsd ?? '0');
                  const original = parseFloat(a.priceWhenCreated);
                  const savings = original - triggered;
                  return (
                    <motion.div key={a.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                      className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-3 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-500/15 flex items-center justify-center">
                        <ArrowDown size={16} className="text-emerald-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold truncate">{a.productName}</p>
                        <p className="text-[11px] text-muted-foreground">
                          هبط من ${original.toFixed(2)} إلى <span className="text-emerald-400 font-bold">${triggered.toFixed(2)}</span>
                          {savings > 0 && <span className="text-emerald-400"> · وفّرت ${savings.toFixed(2)}</span>}
                        </p>
                      </div>
                      <Link href={`/products/${encodeURIComponent(a.productId)}`}
                        className="text-xs px-3 py-1.5 rounded-lg bg-primary/15 text-primary font-bold hover:bg-primary/25">
                        اشتري الآن
                      </Link>
                      <button onClick={() => delMut.mutate(a.id)} className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400">
                        <Trash2 size={12} />
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            </section>
          )}
        </>
      )}

      <div className="bg-card border border-border rounded-2xl p-4 text-xs text-muted-foreground leading-relaxed">
        💡 <span className="font-bold text-foreground">كيف تعمل التنبيهات؟</span> نحدّث الأسعار من المزوّدين كل 6 ساعات. لما يصل سعر منتجك إلى السعر المستهدف، يصلك إشعار فوري داخل الموقع وتنتهي صلاحية التنبيه (تنبيه واحد لكل منتج).
      </div>
    </div>
  );
}

export default function PriceAlerts() {
  return (
    <ProtectedRoute>
      <PublicLayout>
        <PriceAlertsContent />
      </PublicLayout>
    </ProtectedRoute>
  );
}
