import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useCreatePayment, useGetMyPayments } from '@workspace/api-client-react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/Layout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { useLanguage } from '@/i18n';
import { Loader2, Upload, CheckCircle, X, Image as ImageIcon, Hash, Clock, XCircle, Copy, Check, Wallet, Shield, Zap, HeadphonesIcon, ArrowLeft, ArrowRight, CreditCard, Receipt, Camera } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';

type Currency = 'USD' | 'SYP' | 'EUR';

interface ApiPaymentMethod {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  emoji: string;
  color: string;
  imageUrl: string | null;
  details: { label: string; value: string }[];
  currency: string;
  isActive: boolean;
  sortOrder: number;
}

export default function Deposit() {
  const { lang } = useLanguage();
  const { toast } = useToast();
  const { token } = useAuth();
  const createPayment = useCreatePayment();
  const { data: payments } = useGetMyPayments();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: apiMethods = [], isLoading: methodsLoading } = useQuery<ApiPaymentMethod[]>({
    queryKey: ['payment-methods'],
    queryFn: async () => {
      const res = await fetch('/api/payment-methods');
      if (!res.ok) throw new Error('Failed to load payment methods');
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });

  const [methodSlug, setMethodSlug] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<Currency>('SYP');

  const selectedMethod = apiMethods.find(m => m.slug === methodSlug) ?? apiMethods[0];
  const method = selectedMethod?.slug ?? methodSlug;

  const handleMethodChange = (slug: string) => {
    const m = apiMethods.find(x => x.slug === slug);
    setMethodSlug(slug);
    if (m) setCurrency((m.currency as Currency) ?? 'SYP');
  };

  // Set default method once loaded
  useEffect(() => {
    if (apiMethods.length > 0 && !methodSlug) {
      const first = apiMethods[0];
      setMethodSlug(first.slug);
      setCurrency((first.currency as Currency) ?? 'SYP');
    }
  }, [apiMethods, methodSlug]);
  const [transactionRef, setTransactionRef] = useState('');
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [screenshotName, setScreenshotName] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [submitted, setSubmitted] = useState(false);

  // Clean up preview URL when component unmounts or file changes
  useEffect(() => {
    return () => {
      if (screenshotPreview) URL.revokeObjectURL(screenshotPreview);
    };
  }, [screenshotPreview]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: lang === 'ar' ? 'الملف كبير جداً' : 'File too large', description: lang === 'ar' ? 'يجب أن يكون الملف أقل من 10MB' : 'Maximum file size is 10MB', variant: 'destructive' });
      return;
    }
    if (screenshotPreview) URL.revokeObjectURL(screenshotPreview);
    const preview = URL.createObjectURL(file);
    setScreenshotFile(file);
    setScreenshotPreview(preview);
    setScreenshotName(file.name);
  };

  const clearScreenshot = () => {
    if (screenshotPreview) URL.revokeObjectURL(screenshotPreview);
    setScreenshotFile(null);
    setScreenshotPreview(null);
    setScreenshotName('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0) {
      toast({ title: lang === 'ar' ? 'مبلغ غير صحيح' : 'Invalid amount', description: lang === 'ar' ? 'أدخل مبلغاً صحيحاً' : 'Enter a valid amount', variant: 'destructive' });
      return;
    }
    if (!transactionRef.trim()) {
      toast({ title: lang === 'ar' ? 'رقم العملية مطلوب' : 'Transaction ref required', description: lang === 'ar' ? 'أدخل رقم العملية' : 'Enter the transaction reference', variant: 'destructive' });
      return;
    }
    if (!screenshotFile) {
      toast({ title: lang === 'ar' ? 'الصورة مطلوبة' : 'Screenshot required', description: lang === 'ar' ? 'ارفع صورة إثبات التحويل' : 'Upload a screenshot', variant: 'destructive' });
      return;
    }

    try {
      // Step 1: Upload the file via multipart form data
      setIsUploading(true);
      const formData = new FormData();
      formData.append('screenshot', screenshotFile);

      const uploadRes = await fetch('/api/upload/screenshot', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      if (!uploadRes.ok) {
        const err = await uploadRes.json().catch(() => ({}));
        throw new Error(err?.message ?? (lang === 'ar' ? 'فشل رفع الصورة' : 'Failed to upload screenshot'));
      }

      const { url: screenshotUrl } = await uploadRes.json();
      setIsUploading(false);

      // Step 2: Create the payment record with the uploaded file URL
      await createPayment.mutateAsync({
        data: {
          amount: parseFloat(amount),
          currency,
          method,
          screenshotUrl,
          transactionRef: transactionRef.trim(),
        } as any,
      });

      setSubmitted(true);
    } catch (err: any) {
      setIsUploading(false);
      const msg = err?.message ?? err?.data?.message ?? (lang === 'ar' ? 'فشل إرسال الطلب' : 'Failed to submit');
      toast({ title: lang === 'ar' ? 'خطأ' : 'Error', description: msg, variant: 'destructive' });
    }
  };

  const isPending = isUploading || createPayment.isPending;

  if (submitted) {
    return (
      <ProtectedRoute>
        <DashboardLayout>
          <div className="flex items-center justify-center min-h-[60vh]">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-sm" dir="rtl">
              <div className="w-20 h-20 rounded-full bg-green-500/15 border border-green-500/30 flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={36} className="text-green-400" />
              </div>
              <h2 className="font-heading text-xl font-bold mb-2">{lang === 'ar' ? 'تم إرسال الطلب' : 'Request Submitted'}</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {lang === 'ar'
                  ? 'تم إرسال طلب شحن رصيدك بنجاح. سيتم مراجعته من قبل الإدارة وإضافة الرصيد خلال فترة قصيرة.'
                  : 'Your deposit request has been submitted. Our team will verify it and add the balance shortly.'}
              </p>
              <button onClick={() => { setSubmitted(false); setStep(1); setAmount(''); setTransactionRef(''); clearScreenshot(); }}
                className="mt-6 px-5 py-2.5 bg-primary text-white text-sm font-semibold rounded-xl hover:bg-primary/90 transition-colors">
                {lang === 'ar' ? 'شحن مرة أخرى' : 'New Deposit'}
              </button>
            </motion.div>
          </div>
        </DashboardLayout>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-xl mx-auto space-y-5 px-3 sm:px-0 pb-8" dir="rtl">

          {/* Hero Header Card */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative overflow-hidden rounded-3xl border border-primary/30 p-5 sm:p-6"
            style={{
              background: 'linear-gradient(135deg, rgba(108,92,231,0.18), rgba(108,92,231,0.04) 60%, rgba(34,197,94,0.06))',
            }}
          >
            <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full bg-primary/20 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-12 -right-8 w-44 h-44 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
            <div className="relative flex items-start gap-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-primary/20 border border-primary/40 flex items-center justify-center shrink-0">
                <Wallet size={22} className="text-primary" />
              </div>
              <div className="min-w-0">
                <h1 className="font-heading text-xl sm:text-2xl font-bold leading-tight">
                  {lang === 'ar' ? 'شحن رصيد المحفظة' : 'Top Up Wallet'}
                </h1>
                <p className="text-muted-foreground text-xs sm:text-sm mt-1 leading-relaxed">
                  {lang === 'ar' ? 'اختر طريقة الدفع وأكمل التحويل بـ 3 خطوات سريعة' : 'Choose a method and finish in 3 quick steps'}
                </p>
              </div>
            </div>

            {/* Trust badges row */}
            <div className="relative grid grid-cols-3 gap-2 mt-4">
              {[
                { icon: Shield, color: '#22c55e', labelAr: 'آمن 100%', labelEn: 'Secure' },
                { icon: Zap, color: '#f59e0b', labelAr: 'مراجعة سريعة', labelEn: 'Fast Review' },
                { icon: HeadphonesIcon, color: '#6366f1', labelAr: 'دعم 24/7', labelEn: '24/7 Support' },
              ].map(({ icon: Icon, color, labelAr, labelEn }) => (
                <div
                  key={labelEn}
                  className="flex flex-col items-center gap-1 px-2 py-2 rounded-xl bg-background/50 border border-border/60 backdrop-blur"
                >
                  <Icon size={16} style={{ color }} strokeWidth={2.2} />
                  <span className="text-[10px] sm:text-xs font-bold text-foreground/90 leading-tight text-center">
                    {lang === 'ar' ? labelAr : labelEn}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Step Indicator — circles with connector */}
          <div className="flex items-center justify-between gap-1 px-1">
            {[
              { num: 1, icon: CreditCard, labelAr: 'الطريقة', labelEn: 'Method' },
              { num: 2, icon: Receipt, labelAr: 'المبلغ', labelEn: 'Amount' },
              { num: 3, icon: Camera, labelAr: 'الإثبات', labelEn: 'Proof' },
            ].map(({ num, icon: Icon, labelAr, labelEn }, i, arr) => {
              const done = step > num;
              const active = step === num;
              return (
                <React.Fragment key={num}>
                  <button
                    type="button"
                    onClick={() => { if (num < step || done) setStep(num as 1|2|3); }}
                    className="flex flex-col items-center gap-1.5 shrink-0"
                  >
                    <div
                      className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-xs font-bold transition-all border-2 ${
                        active
                          ? 'bg-primary text-white border-primary shadow-lg shadow-primary/40 scale-110'
                          : done
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50'
                          : 'bg-card text-muted-foreground border-border'
                      }`}
                    >
                      {done ? <Check size={16} /> : <Icon size={15} />}
                    </div>
                    <span className={`text-[10px] sm:text-xs font-semibold transition-colors ${active ? 'text-primary' : done ? 'text-emerald-400' : 'text-muted-foreground'}`}>
                      {lang === 'ar' ? labelAr : labelEn}
                    </span>
                  </button>
                  {i < arr.length - 1 && (
                    <div className="flex-1 h-0.5 mb-5 rounded-full transition-colors" style={{ background: step > num ? 'rgb(34 197 94 / 0.5)' : 'rgb(var(--border) / 0.6)' }} />
                  )}
                </React.Fragment>
              );
            })}
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Step 1: Choose Payment Method */}
            {step === 1 && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                <div className="text-center">
                  <h2 className="font-heading font-bold text-lg">{lang === 'ar' ? 'اختر طريقة الشحن' : 'Select Payment Method'}</h2>
                  <p className="text-xs text-muted-foreground mt-1">{lang === 'ar' ? 'إدخال كود الشحن' : 'Enter charge code'}</p>
                </div>
                {methodsLoading ? (
                  <div className="py-8 flex justify-center"><Loader2 size={24} className="animate-spin text-primary" /></div>
                ) : (
                <div className="grid grid-cols-3 gap-3">
                  {apiMethods.map((info, idx) => {
                    const selected = method === info.slug;
                    return (
                      <motion.button
                        key={info.slug}
                        type="button"
                        onClick={() => handleMethodChange(info.slug)}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.04 }}
                        whileTap={{ scale: 0.95 }}
                        className="relative flex flex-col items-center gap-2 p-3 rounded-2xl transition-all overflow-hidden"
                        style={{
                          background: selected
                            ? `linear-gradient(145deg, ${info.color}33, ${info.color}18)`
                            : 'linear-gradient(145deg, #1a1a2e, #16213e)',
                          border: selected ? `2px solid ${info.color}` : '2px solid #2a2a40',
                          boxShadow: selected ? `0 0 20px ${info.color}30` : '0 4px 12px rgba(0,0,0,0.4)',
                        }}
                      >
                        <div className="absolute top-1 left-1"><span className="text-yellow-400/60 text-[8px]">★</span></div>
                        <div className="absolute top-1 right-1"><span className="text-yellow-400/60 text-[8px]">★</span></div>

                        {selected && (
                          <div className="absolute top-2 left-2 w-4 h-4 rounded-full flex items-center justify-center z-10"
                            style={{ background: info.color }}>
                            <CheckCircle size={10} className="text-white" />
                          </div>
                        )}

                        <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl relative"
                          style={{
                            background: `radial-gradient(circle at 35% 35%, ${info.color}40, ${info.color}10)`,
                            border: `1px solid ${info.color}40`,
                          }}>
                          {info.imageUrl ? (
                            <img src={info.imageUrl} alt="" className="w-10 h-10 object-contain rounded-xl" />
                          ) : (
                            <span>{info.emoji}</span>
                          )}
                        </div>

                        <span className="text-[10px] font-bold text-center leading-tight text-white/90">
                          {lang === 'ar' ? info.nameAr : info.nameEn}
                        </span>

                        <span className="text-[9px] px-2 py-0.5 rounded-full font-semibold"
                          style={{ background: '#f59e0b20', color: '#f59e0b', border: '1px solid #f59e0b40' }}>
                          {lang === 'ar' ? 'يدوي' : 'Manual'}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>
                )}
                <button type="button" onClick={() => setStep(2)}
                  className="w-full py-3 bg-primary text-white font-semibold rounded-xl hover:bg-primary/90 transition-colors shadow-xl shadow-primary/30">
                  {lang === 'ar' ? 'التالي' : 'Continue'}
                </button>
              </motion.div>
            )}

            {/* Step 2: Payment Details + Amount */}
            {step === 2 && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                <h2 className="font-heading font-bold">{lang === 'ar' ? 'تفاصيل التحويل' : 'Transfer Details'}</h2>

                <div className="bg-card border-2 rounded-2xl p-5 space-y-3" style={{ borderColor: selectedMethod?.color ?? '#6366f1' }}>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-2xl">
                      {selectedMethod?.imageUrl ? (
                        <img src={selectedMethod.imageUrl} alt="" className="w-8 h-8 object-contain rounded-lg" />
                      ) : selectedMethod?.emoji}
                    </span>
                    <span className="font-bold">{lang === 'ar' ? selectedMethod?.nameAr : selectedMethod?.nameEn}</span>
                    <span className="mr-auto text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{ background: '#f59e0b22', color: '#f59e0b' }}>
                      {lang === 'ar' ? 'يدوي' : 'Manual'}
                    </span>
                  </div>
                  {(selectedMethod?.details ?? []).map((d, i) => {
                    const isCopyable = d.value.length > 10 && !d.value.includes(' ');
                    return (
                      <div key={i} className="flex justify-between items-center text-sm p-2 bg-background rounded-xl gap-2">
                        <span className="text-muted-foreground shrink-0">{d.label}</span>
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="font-mono font-bold text-white select-all truncate">{d.value}</span>
                          {isCopyable && (
                            <button
                              type="button"
                              onClick={() => { navigator.clipboard.writeText(d.value); toast({ title: lang === 'ar' ? 'تم النسخ!' : 'Copied!' }); }}
                              className="shrink-0 p-1 rounded-lg hover:bg-primary/20 text-muted-foreground hover:text-primary transition-colors"
                            >
                              <Copy size={13} />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <p className="text-xs text-muted-foreground pt-1">
                    {lang === 'ar' ? '⚠️ تأكد من نسخ المعلومات بشكل صحيح قبل التحويل' : '⚠️ Copy the details carefully before transferring'}
                  </p>
                </div>

                <div className="space-y-3">
                  <label className="block text-sm font-medium">{lang === 'ar' ? 'المبلغ' : 'Amount'}</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={amount}
                      onChange={e => setAmount(e.target.value)}
                      required min="1"
                      placeholder="0.00"
                      className="flex-1 px-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors"
                    />
                    <div className="px-3 py-2.5 bg-card border border-border rounded-xl text-sm font-bold text-muted-foreground">
                      {selectedMethod?.currency === 'USD' ? 'USD $' : selectedMethod?.currency === 'USDT' ? 'USDT' : 'SYP ل.س'}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button type="button" onClick={() => setStep(1)}
                    className="flex-1 py-3 bg-card border border-border text-sm font-semibold rounded-xl hover:bg-background transition-colors">
                    {lang === 'ar' ? 'رجوع' : 'Back'}
                  </button>
                  <button type="button" onClick={() => setStep(3)} disabled={!amount || parseFloat(amount) <= 0}
                    className="flex-1 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50 shadow-xl shadow-primary/30">
                    {lang === 'ar' ? 'التالي' : 'Continue'}
                  </button>
                </div>
              </motion.div>
            )}

            {/* Step 3: Transaction Proof */}
            {step === 3 && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                <h2 className="font-heading font-bold">{lang === 'ar' ? 'إثبات التحويل' : 'Transfer Proof'}</h2>
                <p className="text-muted-foreground text-sm">
                  {lang === 'ar' ? 'أدخل رقم العملية وارفع صورة إثبات التحويل لمراجعتها من الإدارة' : 'Enter the transaction number and upload a screenshot for admin review'}
                </p>

                {/* Transaction Reference */}
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-sm font-medium">
                    <Hash size={15} className="text-primary" />
                    {lang === 'ar' ? 'رقم العملية / Transaction ID' : 'Transaction Reference'}
                  </label>
                  <input
                    type="text"
                    value={transactionRef}
                    onChange={e => setTransactionRef(e.target.value)}
                    placeholder={lang === 'ar' ? 'مثال: TXN123456789' : 'e.g. TXN123456789'}
                    className="w-full px-4 py-3 bg-card border border-border rounded-xl text-sm focus:outline-none focus:border-primary/50 transition-colors font-mono"
                    required
                  />
                </div>

                {/* Screenshot Upload */}
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-sm font-medium">
                    <ImageIcon size={15} className="text-primary" />
                    {lang === 'ar' ? 'صورة إثبات التحويل' : 'Transfer Screenshot'}
                  </label>
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />

                  {screenshotPreview ? (
                    <div className="relative rounded-2xl overflow-hidden border-2 border-primary/40 bg-card">
                      <img src={screenshotPreview} alt="screenshot" className="w-full h-48 object-cover" />
                      <button
                        type="button"
                        onClick={clearScreenshot}
                        className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center hover:bg-black/80 transition-colors"
                      >
                        <X size={14} className="text-white" />
                      </button>
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-3 py-2">
                        <p className="text-white text-xs truncate">{screenshotName}</p>
                      </div>
                    </div>
                  ) : (
                    <button type="button" onClick={() => fileInputRef.current?.click()}
                      className="w-full border-2 border-dashed border-border rounded-2xl p-8 text-center hover:border-primary/40 transition-colors flex flex-col items-center gap-3">
                      <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                        <Upload size={24} className="text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{lang === 'ar' ? 'اضغط لرفع الصورة' : 'Click to upload'}</p>
                        <p className="text-xs text-muted-foreground mt-1">{lang === 'ar' ? 'JPG، PNG، حتى 10MB' : 'JPG, PNG, up to 10MB'}</p>
                      </div>
                    </button>
                  )}
                </div>

                {/* Summary */}
                <div className="bg-card border border-border rounded-xl p-4 text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{lang === 'ar' ? 'طريقة الدفع' : 'Method'}</span>
                    <span className="font-medium">{lang === 'ar' ? selectedMethod.nameAr : selectedMethod.nameEn}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{lang === 'ar' ? 'المبلغ' : 'Amount'}</span>
                    <span className="font-medium">{currency} {amount}</span>
                  </div>
                  {transactionRef && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{lang === 'ar' ? 'رقم العملية' : 'Ref'}</span>
                      <span className="font-mono text-xs text-primary">{transactionRef}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <button type="button" onClick={() => setStep(2)}
                    className="flex-1 py-3 bg-card border border-border text-sm font-semibold rounded-xl hover:bg-background transition-colors">
                    {lang === 'ar' ? 'رجوع' : 'Back'}
                  </button>
                  <button type="submit" disabled={isPending || !transactionRef || !screenshotFile}
                    className="flex-1 py-3 flex items-center justify-center gap-2 bg-primary text-white font-semibold rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50 shadow-xl shadow-primary/30">
                    {isPending ? <Loader2 size={18} className="animate-spin" /> : null}
                    {isUploading
                      ? (lang === 'ar' ? 'جاري رفع الصورة...' : 'Uploading...')
                      : createPayment.isPending
                      ? (lang === 'ar' ? 'جاري الإرسال...' : 'Submitting...')
                      : (lang === 'ar' ? 'إرسال الطلب' : 'Submit Request')}
                  </button>
                </div>
              </motion.div>
            )}
          </form>

          <div className="bg-card border border-border rounded-3xl overflow-hidden shadow-sm">
            <div className="p-4 sm:p-5 border-b border-border bg-gradient-to-l from-primary/5 to-transparent">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
                  <Receipt size={16} className="text-primary" />
                </div>
                <div className="min-w-0">
                  <h2 className="font-heading font-bold text-base">{lang === 'ar' ? 'سجل طلبات الشحن' : 'Deposit History'}</h2>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    {lang === 'ar' ? 'تابع حالة طلباتك السابقة' : 'Track your previous deposit requests'}
                  </p>
                </div>
              </div>
            </div>
            {!payments || payments.length === 0 ? (
              <div className="py-12 text-center px-4">
                <div className="w-14 h-14 rounded-2xl bg-muted/50 border border-border flex items-center justify-center mx-auto mb-3">
                  <Receipt size={22} className="text-muted-foreground/40" />
                </div>
                <p className="text-sm text-muted-foreground">
                  {lang === 'ar' ? 'لا يوجد طلبات إيداع بعد' : 'No deposit requests yet'}
                </p>
                <p className="text-[11px] text-muted-foreground/70 mt-1">
                  {lang === 'ar' ? 'ابدأ شحن أول رصيد لك بالأعلى' : 'Make your first deposit above'}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {payments.slice(0, 5).map((payment: any) => {
                  const isApproved = payment.status === 'approved';
                  const isRejected = payment.status === 'rejected';
                  const statusConfig = isApproved
                    ? { icon: CheckCircle, color: '#22c55e', bg: 'rgba(34,197,94,0.12)', border: 'rgba(34,197,94,0.4)', labelAr: 'تمت الموافقة', labelEn: 'Approved' }
                    : isRejected
                    ? { icon: XCircle, color: '#ef4444', bg: 'rgba(239,68,68,0.12)', border: 'rgba(239,68,68,0.4)', labelAr: 'مرفوض', labelEn: 'Rejected' }
                    : { icon: Clock, color: '#f59e0b', bg: 'rgba(245,158,11,0.12)', border: 'rgba(245,158,11,0.4)', labelAr: 'قيد المراجعة', labelEn: 'Pending' };
                  const StatusIcon = statusConfig.icon;
                  const date = payment.createdAt ? new Date(payment.createdAt) : null;
                  return (
                    <motion.div
                      key={payment.id}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3.5 sm:p-4 flex items-center gap-3 hover:bg-muted/30 transition-colors"
                    >
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border"
                        style={{ background: statusConfig.bg, borderColor: statusConfig.border }}
                      >
                        <StatusIcon size={18} style={{ color: statusConfig.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-bold truncate">
                            {Number(payment.amount).toLocaleString('en-US')} <span className="text-xs text-muted-foreground font-normal">{payment.currency}</span>
                          </p>
                          <span
                            className="text-[10px] font-bold px-2 py-0.5 rounded-full border whitespace-nowrap"
                            style={{ color: statusConfig.color, borderColor: statusConfig.border, background: statusConfig.bg }}
                          >
                            {lang === 'ar' ? statusConfig.labelAr : statusConfig.labelEn}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mt-0.5 flex-wrap">
                          <span className="capitalize">{payment.method}</span>
                          <span className="text-muted-foreground/40">•</span>
                          <span className="font-mono">#{payment.id}</span>
                          {date && (
                            <>
                              <span className="text-muted-foreground/40">•</span>
                              <span>{date.toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-GB')}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
