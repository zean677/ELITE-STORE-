import React, { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { Crown, Trophy, Medal, ArrowLeft, Loader2, Lock } from 'lucide-react';
import { PublicLayout } from '@/components/Layout';
import { useLanguage } from '@/i18n';
import { useAuth } from '@/hooks/use-auth';
import { VIP_TIERS } from '@/components/VipBadge';

interface Leader {
  rank: number;
  username: string;
  vipLevel: number;
  totalSpentUsd: number;
}

const RANK_ICONS = [
  <Trophy size={18} className="text-yellow-300" key="1" />,
  <Medal size={18} className="text-slate-300" key="2" />,
  <Medal size={18} className="text-amber-600" key="3" />,
];

const TIER_COLORS: Record<number, { from: string; to: string; label: string }> = {
  1: { from: '#f59e0b', to: '#eab308', label: 'VIP 1' },
  2: { from: '#38bdf8', to: '#22d3ee', label: 'VIP 2' },
  3: { from: '#d946ef', to: '#f472b6', label: 'VIP 3' },
  4: { from: '#7c3aed', to: '#facc15', label: 'VIP 4' },
};

export default function VipLeaderboard() {
  const { lang } = useLanguage();
  const { user } = useAuth();
  const [data, setData] = useState<{ enabled: boolean; leaders: Leader[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const ar = lang === 'ar';

  useEffect(() => {
    fetch('/api/vip-leaderboard')
      .then(r => r.json())
      .then(d => setData(d))
      .catch(() => setData({ enabled: false, leaders: [] }))
      .finally(() => setLoading(false));
  }, []);

  return (
    <PublicLayout>
      <div className="min-h-screen py-6 px-4 max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link href="/profile" className="p-2 rounded-xl hover:bg-muted transition-colors">
            <ArrowLeft size={18} className={ar ? 'rotate-180' : ''} />
          </Link>
          <div>
            <h1 className="font-heading text-xl font-black flex items-center gap-2">
              <Crown size={20} className="text-yellow-400" fill="currentColor" />
              {ar ? 'لوحة صدارة VIP' : 'VIP Leaderboard'}
            </h1>
            <p className="text-xs text-muted-foreground">{ar ? 'أفضل عملاء المتجر' : 'Top store customers'}</p>
          </div>
        </div>

        {loading && (
          <div className="flex justify-center py-16">
            <Loader2 size={28} className="animate-spin text-amber-400" />
          </div>
        )}

        {!loading && !data?.enabled && (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center">
              <Lock size={24} className="text-muted-foreground" />
            </div>
            <div>
              <p className="font-bold text-foreground">{ar ? 'لوحة الصدارة غير متاحة' : 'Leaderboard Not Available'}</p>
              <p className="text-sm text-muted-foreground mt-1">{ar ? 'هذه الميزة معطّلة حالياً' : 'This feature is currently disabled'}</p>
            </div>
          </div>
        )}

        {!loading && data?.enabled && data.leaders.length === 0 && (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <Crown size={40} className="text-muted-foreground" />
            <p className="text-muted-foreground">{ar ? 'لا يوجد VIP حتى الآن' : 'No VIP members yet'}</p>
          </div>
        )}

        {!loading && data?.enabled && data.leaders.length > 0 && (
          <div className="space-y-3">
            {/* Top 3 podium */}
            {data.leaders.slice(0, 3).length >= 1 && (
              <div className="flex items-end justify-center gap-3 mb-6 pt-2">
                {/* 2nd place */}
                {data.leaders[1] && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                    className="flex flex-col items-center gap-2 flex-1">
                    <div className="w-12 h-12 rounded-full border-2 border-slate-400/50 bg-slate-500/20 flex items-center justify-center">
                      <span className="text-lg font-black text-slate-300">{data.leaders[1].username[0].toUpperCase()}</span>
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-bold truncate">{data.leaders[1].username}</p>
                      <VipLevelBadge level={data.leaders[1].vipLevel} />
                    </div>
                    <div className="w-full h-16 rounded-t-xl flex items-center justify-center" style={{ background: 'linear-gradient(180deg, rgba(148,163,184,0.2), rgba(148,163,184,0.08))' }}>
                      <Medal size={20} className="text-slate-400" />
                    </div>
                  </motion.div>
                )}
                {/* 1st place */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col items-center gap-2 flex-1">
                  <div className="w-16 h-16 rounded-full border-2 border-yellow-400/60 flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, rgba(245,158,11,0.3), rgba(234,179,8,0.2))' }}>
                    <span className="text-xl font-black text-yellow-300">{data.leaders[0].username[0].toUpperCase()}</span>
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-bold truncate">{data.leaders[0].username}</p>
                    <VipLevelBadge level={data.leaders[0].vipLevel} />
                  </div>
                  <div className="w-full h-24 rounded-t-xl flex items-center justify-center" style={{ background: 'linear-gradient(180deg, rgba(245,158,11,0.25), rgba(245,158,11,0.08))' }}>
                    <Trophy size={22} className="text-yellow-300" />
                  </div>
                </motion.div>
                {/* 3rd place */}
                {data.leaders[2] && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                    className="flex flex-col items-center gap-2 flex-1">
                    <div className="w-12 h-12 rounded-full border-2 border-amber-700/50 bg-amber-800/20 flex items-center justify-center">
                      <span className="text-lg font-black text-amber-600">{data.leaders[2].username[0].toUpperCase()}</span>
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-bold truncate">{data.leaders[2].username}</p>
                      <VipLevelBadge level={data.leaders[2].vipLevel} />
                    </div>
                    <div className="w-full h-12 rounded-t-xl flex items-center justify-center" style={{ background: 'linear-gradient(180deg, rgba(180,83,9,0.2), rgba(180,83,9,0.08))' }}>
                      <Medal size={20} className="text-amber-600" />
                    </div>
                  </motion.div>
                )}
              </div>
            )}

            {/* Full ranked list */}
            {data.leaders.map((leader, i) => {
              const tc = TIER_COLORS[leader.vipLevel];
              const isMe = user && leader.username.startsWith((user as any).username?.slice(0, 2) ?? '##');
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-colors ${isMe ? 'bg-amber-500/10 border-amber-500/30' : 'bg-card border-border hover:border-border/80'}`}
                >
                  <div className="w-7 h-7 flex items-center justify-center flex-shrink-0">
                    {i < 3 ? RANK_ICONS[i] : <span className="text-xs font-black text-muted-foreground">#{i + 1}</span>}
                  </div>
                  <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: `linear-gradient(135deg, ${tc?.from ?? '#6b7280'}, ${tc?.to ?? '#9ca3af'})` }}>
                    <span className="text-sm font-black text-white">{leader.username[0].toUpperCase()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold truncate">{leader.username} {isMe && <span className="text-amber-400">(أنت)</span>}</p>
                    <p className="text-xs text-muted-foreground">${leader.totalSpentUsd.toLocaleString()} {ar ? 'مُنفَق' : 'spent'}</p>
                  </div>
                  <VipLevelBadge level={leader.vipLevel} />
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Disclaimer */}
        <p className="text-[11px] text-muted-foreground text-center mt-6">
          {ar ? 'الأسماء مخفية جزئياً للخصوصية' : 'Usernames are partially masked for privacy'}
        </p>
      </div>
    </PublicLayout>
  );
}

function VipLevelBadge({ level }: { level: number }) {
  const tier = VIP_TIERS.find(t => t.level === level);
  if (!tier) return null;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black text-slate-900 bg-gradient-to-r ${tier.from} ${tier.to}`}>
      <Crown size={9} fill="currentColor" /> VIP {level}
    </span>
  );
}
