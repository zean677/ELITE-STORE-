import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';

export interface CartItem {
  cartId: string;
  productId: string;
  name: string;
  nameAr?: string;
  image?: string;
  description?: string;
  category?: string;
  priceUsd: string;
  qty: number;
  playerId?: string;
  formValues: Record<string, string>;
  giftEmail?: string;
  promoCodeId?: string;
  promoCode?: string;
  addedAt: number;
}

interface CartContextValue {
  items: CartItem[];
  count: number;
  totalUsd: number;
  addItem: (item: Omit<CartItem, 'cartId' | 'addedAt'>) => void;
  removeItem: (cartId: string) => void;
  updateQty: (cartId: string, qty: number) => void;
  clear: () => void;
  hasItem: (productId: string) => boolean;
}

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = 'elite_cart_v1';

function loadCart(): CartItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(loadCart);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {}
  }, [items]);

  // Cross-tab sync
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) setItems(loadCart());
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const addItem = useCallback((item: Omit<CartItem, 'cartId' | 'addedAt'>) => {
    setItems(prev => {
      // If exact same product+playerId+formValues, merge qty
      const existing = prev.find(i =>
        i.productId === item.productId &&
        i.playerId === item.playerId &&
        JSON.stringify(i.formValues) === JSON.stringify(item.formValues)
      );
      if (existing) {
        return prev.map(i => i.cartId === existing.cartId ? { ...i, qty: i.qty + item.qty } : i);
      }
      const cartId = `${item.productId}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      return [...prev, { ...item, cartId, addedAt: Date.now() }];
    });
  }, []);

  const removeItem = useCallback((cartId: string) => {
    setItems(prev => prev.filter(i => i.cartId !== cartId));
  }, []);

  const updateQty = useCallback((cartId: string, qty: number) => {
    if (qty < 1) return;
    setItems(prev => prev.map(i => i.cartId === cartId ? { ...i, qty } : i));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const hasItem = useCallback((productId: string) => items.some(i => i.productId === productId), [items]);

  const value = useMemo<CartContextValue>(() => {
    const totalUsd = items.reduce((sum, i) => sum + (parseFloat(i.priceUsd || '0') * i.qty), 0);
    const count = items.reduce((sum, i) => sum + i.qty, 0);
    return { items, count, totalUsd, addItem, removeItem, updateQty, clear, hasItem };
  }, [items, addItem, removeItem, updateQty, clear, hasItem]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
