import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useGetMe, User } from '@workspace/api-client-react';
import { setAuthTokenGetter } from '@workspace/api-client-react/src/custom-fetch';

// Install the token getter synchronously at module load so that the very first
// /me request on page refresh always includes the Authorization header.
// (Doing this inside a useEffect was racy — the request could fire before the
// effect ran, producing a spurious 401 and a forced logout on refresh.)
setAuthTokenGetter(() => {
  try {
    return typeof localStorage !== 'undefined' ? localStorage.getItem('elite_token') : null;
  } catch {
    return null;
  }
});

function extractStatus(err: any): number | undefined {
  if (!err) return undefined;
  return (
    err.status ??
    err.statusCode ??
    err.response?.status ??
    err.cause?.status ??
    err.code
  );
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (token: string, user: User) => void;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setTokenState] = useState<string | null>(localStorage.getItem('elite_token'));
  const [user, setUser] = useState<User | null>(null);

  const { data: userData, isError, error, isFetched } = useGetMe({
    query: ({
      enabled: !!token,
      retry: (failureCount: number, err: any) => {
        // Don't retry on 401 (real auth error). Retry up to 2x on network/5xx.
        if (extractStatus(err) === 401) return false;
        return failureCount < 2;
      },
      retryDelay: (i: number) => Math.min(1000 * 2 ** i, 4000),
      staleTime: 5 * 60 * 1000,
      refetchOnWindowFocus: false,
    } as any),
  });

  useEffect(() => {
    if (userData) {
      setUser(userData);
    }
    // Only clear token on confirmed 401 Unauthorized — not on network errors,
    // server restarts, timeouts, or 5xx (which would log the user out unfairly).
    if (isError && extractStatus(error) === 401) {
      setTokenState(null);
      setUser(null);
      localStorage.removeItem('elite_token');
    }
  }, [userData, isError, error]);

  // Auth is "resolved" when there's no token, OR we've fetched (success/failure).
  const authResolved = !token || isFetched;

  const login = (newToken: string, newUser: User) => {
    localStorage.setItem('elite_token', newToken);
    localStorage.setItem('elite_login_at', Date.now().toString());
    setTokenState(newToken);
    setUser(newUser);
  };

  const logout = () => {
    localStorage.removeItem('elite_token');
    localStorage.removeItem('elite_login_at');
    setTokenState(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading: !!token && !authResolved }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
