import { useQuery } from '@tanstack/react-query';
import { useAuth } from './use-auth';

interface LoyaltyData {
  points: number;
  pointsPerUsdEarned: number;
  pointsPerUsdRedeemed: number;
  minRedeem: number;
}

export function useLoyaltyPoints() {
  const { user, token } = useAuth();
  return useQuery<LoyaltyData | null>({
    queryKey: ['loyalty-points', user?.id],
    enabled: !!user && !!token,
    refetchInterval: 30000,
    queryFn: async () => {
      const r = await fetch('/api/loyalty', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return null;
      return r.json();
    },
  });
}
