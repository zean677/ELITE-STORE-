import { useEffect, useRef, useState, useCallback } from 'react';
import { useAuth } from './use-auth';
import { useToast } from './use-toast';
import { useQueryClient } from '@tanstack/react-query';

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

export type AdminWsEvent = {
  type:
    | 'connected'
    | 'pong'
    | 'new_order'
    | 'order_completed'
    | 'order_failed'
    | 'new_user'
    | 'new_payment'
    | 'payment_approved'
    | 'stats_update'
    | 'ping';
  data: Record<string, any>;
  ts: number;
};

export type AdminNotificationItem = {
  id: string;
  type: AdminWsEvent['type'];
  title: string;
  body: string;
  ts: number;
  read: boolean;
  href?: string;
};

const MAX_ITEMS = 30;
const STORAGE_KEY = 'elite_admin_notifications';

function loadStored(): AdminNotificationItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.slice(0, MAX_ITEMS);
  } catch {
    return [];
  }
}

function saveStored(items: AdminNotificationItem[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, MAX_ITEMS)));
  } catch {}
}

const SOUND_PREF_KEY = 'elite_admin_sound_enabled';
const DESKTOP_PREF_KEY = 'elite_admin_desktop_enabled';

export function isAdminSoundEnabled() {
  try { return localStorage.getItem(SOUND_PREF_KEY) !== '0'; } catch { return true; }
}
export function setAdminSoundEnabled(on: boolean) {
  try { localStorage.setItem(SOUND_PREF_KEY, on ? '1' : '0'); } catch {}
}
export function isAdminDesktopEnabled() {
  try { return localStorage.getItem(DESKTOP_PREF_KEY) !== '0'; } catch { return true; }
}
export function setAdminDesktopEnabled(on: boolean) {
  try { localStorage.setItem(DESKTOP_PREF_KEY, on ? '1' : '0'); } catch {}
}

export async function ensureNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'denied';
  if (Notification.permission === 'default') {
    try { return await Notification.requestPermission(); } catch { return 'denied'; }
  }
  return Notification.permission;
}

function playBeep(opts?: { urgent?: boolean }) {
  if (!isAdminSoundEnabled()) return;
  try {
    const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const playTone = (start: number, freqStart: number, freqEnd: number, dur = 0.22, gain = 0.22) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type = 'sine';
      o.frequency.setValueAtTime(freqStart, ctx.currentTime + start);
      o.frequency.exponentialRampToValueAtTime(freqEnd, ctx.currentTime + start + dur * 0.6);
      g.gain.setValueAtTime(0.0001, ctx.currentTime + start);
      g.gain.exponentialRampToValueAtTime(gain, ctx.currentTime + start + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
      o.start(ctx.currentTime + start);
      o.stop(ctx.currentTime + start + dur + 0.02);
    };
    if (opts?.urgent) {
      // Two-tone alert chime — louder, two beeps
      playTone(0, 880, 1320, 0.22, 0.28);
      playTone(0.28, 1100, 1500, 0.22, 0.28);
      playTone(0.6, 880, 1320, 0.22, 0.28);
    } else {
      playTone(0, 880, 1320, 0.22, 0.18);
    }
  } catch {}
}

function showDesktopNotification(item: AdminNotificationItem) {
  if (!isAdminDesktopEnabled()) return;
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;
  // Only show when tab is hidden / window not focused, otherwise toast is enough
  if (typeof document !== 'undefined' && document.visibilityState === 'visible' && document.hasFocus()) return;
  try {
    const n = new Notification(item.title, {
      body: item.body,
      icon: `${BASE}/icon-192.png`,
      badge: `${BASE}/icon-192.png`,
      tag: item.type,
      requireInteraction: item.type === 'new_order' || item.type === 'new_payment',
    });
    n.onclick = () => {
      window.focus();
      if (item.href) window.location.href = `${BASE}${item.href}`;
      n.close();
    };
  } catch {}
}

const ORIGINAL_TITLE = typeof document !== 'undefined' ? document.title : '';
let titleFlashTimer: number | null = null;
function flashTitle(text: string) {
  if (typeof document === 'undefined') return;
  if (document.visibilityState === 'visible') return;
  let toggle = false;
  if (titleFlashTimer) window.clearInterval(titleFlashTimer);
  titleFlashTimer = window.setInterval(() => {
    document.title = toggle ? ORIGINAL_TITLE : text;
    toggle = !toggle;
  }, 1000) as unknown as number;
  const stop = () => {
    if (titleFlashTimer) window.clearInterval(titleFlashTimer);
    titleFlashTimer = null;
    document.title = ORIGINAL_TITLE;
    document.removeEventListener('visibilitychange', onVis);
    window.removeEventListener('focus', stop);
  };
  const onVis = () => { if (document.visibilityState === 'visible') stop(); };
  document.addEventListener('visibilitychange', onVis);
  window.addEventListener('focus', stop);
}

function eventToItem(ev: AdminWsEvent): AdminNotificationItem | null {
  const id = `${ev.type}_${ev.data?.id ?? ev.data?.orderId ?? ev.ts}_${ev.ts}`;
  const num = (v: any) => Number(v ?? 0).toLocaleString('en-US');
  switch (ev.type) {
    case 'new_order':
      return {
        id,
        type: ev.type,
        title: '🛒 طلب جديد',
        body: `${ev.data.username ?? '—'} طلب: ${ev.data.productName ?? '—'} • $${num(ev.data.totalPrice)}`,
        ts: ev.ts,
        read: false,
        href: '/admin/orders',
      };
    case 'order_completed':
      return {
        id,
        type: ev.type,
        title: '✅ طلب مكتمل',
        body: `${ev.data.productName ?? '—'} (${ev.data.username ?? '—'})`,
        ts: ev.ts,
        read: false,
        href: '/admin/orders',
      };
    case 'order_failed':
      return {
        id,
        type: ev.type,
        title: '❌ فشل تنفيذ طلب',
        body: `${ev.data.productName ?? '—'} (${ev.data.username ?? '—'})`,
        ts: ev.ts,
        read: false,
        href: '/admin/orders',
      };
    case 'new_payment':
      return {
        id,
        type: ev.type,
        title: '💳 طلب شحن جديد',
        body: `${ev.data.username ?? '—'} • ${num(ev.data.amount)} ${ev.data.currency ?? ''} • ${ev.data.method ?? ''}`,
        ts: ev.ts,
        read: false,
        href: '/admin/payments',
      };
    case 'payment_approved':
      return {
        id,
        type: ev.type,
        title: '✅ موافقة على شحن',
        body: `${ev.data.username ?? '—'} • ${num(ev.data.amount)} ${ev.data.currency ?? ''}`,
        ts: ev.ts,
        read: false,
        href: '/admin/payments',
      };
    case 'new_user':
      return {
        id,
        type: ev.type,
        title: '👤 مستخدم جديد',
        body: `${ev.data.username ?? '—'} (${ev.data.email ?? ''})`,
        ts: ev.ts,
        read: false,
        href: '/admin/users',
      };
    default:
      return null;
  }
}

let singletonState: {
  items: AdminNotificationItem[];
  status: 'idle' | 'connecting' | 'connected' | 'disconnected';
  listeners: Set<() => void>;
  ws: WebSocket | null;
  reconnectTimer: number | null;
  attempts: number;
} | null = null;

function getState() {
  if (!singletonState) {
    singletonState = {
      items: loadStored(),
      status: 'idle',
      listeners: new Set(),
      ws: null,
      reconnectTimer: null,
      attempts: 0,
    };
  }
  return singletonState;
}

function emitChange() {
  const s = getState();
  s.listeners.forEach(cb => cb());
}

function pushItem(item: AdminNotificationItem) {
  const s = getState();
  s.items = [item, ...s.items].slice(0, MAX_ITEMS);
  saveStored(s.items);
  emitChange();
}

export function useAdminWs(opts?: { enabled?: boolean }) {
  const enabled = opts?.enabled !== false;
  const { user, token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const isAdmin = user?.role === 'admin';
  const [, force] = useState(0);
  const lastTokenRef = useRef<string | null>(null);

  const subscribe = useCallback(() => {
    const s = getState();
    const cb = () => force(x => x + 1);
    s.listeners.add(cb);
    return () => { s.listeners.delete(cb); };
  }, []);

  useEffect(() => subscribe(), [subscribe]);

  useEffect(() => {
    if (!enabled || !isAdmin || !token) return;
    if (lastTokenRef.current === token && getState().ws) return;
    lastTokenRef.current = token;

    const s = getState();

    const connect = () => {
      if (s.ws && (s.ws.readyState === WebSocket.OPEN || s.ws.readyState === WebSocket.CONNECTING)) return;
      try {
        const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host;
        // /api/ws goes through the existing /api proxy (Vite dev) and the artifact proxy (prod)
        const path = `${BASE}/api/ws?token=${encodeURIComponent(token)}`;
        const url = `${proto}//${host}${path}`;
        s.status = 'connecting';
        emitChange();
        const ws = new WebSocket(url);
        s.ws = ws;

        ws.onopen = () => {
          s.status = 'connected';
          s.attempts = 0;
          emitChange();
        };

        ws.onmessage = (ev) => {
          try {
            const parsed: AdminWsEvent = JSON.parse(ev.data);
            if (parsed.type === 'connected' || parsed.type === 'pong' || parsed.type === 'ping') return;

            const item = eventToItem(parsed);
            if (item) {
              pushItem(item);
              const urgent = parsed.type === 'new_order' || parsed.type === 'new_payment';
              playBeep({ urgent });
              showDesktopNotification(item);
              flashTitle(`🔔 ${item.title}`);
              toast({ title: item.title, description: item.body });
            }

            // Smart cache invalidation so admin pages refresh instantly
            if (parsed.type === 'new_order' || parsed.type === 'order_completed' || parsed.type === 'order_failed') {
              qc.invalidateQueries({ queryKey: ['admin', 'orders'] });
              qc.invalidateQueries({ queryKey: ['admin', 'stats'] });
            }
            if (parsed.type === 'new_payment' || parsed.type === 'payment_approved') {
              qc.invalidateQueries({ queryKey: ['admin', 'payments'] });
              qc.invalidateQueries({ queryKey: ['admin', 'stats'] });
            }
            if (parsed.type === 'new_user') {
              qc.invalidateQueries({ queryKey: ['admin', 'users'] });
              qc.invalidateQueries({ queryKey: ['admin', 'stats'] });
            }
          } catch {}
        };

        ws.onclose = () => {
          s.status = 'disconnected';
          s.ws = null;
          emitChange();
          if (!enabled || !isAdmin) return;
          s.attempts = Math.min(s.attempts + 1, 6);
          const delay = Math.min(2000 * 2 ** (s.attempts - 1), 30000);
          if (s.reconnectTimer) window.clearTimeout(s.reconnectTimer);
          s.reconnectTimer = window.setTimeout(connect, delay) as unknown as number;
        };

        ws.onerror = () => {
          // onclose will follow, no double-handling
        };
      } catch {
        s.status = 'disconnected';
        emitChange();
      }
    };

    connect();

    return () => {
      // Don't disconnect on every unmount — singleton keeps connection alive across navigation
    };
  }, [enabled, isAdmin, token, toast, qc]);

  const s = getState();
  const items = s.items;
  const unread = items.filter(i => !i.read).length;

  const markAllRead = useCallback(() => {
    const st = getState();
    st.items = st.items.map(i => ({ ...i, read: true }));
    saveStored(st.items);
    emitChange();
  }, []);

  const clear = useCallback(() => {
    const st = getState();
    st.items = [];
    saveStored(st.items);
    emitChange();
  }, []);

  return {
    items,
    unread,
    status: s.status,
    markAllRead,
    clear,
  };
}
