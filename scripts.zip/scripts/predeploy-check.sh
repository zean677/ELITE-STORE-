#!/usr/bin/env bash
# Pre-deploy build & type check for Elite Store.
# Run BEFORE deploying to catch JSX/TS/build errors early.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "==> [1/4] pnpm install --frozen-lockfile"
pnpm install --frozen-lockfile --prefer-offline

echo "==> [2/4] Type-check shared lib(s)"
pnpm -r --filter "./lib/**" run build || true

echo "==> [3/4] Build API server (artifacts/api-server)"
pnpm --filter @workspace/api-server run build

echo "==> [4/4] Build frontend (artifacts/elite-store)"
pnpm --filter @workspace/elite-store run build

echo ""
echo "✅ Pre-deploy check passed. Safe to deploy."
