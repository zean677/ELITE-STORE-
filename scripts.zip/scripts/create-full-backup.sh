#!/usr/bin/env bash
# Create a full project archive: source code + uploads + DB dump.
# Output: backups/elite-store-full-<timestamp>.tar.gz
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

TS="$(date +%Y%m%d-%H%M%S)"
OUT_DIR="$ROOT/backups"
STAGE="$ROOT/.backup-stage-$TS"
mkdir -p "$OUT_DIR" "$STAGE"

echo "==> [1/3] Dumping database"
if [ -n "${DATABASE_URL:-}" ]; then
  pg_dump --no-owner --no-acl --clean --if-exists "$DATABASE_URL" \
    > "$STAGE/database.sql" 2> "$STAGE/db-dump.log" || {
    echo "⚠️  pg_dump failed — see db-dump.log"; cat "$STAGE/db-dump.log";
  }
else
  echo "⚠️  DATABASE_URL not set — skipping DB dump"
fi

echo "==> [2/3] Archiving source + uploads + images (skipping node_modules/dist/caches)"
ARCHIVE="$OUT_DIR/elite-store-full-$TS.tar.gz"
tar -czf "$ARCHIVE" \
  --exclude='node_modules' \
  --exclude='dist' \
  --exclude='.next' \
  --exclude='.turbo' \
  --exclude='.cache' \
  --exclude='.pnpm-store' \
  --exclude='backups' \
  --exclude='.backup-stage-*' \
  --exclude='.git' \
  --exclude='.local' \
  --exclude='.agents' \
  --exclude='*.log' \
  -C "$ROOT" \
  $(ls -A "$ROOT" | grep -vE '^(node_modules|backups|\.git|\.local|\.agents|\.backup-stage-.*)$') \
  -C "$STAGE" $( [ -f "$STAGE/database.sql" ] && echo database.sql )

echo "==> [3/3] Finalizing"
SIZE="$(du -h "$ARCHIVE" | cut -f1)"
rm -rf "$STAGE"

echo ""
echo "✅ Backup ready: $ARCHIVE ($SIZE)"
echo "   Includes: project source, uploads/images, public assets, DB dump."
