#!/bin/bash
##############################################################
# Elite Store — Automatic Database Backup Script
# Usage: bash scripts/backup-db.sh
# Cron (daily at 3 AM): 0 3 * * * /path/to/scripts/backup-db.sh
##############################################################

set -euo pipefail

# ── Configuration ─────────────────────────────────────────────
BACKUP_DIR="${BACKUP_DIR:-/var/backups/elite-store}"
KEEP_DAYS="${KEEP_DAYS:-14}"               # Keep last 14 days
DATABASE_URL="${DATABASE_URL:?DATABASE_URL not set}"

# Parse connection info from DATABASE_URL
# Format: postgres://user:pass@host:port/dbname
DB_NAME=$(echo "$DATABASE_URL" | sed 's|.*\/||' | sed 's|?.*||')
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
FILENAME="elite-store-${DB_NAME}-${TIMESTAMP}.sql.gz"
FILEPATH="${BACKUP_DIR}/${FILENAME}"

# ── Create backup directory ────────────────────────────────────
mkdir -p "$BACKUP_DIR"

echo "[$(date)] Starting backup: $FILENAME"

# ── Run pg_dump via DATABASE_URL ───────────────────────────────
pg_dump "$DATABASE_URL" \
  --no-owner \
  --no-acl \
  --format=plain \
  | gzip -9 > "$FILEPATH"

SIZE=$(du -sh "$FILEPATH" | cut -f1)
echo "[$(date)] Backup complete: $FILEPATH ($SIZE)"

# ── Remove old backups ────────────────────────────────────────
find "$BACKUP_DIR" -name "elite-store-*.sql.gz" -mtime "+${KEEP_DAYS}" -delete
echo "[$(date)] Old backups cleaned (kept last ${KEEP_DAYS} days)"

# ── Optional: send Telegram notification ──────────────────────
if [ -n "${TELEGRAM_BOT_TOKEN:-}" ] && [ -n "${TELEGRAM_ADMIN_CHAT_ID:-}" ]; then
  MSG="✅ *Elite Store Backup*%0A📦 File: \`${FILENAME}\`%0A📏 Size: ${SIZE}%0A🕐 Time: $(date)"
  curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -d "chat_id=${TELEGRAM_ADMIN_CHAT_ID}" \
    -d "text=${MSG}" \
    -d "parse_mode=Markdown" > /dev/null
fi

echo "[$(date)] Done."
